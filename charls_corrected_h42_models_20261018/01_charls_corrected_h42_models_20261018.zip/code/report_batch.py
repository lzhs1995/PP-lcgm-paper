"""从独立核验过的完整家族生成研究报告；未完成家族保留原状态。"""
from pathlib import Path
import collections, csv, datetime, hashlib, json, math

R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert (R/'runtime/MODELS_TERMINAL').exists(), 'Wait for original coordinator terminal'
verification=read(R/'audit/POOL_INDEPENDENT_EDU_URBAN.json')
assert verification['status']=='PASS'
contract=read(R/'contracts/RUN_CONTRACT.json')
pool=R/'results/pool_EDU_URBAN'
with (pool/'H42_REGISTERED.csv').open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
calls=read(R/'results/CALL_RESULTS.json')
complete=[r for r in rows if r['family'] in verification['complete_families']]
assert len(rows)==8 and len(complete)==len(verification['complete_families'])
def num(x):
    try: v=float(x)
    except (ValueError,TypeError):return '—'
    return f'{v:.4f}' if math.isfinite(v) else '—'
def interval(r):return f'[{num(r["lower"])}, {num(r["upper"])}]' if num(r['estimate'])!='—' else '—'
text=[
 '# CHARLS修正来源：教育与城乡的H4.2工作插补分析',
 '',
 '**四项调节完整推断、完整 H4 仍未完成。** 本批是CHARLS观测基期关系结构与教育/城乡的三重交互敏感性分析，不能替代CFPS潜在初始状态路线，也不包括尚待独立验收的收入四家族。',
 '',
 f'本批登记8个家族，每家族目标20份；完成并经独立复算的家族为{len(complete)}个。实际引擎调用{len(calls)}次。既有H4.1结果、原始数据及冻结论文均未修改。',
 '',
 '## 全部登记家族',
 '',
 '| 家族 | 原始状态 | 已完成成员/目标 | 组间调节差 dcg | 95%工作MI区间 | 原始P | 固定12项Holm |',
 '|---|---|---:|---:|---|---:|---:|']
for r in rows:
    text.append(f'| {r["family"]} | {r["status"]} | {r["members"]}/{r["m"]} | {num(r["estimate"])} | {interval(r)} | {num(r["p"])} | {num(r["Holm_12"])} |')
text += ['', '未完成家族不填零、不合并零散成功成员，也不作“效应不存在”的判定。完整家族仍需按区间与精度解释；组间差异检验直接使用dcg，不比较两组星号。',
 '', '## 模型、来源与推断边界', '',
 '模型保持0、2、4、7、9年载荷、11列基期控制、社区MLR、同期X/Y残差关联及完整低阶项，估计SX×Z、SX×G、SX×ZG→SY。没有为了取得显著结果新增零方差限制。CHARLS见面频率与CFPS情感亲近度是相邻但不同的构念；SD为绝对离散，其他差异指标保留其方向。',
 '',
 '源数据为已独立验收的80份ADL工作插补。插补包含观测波次、Z及教育/城乡的相关乘积辅助项，保留原观测及X/Y的FIML缺失掩码；工作插补不证明MAR或与潜在交互模型精确相容。完整20份均可采用后，使用参数及TECH3协方差作Rubin合并；另保存G=0、G=1的调节、直接组差、共同支持范围内的条件斜率和有限社区自由度敏感性。',
 '',
 '多重检验范围预先冻结为四项差异×三类资源的12项。当前只完成其中教育/城乡批次；校正不缩减为有结果或显著的子集。收入结果到齐后需按相同12项范围统一更新校正，不改变各家族原始估计。',
 '', '## 运行与停止记录', '',
 f'单次清醒引擎时间上限{contract["per_call_seconds"]}秒，整批最多{contract["max_calls"]}次、{contract["total_engine_seconds"]}清醒引擎秒；单个自有Mplus槽位。实际调用状态：'+', '.join(f'{k}={v}' for k,v in sorted(collections.Counter(c['status'] for c in calls.values()).items()))+'。',
 '',
 '超时、非法解、未启动和完整可用家族分别保留。INPUT READING TERMINATED NORMALLY只说明输入读取，不表示模型估计已完成。耗时记录包括引擎启动及I/O，不凭超时单独诊断不可识别、无效应或内存不足。',
 '', '## 独立复核与下一步', '',
 '独立验证器直接读取完整家族的原始保存参数、TECH1与TECH3，核对数据/输入/输出哈希、实际样本、双起点、参数方差和协方差、Rubin合并、组间差与条件斜率及12项校正。失败家族保留输入、失败输出、预算和状态，不替换失败成员。',
 '',
 '本批不修改已收尾稿件，也不新增NLM审阅。收入40链完成、混合与逐成员检查通过后才准入其模型。CFPS既有失败规格不原样重跑。',
 '',
 '相关已发布四类观测基期动态家族：https://github.com/lzhs1995/PP-lcgm-paper/tree/f6e7c9448d5f0fd14e4b8e7b33bc8c07ebcfcca0/charls_corrected_dynamic_mi_models_20261018', '']
report=R/'reports/REPORT.md'
assert not report.exists(), 'Preserve prior report; inspect before making a revision'
report.write_text('\n'.join(text),encoding='utf-8')
receipt=dict(status='REPORT_FROM_VERIFIED_POOLS',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    complete_families=len(complete),registered=8,calls=len(calls),report_sha256=hashlib.sha256(report.read_bytes()).hexdigest(),
    original_four_complete=False,full_H4_complete=False,new_Mplus_calls=0)
(R/'audit/REPORT.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))
