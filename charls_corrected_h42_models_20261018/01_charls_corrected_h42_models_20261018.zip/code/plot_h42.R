# 基于已合并保存结果画区间，未完成范围不填零；不调用任何估计器。
plot_h42<-function(phase='EDU_URBAN'){
 root<-file.path('<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_h42_models_20261018/results',paste0('pool_',phase))
 d<-read.csv(file.path(root,'H42_REGISTERED.csv'));v<-d[is.finite(d$estimate),];stopifnot(nrow(v)>0)
 draw<-function(){
  old<-par(mar=c(6,11,4,2));on.exit(par(old));y<-rev(seq_len(nrow(v)));xr<-range(c(v$lower,v$upper,0));pad<-diff(xr)*.08
  plot(v$estimate,y,xlim=xr+c(-pad,pad),ylim=c(.5,nrow(v)+.5),yaxt='n',ylab='',xlab='Direct group difference in moderation (dcg), 95% MI interval',pch=19,main='CHARLS H4.2: working-imputation sensitivity')
  axis(2,at=y,labels=paste(v$family,'  m =',v$m),las=1,cex.axis=.85);abline(v=0,lty=2,col='gray50');segments(v$lower,y,v$upper,y,lwd=2);points(v$estimate,y,pch=19)
  mtext('Fixed multiplicity family: 12; incomplete families are not plotted. Not full CFPS H4.',side=1,line=4.8,cex=.7)
 }
 pdf(file.path(root,'H42_GROUP_DIFFERENCES.pdf'),width=10,height=6);draw();dev.off()
 png(file.path(root,'H42_GROUP_DIFFERENCES.png'),width=1800,height=1080,res=180);draw();dev.off()
 cat('H42_FIGURE_SAVED',nrow(v),'complete families\n')
}
