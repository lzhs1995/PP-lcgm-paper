# 复用合法起点，完整家族检验；本批只准一个自有Mplus槽位。
local({
 ROOT<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_h42_models_20261018'
 Sys.setenv(OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1,MKL_NUM_THREADS=1)
 library(jsonlite);library(ps);library(processx)
 source(file.path(ROOT,'code/models.R'),local=TRUE)
 stopifnot(file.exists(file.path(contract$dependency_models,'runtime/MODELS_TERMINAL')))
 stopifnot(!file.exists(file.path(contract$dependency_models,'runtime/engine.lock')))
 old<-rj(file.path(contract$dependency_models,'runtime/OWNER.json'))$owner
 alive<-tryCatch(ps_is_running(ps_handle(old$pid,old$created)),error=function(e)FALSE)
 stopifnot(!alive,!file.exists(file.path(ROOT,'runtime/OWNER.json')))
 host<-rj(file.path(ROOT,'audit/HOST_ADMISSION.json'));stopifnot(isTRUE(host$admitted))
 stamp<-as.POSIXct(substr(host$utc,1,19),format='%Y-%m-%dT%H:%M:%S',tz='UTC')
 # 启动协调R需要额外空间；引擎的1.2GiB准入门槛另行保留。
 stopifnot(host$available_GiB>=1.4,as.numeric(difftime(Sys.time(),stamp,units='secs'))>=0,as.numeric(difftime(Sys.time(),stamp,units='secs'))<120)
 ps_set_cpu_affinity(ps_handle(),unlist(host$selected_cores))
 op<-file.path(ROOT,'runtime/OWNER.json');wj(list(owner=list(pid=Sys.getpid(),created=as.numeric(ps_create_time(ps_handle())))),op)
 aw<-file.path(ROOT,'runtime/awake_MODELS');a<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/windows_awake_guard.py'),'--owner-file',op,'--output',aw,'--interval','5'),stdout=file.path(ROOT,'runtime/awake.log'),stderr='2>&1',cleanup=FALSE)
 on.exit({if(dir.exists(aw))writeLines('release',file.path(aw,'stop.request'));a$wait(8000L)},add=TRUE)
 states<-rj(file.path(ROOT,'results/FAMILY_STATUS.json'));calls<-rj(file.path(ROOT,'results/CALL_RESULTS.json'));if(is.null(calls))calls<-list()
 begun<-Sys.time()
 for(f in names(states)){
  st<-states[[f]];if(st$status!='REGISTERED_NOT_STARTED')next
  seqs<-c(list(list(type='E0',k=1L,start='A'),list(type='E1',k=1L,start='A'),list(type='E1',k=1L,start='B')),lapply(2:st$m,function(k)list(type='E1',k=k,start='A')))
  for(q in seqs){
   if(as.numeric(difftime(Sys.time(),begun,units='secs'))>contract$wall_seconds-contract$per_call_seconds){st$status<-'BATCH_WALL_LIMIT';break}
   j<-prepare(f,q$type,q$k,q$start);r<-run(j);calls[[j$id]]<-r;wj(calls,file.path(ROOT,'results/CALL_RESULTS.json'))
   if(r$status=='NOT_RUN_RESOURCE_OR_BUDGET'){st$status<-if(identical(r$detail$status,'RESOURCE_HOLD'))'RESOURCE_DEFERRED'else'BUDGET_NOT_RUN';break}
   if(r$status!='USABLE_SINGLE_DATASET'){st$status<-paste('MEMBER_FAILED',j$id,r$status,sep=':');break}
   if(q$type=='E1'&&q$start=='A')st$members<-q$k
   if(q$type=='E1'&&q$start=='B'&&!isTRUE(compare_starts(f)$passed)){st$status<-'STARTS_DISAGREE';break}
   st$status<-if(st$members==st$m)'FULL_FAMILY_PENDING_POOLING'else'RUNNING'
   states[[f]]<-st;wj(states,file.path(ROOT,'results/FAMILY_STATUS.json'))
  }
  states[[f]]<-st;wj(states,file.path(ROOT,'results/FAMILY_STATUS.json'))
  clauder_progress('corrected_H42_family_terminal',paste(f,st$status,st$members))
 }
 source(file.path(ROOT,'code/pool_h42.R'),local=TRUE);pool_h42('EDU_URBAN')
 writeLines('COMPLETE',file.path(ROOT,'runtime/MODELS_TERMINAL'))
 clauder_progress('corrected_H42_terminal','Eight registered working-MI families adjudicated; income and original full H4 remain separate')
 cat('CORRECTED_H42_MODELS_NATIVE_TERMINAL\n')
})
