# 当前原生R后台只读验收，使用独立原始参数解析；零Mplus调用。
local({
 root<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_h42_models_20261018';library(jsonlite);library(ps)
 d<-file.path(root,'audit/base_R_verification');stopifnot(!file.exists(file.path(d,'OWNER.json')))
 h<-fromJSON(file.path(d,'ADMISSION.json'));age<-as.numeric(difftime(Sys.time(),as.POSIXct(substr(h$utc,1,19),format='%Y-%m-%dT%H:%M:%S',tz='UTC'),units='secs'))
 stopifnot(h$admitted,is.finite(age),age>=0,age<120)
 write_json(list(pid=Sys.getpid(),created=as.numeric(ps_create_time(ps_handle()))),file.path(d,'OWNER.json'),auto_unbox=TRUE,digits=16)
 clauder_progress('BASE_R_VERIFY_BEGIN','Read saved native parameters; zero Mplus calls')
 result<-tryCatch({source(file.path(root,'verification/verify_pooled_base.R'),local=TRUE);verify_pooled_base(root);list(status='PASS')},error=function(e)list(status='FAILED',error=conditionMessage(e)))
 result$utc<-format(Sys.time(),tz='UTC');write_json(result,file.path(d,'TERMINAL.json'),auto_unbox=TRUE,pretty=TRUE)
 if(result$status!='PASS')stop(result$error)
 cat('BASE_R_VERIFICATION_NATIVE_TERMINAL\n')
})
