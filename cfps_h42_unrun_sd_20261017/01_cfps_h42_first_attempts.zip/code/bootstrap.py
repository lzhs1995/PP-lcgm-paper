"""只准备尚未运行的两个登记H4.2规格；不重跑历史失败模型。"""
from pathlib import Path
import datetime, hashlib, json, shutil
R=Path(__file__).resolve().parents[1]
P=R.parent/'reopen_observed_charls_20261015'
S=R.parent/'charls_adjusted_h41_20261015'
E=R.parent/'charls_h42_mi_20261017'
for name in ('audit','contracts','models','results','runtime','reports'):(R/name).mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={name:P/'code'/name for name in ('r2e_local.R','r2e_tools.R','r2e_upstream_math.R')}
sources.update({name:E/'code'/name for name in ('engine.py','run_one.R')})
sources['windows_awake_guard.py']=Path('<LOCAL_USER>/Desktop/cnm/tasks/01_R_analysis/work/mplusautomation_reopen_20261015/skills/mplusautomation-guide/scripts/windows_awake_guard.py')
manifest=[]
for name,src in sources.items():
 dst=R/'code'/name
 if dst.exists():assert sha(dst)==sha(src)
 else:shutil.copy2(src,dst)
 manifest.append(dict(file=name,source=str(src),sha256=sha(src)))
existing=[str(p) for p in R.parent.glob('*/models/CFPS*H42*') if R not in p.parents]
assert not any('H42_URBAN' in p or 'H42_INC' in p for p in existing),existing
families=json.loads((S/'results/H41_FAMILIES.json').read_text(encoding='utf-8-sig'))
parents=[]
for group in ('URBAN','INC'):
 f=families[group];assert len(f['members'])==10
 for member,row in f['members'].items():
  d=Path(row['source_dir']);assert row['status']=='USABLE'
  assert sha(d/'model.out')==row['output_sha256']
  j=json.loads((d/'job.json').read_text(encoding='utf-8-sig'))
  for name,h in j['hashes'].items():assert sha(d/name)==h
  parents.append(dict(group=group,member=member,source=str(d),output_sha256=sha(d/'model.out'),data_sha256=sha(d/'data.dat')))
contract={
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'authorization':'Persistent user authorization to complete registered H4; no unchanged failed CFPS specification rerun',
 'scope':'First attempts only: registered CFPS SD H4.2 URBAN and positive-personal-income groups, MI01 each',
 'new_basis':'Both corresponding H4.1 families have ten legal saved members; these H4.2 group specifications have no prior attempt in current study roots',
 'scientific_change_from_parent':'Add SX*Z0, SX*G and SX*(Z0G) to SY, retaining all lower-order terms, original scale, sample, controls and data',
 'starting_values':'High-precision same-group same-member H4.1 parent; only three new interaction coefficients initialized at zero; no fixed residual variance',
 'groups':['URBAN','INC'],'max_calls':2,'total_engine_seconds':480,
 'category_seconds':{'CFPS_H42_FIRST':480},'per_call_seconds':240,
 'engine_slots':1,'processors':1,'integration_points':30,
 'resource_admission_revision':{'owned_engine_slots':1,'max_external_mplus_at_admission':2,'minimum_available_gib':1,'minimum_commit_available_gib':2,'max_host_cpu_percent':85,'resource_wait_seconds':120,'foreign_processes_never_modified':True},
 'stops':['Two first attempts maximum','No EDU retry','No budget/algorithm/variance escalation','No full MI or pooling from a single member','No p-value admission'],
 'full_family_next_gate':'Only a legal MI01 can justify a separately bounded second-start and missing-member continuation; no forecast of other members',
 'compatibility':'Frozen CFPS covariate FCS, not proven compatible with all latent interactions; first attempts are feasibility only',
 'full_H4_complete':False,'manuscript_changed':False,'preregistration_claim':False}
target=R/'contracts/RUN_CONTRACT.json'
assert not target.exists(),'Do not replace a frozen contract'
target.write_text(json.dumps(contract,ensure_ascii=False,indent=2),encoding='utf-8')
(R/'audit/SOURCE_ADMISSION.json').write_text(json.dumps(dict(existing_H42=existing,parents=parents,reused_code=manifest),ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(status='PREPARED',parent_members=len(parents),new_first_specs=2,previous_failed_specs_repeated=0)))
