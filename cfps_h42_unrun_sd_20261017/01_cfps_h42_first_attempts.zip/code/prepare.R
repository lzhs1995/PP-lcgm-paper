# 隔离准备两项从未执行的登记模型。仅在原生后台R中运行，不改前台对象。
ROOT <- '<LOCAL_USER>/pp_lgcm_review/cfps_h42_unrun_sd_20261017'
Sys.setenv(R2E_ROOT=ROOT)
source(file.path(ROOT,'code/r2e_local.R'),local=TRUE)
library(MplusAutomation)
parents <- rj(file.path(ROOT,'audit/SOURCE_ADMISSION.json'))$parents
splice_check <- function(spliced,si) {
 missing<-setdiff(stmt_pairs(si$model),stmt_pairs(spliced))
 txt<-gsub('[*@]\\s*[+-]?(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)(?:[eE][+-]?[0-9]+)?',' ',tolower(spliced),perl=TRUE)
 txt<-gsub('\\([^)]*\\)',' ',txt)
 tok<-unique(unlist(regmatches(txt,gregexpr('[a-z][a-z0-9_]*',txt))))
 xw<-tolower(sub('^\\s*([A-Za-z0-9_]+)\\s*\\|.*$','\\1',grep('XWITH',spliced,value=TRUE,ignore.case=TRUE)))
 foreign<-setdiff(tok,c(tolower(expand_vars(unlist(strsplit(si$use,'\\s+')))),tolower(si$fac),xw,'on','with','by','xwith'))
 list(ok=!length(missing)&&!length(foreign),missing=missing,foreign=foreign)
}
jobs<-list()
for(g in c('URBAN','INC')){
 progress('PREPARING_NEW_SPEC',g)
 p<-Filter(function(x)x$group==g&&x$member=='MI01',parents)[[1]]
 si<-spec_info_r2e('SD',paste0('H4_',g),'c1-c24')
 d<-file.path(ROOT,'models',paste0('CFPS_SD_H42_',g,'_MI01'))
 stopifnot(!file.exists(file.path(d,'job.json')),!file.exists(file.path(d,'model.inp')));dir.create(d,showWarnings=FALSE)
 mm<-make_model(si,p$source);sc<-splice_check(mm$lines,si);stopifnot(isTRUE(sc$ok))
 new<-mm$mapping[mm$mapping$action=='new_start',]
 stopifnot(setequal(new$key,c('ON:SY:SXZ','ON:SY:SXG','ON:SY:SXZG')),all(new$value==0))
 stopifnot(!length(si$fixed_zero),!any(grepl('sy@0',mm$lines,fixed=TRUE)))
 dd<-read_dat(file.path(p$source,'data.dat'),R2D_NAMES)
 a<-dd[c('z0',if(g=='INC')'ginc',paste0('c',1:24))];a$zg<-dd$z0*dd[[si$g]]
 mat<-cbind(1,as.matrix(a));stopifnot(!anyNA(mat),qr(mat)$rank==ncol(mat),setequal(unique(dd[[si$g]]),c(0,1)))
 wj(list(rows=nrow(mat),columns=ncol(mat),rank=qr(mat)$rank,group=g,G_variable=si$g,counts=as.data.frame(table(dd[[si$g]])),input_sha256=hashf(file.path(p$source,'data.dat')),parent_output_sha256=hashf(file.path(p$source,'model.out'))),file.path(d,'design.json'))
 analysis<-c(analysis_r2e('lms_observed',points=30),'LOGCRITERION=0.00001; RLOGCRITERION=0.000000001; MCONVERGENCE=0.00001;')
 lines<-inp_text(basename(d),si$use,wrap90(analysis),mm$lines,define=si$define,kind='lms')
 writeLines(lines,file.path(d,'model.inp'));stopifnot(file.copy(file.path(p$source,'data.dat'),file.path(d,'data.dat'),overwrite=FALSE))
 stopifnot(hashf(file.path(d,'data.dat'))==p$data_sha256)
 csv(mm$mapping,file.path(d,'start_mapping.csv'));wj(sc,file.path(d,'splice_check.json'))
 j<-list(id=basename(d),root=ROOT,dest=d,spec=paste0('H4_',g),group=g,member=1,category='CFPS_H42_FIRST',cap_seconds=240,rscript=file.path(R.home('bin'),'Rscript.exe'),mplus=MPLUS,parent=p,hashes=list(model.inp=hashf(file.path(d,'model.inp')),data.dat=hashf(file.path(d,'data.dat'))))
 wj(j,file.path(d,'job.json'));jobs[[g]]<-j
}
wj(jobs,file.path(ROOT,'contracts/JOBS.json'))
writeLines(capture.output(sessionInfo()),file.path(ROOT,'audit/R_SESSION_INFO.txt'))
progress('PREPARED','Two new H4.2 inputs; same-parent data and full lower-order paths; zero engine calls')
cat('CFPS_H42_PREPARE_NATIVE_TERMINAL\n')
