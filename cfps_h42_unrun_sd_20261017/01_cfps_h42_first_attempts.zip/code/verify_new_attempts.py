"""独立从原始参数、TECH1/TECH3确认两项首次尝试的真实状态。"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
from pathlib import Path
import hashlib,json,sys
from raw_parameter_reader import raw_model
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
public='--public' in sys.argv
rows=[]
for d in sorted((R/'models').iterdir()):
 if not d.is_dir():continue
 rec=read(d/'receipt.json');engine=read(d/'engine_receipt.json');job=read(d/'job.json')
 if not public:
  for n,h in job['hashes'].items():assert sha(d/n)==h
  assert sha(Path(job['parent']['source'])/'model.out')==job['parent']['output_sha256']
  assert sha(d/'model.out')==rec['output_sha256']==engine['output_sha256']
 row=dict(id=d.name,group=rec['group'],status=rec['status'],engine_seconds=engine['seconds'],peak_tree_rss=engine['peak_tree_rss'],sampled_tree_cpu_seconds=engine['sampled_tree_cpu_seconds'])
 if engine['status']=='EXITED':
  out,mapping,q,se,v,paths,ll=raw_model(d)
  sy={x[3] for x in mapping if x[:3]==('PSI','SY','SY')};assert len(sy)==1
  i=next(iter(sy))-1
  assert abs(q[i]-rec['SY'])<1e-10
  row.update(normal='THE MODEL ESTIMATION TERMINATED NORMALLY' in out,SY_residual_variance=float(q[i]),SY_SE=float(se[i]),n_parameters=len(q))
  assert row['normal']
  if rec['status']=='INADMISSIBLE_SY_ONLY':
   assert q[i]<0 and 'THE LATENT VARIABLE COVARIANCE MATRIX (PSI) IS NOT POSITIVE' in out
  elif rec['status']=='USABLE':assert q[i]>0 and read(d/'validation.json')['passed']
  else:raise AssertionError('Review unanticipated statistical state: '+str(rec))
 elif engine['status']=='TIMEOUT':
  row.update(normal=False,SY_residual_variance=None,SY_SE=None,n_parameters=None)
 else:raise AssertionError('Review unanticipated engine state: '+str(engine))
 rows.append(row)
assert {r['group'] for r in rows}=={'URBAN','INC'}
terminal=read(R/'audit/BATCH_TERMINAL.json');assert terminal['new_calls']==2 and terminal['complete_MI_families']==0
result=dict(status='PASS',scope='Two first attempts only; no full-family inference',models=rows,original_four_complete=False,full_H4_complete=False,new_estimation_calls=0,public_mode=public)
(R/'audit/INDEPENDENT_ATTEMPTS.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
