# 两个登记H4.2规格的首次有界尝试；失败不重跑，单份结果不合并。
ROOT<-'<LOCAL_USER>/pp_lgcm_review/cfps_h42_unrun_sd_20261017'
.libPaths(c('<LOCAL_USER>/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
Sys.setenv(R2E_ROOT=ROOT,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
source(file.path(ROOT,'code/r2e_local.R'),local=TRUE)
library(MplusAutomation);library(ps)
safe_progress<-function(stage,message){
 tryCatch(progress(stage,message),error=function(e){cat('Progress publication deferred:',conditionMessage(e),'\n');flush.console()})
}
main<-function(){
 h<-ps::ps_handle();owner<-list(pid=Sys.getpid(),created=as.numeric(ps::ps_create_time(h)))
 wj(list(owner=owner),file.path(ROOT,'runtime/OWNER.json'))
 awake<-processx::process$new(PY,c('-X','utf8',file.path(ROOT,'code/windows_awake_guard.py'),'--owner-file',file.path(ROOT,'runtime/OWNER.json'),'--output',file.path(ROOT,'runtime/awake'),'--interval','5'),stdout=file.path(ROOT,'runtime/awake.log'),stderr='2>&1',cleanup=FALSE)
 on.exit({if(dir.exists(file.path(ROOT,'runtime/awake')))writeLines('release owned guard',file.path(ROOT,'runtime/awake/stop.request'));awake$wait(8000L)},add=TRUE)
 active<-FALSE
 for(i in 1:40){
  a<-rj(file.path(ROOT,'runtime/awake/identity.json'));hb<-rj(file.path(ROOT,'runtime/awake/heartbeat.json'))
  if(!is.null(a)&&!is.null(hb)&&a$owner$pid==owner$pid&&abs(a$owner$created-owner$created)<.01&&awake$is_alive()){active<-TRUE;break}
  if(!awake$is_alive())stop('Awake helper exited before admission')
  Sys.sleep(.5)
 }
 stopifnot(active)
 jobs<-rj(file.path(ROOT,'contracts/JOBS.json'));results<-list()
 for(g in names(jobs)){
  j<-jobs[[g]];d<-j$dest;stopifnot(!file.exists(file.path(d,'receipt.json')))
  safe_progress('NEW_H42_FIRST_ATTEMPT',j$id)
  p<-processx::process$new(PY,c('-X','utf8',file.path(ROOT,'code/engine.py'),file.path(d,'job.json')),stdout=file.path(d,'supervisor.log'),stderr='2>&1',cleanup=FALSE)
  last<-0
  while(p$is_alive()){
   p$wait(1000L)
   if(as.numeric(Sys.time())-last>25){
    hb<-tryCatch(rj(file.path(ROOT,'runtime/progress.json')),error=function(e)NULL)
    msg<-if(is.null(hb))paste(j$id,'engine admission') else paste(j$id,hb$stage,if(!is.null(hb$elapsed_seconds))round(hb$elapsed_seconds,1) else '')
    if(exists('clauder_progress',mode='function'))try(clauder_progress('estimating',msg),silent=TRUE)
    cat(msg,'\n');flush.console();last<-as.numeric(Sys.time())
   }
  }
  er<-rj(file.path(d,'engine_receipt.json'));nr<-rj(file.path(d,'not_run.json'))
  rr<-list(id=j$id,group=g,member=1,full_MI=FALSE,status=if(!is.null(er))er$status else if(!is.null(nr))nr$status else 'SUPERVISOR_NO_RECEIPT',engine_exit=p$get_exit_status(),dest=d)
  if(!is.null(er))rr$engine<-er
  if(!is.null(er)&&er$status=='EXITED'){
   rr<-tryCatch({
    native<-MplusAutomation::readModels(file.path(d,'model.out'),what='all',quiet=TRUE);saveRDS(native,file.path(d,'mplusautomation_readback.rds'))
    m<-read_mplus_raw(d);si<-spec_info_r2e('SD',j$spec,'c1-c24');dd<-read_dat(file.path(d,'data.dat'),R2D_NAMES)
    gt<-gate_r2e(m,si,range(dd$z0,na.rm=TRUE));rr$status<-classify_local(m,si,gt)
    if(any(grepl('FIXED TO AVOID SINGULARITY',m$lines,fixed=TRUE)))rr$status<-'AUTOFIX_REJECTED'
    rr$negative<-gt$negative;rr$SY<-mval(m,'PSI','SY','SY');rr$LL<-m$extra[['H0 Loglikelihood']]
    csv(m$par,file.path(d,'parameters_high_precision.csv'));csv(key_paths_r2e(m,si$key),file.path(d,'key_paths.csv'));csv(m$spec,file.path(d,'tech1_parameter_map.csv'));csv(m$values,file.path(d,'matrix_values.csv'))
    write.table(m$V,file.path(d,'parameter_covariance.csv'),sep=',',row.names=FALSE,col.names=FALSE);wj(gt,file.path(d,'validation.json'));rr
   },error=function(e){rr$status<-'READBACK_OR_ESTIMATION_FAILURE';rr$error<-conditionMessage(e);rr})
  }
  if(file.exists(file.path(d,'model.out')))rr$output_sha256<-hashf(file.path(d,'model.out'))
  wj(rr,file.path(d,'receipt.json'));results[[g]]<-rr;wj(results,file.path(ROOT,'results/FIRST_ATTEMPTS.json'))
  safe_progress('NEW_H42_ATTEMPT_FINISHED',paste(g,rr$status))
 }
 wj(list(status='TWO_FIRST_ATTEMPTS_ADJUDICATED',groups=lapply(results,function(x)x[c('id','status','negative','SY','LL')]),new_calls=length(results),full_H4_complete=FALSE,complete_MI_families=0,unchanged_failed_repeats=0),file.path(ROOT,'audit/BATCH_TERMINAL.json'))
 safe_progress('CFPS_H42_NEW_GROUPS_TERMINAL','Both first attempts adjudicated; inspect actual statistical states; no full MI claim')
 cat('CFPS_H42_NEW_GROUPS_NATIVE_TERMINAL\n')
}
main()
