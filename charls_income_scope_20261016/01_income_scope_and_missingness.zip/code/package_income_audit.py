"""只发布收入来源汇总和可审阅代码；不发布逐人输入，不重复既有模型包。"""
from pathlib import Path
import csv, hashlib, io, json, re, shutil, zipfile

ROOT = Path(__file__).resolve().parents[1]
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda b: hashlib.sha256(b).hexdigest()
audit = read(ROOT/'audit/SOURCE_AUDIT.json')
assert audit['status']=='SOURCE_AND_SCOPE_AUDIT_COMPLETE'
assert audit['source_unchanged'] and audit['household_income_matches_frozen_core']
assert audit['new_Mplus_calls']==audit['new_imputations']==0
assert read(ROOT/'audit/CLAUDER_COMPLETION.json')['decision']=='PASS'
with (ROOT/'results/CFPS_MEDIAN_EQUIVALENCE.csv').open(encoding='utf-8-sig',newline='') as f:
    rows=list(csv.DictReader(f))
assert len(rows)==12 and all(float(r['median'])==0 and int(r['median_vs_positive_disagreements'])==0 and int(r['stored_group_disagreements'])==0 for r in rows)
body=(ROOT/'audit/MICE_2L_BIN_INTERFACE.txt').read_bytes()
interface={'installed_version':'3.19.0','random_effects_formal':False,'local_function_evidence_sha256':sha(body),'current_documentation':'https://amices.org/mice/reference/mice.impute.2l.bin.html','newer_binary_method_installed_or_executed':False,'prior_completed_H41_method':'miceadds two-level PMM, not mice 2l.bin'}
(ROOT/'audit/MICE_INTERFACE_SUMMARY.json').write_text(json.dumps(interface,indent=2),encoding='utf-8')
selection={
 'reports/REPORT.md':'aggregate_report','reports/FOR_WEB_REVIEWERS.md':'scope_and_limits',
 'code/audit_income_sources.R':'read_only_source_recipe','code/package_income_audit.py':'packaging_recipe',
 'audit/SOURCE_AUDIT.json':'zero_estimation_receipt','audit/SOURCE_HASHES.csv':'source_hashes_without_local_paths',
 'audit/CFPS_MI_SOURCE_HASHES.csv':'source_hashes','audit/MICE_INTERFACE_SUMMARY.json':'installed_interface_metadata',
 'audit/CLAUDER_COMPLETION.json':'actual_native_completion_evidence',
 'results/INCOME_DICTIONARY.csv':'variable_dictionary','results/COMPONENT_COVERAGE.csv':'aggregate_coverage',
 'results/SCOPE_MISSINGNESS.csv':'aggregate_scope','results/CFPS_MEDIAN_EQUIVALENCE.csv':'aggregate_definition_equivalence'}
payload={};manifest=[]
for name,role in selection.items():
    p=ROOT/name
    assert 'private' not in Path(name).parts and p.suffix.lower() not in {'.rds','.dta','.dat'}
    raw=p.read_bytes();s=raw.decode('utf-8-sig')
    for prefix in ('<LOCAL_USER_HOME>','<LOCAL_USER_HOME>','C:\\\\Users\\\\LZHS','<LOCAL_USER_HOME>','<LOCAL_USER_HOME>'):
        s=s.replace(prefix,'<LOCAL_USER_HOME>')
    assert not re.search(r'(?i)(?:api[_-]?key|access_token)\s*[:=]\s*["\']?[A-Za-z0-9_-]{20,}',s)
    if p.suffix=='.csv':
        headers=next(csv.reader(io.StringIO(s)))
        assert not set(map(str.lower,headers))&{'pid','fid','id','childid','householdid','communityid'}
    data=s.encode('utf-8');payload[name]=data
    manifest.append({'path':name,'role':role,'bytes':len(data),'sha256':sha(data),'local_source_sha256':sha(raw),'paths_redacted':data!=raw})
payload['PAYLOAD_MANIFEST.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8')
stage=ROOT/'public_stage';stage.mkdir(exist_ok=True)
zp=stage/'01_income_scope_and_missingness.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,data in payload.items(): z.writestr(name,data)
assert zp.stat().st_size < 25_000_000
with zipfile.ZipFile(zp) as z:
    assert z.testzip() is None
    for row in manifest: assert sha(z.read(row['path']))==row['sha256']
pm={'packages':[{'file':zp.name,'bytes':zp.stat().st_size,'sha256':sha(zp.read_bytes()),'files':len(payload)}],'selection':'Explicit per-file aggregate/code allowlist; no participant records, RDS, DAT, DTA, actual MI or identifiers; local paths redacted','new_Mplus_calls':0,'new_imputations':0}
(stage/'PACKAGE_MANIFEST.json').write_text(json.dumps(pm,ensure_ascii=False,indent=2),encoding='utf-8')
for name in ('REPORT.md','FOR_WEB_REVIEWERS.md'):(stage/name).write_bytes(payload['reports/'+name])
for name in ('CFPS_MEDIAN_EQUIVALENCE.csv','SCOPE_MISSINGNESS.csv'):(stage/name).write_bytes(payload['results/'+name])
(stage/'README.md').write_text('# 收入口径与缺失处理入口\n\n**四项调节完整推断、完整 H4 仍未完成。**\n\n[来源报告与下一步](REPORT.md) · [网页端说明](FOR_WEB_REVIEWERS.md) · [CFPS等价核对](CFPS_MEDIAN_EQUIVALENCE.csv) · [CHARLS范围](SCOPE_MISSINGNESS.csv)\n\n本包只有来源和方法入口，新Mplus/MI均为0；八个已完成的CHARLS家族请复用此前固定提交950a01e的包，不重复下载拟合。收入新MI方法仍须在实际接口小试后冻结。\n',encoding='utf-8')
(ROOT/'audit/PUBLIC_SELECTION.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'audit/LOCAL_PACKAGE_VERIFICATION.json').write_text(json.dumps({'status':'PASS','payloads':len(manifest),'zip_crc_ok':True,'all_payload_hashes_ok':True,'source_semantics_checked':True,'no_new_estimation':True}),encoding='utf-8')
print(json.dumps(pm,ensure_ascii=False))
