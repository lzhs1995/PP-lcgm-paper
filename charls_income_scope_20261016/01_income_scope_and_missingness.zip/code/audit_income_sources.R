# 收入口径与缺失范围只读核对：不插补、不运行Mplus、不写回任何源数据。
local({
.libPaths(c('<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
library(haven);library(jsonlite);library(digest)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_scope_20261016'
for(z in c('audit','results','private','reports','contracts','runtime'))dir.create(file.path(ROOT,z),recursive=TRUE,showWarnings=FALSE)
src<-c(core='<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015/private/charls_core_mi_inputs.rds',
 roster='<LOCAL_USER_HOME>/pp_lgcm_review/charls_roster_moderation_20261015/private/CONSTRUCTED_BASELINE_CONTRASTS.rds',
 harmonized='<LOCAL_USER_HOME>/Desktop/20230505 毕业论文/开题报告/开题报告/CHARLS/charls11_20_harmonized/data_Harmonized/H_CHARLS_D_Data.dta',
 source_do='<LOCAL_USER_HOME>/Desktop/20230505 毕业论文/开题报告/开题报告/CHARLS/charls11_20_harmonized/data_Harmonized/H_CHARLS_D_do_file.do',
 cfps_original='<LOCAL_USER_HOME>/Desktop/开题报告/0_data_clo/cesd2_closeness_2012_22_unbal.csv',
 cfps_do='<LOCAL_USER_HOME>/Desktop/开题报告/20250930 Closeness & Cognitive_final.do',
 cfps_premi='<LOCAL_USER_HOME>/pp_lgcm_review/round2B_20261006/private/baseline_preMI.rds')
hash0<-vapply(src,function(f)digest(file=f,algo='sha256'),'')
write.csv(data.frame(role=names(src),sha256=unname(hash0)),file.path(ROOT,'audit/SOURCE_HASHES.csv'),row.names=FALSE)
write_json(as.list(src),file.path(ROOT,'private/SOURCE_PATHS.json'),pretty=TRUE,auto_unbox=TRUE)
a<-readRDS(src['core']);r<-readRDS(src['roster']);d<-a$raw
vars<-c('r1itearn','r1itsemp','r1itrest','r1ipen','r1igxfr','r1iothr','hh1itsemp','hh1itrest','hh1irent','hh1igxfr','hh1iothhh','hh1itot')
h<-read_dta(src['harmonized'],col_select=tidyselect::all_of(c('ID','householdID',vars)))
labels<-vapply(h[vars],function(x)as.character(attr(x,'label')),'')
idx<-match(d$pid,as.character(h$ID));stopifnot(!anyNA(idx),!anyDuplicated(h$ID),nrow(d)==3006)
v<-as.data.frame(lapply(h[idx,vars],as.numeric))
stopifnot(isTRUE(all.equal(v$hh1itot,d$hh_income,check.attributes=FALSE)),!anyDuplicated(d$fid))
write.csv(data.frame(variable=vars,label=labels),file.path(ROOT,'results/INCOME_DICTIONARY.csv'),row.names=FALSE)
summ<-function(x,nm,scope){data.frame(scope=scope,variable=nm,N=length(x),observed=sum(!is.na(x)),missing=sum(is.na(x)),zero=sum(x==0,na.rm=TRUE),negative=sum(x<0,na.rm=TRUE),median=median(x,na.rm=TRUE),q25=quantile(x,.25,na.rm=TRUE,names=FALSE),q75=quantile(x,.75,na.rm=TRUE,names=FALSE),min=min(x,na.rm=TRUE),max=max(x,na.rm=TRUE))}
comp<-c('r1itearn','r1itsemp','r1itrest','r1ipen','r1igxfr','r1iothr')
# 仅诊断完整分量覆盖；此和数并非官方个人总收入，不送入估计。
v$respondent_component_sum_diagnostic<-rowSums(v[comp],na.rm=FALSE)
stat<-lapply(names(v),function(nm)summ(v[[nm]],nm,'cohort'))
cut<-median(v$hh1itot,na.rm=TRUE);groups<-ifelse(is.na(v$hh1itot),NA_integer_,as.integer(v$hh1itot>cut))
coverage<-list();ix<-list(cohort=rep(TRUE,nrow(d)))
for(z in c('sd','gender','oldest','son'))ix[[z]]<-r$all_listed[[paste0(z,'_status')]]=='DEFINED' & r$legacy_keys_compatible
for(z in names(ix)){
 ii<-ix[[z]];gg<-groups[ii];adl<-a$data$adl[ii]
 coverage[[z]]<-data.frame(scope=z,N=sum(ii),communities=length(unique(a$data$cluster[ii])),income_missing=sum(is.na(gg)),ADL_missing=sum(is.na(adl)),both_missing=sum(is.na(gg)&is.na(adl)),income_low_observed=sum(gg==0,na.rm=TRUE),income_high_observed=sum(gg==1,na.rm=TRUE),CC=sum(!is.na(gg)&!is.na(adl)),fixed_household_threshold_CNY=cut,scope_observed_median=median(v$hh1itot[ii],na.rm=TRUE))
}
write.csv(do.call(rbind,stat),file.path(ROOT,'results/COMPONENT_COVERAGE.csv'),row.names=FALSE)
write.csv(do.call(rbind,coverage),file.path(ROOT,'results/SCOPE_MISSINGNESS.csv'),row.names=FALSE)
o<-read.csv(src['cfps_original'],na.strings=c('9999','9999.00','NA',''),check.names=FALSE)
cfpsrow<-function(x,nm){m<-median(x$pinc212,na.rm=TRUE);g<-as.integer(x$pinc212>m);data.frame(source=nm,N=nrow(x),income_missing=sum(is.na(x$pinc212)),median=m,positive_n=sum(x$pinc212>0,na.rm=TRUE),median_vs_positive_disagreements=sum(g!=as.integer(x$pinc212>0),na.rm=TRUE),stored_group_disagreements=if('pinc412'%in%names(x))sum(g!=x$pinc412,na.rm=TRUE)else NA_integer_)}
cf<-list(cfpsrow(o,'original_export'),cfpsrow(readRDS(src['cfps_premi'])$data,'corrected_preMI'))
mh<-list()
for(k in 1:10){p<-sprintf('<LOCAL_USER_HOME>/pp_lgcm_review/round2B_20261006/private/mi10/member_%02d.rds',k);cf[[length(cf)+1L]]<-cfpsrow(readRDS(p),sprintf('frozen_MI%02d',k));mh[[k]]<-data.frame(member=k,sha256=digest(file=p,algo='sha256'))}
write.csv(do.call(rbind,cf),file.path(ROOT,'results/CFPS_MEDIAN_EQUIVALENCE.csv'),row.names=FALSE)
write.csv(do.call(rbind,mh),file.path(ROOT,'audit/CFPS_MI_SOURCE_HASHES.csv'),row.names=FALSE)
saveRDS(list(data=v,group=groups,threshold=cut,scope=ix,core=a$data,pid=d$pid),file.path(ROOT,'private/INCOME_SCOPE_INPUTS.rds'))
stopifnot(identical(hash0,vapply(src,function(f)digest(file=f,algo='sha256'),'')),all(do.call(rbind,cf)$median==0),all(do.call(rbind,cf)$median_vs_positive_disagreements==0))
rec<-list(status='SOURCE_AND_SCOPE_AUDIT_COMPLETE',created_utc=format(Sys.time(),tz='UTC',usetz=TRUE),N=nrow(d),matched_exact_ID=TRUE,household_income_matches_frozen_core=TRUE,source_unchanged=TRUE,cfps_12_sources_median_zero=TRUE,cfps_reestimation_needed_for_median_definition=FALSE,official_personal_total_present=FALSE,respondent_component_sum_adopted=FALSE,household_threshold_candidate=cut,new_imputations=0,new_Mplus_calls=0,individual_files_publishable=FALSE,semantic_boundary='hh1itot is household net income; r1itearn is earnings, not total personal income. A diagnostic component sum is not an adopted equivalent of CFPS personal income.')
write_json(rec,file.path(ROOT,'audit/SOURCE_AUDIT.json'),pretty=TRUE,auto_unbox=TRUE,digits=16)
writeLines(capture.output(sessionInfo()),file.path(ROOT,'audit/R_SESSION_INFO.txt'))
print(do.call(rbind,coverage));print(do.call(rbind,cf));cat('INCOME_SCOPE_AUDIT_DONE\n')
})
