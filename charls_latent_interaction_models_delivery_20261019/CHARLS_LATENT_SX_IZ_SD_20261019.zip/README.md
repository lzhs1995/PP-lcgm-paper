# CHARLS latent SX × IZ: sd

Status: COMPLETE_20_MI_WORKING_MODEL. Complete 20-member families only are pooled. Run `python code/verify_family.py sd --public` after extraction if this family is complete. The reader independently reconstructs raw TECH1/RESULTS/TECH3 and all-parameter Rubin inference; it does not fit Mplus or verify absent participant data.

CC parent/refinement and MI01 second starts are diagnostics, not extra imputations. This working MI is not exact latent congeniality or proof of MAR. Original CFPS four moderation families and full H4 remain incomplete. No manuscript changes or NLM cycle are included.
