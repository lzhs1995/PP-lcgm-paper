"""绑定原生异步作业的真实worker，按实测CPU挑选互不重叠的四核。"""
from pathlib import Path
import datetime,json,sys,psutil
from adapter import resource
R=Path(__file__).resolve().parents[1];q=sys.argv[1];p=psutil.Process(int(sys.argv[2]));expected=float(sys.argv[3])
assert q in ['q1','q2'] and p.name().lower() in ['rscript.exe','rterm.exe']
assert abs(p.create_time()-expected)<1e-6 and any(x.pid==8764 for x in p.parents())
assert int((R/'runtime'/f'BOOT_PID_{q}.txt').read_text().strip())==p.pid
occupied=[];known=[p.pid]
for f in (R/'audit').glob('PREFLIGHT_q*.json'):
 j=json.loads(f.read_text());op=psutil.Process(j['owner']['pid'])
 assert abs(op.create_time()-float(j['owner']['created_exact']))<1e-6
 known.append(op.pid);occupied.extend(j['affinity'])
r=resource()
for pid in r['mplus_pids']:assert any(a.pid in known for a in psutil.Process(pid).parents()),'Unowned engine'
assert r['available_gib']>=2 and r['commit_available_gib']>=2.8
loads=psutil.cpu_percent(interval=2,percpu=True);before=p.cpu_affinity();candidate=[k for k in before if k not in occupied]
assert len(candidate)>=4
cpus=sorted(sorted(candidate,key=lambda k:loads[k])[:4]);p.cpu_affinity(cpus)
out=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),queue=q,owner=dict(pid=p.pid,created_exact=format(p.create_time(),'.17g')),affinity=cpus,original_affinity=before,percpu=loads,resource=r)
target=R/'audit'/f'PREFLIGHT_{q}.json';assert not target.exists();target.write_text(json.dumps(out,indent=2))
print(json.dumps(out),flush=True)
