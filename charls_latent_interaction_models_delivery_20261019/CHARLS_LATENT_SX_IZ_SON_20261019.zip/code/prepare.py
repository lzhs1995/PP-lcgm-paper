"""完整潜交互MI模型：只替换数据、标题和登记初值。"""
from pathlib import Path
import csv,datetime,hashlib,json,re,shutil,sys
R=Path(__file__).resolve().parents[1];B=R.parent
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
save=lambda p,x:Path(p).write_text(json.dumps(x,indent=2,ensure_ascii=False),encoding='utf-8')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def compile_model(z,k,start):
 c=read(R/'contracts/RUN_CONTRACT.json');k=int(k);assert z in c['indicators'] and 1<=k<=20 and start in ['A','B'] and (start=='A' or k==1)
 mi=Path(c['mi_root'])/'mi'/z;ad=read(mi/'audit/MI_ADMISSION.json');ind=read(mi/'audit/INDEPENDENT_MI.json')
 assert ad['status']=='ADMITTED_WORKING_MI' and ind['status']=='PASS' and ad['m']==20
 cc=Path(c['calibration_roots'][z]);assert read(cc/'audit/INDEPENDENT_VERIFICATION.json')['status']=='PASS_INDEPENDENT_RAW_READBACK'
 src=cc/'models'/('E1_GH15_A' if start=='A' else 'E1_GH07_B')
 for n,h in c['template_hashes'][z][start].items():assert sha(src/n)==h
 text=(src/'model.inp').read_text();ident=f'LATENT_{z.upper()}_MI{k:02d}_{start}'
 if start=='A':
  rows=list(csv.DictReader((src/'parameters_high_precision.csv').open()));assert len(rows)==127
  core=text.split('sz BY z2*',1)[0];lines=[]
  for p in rows:
   m=p['matrix'].lower();a=p['row'].lower();b=p['column'].lower();v=format(float(p['estimate']),'.14g')
   if m=='alpha':s=f'[{b}*{v}];'
   elif m=='beta':s=f'{a} ON {b}*{v};'
   elif m=='lambda':s=f'{b} BY {a}*{v};'
   elif m in ['psi','theta']:s=f'{a}*{v};' if a==b else f'{a} WITH {b}*{v};'
   else:raise ValueError(m)
   lines.append(s)
  text=core+'\n'.join(lines)+'\niy WITH ix@0 iz@0 sy@0;\nsy WITH ix@0 sx@0 iz@0 sz@0;\nOUTPUT: TECH1 TECH3 TECH4 TECH8 SVALUES CINTERVAL;\nSAVEDATA: RESULTS=estimates.dat; TECH3=tech3.dat;\n'
 else:
  # 保留原独立父模型B起点，不把两个几乎相同终点称作独立起点。
  text=text.replace('INTEGRATION=GAUSSHERMITE(7);','INTEGRATION=GAUSSHERMITE(15);')
 text=re.sub(r'^TITLE:[^\n]*',f'TITLE: {ident} latent SX by IZ complete working MI;',text)
 assert 'INTEGRATION=GAUSSHERMITE(15);' in text and max(map(len,text.splitlines()))<=90
 assert not re.search(r'^\s*sy\s*@0\s*;',text,re.I|re.M) and text.count('sxiz | sx XWITH iz;')==1
 d=R/'models'/ident;d.mkdir(exist_ok=False)
 member=list(csv.DictReader((mi/'audit/MI_MEMBERS.csv').open()));row=next(x for x in member if int(x['member'])==k)
 inp=mi/'private'/f'MI{k:02d}.dat';assert sha(inp)==row['sha256']
 shutil.copyfile(inp,d/'data.dat');(d/'model.inp').write_text(text,encoding='ascii')
 j=dict(id=ident,indicator=z,member=k,start=start,N=ad['N'],communities=ad['communities'],expected_free=127,cap_seconds=240,
   source_CC=str(src),start_kind='accepted_CC_final' if start=='A' else 'independent_original_parent_B',
   hashes={n:sha(d/n) for n in ['model.inp','data.dat']})
 save(d/'job.json',j)
 (d/'launch.cmd').write_text('@echo off\n"C:/Users/LZHS/AppData/Local/Programs/Python/Python314/python.exe" -X utf8 "'+R.as_posix()+'/code/adapter.py" "%~dp0job.json" "%~1"\nexit /b %ERRORLEVEL%\n')
 print(str(d),flush=True)

if __name__=='__main__':
 if len(sys.argv)>1:compile_model(*sys.argv[1:]);raise SystemExit()
 for n in ['contracts','audit','models','runtime','results','reports']:(R/n).mkdir(exist_ok=True)
 assert not (R/'contracts/RUN_CONTRACT.json').exists()
 roots={z:str(B/'charls_latent_gh_calibration_20261019' if z=='sd' else B/'charls_latent_gh_remaining_20261019/families'/z) for z in ['sd','gender','oldest','son']}
 hashes={}
 for z,cc in roots.items():
  root=Path(cc);assert read(root/'audit/INDEPENDENT_VERIFICATION.json')['status']=='PASS_INDEPENDENT_RAW_READBACK'
  hashes[z]={s:{n:sha(root/'models'/m/n) for n in ['model.inp','model.out','parameters_high_precision.csv']} for s,m in [('A','E1_GH15_A'),('B','E1_GH07_B')]}
 base=read(B/'charls_latent_income_models_20261019/contracts/RUN_CONTRACT.json')
 c={k:base[k] for k in ['executable','executable_sha256','minimum_available_gib','minimum_commit_available_gib','max_cpu_percent','engine_incremental_gib','engine_incremental_commit_gib']}
 c.update(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),indicators=['sd','gender','oldest','son'],m=20,
    mi_root=str(B/'charls_latent_interaction_mi_20261019'),calibration_roots=roots,template_hashes=hashes,
    queues={'q1':['sd','oldest'],'q2':['gender','son']},maximum_parallel_mplus=2,max_mplus_calls=84,total_engine_seconds=20160,
    per_model_seconds=240,resource_wait_seconds=120,processors=4,
    tolerances=read(B/'charls_latent_gh_calibration_20261019/contracts/RUN_CONTRACT.json')['tolerances'],
    primary='SY ON SXIZ; latent SX-by-IZ moderation, four indicators in corrected CHARLS cohort',
    pooling='Rubin full coefficient/covariance pooling only after all 20 members; cluster-df sensitivity; Holm primary across four indicators; MCSE/SE reported',
    starts='A from adopted CC final; MI01 B from original perturbed no-interaction parent plus opposite interaction start; all use GH15. No previous-MI warm substitution.',
    stops=['First failed member or first-member start mismatch stops that indicator. Never replace failed members or pool subset.',
           'No significance-based admission; no source/estimator/variance changes; no CFPS reruns.'],
    original_CFPS_four_complete=False,full_H4_complete=False)
 save(R/'contracts/RUN_CONTRACT.json',c)
 for n in ['engine_slots.py','bounded_child_awake.py','active_clock.py']:shutil.copyfile(B/'charls_latent_income_models_20261019/code'/n,R/'code'/n)
 for n in ['r2e_tools.R','r2e_upstream_math.R','raw_tech1.py','harness.py']:shutil.copyfile(B/'charls_latent_gh_calibration_20261019/code'/n,R/'code'/n)
 shutil.copyfile(B/'charls_latent_h41_mi_20261019/code/mi_pool_math.R',R/'code/mi_pool_math.R')
 print('LATENT_INTERACTION_MODELS_FROZEN 4x20 +4 second starts; max2 engines; no p selection')
