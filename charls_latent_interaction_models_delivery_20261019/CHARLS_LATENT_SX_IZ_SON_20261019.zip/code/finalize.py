"""等待现有模型终态后核验、制图和打包；不提交模型，不自动发布。"""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import datetime,hashlib,json,re,subprocess,sys,time,zipfile
R=Path(__file__).resolve().parents[1];B=R.parent;P=B/'charls_latent_interaction_models_delivery_20261019'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,ensure_ascii=False),encoding='utf-8')
def ready():return all((R/'results'/f'{q}_TERMINAL.json').exists() or (R/'results'/f'{q}_ERROR.json').exists() for q in ['q1','q2'])
def main():
 with (R/'runtime/FINALIZER_RESERVED').open('x') as f:f.write(str(os.getpid()))
 end=time.monotonic()+14400
 while not ready():
  if time.monotonic()>end:raise TimeoutError('Existing queues did not reach terminal; no resubmission')
  save(R/'audit/FINALIZER_STATE.json',dict(stage='WAIT_EXISTING_MODEL_QUEUES',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),new_model_calls=0));time.sleep(20)
 import numpy as np
 import pandas as pd
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 from verify_family import verify
 c=read(R/'contracts/RUN_CONTRACT.json');completed=[];states={};ledger=[]
 for z in c['indicators']:
  f=R/'results'/z/'FAMILY_RECEIPT.json';term=R/'results'/f'{z}_TERMINAL.json'
  states[z]=read(term) if term.exists() else dict(status='QUEUE_ERROR_BEFORE_FAMILY_TERMINAL')
  if f.exists():
   verify(z);completed.append(z)
  for d in sorted((R/'models').glob(f'LATENT_{z.upper()}_*')):
   j=read(d/'job.json');rec=read(d/'receipt.json') if (d/'receipt.json').exists() else dict(status='NO_TERMINAL_READBACK')
   eng=read(d/'engine_receipt.json') if (d/'engine_receipt.json').exists() else {}
   ledger.append(dict(model=d.name,indicator=z,member=j['member'],start=j['start'],status=rec['status'],actual_engine_calls=eng.get('actual_engine_calls',0),engine_seconds=eng.get('active_seconds',0),N=j['N']))
 assert sum(x['actual_engine_calls'] for x in ledger)<=84 and sum(x['engine_seconds'] for x in ledger)<=20160+2
 pd.DataFrame(ledger).to_csv(R/'results/ALL_CALLS.csv',index=False)
 rows=[]
 for z in completed:
  tab=pd.read_csv(R/'results'/z/'POOLED_PATHS.csv');x=tab[tab.key=='beta:SY:SXIZ'].iloc[0].to_dict();x.update(indicator=z,N=read(R/'results'/z/'FAMILY_RECEIPT.json')['N']);rows.append(x)
 if rows:
  df=pd.DataFrame(rows);order=np.argsort(df.p.to_numpy());adj=np.empty(len(df));adj[order]=np.minimum(1,np.maximum.accumulate(df.p.to_numpy()[order]*(4-np.arange(len(df)))))
  df['holm_planned4']=adj;df.to_csv(R/'results/PRIMARY_MODERATION_PLANNED4.csv',index=False)
  fig,ax=plt.subplots(figsize=(7,3.8));y=np.arange(len(df));ax.errorbar(df.estimate,y,xerr=np.vstack([df.estimate-df.lower,df.upper-df.estimate]),fmt='o',capsize=4,color='#235789');ax.axvline(0,color='gray',ls='--',lw=1);ax.set_yticks(y,df.indicator);ax.set_xlabel('Latent SX × IZ coefficient, with 95% conditional MI interval');ax.set_title('CHARLS: complete 20-imputation working families');ax.grid(axis='x',alpha=.15);fig.tight_layout()
  for ext in ['png','pdf']:fig.savefig(R/'results'/('PRIMARY_MODERATION.'+ext),dpi=180)
  plt.close(fig)
 else:df=pd.DataFrame()
 save(R/'results/BATCH_RECEIPT.json',dict(status='ALL_ATTEMPTS_CLOSED',complete_working_MI_families=completed,states=states,actual_calls=sum(x['actual_engine_calls'] for x in ledger),engine_seconds=sum(x['engine_seconds'] for x in ledger),original_CFPS_four_complete=False,full_H4_complete=False))
 assert not P.exists()
 for n in ['delivery','audit','reports','replay']:(P/n).mkdir(parents=True)
 model_names=['model.inp','model.out','estimates.dat','tech3.dat','job.json','receipt.json','validation.json','engine_receipt.json','parameters_high_precision.csv','parameter_covariance.csv','tech1_parameter_map.csv','matrix_values.csv','fit.json','R_WRAPPER_RETURN.json','RESOURCE_ADMITTED.json','RESERVATION.json','ADMISSION_HISTORY.jsonl']
 code_names=['prepare.py','adapter.py','engine_slots.py','bounded_child_awake.py','active_clock.py','run_queue.R','preflight.py','verify_family.py','raw_tech1.py','mi_pool_math.R','r2e_tools.R','r2e_upstream_math.R','watch.py','finalize.py']
 packages=[];privacy=[]
 for z in c['indicators']:
  payload={}
  def put(n,p):
   assert n not in payload and p.is_file();payload[n]=p.read_bytes()
  for n in code_names:put('code/'+n,R/'code'/n)
  put('contracts/RUN_CONTRACT.json',R/'contracts/RUN_CONTRACT.json')
  for n in ['ALL_CALLS.csv','BATCH_RECEIPT.json','PRIMARY_MODERATION_PLANNED4.csv','PRIMARY_MODERATION.png','PRIMARY_MODERATION.pdf',f'{z}_TERMINAL.json',f'{z}_CALL_RESULTS.json',f'{z}_MI01_START_COMPARISON.json']:
   if (R/'results'/n).exists():put('results/'+n,R/'results'/n)
  if z in completed:
   for n in ['POOLED_ALL.csv','POOLED_CLUSTER_DF.csv','POOLED_W.csv','POOLED_B.csv','POOLED_T.csv','POOLED_PATHS.csv','FAMILY_RECEIPT.json','INDEPENDENT_PARAMETER_LEDGER.csv','INDEPENDENT_VERIFICATION.json']:put('results/'+z+'/'+n,R/'results'/z/n)
  for d in sorted((R/'models').glob(f'LATENT_{z.upper()}_*')):
   for n in model_names:
    if (d/n).is_file():put('models/'+d.name+'/'+n,d/n)
   for n in ['stdout.log','stderr.log','receipt.json','progress.jsonl']:
    if (d/'execution'/n).is_file():put('models/'+d.name+'/execution/'+n,d/'execution'/n)
  mi=Path(c['mi_root']);put('mi/contracts/RUN_CONTRACT.json',mi/'contracts/RUN_CONTRACT.json')
  for n in ['run_scope.R','mi_exact_fit_cache.R','verify_mi.py']:put('mi/code/'+n,mi/'code'/n)
  for n in ['MI_ADMISSION.json','INDEPENDENT_MI.json','MI_MEMBERS.csv']:put('mi/'+z+'/audit/'+n,mi/'mi'/z/'audit'/n)
  cc=Path(c['calibration_roots'][z]);put('cc/audit/INDEPENDENT_VERIFICATION.json',cc/'audit/INDEPENDENT_VERIFICATION.json')
  for d in sorted((cc/'models').iterdir()):
   if not d.is_dir():continue
   for n in ['model.inp','model.out','estimates.dat','tech3.dat','parameters_high_precision.csv','parameter_covariance.csv','validation.json','receipt.json','job.json','LAUNCH_RECEIPT.json']:
    if (d/n).is_file():put('cc/models/'+d.name+'/'+n,d/n)
  payload['README.md']=(f'# CHARLS latent SX × IZ: {z}\n\nStatus: {states[z]["status"]}. Complete 20-member families only are pooled. Run `python code/verify_family.py {z} --public` after extraction if this family is complete. The reader independently reconstructs raw TECH1/RESULTS/TECH3 and all-parameter Rubin inference; it does not fit Mplus or verify absent participant data.\n\nCC parent/refinement and MI01 second starts are diagnostics, not extra imputations. This working MI is not exact latent congeniality or proof of MAR. Original CFPS four moderation families and full H4 remain incomplete. No manuscript changes or NLM cycle are included.\n').encode()
  assert not any('/private/' in n or n.lower().endswith(('.rds','.rdata','.sav','.dta','.parquet')) for n in payload)
  assert all(n.endswith(('/estimates.dat','/tech3.dat')) for n in payload if n.endswith('.dat'))
  # 明确白名单与内容标识检查；不以CSV行数阈值断言没有微观数据。
  for n,b in payload.items():
   assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY',b),n
  mf=dict(indicator=z,files=[dict(path=n,bytes=len(b),sha256=sha(b)) for n,b in sorted(payload.items())])
  zp=P/'delivery'/f'CHARLS_LATENT_SX_IZ_{z.upper()}_20261019.zip'
  with zipfile.ZipFile(zp,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as out:
   for n,b in sorted(payload.items()):out.writestr(n,b)
   out.writestr('INTERNAL_MANIFEST.json',json.dumps(mf,indent=2))
  assert zp.stat().st_size<25_000_000
  with zipfile.ZipFile(zp) as out:
   assert out.testzip() is None and set(out.namelist())==set(payload)|{'INTERNAL_MANIFEST.json'}
   for n,b in payload.items():assert out.read(n)==b
   out.extractall(P/'replay'/z)
  if z in completed:
   run=subprocess.run([sys.executable,'-X','utf8',str(P/'replay'/z/'code/verify_family.py'),z,'--public'],capture_output=True,text=True,encoding='utf-8',timeout=300)
   save(P/'audit'/f'PUBLIC_REPLAY_{z}.json',dict(returncode=run.returncode,stdout=run.stdout,stderr=run.stderr));assert run.returncode==0,run.stderr
  packages.append(dict(file=zp.name,bytes=zp.stat().st_size,sha256=sha(zp.read_bytes()),entries=len(payload)+1,indicator=z,complete_MI=z in completed))
  privacy.append(dict(indicator=z,classification='Aggregate parameters, covariance, diagnostics, code and hash receipts only',participant_DAT_RDS_MIDS_or_scores=False,explicit_whitelist=True,credential_pattern_scan='PASS'))
 table='| Indicator | N | delta | 95% conditional MI interval | p | Holm, planned four |\n|---|---:|---:|---|---:|---:|\n'
 for x in df.itertuples():table+=f'| {x.indicator} | {x.N} | {x.estimate:.6f} | [{x.lower:.6f}, {x.upper:.6f}] | {x.p:.6g} | {x.holm_planned4:.6g} |\n'
 report='''# CHARLS 潜在 SX×IZ 调节：本批结果与边界

**四项调节完整推断、完整 H4 仍未完成。** 这句话指原CFPS研究的完整时间路径与H4覆盖。本批推进的是CHARLS四个指标的一个明确潜在交互路径：SX×IZ→SY；不能用它替代全部原时间路径或H4.2三重交互。

此前已完成的12个潜H4.1工作家族320主MI复用，不重复估计。本批改变的是有实测依据的求积规则，保留模型结构、控制变量、自由残差方差和收敛标准。完整案例分别核验7/15点及独立父起点。之后另做包含25个观测X×Z辅助项的ADL-only工作MI；每指标20份，仅填补缺失ADL，原XYZ和已观测控制保持。辅助项并不证明严格潜交互相容性或MAR。

20主成员全部可采用且首份双起点通过，才合并全部127参数和完整robust协方差；使用Rubin合并，附社区自由度敏感性与MCSE/SE。主交互按计划四指标Holm校正，无p值筛选。CC的7→15点检查不能冒充全部MI成员均做过积分阶数敏感性。

'''+table+'\n每个指标终态：\n'+json.dumps(states,ensure_ascii=False,indent=2)+'''

打包只含聚合估计、原始参数保存文件、代码和核验凭证，不含个人DAT、RDS、MIDS或逐人因子得分。完整家族已经在真实解压目录重新执行独立原始参数与Rubin读回；这不是重新拟合。文件白名单和内容检查不以CSV行数代替数据分类。

本批没有改动原始数据、历史CFPS输出或封存稿，没有新增NLM或改写论文。CHARLS的见面频率与CFPS亲近度、绝对SD与相对SD、各资源定义不能混称；本批保留sd/gender/oldest/son的既有输入定义。

后续以原假设覆盖表确定尚缺的时间交互和H4.2，先复用本批父模型、准入结果及失败记录；不原样重跑已经失败的CFPS规格，也不把不显著当作数值故障修复。
'''
 (P/'reports/REPORT.md').write_text(report,encoding='utf-8');(P/'delivery/REPORT.md').write_text(report,encoding='utf-8')
 feedback='# 给网页端复核者\n\n请复核本批CHARLS潜在SX×IZ工作MI的参数、完整家族合并与范围。当前包不包含个人数据，请勿声称重新拟合或核验未提供的记录。不要把此批结果当作CFPS四项全部调节或完整H4已完成。\n\n'+table+'\n每ZIP不足25MB，内部manifest给出逐文件SHA-256；独立复核脚本及原始TECH1/RESULTS/TECH3随包提供。失败尝试若存在，也在对应包保留，不能以有效子集替代完整20份。\n'
 (P/'delivery/FEEDBACK_TO_WEB_REVIEWERS.md').write_text(feedback,encoding='utf-8')
 save(P/'delivery/PACKAGE_MANIFEST.json',dict(packages=packages,privacy=privacy,new_model_calls_by_finalizer=0,original_CFPS_four_complete=False,full_H4_complete=False))
 save(P/'audit/LOCAL_DELIVERY_READY.json',dict(status='PASS',complete_families=completed,packages=packages,public_replay=True,at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
 save(R/'audit/FINALIZER_STATE.json',dict(stage='LOCAL_DELIVERY_READY',path=str(P),published=False))
 print('LOCAL_DELIVERY_READY',str(P),flush=True)
if __name__=='__main__':
 try:main()
 except Exception as exc:
  save(R/'audit/FINALIZER_FAILURE.json',dict(type=type(exc).__name__,error=str(exc),at=datetime.datetime.now(datetime.timezone.utc).isoformat()));raise
