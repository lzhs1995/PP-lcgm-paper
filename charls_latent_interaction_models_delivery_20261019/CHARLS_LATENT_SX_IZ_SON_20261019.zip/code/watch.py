"""轻量只读进度与本任务引擎优先级；未知应用保持原状。"""
from pathlib import Path
import datetime,json,time,psutil
from adapter import resource
R=Path(__file__).resolve().parents[1];owners={1740:1792460401.3538857,9456:1792460570.1450031}
def live(pid,created):
 try:return abs(psutil.Process(pid).create_time()-created)<1e-6
 except psutil.NoSuchProcess:return False
out=R/'audit/LIVE_RESOURCE.jsonl';assert not out.exists();changes={};started=time.monotonic()
try:
 while time.monotonic()-started<14400:
  alive=[pid for pid,c in owners.items() if live(pid,c)]
  if not alive:break
  r=resource();eng=[]
  for pid in r['mplus_pids']:
   try:
    p=psutil.Process(pid)
    if not any(a.pid in alive for a in p.parents()):continue
    created=p.create_time();key=(pid,created)
    if key not in changes:
     prior=p.nice();change=prior not in [psutil.ABOVE_NORMAL_PRIORITY_CLASS,psutil.HIGH_PRIORITY_CLASS,psutil.REALTIME_PRIORITY_CLASS]
     if change:p.nice(psutil.ABOVE_NORMAL_PRIORITY_CLASS)
     changes[key]=dict(pid=pid,created=created,original=int(prior),changed=change)
     with (R/'audit/PRIORITY_CHANGES.jsonl').open('a') as f:f.write(json.dumps(changes[key])+'\n')
    m=p.memory_info();cpu=p.cpu_times();eng.append(dict(pid=pid,created=created,affinity=p.cpu_affinity(),priority=int(p.nice()),rss=m.rss,private=getattr(m,'private',None),cpu_seconds=cpu.user+cpu.system,threads=p.num_threads()))
   except psutil.NoSuchProcess:pass
  r.update(owners_alive=alive,engines=eng)
  with out.open('a') as f:f.write(json.dumps(r)+'\n')
  time.sleep(5)
finally:
 restored=[]
 for (pid,c),j in changes.items():
  if j['changed'] and live(pid,c):
   try:psutil.Process(pid).nice(j['original']);restored.append(pid)
   except psutil.Error:pass
 (R/'audit/WATCH_TERMINAL.json').write_text(json.dumps(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='OWNERS_EXITED' if not any(live(p,c) for p,c in owners.items()) else 'WATCHER_LIMIT_OR_ERROR',restored=restored),indent=2))
