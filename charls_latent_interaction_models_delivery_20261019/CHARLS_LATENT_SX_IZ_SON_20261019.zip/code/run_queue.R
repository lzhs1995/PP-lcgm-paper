# 独立原生ClaudeR队列：两个队列共享互斥引擎准入，完整家族才合并。
local({
 ROOT <- 'C:/Users/LZHS/pp_lgcm_review/charls_latent_interaction_models_20261019'
 PY <- 'C:/Users/LZHS/AppData/Local/Programs/Python/Python314/python.exe'
 queue <- Sys.getenv('PP_LGCM_QUEUE');stopifnot(queue%in%c('q1','q2'))
 say0 <- function(stage,message) {cat(format(Sys.time(),tz='UTC'),stage,message,'\n');flush.console();if(exists('clauder_progress',mode='function',inherits=TRUE))clauder_progress(stage,message)}
 writeLines(as.character(Sys.getpid()),file.path(ROOT,'runtime',paste0('BOOT_PID_',queue,'.txt')))
 say0('WAIT_PREFLIGHT',paste(queue,'native owner binding before package load'))
 pf <- file.path(ROOT,'audit',paste0('PREFLIGHT_',queue,'.json'));deadline<-Sys.time()+120
 while(!file.exists(pf)&&Sys.time()<deadline)Sys.sleep(.5)
 stopifnot(file.exists(pf))
 .libPaths(c('C:/Users/LZHS/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
 Sys.setenv(OPENBLAS_NUM_THREADS=1,MKL_NUM_THREADS=1,OMP_NUM_THREADS=4,R2E_ROOT=ROOT)
 say0('LOAD_PACKAGES',queue)
 library(jsonlite);library(ps);library(digest);library(processx);library(MplusAutomation)
 wj<-function(x,p)write_json(x,p,auto_unbox=TRUE,pretty=TRUE,digits=NA,null='null')
 say<-function(stage,message){say0(stage,message);cat(toJSON(list(at=format(Sys.time(),tz='UTC'),stage=stage,message=message),auto_unbox=TRUE),'\n',file=file.path(ROOT,'runtime',paste0('PROGRESS_',queue,'.jsonl')),append=TRUE)}
 h<-ps_handle();owner<-list(pid=Sys.getpid(),created=as.numeric(ps_create_time(h)))
 op<-file.path(ROOT,'runtime',paste0('AWAKE_OWNER_',queue,'.json'));wj(list(owner=owner),op)
 ar<-file.path(ROOT,'runtime',paste0('awake_',queue))
 awake<-processx::process$new(PY,c('-X','utf8','C:/Users/LZHS/.agents/skills/mplusautomation-guide/scripts/windows_awake_guard.py','--owner-file',op,'--output',ar,'--interval','2'),stdout=paste0(ar,'_stdout.log'),stderr=paste0(ar,'_stderr.log'),supervise=FALSE)
 release<-function(){if(dir.exists(ar))writeLines('queue terminal',file.path(ar,'stop.request'));try(awake$wait(timeout=6000),silent=TRUE);wj(list(alive=awake$is_alive(),completion=if(file.exists(file.path(ar,'completion.json')))fromJSON(file.path(ar,'completion.json'))else NULL),file.path(ROOT,'audit',paste0('AWAKE_RELEASE_',queue,'.json')))}
 source(file.path(ROOT,'code/r2e_tools.R'),local=TRUE);source(file.path(ROOT,'code/mi_pool_math.R'),local=TRUE)
 con<-fromJSON(file.path(ROOT,'contracts/RUN_CONTRACT.json'))
 reserve<-file.path(ROOT,'runtime',paste0('RESERVED_',queue));stopifnot(!file.exists(reserve));writeLines('Native queue; no duplicate resume',reserve)
 wj(list(owner=owner,queue=queue,R=R.version.string,library=find.package('MplusAutomation'),version=as.character(packageVersion('MplusAutomation')),affinity=ps_get_cpu_affinity(h)),file.path(ROOT,'audit',paste0('RUNTIME_',queue,'.json')))
 FAC<-c('IX','SX','IY','SY','IZ','SZ');OBS<-c(paste0('X',1:5),paste0('Y',1:5),paste0('Z',1:5))
 key<-function(p)vapply(seq_len(nrow(p)),function(i){a<-toupper(p$row[i]);b<-toupper(p$column[i]);mat<-tolower(p$matrix[i]);if(mat%in%c('psi','theta')){s<-sort(c(a,b));a<-s[1];b<-s[2]};paste(mat,a,b,sep=':')},'')
 run_one<-function(z,k,start){
  id<-sprintf('LATENT_%s_MI%02d_%s',toupper(z),k,start);d<-file.path(ROOT,'models',id);say('COMPILE',id)
  prep<-processx::run(PY,c('-X','utf8',file.path(ROOT,'code/prepare.py'),z,as.character(k),start),timeout=60000,error_on_status=FALSE)
  wj(list(status=prep$status,stdout=prep$stdout,stderr=prep$stderr),file.path(ROOT,'audit',paste0(id,'_COMPILE.json')))
  if(prep$status!=0)stop(paste('Compile failed',id,prep$stderr))
  j<-fromJSON(file.path(d,'job.json'));say('RUNMODELS',id);warnings<-character();err<-NULL
  withCallingHandlers(tryCatch(MplusAutomation::runModels(target=file.path(d,'model.inp'),recursive=FALSE,showOutput=TRUE,replaceOutfile='never',Mplus_command=file.path(d,'launch.cmd'),killOnFail=FALSE,logFile=file.path(d,'MplusAutomation.log')),error=function(e)err<<-conditionMessage(e)),warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')})
  wj(list(error=err,warnings=warnings),file.path(d,'R_WRAPPER_RETURN.json'))
  ans<-list(id=id,indicator=z,member=k,start=start,accepted=FALSE)
  if(!file.exists(file.path(d,'engine_receipt.json'))){ans$status<-'NO_ENGINE_RECEIPT';wj(ans,file.path(d,'receipt.json'));return(ans)}
  e<-fromJSON(file.path(d,'engine_receipt.json'));ans$engine<-e
  if(e$status=='NOT_RUN_RESOURCE_HOLD'){ans$status<-e$status;wj(ans,file.path(d,'receipt.json'));return(ans)}
  if(e$state!='EXITED'||e$exitcode!=0||!isTRUE(e$process_exited)){ans$status<-paste0('ENGINE_',e$state);wj(ans,file.path(d,'receipt.json'));return(ans)}
  say('READBACK',id)
  tryCatch({
   m<-read_mplus_raw(d);gate<-gate_r2e(m,list(kind='lms_latent',fac=FAC,obs=OBS,fixed_zero=character()));native<-MplusAutomation::readModels(file.path(d,'model.out'),what='summaries',quiet=TRUE)
   stopifnot(identical(as.integer(m$par$parameter),seq_len(m$P)))
   write.csv(m$par,file.path(d,'parameters_high_precision.csv'),row.names=FALSE);write.csv(m$spec,file.path(d,'tech1_parameter_map.csv'),row.names=FALSE);write.csv(m$values,file.path(d,'matrix_values.csv'),row.names=FALSE);write.table(m$V,file.path(d,'parameter_covariance.csv'),sep=',',row.names=FALSE,col.names=FALSE)
   wj(gate,file.path(d,'validation.json'));wj(native$summaries,file.path(d,'fit.json'))
   ans$LL<-m$extra[['H0 Loglikelihood']];ans$N<-native$summaries$Observations;ans$free_parameters<-m$P
   ans$accepted<-isTRUE(gate$passed)&&ans$N==j$N&&m$P==j$expected_free&&!any(grepl('FIXED TO AVOID SINGULARITY',m$lines,fixed=TRUE))
   ans$status<-if(ans$accepted)'USABLE'else'INADMISSIBLE_OR_CONTRACT_FAILURE'
  },error=function(e){ans$status<<-'READBACK_FAILURE';ans$error<<-conditionMessage(e)})
  if(file.exists(file.path(d,'model.out')))ans$output_sha256<-digest(file=file.path(d,'model.out'),algo='sha256')
  wj(ans,file.path(d,'receipt.json'));ans
 }
 compare<-function(z,a,b){
  da<-file.path(ROOT,'models',a$id);db<-file.path(ROOT,'models',b$id);x<-read.csv(file.path(da,'parameters_high_precision.csv'));y<-read.csv(file.path(db,'parameters_high_precision.csv'));k<-match(key(x),key(y));stopifnot(!anyNA(k),!anyDuplicated(key(x)),!anyDuplicated(key(y)),nrow(x)==127,nrow(y)==127)
  y<-y[k,];v0<-as.matrix(read.csv(file.path(da,'parameter_covariance.csv'),header=FALSE));v<-as.matrix(read.csv(file.path(db,'parameter_covariance.csv'),header=FALSE))[k,k]
  checks<-list(LL=abs(a$LL-b$LL),parameter_over_SE=max(abs(x$estimate-y$estimate)/x$se),SE_relative=max(abs(x$se-y$se)/x$se),normalized_vcov=max(abs(v-v0)/sqrt(outer(diag(v0),diag(v0)))))
  t<-con$tolerances;pass<-checks$LL<=t$LL_absolute&&checks$parameter_over_SE<=t$parameter_difference_in_reference_SE&&checks$SE_relative<=t$SE_relative&&checks$normalized_vcov<=t$normalized_vcov_difference
  wj(list(passed=pass,checks=checks,tolerances=t,reference=a$id,candidate=b$id,parameters=127),file.path(ROOT,'results',paste0(z,'_MI01_START_COMPARISON.json')));pass
 }
 pool<-function(z,calls){
  ids<-vapply(calls,function(x)x$id,'');ids<-ids[grepl('_A$',ids)];stopifnot(length(ids)==20)
  p<-read.csv(file.path(ROOT,'models',ids[1],'parameters_high_precision.csv'));keys<-key(p);Q<-matrix(NA_real_,20,127);U<-list()
  for(i in 1:20){d<-file.path(ROOT,'models',ids[i]);r<-read.csv(file.path(d,'parameters_high_precision.csv'));k<-match(keys,key(r));stopifnot(!anyNA(k));Q[i,]<-r$estimate[k];U[[i]]<-as.matrix(read.csv(file.path(d,'parameter_covariance.csv'),header=FALSE))[k,k]}
  j<-fromJSON(file.path(ROOT,'models',ids[1],'job.json'));a<-rubin_pool(Q,U);s<-rubin_pool(Q,U,j$communities-1)
  tab<-cbind(p[,c('parameter','matrix','row','column')],key=keys,a$table);sen<-cbind(p[,c('parameter','matrix','row','column')],key=keys,s$table)
  dest<-file.path(ROOT,'results',z);dir.create(dest,showWarnings=FALSE);write.csv(tab,file.path(dest,'POOLED_ALL.csv'),row.names=FALSE);write.csv(sen,file.path(dest,'POOLED_CLUSTER_DF.csv'),row.names=FALSE)
  for(n in c('W','B','T'))write.table(a[[n]],file.path(dest,paste0('POOLED_',n,'.csv')),sep=',',row.names=FALSE,col.names=FALSE)
  sel<-keys%in%c('beta:SY:SXIZ','beta:SY:SX','beta:IY:IX','beta:SY:IX','beta:IY:IZ','beta:SY:IZ','beta:SY:SZ','beta:SY:IY');write.csv(tab[sel,],file.path(dest,'POOLED_PATHS.csv'),row.names=FALSE)
  wj(list(status='COMPLETE_20_MI_WORKING_MODEL',indicator=z,N=j$N,communities=j$communities,m=20,free_parameters=127,full_covariance=TRUE,MCSE_over_SE_max_paths=max(tab$MCSE_over_SE[sel]),conditional_working_MI=TRUE,exact_congeniality_proven=FALSE,original_CFPS_four_complete=FALSE,full_H4_complete=FALSE),file.path(dest,'FAMILY_RECEIPT.json'))
 }
 tryCatch({
  for(z in con$queues[[queue]]){
   calls<-list();failed<-FALSE
   for(k in 1:20){
    starts<-if(k==1)c('A','B')else'A'
    for(start in starts){a<-run_one(z,k,start);calls[[a$id]]<-a;wj(calls,file.path(ROOT,'results',paste0(z,'_CALL_RESULTS.json')));say('MODEL_TERMINAL',paste(a$id,a$status));if(!isTRUE(a$accepted)){failed<-TRUE;break}}
    if(failed)break
    if(k==1&&!compare(z,calls[[1]],calls[[2]])){failed<-TRUE;break}
   }
   if(!failed)pool(z,calls)
   wj(list(terminal=TRUE,indicator=z,queue=queue,completed_A=sum(vapply(calls,function(x)isTRUE(x$accepted)&&x$start=='A',TRUE)),status=if(failed)'STOPPED_FAMILY_NOT_POOLABLE'else'COMPLETE_20_MI_WORKING_MODEL',original_CFPS_four_complete=FALSE,full_H4_complete=FALSE),file.path(ROOT,'results',paste0(z,'_TERMINAL.json')))
   say('FAMILY_TERMINAL',paste(z,if(failed)'not poolable'else'20-member family pooled'))
  }
  say('QUEUE_COMPLETE',queue);wj(list(terminal=TRUE,queue=queue),file.path(ROOT,'results',paste0(queue,'_TERMINAL.json')))
 },error=function(e){wj(list(error=conditionMessage(e),queue=queue,terminal=TRUE),file.path(ROOT,'results',paste0(queue,'_ERROR.json')));stop(e)},finally={release()})
 cat('INTERACTION_MI_QUEUE_DONE',queue,'\n');flush.console()
})
