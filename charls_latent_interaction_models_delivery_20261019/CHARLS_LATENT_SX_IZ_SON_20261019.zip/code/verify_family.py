"""独立原始TECH1/RESULTS/TECH3及全127参数Rubin合并；只读估计。"""
import os
for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import argparse,datetime,hashlib,json,re
import numpy as np
import pandas as pd
from scipy.stats import t as student_t
from raw_tech1 import tech1
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def key(m,a,b):
 if m.lower() in ['theta','psi']:a,b=sorted([a.upper(),b.upper()])
 return m.lower()+':'+a.upper()+':'+b.upper()
def raw(d,public=False):
 text=(d/'model.out').read_text(encoding='latin1');mp=tech1(text);n=max(x[3] for x in mp);j=read(d/'job.json');r=read(d/'receipt.json');e=read(d/'engine_receipt.json')
 assert n==127 and set(x[3] for x in mp if x[3])==set(range(1,n+1))
 assert r['status']=='USABLE' and e['state']=='EXITED' and e['process_exited'] and e['exitcode']==0
 for name,h in j['hashes'].items():
  if public and name=='data.dat':assert not (d/name).exists()
  else:assert sha(d/name)==h
 assert sha(d/'model.out')==r['output_sha256']
 for name in ['stdout','stderr']:assert sha(d/'execution'/f'{name}.log')==e[name+'_sha256']
 a=np.fromstring((d/'estimates.dat').read_text(),sep=' ');t=np.fromstring((d/'tech3.dat').read_text(),sep=' ');assert len(t)==n*(n+1)//2 and int(a[2*n])==n
 q=a[:n];se=a[n:2*n];V=np.zeros((n,n));V[np.tril_indices(n)]=t;V+=V.T-np.diag(V.diagonal())
 assert np.isfinite(a).all() and (se>0).all() and np.allclose(np.sqrt(V.diagonal()),se,atol=1e-8,rtol=1e-6)
 assert np.linalg.eigvalsh(V/np.outer(se,se)).min()>1e-10
 p=pd.read_csv(d/'parameters_high_precision.csv');assert len(p)==n
 assert np.allclose(p.estimate,q,rtol=0,atol=1e-12) and np.allclose(p.se,se,rtol=0,atol=1e-12)
 assert np.allclose(np.loadtxt(d/'parameter_covariance.csv',delimiter=','),V,rtol=1e-12,atol=1e-12)
 keys=[key(x.matrix,x.row,x.column) for x in p.itertuples()];assert len(set(keys))==n
 for i,k in enumerate(keys):
  assert {x[3] for x in mp if x[3] and key(*x[:3])==k}=={i+1}
  s=k.split(':')
  if s[0] in ['psi','theta'] and s[1]==s[2]:assert q[i]>=0
 assert 'THE MODEL ESTIMATION TERMINATED NORMALLY' in text and '*** ERROR' not in text
 assert not re.search(r'FIXED TO AVOID SINGULARITY|STANDARD ERRORS OF THE MODEL PARAMETER ESTIMATES COULD NOT BE COMPUTED',text)
 assert int(re.search(r'Number of observations\s+(\d+)',text).group(1))==j['N']
 return keys,q,se,V,a[2*n+1],e['active_seconds']
def verify(z,public=False):
 c=read(R/'contracts/RUN_CONTRACT.json');dest=R/'results'/z;rec=read(dest/'FAMILY_RECEIPT.json');assert rec['m']==20
 Q=[];U=[];ledger=[];first=None
 for k,st in [(k,'A') for k in range(1,21)]+[(1,'B')]:
  ident=f'LATENT_{z.upper()}_MI{k:02d}_{st}';keys,q,se,V,ll,seconds=raw(R/'models'/ident,public)
  if first is None:first=(keys,q,se,V,ll)
  order=[keys.index(x) for x in first[0]];q=q[order];se=se[order];V=V[np.ix_(order,order)]
  if st=='A':Q.append(q);U.append(V)
  else:
   _,aq,ase,AV,alll=first
   ch=dict(LL=float(abs(alll-ll)),parameter_over_SE=float(np.max(abs(aq-q)/ase)),SE_relative=float(np.max(abs(ase-se)/ase)),normalized_vcov=float(np.max(abs(AV-V)/np.outer(ase,ase))))
   expected=read(R/'results'/f'{z}_MI01_START_COMPARISON.json');assert expected['passed'];assert all(abs(ch[k]-expected['checks'][k])<1e-7 for k in ch)
   t=c['tolerances'];assert ch['LL']<=t['LL_absolute'] and ch['parameter_over_SE']<=t['parameter_difference_in_reference_SE'] and ch['SE_relative']<=t['SE_relative'] and ch['normalized_vcov']<=t['normalized_vcov_difference']
  ledger.append(dict(id=ident,parameters=127,engine_seconds=seconds))
 Q=np.asarray(Q);U=np.asarray(U);m=20;W=U.mean(0);B=np.cov(Q,rowvar=False,ddof=1);T=W+(1+1/m)*B;est=Q.mean(0);se=np.sqrt(T.diagonal());r=(1+1/m)*B.diagonal()/W.diagonal();lam=(1+1/m)*B.diagonal()/T.diagonal();df=(m-1)*(1+1/r)**2
 fields=['estimate','se','df','lower','upper','p','lambda','MCSE_over_SE']
 for name,dfcom in [('POOLED_ALL',np.inf),('POOLED_CLUSTER_DF',rec['communities']-1)]:
  nu=df if not np.isfinite(dfcom) else 1/(1/df+1/((dfcom+1)/(dfcom+3)*dfcom*(1-lam)))
  calc=np.column_stack([est,se,nu,est-student_t.ppf(.975,nu)*se,est+student_t.ppf(.975,nu)*se,2*student_t.sf(abs(est/se),nu),lam,np.sqrt(B.diagonal()/m)/se])
  saved=pd.read_csv(dest/(name+'.csv')).set_index('key').loc[first[0]];assert np.allclose(calc,saved[fields],rtol=2e-8,atol=1e-9)
 for n,v in [('W',W),('B',B),('T',T)]:assert np.allclose(v,np.loadtxt(dest/f'POOLED_{n}.csv',delimiter=','),rtol=1e-9,atol=1e-12)
 pd.DataFrame(ledger).to_csv(dest/'INDEPENDENT_PARAMETER_LEDGER.csv',index=False)
 out=dict(status='PASS_INDEPENDENT_RAW_AND_RUBIN',indicator=z,m=20,models=21,parameters=2667,full_covariance=True,total_engine_seconds=sum(x['engine_seconds'] for x in ledger),new_engine_calls=0,private_hashes_checked=not public,original_CFPS_four_complete=False,full_H4_complete=False)
 (dest/('PUBLIC_INDEPENDENT_VERIFICATION.json' if public else 'INDEPENDENT_VERIFICATION.json')).write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('indicator');ap.add_argument('--public',action='store_true');args=ap.parse_args();verify(args.indicator,args.public)
