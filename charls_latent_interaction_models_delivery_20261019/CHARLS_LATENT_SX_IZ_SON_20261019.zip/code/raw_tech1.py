import re
def tech1(text):
    text=text.split('PARAMETER SPECIFICATION',1)[1].split('STARTING VALUES',1)[0]
    lines=text.splitlines();result=[];i=0
    mats={'NU','LAMBDA','THETA','ALPHA','BETA','PSI','GAMMA','TAU','KAPPA'}
    while i<len(lines)-2:
        mat=lines[i].strip()
        if mat not in mats or not re.fullmatch(r'[_ ]+',lines[i+2]) or not lines[i+2].strip():i+=1;continue
        cols=lines[i+1].split();i+=3
        while i<len(lines) and lines[i].strip() and lines[i].strip() not in mats:
            tk=lines[i].split()
            if mat in {'NU','ALPHA','TAU','KAPPA'} and re.match(r'^[-+\d]',tk[0]):row='1';vals=tk
            else:row=tk[0];vals=tk[1:]
            for col,value in zip(cols,vals,strict=False):result.append((mat,row,col,int(value)))
            i+=1
    return result
