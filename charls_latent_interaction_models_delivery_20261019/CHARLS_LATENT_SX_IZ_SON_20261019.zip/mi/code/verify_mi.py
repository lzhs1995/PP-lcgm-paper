"""逐份实际DAT独立核对观测值、缺失掩码、ADL支持及来源哈希。"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import datetime,hashlib,json,sys
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1];z=sys.argv[1];D=R/'mi'/z
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
c=read(R/'contracts/RUN_CONTRACT.json');rec=read(D/'audit/MI_ADMISSION.json')
assert rec['status']=='ADMITTED_WORKING_MI' and rec['m']==20 and len(rec['XZ_products_retained'])==25
src=c['sources'][z];assert sha(src['path'])==src['sha256']
orig=pd.read_csv(D/'private/ORIGINAL_ANALYSIS.csv');assert orig.shape==(rec['N'],27)
assert list(orig.columns)==['cluster']+[f'x{i}' for i in range(1,6)]+[f'y{i}' for i in range(1,6)]+[f'c{i}' for i in range(1,12)]+[f'z{i}' for i in range(1,6)]
baseline=orig.to_numpy();col=list(orig.columns).index('c7');missing=np.isnan(baseline[:,col]);others=[i for i in range(27) if i!=col]
assert missing.sum()==rec['missing_ADL'];donors=set(baseline[~missing,col])
members=pd.read_csv(D/'audit/MI_MEMBERS.csv');assert list(members.member)==list(range(1,21))
for row in members.itertuples():
 p=D/'private'/f'MI{row.member:02d}.dat';assert sha(p)==row.sha256
 a=np.loadtxt(p);a[a==-9999]=np.nan;assert a.shape==baseline.shape
 assert np.array_equal(np.isnan(a[:,others]),np.isnan(baseline[:,others]))
 assert np.allclose(a[:,others],baseline[:,others],equal_nan=True,atol=1e-10,rtol=0)
 assert np.array_equal(a[~missing,col],baseline[~missing,col])
 assert set(a[missing,col])<=donors and np.isfinite(a[:,col]).all()
pred=pd.read_csv(D/'audit/PREDICTORS_ACTUAL.csv',index_col=0)
assert all(pred.loc['adl',n]==1 for n in rec['XZ_products_retained']) and pred.loc['adl','cluster']==-2
out=dict(status='PASS',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),indicator=z,N=rec['N'],m=20,missing_ADL=int(missing.sum()),verified_DAT_files=20,columns=27,observed_ADL_unchanged=True,other_columns_and_masks_unchanged=True,all_25_XZ_products_retained=True,source_sha256=src['sha256'],compatibility=c['compatibility'])
(D/'audit/INDEPENDENT_MI.json').write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True)
