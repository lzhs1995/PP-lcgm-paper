# 依赖：由调用文件给定SCOPE；仅补基期ADL，不改分析XYZ及其缺失掩码。
local({
 BATCH<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_interaction_mi_20261019'
 z<-get('SCOPE',inherits=TRUE);stopifnot(z%in%c('sd','gender','oldest','son'))
 ROOT<-file.path(BATCH,'mi',z)
 Sys.setenv(OPENBLAS_NUM_THREADS=1,MKL_NUM_THREADS=1,OMP_NUM_THREADS=1)
 if(exists('clauder_progress',mode='function',inherits=TRUE))clauder_progress('MI_PREFLIGHT',paste(z,'waiting for owned-worker resource admission'))
 stopifnot(!file.exists(file.path(ROOT,'private/MIDS.rds')))
 writeLines(as.character(Sys.getpid()),file.path(ROOT,'runtime/BOOT_PID.txt'));t0<-Sys.time()
 while(!file.exists(file.path(ROOT,'audit/PREFLIGHT.json'))) {
   if(as.numeric(difftime(Sys.time(),t0,units='secs'))>120)stop('No external owned-worker preflight')
   Sys.sleep(1)
 }
 .libPaths(c('C:/Users/LZHS/pp_lgcm_review/charls_income_mi_pilot_20261016/library','C:/Users/LZHS/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
 library(jsonlite);library(digest);library(mice);library(miceadds);library(lme4);library(ps)
 pf<-fromJSON(file.path(ROOT,'audit/PREFLIGHT.json'))
 stopifnot(pf$owner$pid==Sys.getpid(),abs(as.numeric(ps_create_time(ps_handle()))-as.numeric(pf$owner$created_exact))<1e-6)
 c<-fromJSON(file.path(BATCH,'contracts/RUN_CONTRACT.json'));src<-c$sources[[z]]
 stopifnot(digest(file=src$path,algo='sha256')==src$sha256,!file.exists(file.path(ROOT,'private/MIDS.rds')))
 a<-readRDS(src$path);cc<-a$data;original<-a$analysis
 stopifnot(identical(names(which(colSums(is.na(cc))>0)),'adl'),identical(original$c7,cc$adl))
 required<-character();product_masks<-character()
 for(i in 1:5)for(j in 1:5) {
   xn<-paste0('obs_x',i);zn<-if(j==1)'z0'else paste0('obs_z',j)
   xmiss<-if(i==1)rep(FALSE,nrow(cc)) else cc[[paste0('missing_x',i)]]==1
   zmiss<-if(j==1)rep(FALSE,nrow(cc)) else cc[[paste0('missing_z',j)]]==1
   name<-paste0('xz_',i,'_',j);mask<-paste0('xz_missing_',i,'_',j)
   cc[[name]]<-cc[[xn]]*cc[[zn]];cc[[mask]]<-as.numeric(xmiss|zmiss)
   required<-c(required,name);product_masks<-c(product_masks,mask)
 }
 stopifnot(!anyNA(cc[setdiff(names(cc),'adl')]))
 method<-make.method(cc);method[]<-'';method['adl']<-'2l.pmm.cached'
 pm<-matrix(0,ncol(cc),ncol(cc),dimnames=list(names(cc),names(cc)));pm['adl',setdiff(names(cc),c('adl','cluster'))]<-1;pm['adl','cluster']<--2
 saveRDS(list(data=cc,analysis=original,source=src,method=method,predictorMatrix=pm,required_products=required),file.path(ROOT,'private/MI_INPUTS.rds'))
 write.table(original,file.path(ROOT,'private/ORIGINAL_ANALYSIS.csv'),sep=',',row.names=FALSE,col.names=TRUE,na='NA',quote=FALSE)
 source(file.path(BATCH,'code/mi_exact_fit_cache.R'),local=TRUE)
 if(exists('clauder_progress',mode='function',inherits=TRUE))clauder_progress('ADL_PRODUCT_AUXILIARY_MI',paste(z,'one conditional fit; 20 fresh parameter and donor draws'))
 warnings<-character();imp<-withCallingHandlers(mice(cc,m=c$m,maxit=c$maxit,method=method,predictorMatrix=pm,
   seed=src$seed,donors=c$donors,remove.collinear=TRUE,printFlag=FALSE),warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')})
 saveRDS(imp,file.path(ROOT,'private/MIDS.rds'));saveRDS(.Random.seed,file.path(ROOT,'private/RNG_FINAL.rds'))
 fit<-readRDS(file.path(ROOT,'private/MI_ADL_CONDITIONAL_LMER.rds'));observed<-!is.na(cc$adl)
 rows<-list()
 for(k in seq_len(c$m)) {
   v<-complete(imp,k);stopifnot(identical(v$adl[observed],cc$adl[observed]),all(v$adl%in%0:6),all(v$adl[!observed]%in%cc$adl[observed]))
   for(n in setdiff(names(v),'adl'))stopifnot(identical(v[[n]],cc[[n]]))
   d<-original;d$c7<-v$adl;stopifnot(identical(d[setdiff(names(d),'c7')],original[setdiff(names(original),'c7')]))
   p<-file.path(ROOT,'private',sprintf('MI%02d.dat',k));write.table(d,p,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
   got<-as.matrix(read.table(p,na.strings='-9999'));want<-as.matrix(d);stopifnot(identical(unname(is.na(got)),unname(is.na(want))),max(abs(got-want),na.rm=TRUE)<1e-10)
   rows[[k]]<-data.frame(member=k,N=nrow(d),sha256=digest(file=p,algo='sha256'),ADL_imputed_mean=mean(v$adl[!observed]),XYZ_unchanged=TRUE)
 }
 write.csv(do.call(rbind,rows),file.path(ROOT,'audit/MI_MEMBERS.csv'),row.names=FALSE)
 write.csv(data.frame(variable=rownames(imp$predictorMatrix),imp$predictorMatrix,check.names=FALSE),file.path(ROOT,'audit/PREDICTORS_ACTUAL.csv'),row.names=FALSE)
 if(!is.null(imp$loggedEvents))write.csv(imp$loggedEvents,file.path(ROOT,'audit/LOGGED_EVENTS.csv'),row.names=FALSE)
 writeLines(warnings,file.path(ROOT,'audit/MI_WARNINGS.txt'))
 retained<-required[imp$predictorMatrix['adl',required]!=0]
 fit_ok<-is.null(fit@optinfo$conv$lme4$messages)&&fit@optinfo$conv$opt==0
 pass<-fit_ok&&length(retained)==25&&cache_env$misses==1&&cache_env$hits==19&&imp$predictorMatrix['adl','cluster']==-2
 rec<-list(status=if(pass)'ADMITTED_WORKING_MI'else'NOT_ADMITTED',indicator=z,N=nrow(cc),communities=length(unique(cc$cluster)),m=20,
   missing_ADL=sum(!observed),fit_ok=fit_ok,singular=isSingular(fit),cache_misses=cache_env$misses,fresh_draws=cache_env$misses+cache_env$hits,
   XZ_products_requested=required,XZ_products_retained=retained,dropped_required=setdiff(required,retained),
   source_sha256=src$sha256,XYZ_masks_preserved=TRUE,compatible_claim=c$compatibility,original_four_complete=FALSE,full_H4_complete=FALSE)
 write_json(rec,file.path(ROOT,'audit/MI_ADMISSION.json'),auto_unbox=TRUE,pretty=TRUE,digits=NA,na='null')
 stopifnot(digest(file=src$path,algo='sha256')==src$sha256)
 if(exists('clauder_progress',mode='function',inherits=TRUE))clauder_progress('MI_SCOPE_TERMINAL',paste(z,rec$status,'no Mplus launched'))
 cat('INTERACTION_ADL_MI_DONE',z,rec$status,'\n');flush.console()
})
