# 四个已核实名册范围的CHARLS观测基期调节小试；保留失败，禁止自动扩大预算。
.libPaths(c('<LOCAL_USER_HOME>/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
library(jsonlite);library(digest);library(processx);library(ps);library(MplusAutomation)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_observed_moderation_20261016'
Sys.setenv(R2E_ROOT=ROOT);source(file.path(ROOT,'code/r2e_local.R'),local=TRUE)
entries<-rj(file.path(ROOT,'contracts/DATA_ENTRIES.json'));contract<-rj(file.path(ROOT,'contracts/RUN_CONTRACT.json'))
growth<-function(p)paste0('i',p,' s',p,' | ',p,'1@0 ',p,'2@2 ',p,'3@4 ',p,'4@7 ',p,'5@9;')
base<-c(growth('x'),growth('y'),'iy ON ix (bii);','sy ON ix (bis);','sy ON sx (bss);','sy ON iy (bsyiy);',
 'ix WITH sx;','sx WITH iy;',paste0('x',1:5,' WITH y',1:5,';'),'ix sx iy sy ON c1-c11;',
 'ix sx ON z0;','iy ON z0 (gi0);','sy ON z0 (gs0);','x1 y1 ON z0;')
specification<-function(type){list(kind=if(type=='E0')'linear'else'lms_observed',fac=FAC_XY,obs=OBS_XY,fixed_zero=character(),
 use='x1-x5 y1-y5 c1-c11 z0',model=c(base,if(type=='E1')c('sxz | sx XWITH z0;','sy ON sxz (dc);')),
 key=rbind(KEY_XY,key_add('gi0','IY','Z0'),key_add('gs0','SY','Z0'),if(type=='E1')key_add('dc','SY','SXZ')))}
# 固定线性时间载荷，不继承CFPS自由载荷的起点槽位。
slots<-function(si){
 rows<-list();add<-function(op,lhs,rhs='',init=0){rows[[length(rows)+1L]]<<-data.frame(op=op,lhs=toupper(lhs),rhs=toupper(rhs),init=init)}
 for(f in FAC_XY)add('MEAN',f)
 for(o in OBS_XY)add('VAR',o,init=.5)
 for(f in FAC_XY)add('VAR',f,init=.1)
 for(key in stmt_pairs(si$model)){tk<-strsplit(toupper(key),' ',fixed=TRUE)[[1]];add(tk[2],tk[1],tk[3])}
 a<-do.call(rbind,rows);a$key<-paste(a$op,a$lhs,a$rhs,sep=':');stopifnot(!anyDuplicated(a$key));a
}
extract_paths<-function(m,key){do.call(rbind,lapply(seq_len(nrow(key)),function(i){k<-key[i,];id<-pnum(m,'BETA',k$row,k$column);if(id==0)id<-pnum(m,'GAMMA',k$row,k$column);stopifnot(id>0);p<-m$par[m$par$parameter==id,];stopifnot(nrow(p)==1);data.frame(k,parameter=id,estimate=p$estimate,se=p$se)}))}
prepare<-function(z,type,start='A'){
 e<-entries[[z]];id<-paste0('CHARLS_',toupper(z),'_',type,'_',start);d<-file.path(ROOT,'models',id);dir.create(d,showWarnings=FALSE)
 if(file.exists(file.path(d,'job.json')))return(rj(file.path(d,'job.json')))
 stopifnot(identical(hashf(e$data_file),e$data_sha256));si<-specification(type)
 source_dir<-if(type=='E0')'<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015/models/CHARLS_CC_COMMUNITY'else file.path(ROOT,'models',paste0('CHARLS_',toupper(z),'_E0_A'))
 # 两个交互起点均来自E0，而不是从一个交互终点续跑。
 mm<-make_model(si,source_dir,perturb=start=='B')
 if(type=='E1'){
  hit<-which(mm$mapping$key=='ON:SY:SXZ');stopifnot(length(hit)==1)
  mm$mapping$value[hit]<-if(start=='A').1 else -.1
  mm$lines[length(si$model)+hit]<-paste0('sy ON sxz*',mm$mapping$value[hit],';')
 }
 csv(mm$mapping,file.path(d,'start_mapping.csv'))
 nms<-unlist(e$columns);a<-read.table(e$data_file,col.names=nms,na.strings='-9999');stopifnot(nrow(a)==e$N,!anyNA(a[c('cluster','z0',paste0('c',1:11))]),all(vapply(a[c('z0',paste0('c',1:11))],function(v)sd(v)>0,TRUE)))
 analysis<-if(type=='E0')c('TYPE=COMPLEX; ESTIMATOR=MLR; PROCESSORS=1;','ITERATIONS=2000; COVERAGE=.005;')else c('TYPE=COMPLEX RANDOM; ESTIMATOR=MLR; PROCESSORS=1;','ALGORITHM=INTEGRATION; INTEGRATION=30; MCSEED=26101601;','ITERATIONS=2000; MITERATIONS=4000; COVERAGE=.005;','LOGCRITERION=.00001; RLOGCRITERION=.000000001; MCONVERGENCE=.00001;')
 lines<-c(paste0('TITLE: ',id,' verified roster complete-case feasibility;'),'DATA: FILE=data.dat;','VARIABLE:',wrap90(paste('NAMES=',paste(nms,collapse=' '),';')),'USEVARIABLES=x1-x5 y1-y5 c1-c11 z0;','MISSING=ALL(-9999);','CLUSTER=cluster;','ANALYSIS:',analysis,'MODEL:',mm$lines,'OUTPUT: TECH1 TECH3 TECH4 TECH8 SVALUES CINTERVAL;','SAVEDATA: RESULTS=estimates.dat; TECH3=tech3.dat;')
 stopifnot(all(nchar(lines)<=90),!any(grepl('BY.*\\*',mm$lines)),length(setdiff(stmt_pairs(si$model),stmt_pairs(mm$lines)))==0)
 writeLines(lines,file.path(d,'model.inp'));stopifnot(file.copy(e$data_file,file.path(d,'data.dat')))
 j<-list(id=id,root=ROOT,dest=d,z=z,type=type,start=start,N=e$N,communities=e$communities,expected_free=mm$expected_free,category='CHARLS',cap_seconds=240,
  source_start=source_dir,rscript=file.path(R.home('bin'),'Rscript.exe'),mplus=MPLUS,zpoints=sort(unique(c(range(a$z0),0,-e$z_mean/e$z_sd,quantile(a$z0,c(.1,.5,.9),names=FALSE)))),
  hashes=list(model.inp=hashf(file.path(d,'model.inp')),data.dat=hashf(file.path(d,'data.dat'))));wj(j,file.path(d,'job.json'));j
}
review<-function(j){
 er<-rj(file.path(j$dest,'engine_receipt.json'));if(is.null(er))return(list(id=j$id,status='NOT_RUN_RESOURCE_OR_BUDGET',detail=rj(file.path(j$dest,'not_run.json'))))
 res<-list(id=j$id,z=j$z,type=j$type,start=j$start,status=er$status,engine_status=er$status,seconds=er$seconds,full_MI=FALSE,N_expected=j$N,source_scope='verified roster/core complete case')
 if(er$status=='EXITED')tryCatch({
  n<-MplusAutomation::readModels(file.path(j$dest,'model.out'),what='all',quiet=TRUE);saveRDS(n,file.path(j$dest,'native_readback.rds'))
  m<-read_mplus_raw(j$dest);si<-specification(j$type);gt<-gate_r2e(m,si,unlist(j$zpoints))
  res$status<-if(isTRUE(gt$passed))'USABLE_SINGLE_DATASET'else'INADMISSIBLE';res$negative<-gt$negative;res$fit<-n$summaries;res$N<-n$summaries$Observations;res$LL<-m$extra[['H0 Loglikelihood']];res$parameters<-nrow(m$par)
  if(any(grepl('FIXED TO AVOID SINGULARITY',m$lines,fixed=TRUE)))res$status<-'AUTOFIX_REJECTED'
  if(res$N!=j$N)res$status<-'SAMPLE_MISMATCH'
  if(res$parameters!=j$expected_free)res$status<-'PARAMETER_CONTRACT_MISMATCH'
  wj(gt,file.path(j$dest,'validation.json'));csv(m$par,file.path(j$dest,'parameters_high_precision.csv'));csv(m$values,file.path(j$dest,'matrix_values.csv'));csv(m$spec,file.path(j$dest,'tech1_parameter_map.csv'))
  write.table(m$V,file.path(j$dest,'parameter_covariance.csv'),sep=',',row.names=FALSE,col.names=FALSE)
  csv(extract_paths(m,si$key),file.path(j$dest,'key_paths.csv'))
 },error=function(e){res$status<<-'READBACK_OR_ESTIMATION_FAILURE';res$error<<-conditionMessage(e)})
 res$output_sha256<-if(file.exists(file.path(j$dest,'model.out')))hashf(file.path(j$dest,'model.out'))else NULL
 wj(res,file.path(j$dest,'receipt.json'));res
}
run<-function(j){
 if(file.exists(file.path(j$dest,'receipt.json')))return(rj(file.path(j$dest,'receipt.json')))
 progress('charls_estimate_start',j$id)
 p<-processx::process$new(PY,c('-X','utf8',file.path(ROOT,'code/engine.py'),file.path(j$dest,'job.json')),stdout=file.path(j$dest,'supervisor.log'),stderr='2>&1',cleanup=TRUE)
 last<-0;while(p$is_alive()){p$wait(1000L);if(as.numeric(Sys.time())-last>25){h<-rj(file.path(ROOT,'runtime/progress.json'));if(exists('clauder_progress',mode='function'))clauder_progress('charls_estimating',paste(j$id,if(is.null(h))'starting'else h$elapsed_seconds));last<-as.numeric(Sys.time())}}
 progress('charls_readback',j$id);r<-review(j);progress('charls_estimate_end',paste(j$id,r$status));r
}
compare_starts<-function(z){
 read<-function(s){d<-file.path(ROOT,'models',paste0('CHARLS_',toupper(z),'_E1_',s));list(receipt=rj(file.path(d,'receipt.json')),key=read.csv(file.path(d,'key_paths.csv')))}
 a<-read('A');b<-read('B');v<-compare_numeric(a,b,'start',list(start_LL=.01,start_path_abs=.001,start_path_se=.05,integration_path_se=.05,se_rel=.05));wj(v,file.path(ROOT,'results',paste0(toupper(z),'_START_COMPARISON.json')));v
}
main<-function(){
 start_time<-Sys.time();owner<-ps::ps_handle();stop_file<-file.path(ROOT,'runtime/BATCH_TERMINAL')
 guard<-processx::process$new(PY,c('-X','utf8',file.path(ROOT,'code/coordinator_awake.py'),'--owner-pid',Sys.getpid(),'--owner-created',as.numeric(ps::ps_create_time(owner)),'--receipt',file.path(ROOT,'runtime/BATCH_AWAKE.json'),'--max-seconds','3600','--stop-file',stop_file),stdout=file.path(ROOT,'runtime/awake.log'),stderr='2>&1',cleanup=FALSE)
 on.exit(writeLines('Coordinator terminal; release execution request',stop_file),add=TRUE)
 wj(list(pid=Sys.getpid(),created=as.numeric(ps::ps_create_time(owner)),started=as.character(start_time)),file.path(ROOT,'runtime/coordinator.json'))
 writeLines(capture.output(sessionInfo()),file.path(ROOT,'audit/R_SESSION_INFO.txt'))
 results<-list();families<-list()
 for(z in names(entries)){
  if(as.numeric(difftime(Sys.time(),start_time,units='secs'))>3600)break
  j<-prepare(z,'E0');r<-run(j);results[[j$id]]<-r;wj(results,file.path(ROOT,'results/CALL_RESULTS.json'))
  families[[z]]<-list(parent=r$status,interaction='NOT_RUN_INVALID_PARENT',full_MI=FALSE)
  if(r$status=='USABLE_SINGLE_DATASET'){
   for(s in c('A','B')){
    if(as.numeric(difftime(Sys.time(),start_time,units='secs'))>3360)break
    j<-prepare(z,'E1',s);r<-run(j);results[[j$id]]<-r;wj(results,file.path(ROOT,'results/CALL_RESULTS.json'))
    families[[z]]$interaction<-r$status
    if(r$status!='USABLE_SINGLE_DATASET')break
    if(s=='B'){v<-compare_starts(z);families[[z]]$interaction<-if(isTRUE(v$passed))'TWO_STARTS_USABLE_SINGLE_DATASET'else'START_DIFFERENCE_RETAINED_NO_RETRY'}
   }
  }
  wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'))
 }
 progress('CHARLS_OBSERVED_TERMINAL','Four registered scopes adjudicated; no complete MI or manuscript adoption implied');cat('CHARLS_OBSERVED_TERMINAL\n')
}
if(!identical(Sys.getenv('CHARLS_PREPARE_ONLY'),'1'))main()
