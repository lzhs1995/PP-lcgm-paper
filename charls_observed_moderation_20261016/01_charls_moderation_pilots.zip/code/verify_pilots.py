"""直接解析原始TECH1、RESULTS和TECH3，独立核验R汇总；公开包可复用。"""
from pathlib import Path
import csv,hashlib,json,re
import numpy as np
import pandas as pd
from scipy.stats import norm

ROOT=Path(__file__).resolve().parents[1]
def read_json(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def tech1(text):
    text=text.split('PARAMETER SPECIFICATION',1)[1].split('STARTING VALUES',1)[0]
    lines=text.splitlines();result=[];i=0
    mats={'NU','LAMBDA','THETA','ALPHA','BETA','PSI','GAMMA','TAU','KAPPA'}
    while i<len(lines)-2:
        mat=lines[i].strip()
        if mat not in mats or not re.fullmatch(r'[_ ]+',lines[i+2]) or not lines[i+2].strip():i+=1;continue
        cols=lines[i+1].split();i+=3
        while i<len(lines) and lines[i].strip() and lines[i].strip() not in mats:
            tk=lines[i].split()
            if mat in {'NU','ALPHA','TAU','KAPPA'} and re.match(r'^[-+\d]',tk[0]):row='1';vals=tk
            else:row=tk[0];vals=tk[1:]
            for col,value in zip(cols,vals,strict=False):result.append((mat,row,col,int(value)))
            i+=1
    return result
def raw_model(d):
    out=(d/'model.out').read_text(encoding='latin1');mapping=tech1(out)
    n=max(r[3] for r in mapping);assert set(r[3] for r in mapping if r[3])==set(range(1,n+1))
    q=np.fromstring((d/'estimates.dat').read_text(),sep=' ');t=np.fromstring((d/'tech3.dat').read_text(),sep=' ')
    assert len(q)>=2*n and len(t)==n*(n+1)//2
    v=np.zeros((n,n));ix=np.tril_indices(n);v[ix]=t;v=v+v.T-np.diag(v.diagonal())
    assert np.allclose(np.sqrt(v.diagonal()),q[n:2*n],rtol=1e-6,atol=1e-8)
    p=pd.read_csv(d/'parameters_high_precision.csv').sort_values('parameter')
    assert len(p)==n and np.allclose(p.estimate,q[:n],atol=1e-12) and np.allclose(p.se,q[n:2*n],atol=1e-12)
    assert np.allclose(pd.read_csv(d/'parameter_covariance.csv',header=None),v,rtol=1e-12,atol=1e-12)
    k=pd.read_csv(d/'key_paths.csv')
    for r in k.itertuples():
        matches={m[3] for m in mapping if m[0] in {'BETA','GAMMA'} and m[1:3]==(r.row,r.column) and m[3]>0}
        assert matches=={r.parameter},(d.name,r.label,matches)
        assert np.allclose([r.estimate,r.se],[q[r.parameter-1],q[n+r.parameter-1]],atol=1e-12)
    return out,mapping,q[:n],q[n:2*n],v,k,q[2*n+1]
def run():
    calls=read_json(ROOT/'results/CALL_RESULTS.json');families=read_json(ROOT/'results/FAMILY_STATUS.json')
    assert len(families)==4
    paths=pd.read_csv(ROOT/'results/ALL_PATHS_WALD.csv');slopes=pd.read_csv(ROOT/'results/CONDITIONAL_SLOPES.csv')
    details={};parsed={};geometry_count=0
    for name,r in calls.items():
        d=ROOT/'models'/name;out=(d/'model.out').read_text(encoding='latin1')
        assert sha(d/'model.out')==r['output_sha256']
        if r['status']!='USABLE_SINGLE_DATASET':details[name]={'status':r['status'],'not_adopted':True};continue
        out,mp,q,se,v,k,ll=raw_model(d);parsed[name]=(q,se,v,k,ll)
        assert 'THE MODEL ESTIMATION TERMINATED NORMALLY' in out and 'FIXED TO AVOID SINGULARITY' not in out
        assert not any(q[p-1]<0 for mat,a,b,p in mp if mat in {'PSI','THETA'} and a==b and p>0)
        corr=v/np.outer(np.sqrt(v.diagonal()),np.sqrt(v.diagonal()));emin=float(np.linalg.eigvalsh(corr).min());assert emin>0
        for label,mat in read_json(d/'validation.json')['geometry']['matrices'].items():
            if label not in {'PSI','THETA'} and not label.startswith('COND_'):continue
            a=np.asarray(mat);assert np.allclose(a,a.T);assert np.linalg.eigvalsh(a).min()>-1e-10;geometry_count+=1
        for kr in k.itertuples():
            ref=paths[(paths.model==name)&(paths.label==kr.label)];assert len(ref)==1
            est=q[kr.parameter-1];sd=se[kr.parameter-1];calc=[est,sd,est-norm.ppf(.975)*sd,est+norm.ppf(.975)*sd,2*norm.sf(abs(est/sd))]
            assert np.allclose(ref[['estimate','se','lower','upper','p']].iloc[0],calc,rtol=1e-9,atol=1e-12)
        sub=slopes[slopes.model==name]
        if not sub.empty:
            ids=k.set_index('label').loc[['bss','dc'],'parameter'].to_numpy(dtype=int)-1
            a=np.c_[np.ones(len(sub)),sub.z];est=a@q[ids];sd=np.sqrt(np.einsum('ij,jk,ik->i',a,v[np.ix_(ids,ids)],a))
            assert np.allclose(sub[['estimate','se','lower','upper']],np.c_[est,sd,est-norm.ppf(.975)*sd,est+norm.ppf(.975)*sd],rtol=1e-9,atol=1e-12)
        details[name]={'status':'PASS','free_parameters':len(q),'key_paths':len(k),'conditional_points':len(sub),'vcov_correlation_min_eigen':emin}
    comparisons={}
    for z,f in families.items():
        names=[f'CHARLS_{z.upper()}_E1_{s}' for s in ['A','B']]
        if not all(n in parsed for n in names):continue
        a,b=(parsed[n] for n in names);ka=a[3].set_index('label');kb=b[3].set_index('label').loc[ka.index]
        delta=(ka.estimate-kb.estimate).abs();tol=np.maximum(.001,.05*np.maximum(ka.se,kb.se))
        sr=(ka.se-kb.se).abs()/np.maximum(ka.se,kb.se)
        passed=bool(abs(a[4]-b[4])<=.01 and (delta<=tol).all() and (sr<=.05).all())
        old=read_json(ROOT/'results'/f'{z.upper()}_START_COMPARISON.json');assert passed==old['passed']
        comparisons[z]={'passed':passed,'LL_difference':float(abs(a[4]-b[4])),'max_key_path_difference_over_SE':float((delta/np.maximum(ka.se,kb.se)).max()),'max_all_parameter_difference_over_SE':float(np.max(abs(a[0]-b[0])/np.maximum(a[1],b[1])))}
    result={'status':'PASS','models':details,'start_comparisons':comparisons,'geometry_matrices_checked':geometry_count,'path_rows':len(paths),'conditional_rows':len(slopes),'boundary':'Independent saved-result arithmetic and parameter identity; no microdata re-fit or complete MI claim'}
    (ROOT/'audit/INDEPENDENT_PILOT_VERIFICATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':run()
