"""逐文件白名单，发布统计参数DAT而不发布个人data.dat。"""
from pathlib import Path
import csv,hashlib,io,json,re,zipfile
R=Path(__file__).resolve().parents[1];S=R/'public_stage';S.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda x:hashlib.sha256(x).hexdigest()
assert read(R/'audit/CLAUDER_COMPLETION.json')['decision']=='PASS'
assert read(R/'audit/INDEPENDENT_PILOT_VERIFICATION.json')['status']=='PASS'
assert read(R/'audit/TERMINAL_CHECK.json')['status']=='PASS'
files='''reports/REPORT.md
reports/FOR_WEB_REVIEWERS.md
reports/BATCH_RECEIPT.json
contracts/RUN_CONTRACT.json
contracts/DATA_ENTRIES.json
results/CALL_RESULTS.json
results/FAMILY_STATUS.json
results/ALL_PATHS_WALD.csv
results/CONDITIONAL_SLOPES.csv
results/MODERATION_SUMMARY.csv
results/ENGINE_RESOURCES.csv
results/CONDITIONAL_SLOPES.png
results/CONDITIONAL_SLOPES.pdf
audit/INPUT_INTEGRITY.csv
audit/TERMINAL_CHECK.json
audit/INDEPENDENT_PILOT_VERIFICATION.json
audit/CLAUDER_COMPLETION.json
audit/R_SESSION_INFO.txt
runtime/BATCH_AWAKE.json
runtime/budget_status.json
runtime/native_terminal.json
code/observed_pilots.R
code/run_one.R
code/engine.py
code/coordinator_awake.py
code/r2e_local.R
code/r2e_tools.R
code/r2e_upstream_math.R
code/summarize_pilots.R
code/verify_pilots.py
code/finalize_batch.py
code/package_batch.py
code/verify_public_bundle.py'''.splitlines()
calls=read(R/'results/CALL_RESULTS.json');families=read(R/'results/FAMILY_STATUS.json')
for z in families:
 p=f'results/{z.upper()}_START_COMPARISON.json'
 if (R/p).exists():files.append(p)
roles={}
for name,c in calls.items():
 for b in ['model.inp','model.out','engine_receipt.json','receipt.json','job.json','start_mapping.csv','mplus_execution.log','validation.json','parameters_high_precision.csv','matrix_values.csv','tech1_parameter_map.csv','parameter_covariance.csv','key_paths.csv','estimates.dat','tech3.dat']:
  p=f'models/{name}/{b}'
  if (R/p).exists():files.append(p)
  roles[p]='model_parameters' if b=='estimates.dat' else 'parameter_covariance' if b=='tech3.dat' else 'aggregate_model_evidence'
payload={};manifest=[]
for name in files:
 p=R/name;assert p.is_file(),name
 assert not name.startswith('private/') and p.name!='data.dat' and p.suffix.lower() not in {'.rds','.dta'}
 raw=p.read_bytes()
 if p.suffix in {'.png','.pdf'}:data=raw
 else:
  text=raw.decode('utf-8-sig')
  for prefix in ['<LOCAL_USER_HOME>','<LOCAL_USER_HOME>','C:\\\\Users\\\\LZHS','<LOCAL_USER_HOME>','<LOCAL_USER_HOME>']:text=text.replace(prefix,'<LOCAL_USER_HOME>')
  assert not re.search(r'(?i)(?:api[_-]?key|access_token)\s*[:=]\s*["\']?[A-Za-z0-9_-]{20,}',text),name
  if p.suffix=='.csv' and p.name!='parameter_covariance.csv':
   header=next(csv.reader(io.StringIO(text)));assert not {h.lower() for h in header}&{'pid','fid','childid','householdid','communityid'},name
  data=text.encode('utf-8')
 payload[name]=data;manifest.append({'path':name,'bytes':len(data),'sha256':sha(data),'local_source_sha256':sha(raw),'paths_redacted':data!=raw,'role':roles.get(name,'aggregate_report_or_code')})
payload['PAYLOAD_MANIFEST.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
zpath=S/'01_charls_moderation_pilots.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,data in payload.items():z.writestr(name,data)
assert zpath.stat().st_size<25_000_000
with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
pm={'packages':[{'file':zpath.name,'bytes':zpath.stat().st_size,'sha256':sha(zpath.read_bytes()),'files':len(payload)}],'payload_files':len(payload),'privacy':'Explicit per-file roles; estimates.dat/tech3.dat are model parameters, NOT individual data; no individual data.dat/DTA/RDS/MI; personal paths redacted'}
(S/'PACKAGE_MANIFEST.json').write_text(json.dumps(pm,ensure_ascii=False,indent=2),encoding='utf-8')
for n in ['REPORT.md','FOR_WEB_REVIEWERS.md','BATCH_RECEIPT.json']:(S/n).write_bytes(payload['reports/'+n])
for n in ['MODERATION_SUMMARY.csv','CONDITIONAL_SLOPES.png','CONDITIONAL_SLOPES.pdf']:(S/n).write_bytes(payload['results/'+n])
(S/'README.md').write_text('''# CHARLS四项基期调节小试

**四项调节完整推断、完整 H4 仍未完成。**

[本批报告](REPORT.md) · [网页端说明](FOR_WEB_REVIEWERS.md) · [实际调用回执](BATCH_RECEIPT.json) · [结果表](MODERATION_SUMMARY.csv) · [条件曲线](CONDITIONAL_SLOPES.pdf)

本批仅为已核实名册和原始核心控制完整的四个范围估计父模型与单个交互，两套起点不算多重插补。H4.1已有三个十份条件家族、CHARLS核心20份与资源40份MI，均复用既有固定证据。未重跑旧CFPS失败输入，未修改收尾稿。

ZIP小于25MB；解压后`python code/verify_public_bundle.py`检查哈希，`python code/verify_pilots.py`直接解析保存参数、TECH1与TECH3复算区间。后者需numpy/pandas/scipy，不拟合微观数据。个人data.dat及MI不公开；estimates.dat、tech3.dat只是模型统计参数。源码本机路径已脱敏。

经验沉淀见[mplusautomation-guide PR25](https://github.com/lzhs1995/clauder-rstudio-workbench/pull/25)。
''',encoding='utf-8')
(R/'audit/PUBLIC_FILE_SELECTION.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(pm,ensure_ascii=False))
