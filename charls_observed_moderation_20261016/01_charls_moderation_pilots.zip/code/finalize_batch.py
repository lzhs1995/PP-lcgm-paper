"""汇总本批边界、资源与输入身份；不重估，不修改历史数据。"""
from pathlib import Path
import datetime,hashlib,json,sqlite3
import pandas as pd
import psutil
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
calls=read(R/'results/CALL_RESULTS.json');fam=read(R/'results/FAMILY_STATUS.json');contract=read(R/'contracts/RUN_CONTRACT.json')
assert len(fam)==4 and (R/'runtime/BATCH_TERMINAL').exists()
budget=read(R/'runtime/budget_status.json');assert len(budget['rows'])<=contract['max_calls'] and budget['engine_seconds']<=contract['total_engine_seconds']
assert read(R/'audit/INDEPENDENT_PILOT_VERIFICATION.json')['status']=='PASS'
con=sqlite3.connect(f'file:{(R/"runtime/budget.sqlite").as_posix()}?mode=ro',uri=True)
assert con.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
assert con.execute('SELECT count(*) FROM calls WHERE seconds IS NULL').fetchone()[0]==0;con.close()
entries=read(R/'contracts/DATA_ENTRIES.json');checks=[];resources=[];owned=[]
for name,c in calls.items():
 d=R/'models'/name;j=read(d/'job.json');e=read(d/'engine_receipt.json')
 for file,h in j['hashes'].items():assert sha(d/file)==h;checks.append({'model':name,'file':file,'sha256':h,'status':'PASS'})
 assert sha(d/'data.dat')==entries[j['z']]['data_sha256']==sha(entries[j['z']]['data_file'])
 assert sha(d/'model.out')==c['output_sha256']==e['output_sha256']
 for line in (d/'resources.jsonl').read_text().splitlines():
  for p in json.loads(line)['processes']:
   if p['name'].lower()=='mplus.exe':owned.append((p['pid'],p['created']))
 resources.append({'model':name,'status':c['status'],'seconds':e['seconds'],'peak_tree_rss_mib':e['peak_tree_rss']/2**20,'sampled_tree_cpu_seconds':e['sampled_tree_cpu_seconds']})
for pid,born in set(owned):
 try:assert abs(psutil.Process(pid).create_time()-born)>.01,('Owned engine still active',pid)
 except psutil.NoSuchProcess:pass
awake=read(R/'runtime/BATCH_AWAKE.json');assert awake['status']=='RELEASED'
assert not (R/'runtime/engine.lock').exists()
pd.DataFrame(checks).to_csv(R/'audit/INPUT_INTEGRITY.csv',index=False)
pd.DataFrame(resources).to_csv(R/'results/ENGINE_RESOURCES.csv',index=False)
write(R/'audit/TERMINAL_CHECK.json',{'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_hashes_checked':len(checks),'owned_engine_identities':len(set(owned)),'owned_engines_remaining':0,'awake_guard':awake['status'],'queue_integrity':'ok','unchanged_CFPS_failures_rerun':0,'source_scope':'Frozen four source DATs and current invocation INPs; earlier raw-roster audit reused by fixed commit'})
summary=pd.read_csv(R/'results/MODERATION_SUMMARY.csv')
summary['bonferroni_4_p']=(summary.p*4).clip(upper=1)
summary.to_csv(R/'results/MODERATION_SUMMARY.csv',index=False)
receipt={'status':'BOUNDED_PILOT_BATCH_COMPLETE','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'model_calls':len(calls),'engine_launcher_seconds':budget['engine_seconds'],'families':fam,'complete_moderation_MI_families':0,'H41_complete_conditional_families':3,'H41_registered_families':12,'full_H4_complete':False,'original_four_moderations_complete':False,'RStudio':'native ClaudeR default@8787','original_job_id':'07d40638','source_commit':contract['source_commit'],'new_CFPS_calls':0,'new_MI':0,'new_NLM':0,'closed_manuscript_changed':False}
write(R/'reports/BATCH_RECEIPT.json',receipt)
labels={'SD':'子女见面频率SD','GENDER':'儿子−女儿平均频率差','OLDEST':'最年长子女−其他子女','SON':'长子−所有其他子女'}
rows=[]
for t in summary.itertuples():
 z=t.model.split('_')[1];rows.append(f'| {labels[z]} | {t.N} | {t.estimate:.6f} | [{t.lower:.6f}, {t.upper:.6f}] | {t.p:.4f} | {t.bonferroni_4_p:.4f} | {t.start_status} |')
report='''# CHARLS四项观测基期调节：有上限的完整案例小试

**四项调节完整推断、完整 H4 仍未完成。**

本批已完成四份已核实名册范围的父模型和交互可行性估计。它接续既有H4.1与CHARLS基期控制／缺失处理成果，不原样重跑失败CFPS，不改变已收尾的范围收缩稿。原始目录保持隔离。

## 本批实际结果

下表为SX×观测Z0→SY的交互系数，报告预定A起点及其完整协方差的点态Wald区间。B起点只作独立起点诊断，不是第二份插补。Z0为绝对差异，经各自试估范围标准化；X/Y沿用原3006人队列基期尺度。四项是不同定义、不同样本的检验，不能按系数大小直接比较其相对重要性。

| 基期指标 | N | 交互系数 | 95%完整案例Wald区间 | 原始P | 四项Bonferroni P | 双起点裁定 |
|---|---:|---:|---|---:|---:|---|
'''+ '\n'.join(rows)+f'''

本批共{len(calls)}次引擎／启动器调用，合计{budget['engine_seconds']:.3f}秒；这是调用墙钟之和，不是端到端项目时长。峰值单树RSS为{max(x['peak_tree_rss_mib'] for x in resources):.1f} MiB。Windows准入、PID创建时间、进度和终态记录随包；所有本批引擎已退出、临时空闲保护已释放。Mplus保持单槽，没有关闭其他章节的RStudio或未知MCP进程，也不把这些耗时外推成普遍加速基准。

## 估计对象与缺失处理边界

这里X是CHARLS见面频率的1—9序数编码均值，Y是CESD10；它不是CFPS情感亲近度量表的原样复制。时间载荷为0、2、4、7、9，模型含核心基期控制、社区聚类稳健SE及同期跨过程残差相关。父模型与交互模型均有x1 y1 ON z0，故gi0是给定这些直接路径后的潜截距条件路径，不等于Z0与实测基期抑郁的总关联。

四份数据均要求对应基期差异有定义、子女来源可核验、原始核心控制完整。没有把无儿子、仅一性别、出生年并列等结构问题补成普通缺失；22名历史子女键存在不一致者被排除的规则沿用前批。完整案例样本有选择性，不可称总体无偏估计。后续X/Y未观测值仍按同一FIML规则处理，不要求五期平衡。

既有CHARLS核心20份、收入及消费各40份MI及其合并结果继续有效于原加法模型，但不能直接改名为相容的潜交互MI。本批新增MI为0。四个双起点合法单份解即使全部成立，也不构成完整调节MI家族，更不能替代CFPS四项调节或H4。

## 核验与停止规则

冻结合同先于调用：最多12次、单次240秒、总调用2880秒，单引擎单处理器；不以P值筛选、不清零负方差、不为未通过起点继续无限修复。E1两个起点分别来自同样本E0，交互起点为正／负0.1并扰动其他非方差初值；没有从E1终点接续冒充独立起点。固定30点积分，EM导数与似然停止准则随输入公开。

采用性核对包括原始终止信息、负方差、TECH3协方差、条件矩阵和样本。独立Python再次从原始TECH1映射、estimates.dat及tech3.dat读取所有参数、SE、路径身份和条件斜率区间；未再次拟合。公开的协方差与两份DAT仅含模型参数／参数协方差，个人级data.dat、RDS和IDs不公开。

条件曲线为bss+dc×Z0，区间包含bss与dc的协方差，是点态、完整案例近似Wald区间，不是同时置信带，也不是因果干预效果。双起点规则是项目诊断标准，不证明全局最优或测量等值。

## H4.1及下一步

CFPS仍有SD×教育、城乡、正个人收入三个完整十份条件家族；联合D1 P为0.304077、0.610263、0.896602，其余九个登记家族未形成完整采用结果，失败不等于零效应。完整H4及动态四项调节保持开放，不更改此前裁定。旧CFPS插补与交互的相容性仍有限，不因成员完整或FMI小而宣称解决。

下一步应先冻结CHARLS调节的缺失目标：保留结构性无定义与来源不明排除，单独定义普通缺失的恢复范围；评估实质模型相容的插补／联合模型接口，不能拿现成加法MI直接补成调节家族。H4.1如扩展到CHARLS，应区分基期路径资源异质性与SX×Z0×资源的H4.2，直接检验组差，保留低阶项。对CFPS只允许有新方法依据和独立合同的改变，不重跑原失败输入。当前批次不自动扩大到Bayes、全窗口或新稿审阅。

既有固定证据：名册671d844575c04492be29a2e05c434c876a41ca41；资源MI与H4.1剩余分支437518be9ba2c55313ad91ff2fd079eec73df0d1。完整报告、输入输出与图表均为新隔离增量。
'''
(R/'reports/REPORT.md').write_text(report,encoding='utf-8')
(R/'reports/FOR_WEB_REVIEWERS.md').write_text('''# 给网页端审阅者

请先读REPORT、BATCH_RECEIPT和RUN_CONTRACT。本包是四个CHARLS观测基期调节完整案例可行性分支，不是四项完整MI推断，也不是CFPS稿件定稿。H4.1仍3/12个条件家族；完整H4未完成。请勿要求重复既有CFPS失败规格或重新审阅旧范围收缩稿。

包内保留各父模型、两个起点、原始输出、高精度参数、全TECH3、独立数值回读及条件曲线。可运行`python code/verify_public_bundle.py`核验哈希，再运行`python code/verify_pilots.py`复算保存结果；后者需要numpy、pandas、scipy，不调用Mplus，也不意味着重新拟合微观数据。

值得评估的是：见面频率的数值编码与研究解释、完整案例的选择性、下一步交互相容缺失处理，以及H4.1/H4.2的估计对象。不能以单份不显著、加法MI的低FMI或另一数据集的结果预测尚未执行的完整家族。

公开包没有个人级数据。estimates.dat和tech3.dat只是参数与其协方差；个人data.dat、MI及RDS均未上传。源码路径已脱敏，本机微观复现需另行绑定合法数据。
''',encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
