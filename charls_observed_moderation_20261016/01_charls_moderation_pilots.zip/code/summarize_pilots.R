# 本批只汇总已经保存的完整案例小试；不调用Mplus、不生成插补。
library(jsonlite)
root <- '<LOCAL_USER_HOME>/pp_lgcm_review/charls_observed_moderation_20261016'
calls <- fromJSON(file.path(root,'results/CALL_RESULTS.json'),simplifyVector=FALSE)
families <- fromJSON(file.path(root,'results/FAMILY_STATUS.json'),simplifyVector=FALSE)
stopifnot(length(families)==4L,file.exists(file.path(root,'runtime/BATCH_TERMINAL')))
paths <- list(); slopes <- list(); ci <- qnorm(.975)
for(id in names(calls)) {
 d <- file.path(root,'models',id); r <- calls[[id]]
 if(!identical(r$status,'USABLE_SINGLE_DATASET')) next
 p <- read.csv(file.path(d,'key_paths.csv'))
 p$model <- id; p$N <- r$N; p$lower <- p$estimate-ci*p$se; p$upper <- p$estimate+ci*p$se
 p$p <- 2*pnorm(-abs(p$estimate/p$se));p$inference <- 'single_complete_case_Wald_not_MI'
 paths[[id]] <- p
 if(r$type!='E1') next
 j <- fromJSON(file.path(d,'job.json')); v <- as.matrix(read.csv(file.path(d,'parameter_covariance.csv'),header=FALSE))
 k <- match(c('bss','dc'),p$label); ix <- p$parameter[k];u <- v[ix,ix,drop=FALSE]
 z <- seq(min(j$zpoints),max(j$zpoints),length.out=81L)
 a <- cbind(1,z);est <- drop(a %*% p$estimate[k]); se <- sqrt(rowSums((a %*% u)*a))
 slopes[[id]] <- data.frame(model=id,z=z,estimate=est,se=se,lower=est-ci*se,upper=est+ci*se,
   inference='conditional_SX_to_SY_complete_case_not_MI',N=r$N)
}
path_table <- do.call(rbind,paths);slope_table <- do.call(rbind,slopes)
write.csv(path_table,file.path(root,'results/ALL_PATHS_WALD.csv'),row.names=FALSE)
write.csv(slope_table,file.path(root,'results/CONDITIONAL_SLOPES.csv'),row.names=FALSE)
delta <- subset(path_table,label=='dc' & grepl('_A$',model))
delta$start_status <- vapply(delta$model,function(id) families[[tolower(strsplit(id,'_')[[1]][2])]]$interaction,'')
write.csv(delta,file.path(root,'results/MODERATION_SUMMARY.csv'),row.names=FALSE)
draw <- function() {
 par(mfrow=c(2,2),mar=c(4.2,4.5,3.4,1.2),oma=c(2,0,0,0))
 for(zname in names(families)) {
   id <- paste0('CHARLS_',toupper(zname),'_E1_A');a<-subset(slope_table,model==id)
   if(nrow(a)==0L){plot.new();title(main=paste(toupper(zname),'No usable pilot'));next}
   plot(a$z,a$estimate,type='n',ylim=range(a$lower,a$upper),xlab='Baseline contrast (standardized)',
     ylab='Conditional change association',main=paste0(toupper(zname),' (N=',a$N[1],')'))
   polygon(c(a$z,rev(a$z)),c(a$lower,rev(a$upper)),col=adjustcolor('#3b6c91',.18),border=NA)
   abline(h=0,lty=2,col='gray40');lines(a$z,a$estimate,col='#245875',lwd=2)
 }
 mtext('Complete-case feasibility; pointwise 95% Wald intervals; not pooled MI inference',side=1,outer=TRUE,cex=.8)
}
png(file.path(root,'results/CONDITIONAL_SLOPES.png'),width=1400,height=1000,res=130);draw();dev.off()
pdf(file.path(root,'results/CONDITIONAL_SLOPES.pdf'),width=10.8,height=7.7);draw();dev.off()
cat('POSTPROCESS_COMPLETE paths=',nrow(path_table),' slopes=',nrow(slope_table),' families=',nrow(delta),'\n')
