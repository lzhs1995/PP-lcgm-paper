from pathlib import Path
import json, csv
R = Path(__file__).resolve().parents[1]
forbidden = [p for p in R.rglob("*") if p.is_file() and (p.name.lower() in {"data.dat", "auxiliary_inputs.csv"} or p.suffix.lower() in {".rds", ".rdata", ".mids"})]
assert not forbidden, forbidden
v = json.loads((R / "results/INDEPENDENT_VERIFICATION.json").read_text(encoding="utf-8"))
assert v["status"] == "PASS_FULL_TRANSFORM_AND_RUBIN_SON_URBAN" and v["m"] == 20 and v["models"] == 21 and v["N"] == 2263 and v["communities"] == 433
assert v["full_H4_complete"] is False and v["B_start_sensitivity_passed"] is True
rows = list(csv.DictReader((R / "results/PRIMARY_H42.csv").open(encoding="utf-8")))
assert len(rows) == 1 and rows[0]["path"] == "SY:SXIZ" and rows[0]["contrast"] == "difference"
assert rows[0]["path"] == "SY:SXIZ" and rows[0]["contrast"] == "difference"
assert len(list((R / "models").glob("*/receipt.json"))) == 21
print("PASS_PUBLIC_SON_URBAN_READBACK", v["primary"])
