"""独立从原始参数/TECH3核对模型、组差、Rubin与D1；无新估计。"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import hashlib,json,sys
import numpy as np
import pandas as pd
from scipy.stats import t,f
from calibrated_reader import matrices,pid
R=Path(__file__).resolve().parents[1];public='--public' in sys.argv
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
fac=['IX','SX','IY','SY'];obs=[f'{p}{i}' for p in ['X','Y'] for i in range(1,6)]
labs=['bii','bis','bss','bsyiy','dii','dis','dss'];targets={('IY','IX'),('SY','IX'),('SY','SX')}
def geometry(par):
 P=np.zeros((4,4));TH=np.zeros((10,10));B=np.zeros((4,4));D=np.zeros((4,4));L=np.zeros((10,4));L[:5,0]=1;L[5:,2]=1;L[:5,1]=[0,2,4,7,9];L[5:,3]=[0,2,4,7,9]
 for r in par.itertuples():
  a=r.row;b=r.column;v=r.estimate
  if r.matrix in ('theta','psi'):
   mat,ns=(TH,obs) if r.matrix=='theta' else (P,fac);i=ns.index(a);j=ns.index(b);mat[i,j]=mat[j,i]=v
  elif r.matrix=='beta' and b in fac:B[fac.index(a),fac.index(b)]=v
  elif r.matrix=='beta' and b in ('IXG','SXG'):D[fac.index(a),fac.index(b[:2])]=v
 def pos(m):return bool(np.all(m.diagonal()>0) and np.linalg.eigvalsh(m/np.sqrt(np.outer(m.diagonal(),m.diagonal()))).min()>1e-7)
 ok=pos(P) and pos(TH)
 for g in (0,1):
  A=np.linalg.inv(np.eye(4)-B-g*D);G=A@P@A.T;S=L@G@L.T+TH;ok=ok and pos(G) and pos(S)
 return ok
def printed_check(d,mp,q,se):
 p=pd.read_csv(d/'mplusautomation_printed_parameters.csv',dtype={'LatentClass':str});n=0
 for cl,entries in mp.items():
  for mat,a,b,j in entries:
   if j==0:continue
   if mat=='LAMBDA':heads=[b+'.|',b+'.BY'];param=a
   elif mat=='ALPHA':heads=['Intercepts','Means'];param=b
   elif mat in ('BETA','GAMMA'):heads=[a+'.ON'];param=b
   elif mat in ('THETA','PSI') and a==b:heads=['Residual.Variances','Variances'];param=a
   elif mat in ('THETA','PSI'):
    s=p[(p.LatentClass==str(cl))&(((p.paramHeader==a+'.WITH')&(p.param==b))|((p.paramHeader==b+'.WITH')&(p.param==a)))];assert len(s)==1,(mat,a,b,cl)
    assert abs(float(s.est.iloc[0])-q[j-1])<=.000501 and abs(float(s.se.iloc[0])-se[j-1])<=.000501;n+=1;continue
   else:raise ValueError((mat,a,b))
   s=p[(p.LatentClass==str(cl))&p.paramHeader.isin(heads)&(p.param==param)];assert len(s)==1,(mat,a,b,cl)
   assert abs(float(s.est.iloc[0])-q[j-1])<=.000501 and abs(float(s.se.iloc[0])-se[j-1])<=.000501;n+=1
 return n

raw={};rows=[]
for d in sorted((R/'models').iterdir()):
 if not d.is_dir():continue
 job=read(d/'job.json');rr=read(d/'receipt.json');er=read(d/'engine_receipt.json')
 if not public:
  for n,h in job['hashes'].items():assert sha(d/n)==h
  assert sha(d/'model.out')==rr['output_sha256']==er['output_sha256']
 row=dict(id=d.name,group=job['group'],member=job['member'],start=job['start'],status=rr['status'],engine_seconds=er['seconds'])
 if not (d/'parameters_high_precision.csv').exists():assert rr['status']!='USABLE';rows.append(row);continue
 txt,mp,q,se,V,ll=matrices(d);row["printed_rows"]=printed_check(d,mp,q,se);slots=read(d/'normalized_slots.json');n=len(q);J=np.zeros((n,n));assert n==job['expected_free']==len(slots)
 for i,s in enumerate(slots):
  op=s['op'];a=s['lhs'];b=s['rhs']
  if op=='ON' and b==job['g']:J[i,pid(mp[2],'ALPHA','1',a)]=1;J[i,pid(mp[1],'ALPHA','1',a)]=-1
  elif op=='ON' and b in ('IXG','SXG'):J[i,pid(mp[2],'BETA',a,b[:2])]=1;J[i,pid(mp[1],'BETA',a,b[:2])]=-1
  else:
   if op=='MEAN':m,a,b='ALPHA','1',a
   elif op in ('VAR','WITH'):m='PSI' if a in fac else 'THETA';b=a if op=='VAR' else b
   else:m='BETA'
   j=pid(mp[1],m,a,b);J[i,j]=1
   if op!='MEAN':assert (j!=pid(mp[2],m,a,b))==(job['interaction'] and op=='ON' and (a,b) in targets)
 assert np.linalg.matrix_rank(J)==n and np.array_equal(J,np.loadtxt(d/'parameter_transform.csv',delimiter=','))
 par=pd.read_csv(d/'parameters_high_precision.csv');NV=J@V@J.T;nq=J@q
 assert np.allclose(nq,par.estimate,atol=1e-12,rtol=1e-12) and np.allclose(np.sqrt(NV.diagonal()),par.se,atol=1e-12,rtol=1e-12)
 assert np.allclose(NV,np.loadtxt(d/'parameter_covariance.csv',delimiter=','),atol=1e-12,rtol=1e-12)
 legal=geometry(par) and np.linalg.eigvalsh(NV/np.sqrt(np.outer(NV.diagonal(),NV.diagonal()))).min()>1e-10
 if rr['status']=='USABLE':assert legal and rr['likelihood_identity'] and 'THE MODEL ESTIMATION TERMINATED NORMALLY' in txt and 'FIXED TO AVOID SINGULARITY' not in txt
 keys=pd.read_csv(d/'key_paths.csv');keydict=dict(zip(keys.label,keys.parameter-1));raw[d.name]=(nq,NV,keydict)
 row.update(parameters=n,geometry_legal=bool(legal),SY=float(par.loc[(par.matrix=='psi')&(par.row=='SY')&(par.column=='SY'),'estimate'].iloc[0]),peak_tree_MiB=er['peak_tree_rss']/2**20);rows.append(row)
 if len(rows)%5==0:print(json.dumps({'stage':'raw_model_verified','models':len(rows)}),flush=True)
fs=read(R/'results/FAMILY_STATUS.json');pool=read(R/'results/POOLING_RECEIPT.json');complete=sum(bool(x['complete_MI']) for x in fs.values());assert complete==pool['complete']
pooled=pd.read_csv(R/'results/POOLED_PATHS.csv') if complete else pd.DataFrame();joint=pd.read_csv(R/'results/JOINT_D1.csv') if complete else pd.DataFrame();contr=pd.read_csv(R/'results/GROUP_CONTRASTS.csv') if complete else pd.DataFrame()
def scalar(Q,U):
 m=len(Q);q=Q.mean();W=np.mean(U);B=np.var(Q,ddof=1);T=W+(1+1/m)*B;se=np.sqrt(T);r=(1+1/m)*B/W;df=(m-1)*(1+1/r)**2 if r else np.inf
 return dict(estimate=q,se=se,df=df,lower=q-t.ppf(.975,df)*se,upper=q+t.ppf(.975,df)*se,p=2*t.sf(abs(q/se),df))
for g,fam in fs.items():
 if not fam['complete_MI']:continue
 members=sorted([r for r in rows if r['group']==g and r['start']=='A'],key=lambda r:r['member']);assert [r['member'] for r in members]==list(range(1,21)) and all(r['status']=='USABLE' for r in members)
 Q=[];U=[]
 for r in members:
  q,v,idx=raw[r['id']];ids=[idx[x] for x in labs];Q.append(q[ids]);U.append(v[np.ix_(ids,ids)])
 Q=np.array(Q);U=np.array(U)
 for j,lab in enumerate(labs):
  got=pooled[(pooled.group==g)&(pooled.label==lab)].iloc[0];want=scalar(Q[:,j],U[:,j,j])
  for name,v in want.items():assert np.isclose(got[name],v,atol=1e-8,rtol=1e-7),(g,lab,name,got[name],v)
 W=U[:,4:,4:].mean(0);B=np.cov(Q[:,4:],rowvar=False);qb=Q[:,4:].mean(0);r=1.05*np.trace(B@np.linalg.inv(W))/3;F=qb@np.linalg.solve((1+r)*W,qb)/3;df2=4+53*(1+(1-2/57)/r)**2;pval=f.sf(F,3,df2)
 got=joint[joint.group==g].iloc[0]
 for name,v in dict(F=F,df1=3,df2=df2,p=pval,RIV=r).items():assert np.isclose(got[name],v,atol=1e-8,rtol=1e-7),(g,name,got[name],v)
 for stem,j,delta in [('IY_IX',0,4),('SY_IX',1,5),('SY_SX',2,6)]:
  for suffix,terms in [('G0',{j:1}),('G1',{j:1,delta:1}),('difference',{delta:1})]:
   a=np.zeros(7)
   for idx,v in terms.items():a[idx]=v
   want=scalar(Q@a,np.einsum('i,kij,j->k',a,U,a));got=contr[(contr.group==g)&(contr.contrast==stem+'_'+suffix)].iloc[0]
   for name,v in want.items():assert np.isclose(got[name],v,atol=1e-8,rtol=1e-7),(g,stem,suffix,name)
if complete:
 order=np.argsort(joint.p.to_numpy());adj=np.maximum.accumulate(joint.p.to_numpy()[order]*(2-np.arange(complete)));assert np.allclose(joint.holm_planned2.to_numpy()[order],np.minimum(1,adj))
contract=read(R/'contracts/RUN_CONTRACT.json');assert len(rows)<=contract['max_calls'] and sum(x['engine_seconds'] for x in rows)<=contract['total_engine_seconds']+10
assert read(R/'audit/INDEPENDENT_MI.json')['status']=='PASS' and read(R/'audit/CALIBRATION.json')['status']=='PASS'
if not public:
 for path,h in read(R/'audit/SOURCE_HASHES.json').items():assert sha(Path(path))==h

# 独立从旧父模型保存参数重建73参数校准，不只相信PASS标记。
old=R/'references/CORE_MI01'
_,_,oq,ose,OV,oll=matrices(old)
cq,CV,_=raw['CHARLS_MEAN_CAL_MI01_A']
assert len(oq)==len(cq)==73
assert np.all(np.abs(cq-oq)<=np.maximum(.001,.05*ose))
assert np.max(np.abs(np.sqrt(CV.diagonal())-ose)/ose)<.05
assert np.max(np.abs(CV-OV)/np.outer(ose,ose))<.05
_,_,_,_,_,cll=matrices(R/'models/CHARLS_MEAN_CAL_MI01_A')
assert abs(cll+3006*np.log(2)-oll)<.02
assert read(R/'audit/GUARD_recovery2_complete.json')['decision']=='PASS'
assert read(R/'runtime/awake_run3/completion.json')['released']

result=dict(status='PASS',public_mode=public,calls=len(rows),engine_seconds=sum(x['engine_seconds'] for x in rows),printed_rows=sum(x.get("printed_rows",0) for x in rows),free_parameter_records=sum(x.get('parameters',0) for x in rows),complete_families=complete,registered_families=2,attempts=rows,original_four_complete=False,full_H4_complete=False,scope='Raw parameter/covariance transformation and independent scalar, full-covariance contrast and D1 replay; MI microdata validated locally, excluded publicly')
(R/'audit/INDEPENDENT_RESULTS.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k!='attempts'}))
