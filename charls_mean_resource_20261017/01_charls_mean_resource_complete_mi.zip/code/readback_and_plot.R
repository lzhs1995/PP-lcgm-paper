# 仅读取既有输出和合并结果；不调用估计引擎，不修改前台对象。
local({
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_mean_resource_20261017'
.libPaths(c('<LOCAL_USER>/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
library(MplusAutomation);library(jsonlite)
stopifnot(file.exists(file.path(ROOT,'audit/BATCH_TERMINAL.json')))
dirs<-list.dirs(file.path(ROOT,'models'),recursive=FALSE);rows<-list()
for(i in seq_along(dirs)){
 d<-dirs[i];m<-suppressWarnings(readModels(file.path(d,'model.out'),what=c('summaries','parameters'),quiet=TRUE))
 p<-m$parameters$unstandardized;stopifnot(nrow(p)>0)
 write.csv(p,file.path(d,'mplusautomation_printed_parameters.csv'),row.names=FALSE)
 rows[[i]]<-data.frame(id=basename(d),printed_rows=nrow(p),N=m$summaries$Observations,parameters=m$summaries$Parameters)
 if(i%%5==0){cat('READBACK',i,'/',length(dirs),'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress('readback',paste(i,'of',length(dirs)))}
}
write.csv(do.call(rbind,rows),file.path(ROOT,'audit/MPLUS_AUTOMATION_READBACK.csv'),row.names=FALSE)
write_json(list(status='PASS',models=length(dirs),new_engine_calls=0,package=as.character(packageVersion('MplusAutomation'))),file.path(ROOT,'audit/MPLUS_AUTOMATION_READBACK.json'),auto_unbox=TRUE,pretty=TRUE)
z<-read.csv(file.path(ROOT,'results/GROUP_CONTRASTS.csv'));z<-z[grepl('_difference$',z$contrast),]
dir.create(file.path(ROOT,'reports'),showWarnings=FALSE)
draw<-function(){
 op<-par(mar=c(5,11,4,2));on.exit(par(op));ylim<-c(.5,nrow(z)+.5);y<-rev(seq_len(nrow(z)))
 labels<-paste(z$group,sub('_difference$','',z$contrast),sep=': ')
 xr<-range(c(0,z$lower,z$upper));pad<-diff(xr)*.07
 plot(z$estimate,y,xlim=xr+c(-pad,pad),ylim=ylim,yaxt='n',ylab='',xlab='Group 1 minus group 0 coefficient (95% working-MI CI)',pch=19,col='#155b83',main='CHARLS mean-contact resource differences')
 abline(v=0,lty=2,col='grey50');segments(z$lower,y,z$upper,y,col='#155b83',lwd=2);axis(2,at=y,labels=labels,las=1,cex.axis=.85)
 mtext('20 complete imputations per family; contact frequency is not emotional closeness',side=1,line=3.5,cex=.72)
}
png(file.path(ROOT,'reports/GROUP_DIFFERENCES.png'),width=1600,height=850,res=150);draw();dev.off()
pdf(file.path(ROOT,'reports/GROUP_DIFFERENCES.pdf'),width=10.7,height=5.7);draw();dev.off()
cat('CHARLS_MEAN_READBACK_TERMINAL models',length(dirs),'new_engine_calls0\n')
})
