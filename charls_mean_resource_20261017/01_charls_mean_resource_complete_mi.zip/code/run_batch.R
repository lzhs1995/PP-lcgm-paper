# 原生唯一协调器，先插补/校准/父模型，再完整家族；失败即停止对应家族。
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_mean_resource_20261017'
.libPaths(c('<LOCAL_USER>/pp_lgcm_review/charls_adjusted_h41_20261015/library','<LOCAL_USER>/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
library(jsonlite);library(processx);library(ps)
PY<-'<LOCAL_USER>/AppData/Local/Programs/Python/Python314/python.exe'
rj<-function(p)if(file.exists(p))fromJSON(p,simplifyVector=FALSE)else NULL
wj<-function(x,p)write_json(x,p,auto_unbox=TRUE,pretty=TRUE,digits=NA)
progress<-function(stage,message){cat(format(Sys.time(),tz='UTC',usetz=TRUE),stage,message,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(stage,message)}
py<-function(script,args,log){p<-processx::run(PY,c('-X','utf8',file.path(ROOT,'code',script),args),error_on_status=FALSE,timeout=120000);writeLines(c(p$stdout,p$stderr),log);if(p$status!=0)stop('Stage failed: ',log);p}
run_one<-function(g,k,start){
 id<-sprintf('CHARLS_MEAN_%s_MI%02d_%s',g,k,start);d<-file.path(ROOT,'models',id)
 if(file.exists(file.path(d,'receipt.json'))){
  rr<-rj(file.path(d,'receipt.json'));j<-rj(file.path(d,'job.json'))
  stopifnot(rr$status=='USABLE',identical(digest::digest(file=file.path(d,'model.out'),algo='sha256'),rr$output_sha256))
  for(n in names(j$hashes))stopifnot(identical(digest::digest(file=file.path(d,n),algo='sha256'),j$hashes[[n]]))
  progress('reuse_validated',id);return(rr)
 }
 if(file.exists(file.path(d,'job.json'))){
  j<-rj(file.path(d,'job.json'));stopifnot(!file.exists(file.path(d,'model.out')),!file.exists(file.path(d,'engine_receipt.json')))
  for(n in names(j$hashes))stopifnot(identical(digest::digest(file=file.path(d,n),algo='sha256'),j$hashes[[n]]))
  progress('resume_unstarted',id)
 }else{progress('prepare',id);py('models.py',c('prepare',g,as.character(k),start),file.path(ROOT,'audit',paste0(id,'_prepare.log')))}
 j<-rj(file.path(d,'job.json'));j$rscript<-file.path(R.home('bin'),'Rscript.exe');wj(j,file.path(d,'job.json'))
 p<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/engine.py'),file.path(d,'job.json')),stdout=file.path(d,'supervisor.log'),stderr='2>&1',cleanup=FALSE)
 last<-0
 while(p$is_alive()){
  p$wait(1000L)
  if(as.numeric(Sys.time())-last>25){h<-rj(file.path(ROOT,'runtime/progress.json'));progress('estimating',paste(id,h$stage,if(!is.null(h$elapsed_seconds))round(h$elapsed_seconds,1)else''));last<-as.numeric(Sys.time())}
 }
 if(!file.exists(file.path(d,'engine_receipt.json'))){rr<-list(id=id,dest=d,group=g,member=k,start=start,status='NO_ENGINE_RECEIPT',not_run=rj(file.path(d,'not_run.json')));wj(rr,file.path(d,'receipt.json'));return(rr)}
 progress('validate',id);py('models.py',c('normalize',d),file.path(d,'readback.log'));rr<-rj(file.path(d,'receipt.json'));progress('adjudicated',paste(id,rr$status));rr
}
main<-function(){
 started<-Sys.time();stopifnot(!file.exists(file.path(ROOT,'audit/BATCH_TERMINAL.json')))
 own<-list(pid=Sys.getpid(),created=as.numeric(ps::ps_create_time(ps::ps_handle())));wj(list(owner=own),file.path(ROOT,'runtime/OWNER_run3.json'))
 awake<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/windows_awake_guard.py'),'--owner-file',file.path(ROOT,'runtime/OWNER_run3.json'),'--output',file.path(ROOT,'runtime/awake_run3'),'--interval','5'),stdout=file.path(ROOT,'runtime/awake_run3.log'),stderr='2>&1',cleanup=FALSE)
 on.exit({writeLines('release',file.path(ROOT,'runtime/awake_run3/stop.request'));awake$wait(8000L)},add=TRUE)
 active<-FALSE
 for(i in 1:40){a<-rj(file.path(ROOT,'runtime/awake_run3/identity.json'));h<-rj(file.path(ROOT,'runtime/awake_run3/heartbeat.json'));if(!is.null(a)&&!is.null(h)&&a$owner$pid==own$pid&&abs(a$owner$created-own$created)<.01&&awake$is_alive()){active<-TRUE;break};if(!awake$is_alive())stop('awake startup failed');Sys.sleep(.5)}
 stopifnot(active)
 if(!file.exists(file.path(ROOT,'audit/MI_ADMISSION.json')))source(file.path(ROOT,'code/prepare_mi.R'),local=TRUE)
 stopifnot(rj(file.path(ROOT,'audit/MI_ADMISSION.json'))$status=='ADMITTED_WORKING_MI')
 attempts<-rj(file.path(ROOT,'results/ATTEMPTS.json'));if(is.null(attempts))attempts<-list();save_attempt<-function(rr){attempts[[rr$id]]<<-rr;wj(attempts,file.path(ROOT,'results/ATTEMPTS.json'))}
 cal<-run_one('CAL',1,'A');save_attempt(cal);stopifnot(cal$status=='USABLE')
 py('check_calibration.py',character(),file.path(ROOT,'audit/CALIBRATION.log'))
 parent<-run_one('PARENT',1,'A');save_attempt(parent);stopifnot(parent$status=='USABLE')
 families<-list()
 for(g in c('EDU','URBAN')){
  f<-list(group=g,status='STARTING',complete_MI=FALSE,usable_members=0,planned_members=20)
  a<-run_one(g,1,'A');save_attempt(a)
  if(a$status!='USABLE'){f$status<-'FIRST_MEMBER_FAILED';f$reason<-a$status;families[[g]]<-f;wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'));next}
  b<-run_one(g,1,'B');save_attempt(b)
  if(b$status!='USABLE'){f$status<-'SECOND_START_FAILED';f$reason<-b$status;families[[g]]<-f;wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'));next}
  agreement<-file.path(ROOT,'results',paste0(g,'_START_AGREEMENT.json'))
  py('models.py',c('agree',a$dest,b$dest,agreement),file.path(ROOT,'audit',paste0(g,'_agreement.log')))
  if(!isTRUE(rj(agreement)$passed)){f$status<-'START_DISAGREEMENT';families[[g]]<-f;wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'));next}
  f$usable_members<-1;members<-list(a);f$status<-'EXTENDING_MI'
  for(k in 2:20){
   rr<-run_one(g,k,'A');save_attempt(rr)
   if(rr$status!='USABLE'){f$status<-'MI_FAMILY_INCOMPLETE';f$reason<-rr$status;break}
   members[[k]]<-rr;f$usable_members<-k;families[[g]]<-f;wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'))
  }
  f$complete_MI<-f$usable_members==20L;if(f$complete_MI)f$status<-'COMPLETE_CONDITIONAL_WORKING_MI'
  f$member_paths<-vapply(members,function(x)x$dest,'');families[[g]]<-f;wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'))
 }
 progress('pooling','Complete20 only, full covariance and direct three-path resource differences')
 source(file.path(ROOT,'code/pool_results.R'),local=TRUE)
 wj(list(status='CHARLS_MEAN_RESOURCE_BATCH_ADJUDICATED',groups=families,budget=rj(file.path(ROOT,'runtime/budget_status.json')),coordinator_wall_seconds=as.numeric(difftime(Sys.time(),started,units='secs')),original_four_complete=FALSE,full_H4_complete=FALSE),file.path(ROOT,'audit/BATCH_TERMINAL.json'))
 writeLines(capture.output(sessionInfo()),file.path(ROOT,'audit/R_SESSION_INFO.txt'))
 progress('CHARLS_MEAN_NATIVE_TERMINAL','All registered resource families adjudicated');cat('CHARLS_MEAN_NATIVE_TERMINAL\n')
}
main()
