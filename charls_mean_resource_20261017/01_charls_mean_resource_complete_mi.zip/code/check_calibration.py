"""按73原参数核对CHARLS已知组父模型，与旧同数据SW逐项比较。"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import json
import numpy as np
import pandas as pd
from calibrated_reader import matrices
R=Path(__file__).resolve().parents[1];old=R.parent/'charls_adjusted_h41_20261015/models/CHARLS_CORE_MI01';d=R/'models/CHARLS_MEAN_CAL_MI01_A'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
rr=read(d/'receipt.json');assert rr['status']=='USABLE'
_,_,oq,ose,OV,oll=matrices(old);q=pd.read_csv(d/'parameters_high_precision.csv');ref=pd.read_csv(old/'parameters_high_precision.csv');V=np.loadtxt(d/'parameter_covariance.csv',delimiter=',')
assert q[['matrix','row','column']].equals(ref[['matrix','row','column']]) and len(q)==73
difference=np.abs(q.estimate-oq);se_diff=np.abs(q.se-ose)/ose;covdiff=np.max(np.abs(V-OV)/np.outer(ose,ose))
checks={'parameters':bool(np.all(difference<=np.maximum(.001,.05*ose))),'SE':bool(np.all(se_diff<=.05)),'full_vcov':bool(covdiff<=.05),'conditional_LL':bool(abs(rr['LL']-oll)<.02)}
result=dict(status='PASS' if all(checks.values()) else 'FAIL',checks=checks,N=3006,parameters=73,max_parameter_difference_over_SE=float(np.max(difference/ose)),max_SE_relative=float(np.max(se_diff)),max_vcov_standardized_difference=float(covdiff),conditional_LL_difference=rr['LL']-oll)
(R/'audit/CALIBRATION.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
assert result['status']=='PASS'
