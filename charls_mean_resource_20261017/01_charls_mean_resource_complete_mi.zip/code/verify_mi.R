# 独立重读保存的MIDS和全部DAT；只输出聚合核验，无逐人记录。
library(mice);library(data.table);library(jsonlite);library(digest)
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_mean_resource_20261017'
P<-'<LOCAL_USER>/pp_lgcm_review/charls_adjusted_h41_20261015'
z<-readRDS(file.path(P,'private/charls_core_mi_inputs.rds'));imp<-readRDS(file.path(ROOT,'private/MIDS.rds'))
cols<-c('cluster',paste0('x',1:5),paste0('y',1:5),paste0('c',1:11))
read_dat<-function(path){d<-fread(path,header=FALSE,data.table=FALSE,showProgress=FALSE);names(d)<-cols;for(n in names(d))d[[n]][d[[n]]==-9999]<-NA_real_;d}
base<-read_dat(file.path(P,'models/CHARLS_CORE_MI01/data.dat'))
control_map<-c(c1='age',c2='female',c3='edu',c4='urban',c5='partner',c6='nchild',c7='adl',c8='health2',c9='health3',c10='health4',c11='health5')
order_checks<-lapply(names(control_map),function(n){a<-base[[n]];b<-z$data[[control_map[[n]]]];ok<-!is.na(b);data.frame(column=n,compared=sum(ok),max_difference=max(abs(a[ok]-b[ok])),pass=max(abs(a[ok]-b[ok]))<1e-10)})
order_checks<-do.call(rbind,order_checks);stopifnot(all(order_checks$pass),identical(as.numeric(base$cluster),as.numeric(z$data$cluster)))
write.csv(order_checks,file.path(ROOT,'audit/SOURCE_ROW_ORDER_CONTROLS.csv'),row.names=FALSE)
members<-list();observed<-!is.na(z$data$adl)
for(k in 1:20){
 v<-complete(imp,k);d<-read_dat(file.path(ROOT,'private',sprintf('MI%02d.dat',k)))
 expected<-base;expected$c7<-v$adl
 a<-as.matrix(d);b<-as.matrix(expected);mask<-is.na(b);stopifnot(identical(is.na(a),mask))
 md<-max(abs(a[!mask]-b[!mask]));stopifnot(md<1e-10,identical(as.numeric(v$adl[observed]),as.numeric(z$data$adl[observed])),all(v$adl[!observed]%in%z$data$adl[observed]))
 members[[k]]<-data.frame(member=k,max_export_difference=md,N=nrow(d),XY_masks_preserved=TRUE,observed_ADL_preserved=TRUE,donor_support=TRUE,sha256=digest(file=file.path(ROOT,'private',sprintf('MI%02d.dat',k)),algo='sha256'))
}
tab<-do.call(rbind,members);write.csv(tab,file.path(ROOT,'audit/INDEPENDENT_MI_MEMBERS.csv'),row.names=FALSE)
age_diff<-max(abs(z$data$age-(z$raw$age-70)/10),na.rm=TRUE);sexmask<-!is.na(z$raw$female)
rec<-list(status='PASS',members=nrow(tab),N=nrow(base),communities=length(unique(base$cluster)),original_control_row_order_verified=TRUE,raw_age_max_difference=age_diff,observed_raw_sex_differences=sum(z$data$female[sexmask]!=z$raw$female[sexmask]),original_missing_raw_sex=sum(!sexmask),known_sex_source_recovery='One raw baseline missing sex had concordant later raw sources; preserve that original missing mask. A raw-vs-recovered identical() false is not row reordering.',max_export_difference=max(tab$max_export_difference),new_engine_calls=0,mi_compatibility_not_proven=TRUE)
write_json(rec,file.path(ROOT,'audit/INDEPENDENT_MI.json'),pretty=TRUE,auto_unbox=TRUE,digits=16)
income<-fromJSON(file.path(ROOT,'audit/FULL_CORE_INCOME_SOURCE_AUDIT.json'),simplifyVector=FALSE);income$source_row_order_followup<-rec
write_json(income,file.path(ROOT,'audit/FULL_CORE_INCOME_SOURCE_AUDIT.json'),pretty=TRUE,auto_unbox=TRUE,digits=16)
cat('INDEPENDENT_MI_PASS',toJSON(rec,auto_unbox=TRUE),'\n')
