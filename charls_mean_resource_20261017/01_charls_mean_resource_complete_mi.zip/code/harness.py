"""当前真实原生smoke及每个唯一异步任务的登记，复用已安装harness。"""
from pathlib import Path
import contextlib,datetime,io,json,sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,'<LOCAL_USER>/.codex/skills/clauder-rstudio-workbench')
from clauder_workbench.cli import main
base='pp-lgcm-charls-mean-resource-20261017'
def run(args,name):
 b=io.StringIO()
 with contextlib.redirect_stdout(b):rc=main(args)
 (R/'audit'/name).write_text(b.getvalue(),encoding='utf-8');j=json.loads(b.getvalue());assert rc==0 and j['decision']=='PASS',j
 print(json.dumps(dict(decision=j['decision'],evidence_id=j['evidence_id'],command=args[:2])),flush=True)
mode=sys.argv[1]
if mode=='smoke-start':
 run(['doctor','--expect-client','codex','--check-toml-parse'],'DOCTOR.json')
 run(['native-smoke','start','--task-key',base+'-native','--session-name','default','--agent','codex','--require-raw-file'],'NATIVE_START.json')
 run(['native-smoke','record','--task-key',base+'-native','--step','list_sessions','--ok','--session-name','default','--session-count','2','--raw-file',str(R/'audit/NATIVE_LIST.json')],'NATIVE_LIST_RECORD.json')
 run(['native-smoke','record','--task-key',base+'-native','--step','execute_r','--ok','--marker','CHARLS_MEAN_NATIVE_EXECUTE_OK','--pid','11644','--raw-file',str(R/'audit/NATIVE_EXECUTE.json')],'NATIVE_EXECUTE_RECORD.json')
elif mode=='smoke-finish':
 job=sys.argv[2]
 run(['native-smoke','record','--task-key',base+'-native','--step','execute_r_async','--ok','--job-id',job,'--raw-file',str(R/'audit/NATIVE_SMOKE_SUBMIT.json')],'NATIVE_ASYNC_RECORD.json')
 run(['native-smoke','record','--task-key',base+'-native','--step','get_async_result','--ok','--job-id',job,'--marker','CHARLS_MEAN_SMOKE_DONE','--raw-file',str(R/'audit/NATIVE_SMOKE_TERMINAL.json')],'NATIVE_RESULT_RECORD.json')
 run(['native-smoke','complete','--task-key',base+'-native','--max-age-min','60'],'NATIVE_PROOF.json')
elif mode in ('pre-submit','register-job','complete'):
 stage=sys.argv[2];args=['async-guard',mode,'--task-key',base+'-'+stage]
 if mode=='pre-submit':
  proof=json.loads((R/'audit/NATIVE_PROOF.json').read_text());assert proof['decision']=='PASS' and proof['transport_class']=='NATIVE_MCP_OK'
  age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(proof['timestamp_utc'].replace('Z','+00:00'))).total_seconds();assert age<3600
 if mode in ('pre-submit','register-job'):args+=['--session-name','default','--io-mode','durable_files']
 if len(sys.argv)>3:args+=['--job-id',sys.argv[3]]
 if mode=='complete':args+=['--reason','actual_terminal_saved']
 run(args,'GUARD_'+stage+'_'+mode+'.json')
