# 只调整图注间距，数据仍取同一已完成的完整MI合并表。
local({
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_mean_resource_20261017'
z<-read.csv(file.path(ROOT,'results/GROUP_CONTRASTS.csv'));z<-z[grepl('_difference$',z$contrast),]
draw<-function(){
 op<-par(mar=c(7,11,4,2));on.exit(par(op));y<-rev(seq_len(nrow(z)))
 labels<-paste(z$group,sub('_difference$','',z$contrast),sep=': ')
 xr<-range(c(0,z$lower,z$upper));pad<-diff(xr)*.07
 plot(z$estimate,y,xlim=xr+c(-pad,pad),ylim=c(.5,nrow(z)+.5),yaxt='n',ylab='',xlab='Group 1 minus group 0 coefficient (95% working-MI CI)',pch=19,col='#155b83',main='CHARLS mean-contact resource differences')
 abline(v=0,lty=2,col='grey50');segments(z$lower,y,z$upper,y,col='#155b83',lwd=2);axis(2,at=y,labels=labels,las=1,cex.axis=.85)
 mtext('20 complete imputations per family; contact frequency is not emotional closeness',side=1,line=5.3,cex=.72)
}
png(file.path(ROOT,'reports/GROUP_DIFFERENCES.png'),width=1600,height=950,res=150);draw();dev.off()
pdf(file.path(ROOT,'reports/GROUP_DIFFERENCES.pdf'),width=10.7,height=6.4);draw();dev.off()
cat('CHARLS_MEAN_PLOT_SPACING_FIXED new_engine_calls0\n')
})
