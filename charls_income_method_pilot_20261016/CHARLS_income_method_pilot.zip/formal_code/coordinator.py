"""单计算worker：CC先行，各范围MI完成即转Mplus；持久进度及有界恢复。"""
from pathlib import Path
import ctypes,datetime,hashlib,json,os,subprocess,time,traceback
import psutil
ROOT=Path(__file__).resolve().parents[1]
RSCRIPT='C:/Users/LZHS/Downloads/RStudio/R_ducument/R-4.5.2/bin/x64/Rscript.exe'
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(p,default=None):
    try:return json.loads(Path(p).read_text(encoding='utf-8'))
    except (FileNotFoundError,PermissionError,json.JSONDecodeError):return default
def write(p,value):
    p=Path(p);temp=p.with_name(p.name+f'.{os.getpid()}.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    for k in range(16):
        try:os.replace(temp,p);return
        except PermissionError:
            if k==15:raise
            time.sleep(.1)
def owned_kill(p,born):
    if p.poll() is not None:return
    owner=psutil.Process(p.pid)
    if abs(owner.create_time()-born)>.01:raise RuntimeError('PID identity changed; no kill')
    for q in reversed(owner.children(recursive=True)):
        try:q.kill()
        except psutil.NoSuchProcess:pass
    owner.kill();p.wait(timeout=30)
def main():
    contract=read(ROOT/'contracts/RUN_CONTRACT.json');assert read(ROOT/'audit/SETUP_VALIDATION.json')['status']=='SETUP_AND_CONDITIONAL_VARIANCE_PASS'
    lock=ROOT/'runtime/pipeline.lock';me=psutil.Process();fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    os.write(fd,json.dumps(dict(pid=me.pid,created=me.create_time(),utc=utc())).encode());os.close(fd)
    started=time.monotonic();states=read(ROOT/'runtime/STEPS.json',{});active=None;born=None
    code_hash={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'code').iterdir() if p.suffix in ('.R','.py')}
    write(ROOT/'audit/EXECUTION_CODE_HASHES.json',code_hash)
    awake=bool(ctypes.windll.kernel32.SetThreadExecutionState(0x80000001))
    def step(key,script,args,limit,progress_path=None):
        nonlocal active,born
        if key in states:
            old=states[key]
            if old.get('status')!='RUNNING':return old
            try:
                q=psutil.Process(old['pid'])
                if abs(q.create_time()-old['created'])<.01:raise RuntimeError('Verified prior worker still alive; duplicate refused')
            except psutil.NoSuchProcess:pass
            if not key.startswith('mi_'):raise RuntimeError('Interrupted model step requires engine reservation reconciliation')
            with (ROOT/'runtime/INTERRUPTED_STEPS.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(dict(key=key,prior=old,reconciled_at=utc()))+'\n')
            del states[key]
        for name,h in code_hash.items():
            if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=h:raise RuntimeError('Code changed during active pipeline: '+name)
        for _ in range(91):
            available=psutil.virtual_memory().available/2**30
            if available>=contract['minimum_available_GiB'] and psutil.disk_usage('C:/').free/2**30>=2:break
            write(ROOT/'runtime/PIPELINE.json',dict(status='RESOURCE_WAIT',step=key,available_GiB=available,updated_at=utc()))
            time.sleep(10)
        else:
            r=dict(status='RESOURCE_HOLD',finished_at=utc());states[key]=r;write(ROOT/'runtime/STEPS.json',states);return r
        begin=time.monotonic();r=dict(status='RUNNING',started_at=utc());states[key]=r;write(ROOT/'runtime/STEPS.json',states)
        with (ROOT/'runtime'/f'{key}.log').open('ab') as log:
            active=subprocess.Popen([RSCRIPT,'--vanilla',str(ROOT/'code'/script),*args],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
            owner=psutil.Process(active.pid);born=owner.create_time();low_since=None;last_marker=None;marker_since=time.monotonic()
            r.update(pid=active.pid,created=born);write(ROOT/'runtime/STEPS.json',states)
            while active.poll() is None:
                elapsed=time.monotonic()-begin;vm=psutil.virtual_memory();latest=read(progress_path,{}) if progress_path else {}
                tree=[]
                try:
                    for q in [owner]+owner.children(recursive=True):
                        try:tree.append(dict(pid=q.pid,created=q.create_time(),name=q.name(),rss_MiB=q.memory_info().rss/2**20))
                        except psutil.Error:pass
                except psutil.Error:pass
                write(ROOT/'runtime/PIPELINE.json',dict(status='RUNNING',step=key,elapsed_seconds=elapsed,total_elapsed_seconds=time.monotonic()-started,available_GiB=vm.available/2**30,latest=latest,processes=tree,coordinator_pid=me.pid,coordinator_created=me.create_time(),awake=awake,updated_at=utc()))
                if vm.available/2**30<.4:low_since=low_since or time.monotonic()
                else:low_since=None
                marker=(latest.get('stage'),latest.get('message'))
                if marker!=last_marker:last_marker=marker;marker_since=time.monotonic()
                reason=None
                if latest.get('stage') in ('income_TMB_conditional','ADL_conditional_fit') and time.monotonic()-marker_since>150:reason='CONDITIONAL_FIT_TIME_LIMIT'
                if elapsed>limit:reason='STEP_TIME_LIMIT'
                if time.monotonic()-started>contract['pipeline_wall_seconds']:reason='PIPELINE_TIME_LIMIT'
                if low_since and time.monotonic()-low_since>30:reason='SUSTAINED_MEMORY_PRESSURE'
                if reason:owned_kill(active,born);r['status']=reason;break
                time.sleep(5)
            if r['status']=='RUNNING':r['status']='EXITED' if active.returncode==0 else 'RUNNER_FAILED'
            r.update(exitcode=active.returncode,seconds=time.monotonic()-begin,finished_at=utc());states[key]=r;write(ROOT/'runtime/STEPS.json',states);active=None
            return r
    try:
        # 完整案例模型各只调用一次；后续FULL模式直接复用该输出。
        for z in contract['indicators']:
            step(f'cc_{z}','run_models.R',[z,'CC'],600,ROOT/'runtime/progress.json')
        for z in contract['indicators']:
            if time.monotonic()-started>contract['pipeline_wall_seconds']:break
            mr=step(f'mi_{z}','prepare_scope.R',[z],contract['mi_scope_wall_seconds'],ROOT/'mi'/z/'runtime/progress.json')
            ad=read(ROOT/'mi'/z/'audit/ADMISSION.json')
            if ad is None:ad=dict(scope=z,passed=False,status=mr['status'])
            all_ad=read(ROOT/'audit/MI_ADMISSIONS.json');all_ad[z].update(ad);write(ROOT/'audit/MI_ADMISSIONS.json',all_ad)
            if ad.get('passed'):
                step(f'models_{z}','run_models.R',[z,'FULL'],contract['wall_seconds']+600,ROOT/'runtime/progress.json')
            else:
                fs=read(ROOT/'results/FAMILY_STATUS.json',{});fs[z.upper()+'_INC']=dict(status='IMPUTATION_NOT_ADMITTED',members=0,N=all_ad[z].get('N'),detail=ad);write(ROOT/'results/FAMILY_STATUS.json',fs)
        fs=read(ROOT/'results/FAMILY_STATUS.json',{});ads=read(ROOT/'audit/MI_ADMISSIONS.json')
        for z in contract['indicators']:fs.setdefault(z.upper()+'_INC',dict(status='NOT_RUN_WITHIN_BUDGET',members=0,N=ads[z]['N']))
        write(ROOT/'results/FAMILY_STATUS.json',fs);(ROOT/'runtime/MODELS_TERMINAL').write_text('All registered families adjudicated; inspect statuses',encoding='utf-8')
        step('pool','pool_h41.R',[],300)
        write(ROOT/'runtime/PIPELINE_TERMINAL.json',dict(status='BATCH_TERMINAL',seconds=time.monotonic()-started,results=read(ROOT/'results/POOLING_RECEIPT.json'),full_H4_complete=False,finished_at=utc()))
    except Exception as e:
        if active is not None:owned_kill(active,born)
        write(ROOT/'runtime/PIPELINE_TERMINAL.json',dict(status='COORDINATOR_ERROR',error=repr(e),traceback=traceback.format_exc(),finished_at=utc()));raise
    finally:
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
        write(ROOT/'runtime/AWAKE_RELEASED.json',dict(pid=me.pid,created=me.create_time(),released_at=utc()))
        lock.unlink(missing_ok=True)
if __name__=='__main__':main()
