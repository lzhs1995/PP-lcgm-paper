# 独立收入家族：40链，10轮检查混合；不足才至20轮，禁止依据显著性追加。
args<-commandArgs(TRUE);stopifnot(length(args)==1L);z<-args[1]
BATCH<-'C:/Users/LZHS/pp_lgcm_review/charls_income_h41_mi_20261016'
PILOT<-'C:/Users/LZHS/pp_lgcm_review/charls_income_mi_pilot_20261016'
.libPaths(c(file.path(PILOT,'library'),'C:/Users/LZHS/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
library(mice);library(miceadds);library(lme4);library(glmmTMB);library(jsonlite);library(digest)
contract<-fromJSON(file.path(BATCH,'contracts/RUN_CONTRACT.json'),simplifyVector=FALSE);stopifnot(z%in%unlist(contract$indicators),packageVersion('mice')=='3.19.10')
ROOT<-file.path(BATCH,'mi',z);for(x in c('private','checkpoints','audit','runtime','results'))dir.create(file.path(ROOT,x),showWarnings=FALSE,recursive=TRUE)
if(file.exists(file.path(ROOT,'audit/ADMISSION.json')))stop('Existing adjudication; do not rerun')
contract$max_conditional_calls<-2L*contract$m*contract$maxit
progress<-function(s,m){r<-list(stage=s,message=paste(z,m),scope=z,updated_at=format(Sys.time(),tz='UTC',usetz=TRUE),pid=Sys.getpid());write_json(r,file.path(ROOT,'runtime/progress.json'),auto_unbox=TRUE,pretty=TRUE);cat(s,z,m,'\n');flush.console()}
source(file.path(BATCH,'code/income_imputers.R'),local=TRUE);fit_env$scope<-z
lastfit<-file.path(ROOT,'private',paste0(z,'_g_last_TMB_fit.rds'))
if(file.exists(lastfit)){lf<-readRDS(lastfit);assign(z,list(beta=glmmTMB::fixef(lf)$cond,theta=log(sqrt(as.numeric(glmmTMB::VarCorr(lf)$cond[[1]][1,1])))),envir=fit_env$warm);rm(lf)}
prior_log<-file.path(ROOT,'audit/FIT_LOG.jsonl');if(file.exists(prior_log)){n<-vapply(lapply(readLines(prior_log),fromJSON),function(x)x$fit_n,0);if(length(n))fit_env$fit_n<-max(n)}
src<-file.path(PILOT,'attempt3/private',paste0(z,'_INPUTS.rds'));h0<-digest(file=src,algo='sha256');a<-readRDS(src);d<-a$data
saveRDS(a,file.path(ROOT,'private/INPUTS.rds'))
write_json(list(path=src,sha256=h0),file.path(ROOT,'audit/SOURCE.json'),auto_unbox=TRUE,pretty=TRUE)
warnings<-list();capture<-function(expr)withCallingHandlers(expr,warning=function(w){warnings[[length(warnings)+1L]]<<-data.frame(iteration=fit_env$iteration,target=fit_env$target,type='warning',message=conditionMessage(w));invokeRestart('muffleWarning')},message=function(w){warnings[[length(warnings)+1L]]<<-data.frame(iteration=fit_env$iteration,target=fit_env$target,type='message',message=conditionMessage(w));invokeRestart('muffleMessage')})
checkpoint<-function(imp){
 path<-file.path(ROOT,'checkpoints',sprintf('ITER%02d.rds',imp$iteration));stopifnot(!file.exists(path));tmp<-paste0(path,'.tmp')
 saveRDS(imp,tmp);stopifnot(file.rename(tmp,path));write_json(list(iteration=imp$iteration,sha256=digest(file=path,algo='sha256'),m=imp$m,source_sha256=h0),paste0(path,'.json'),auto_unbox=TRUE,pretty=TRUE)
}
ready<-function(imp){
 if(imp$iteration<contract$minit)return(FALSE)
 cv<-mice::convergence(imp);write.csv(cv,file.path(ROOT,'audit/CONVERGENCE.csv'),row.names=FALSE)
 tailcv<-cv[cv$vrb%in%c('g','adl') & cv$.it>imp$iteration-5L,,drop=FALSE]
 nrow(tailcv)==10L&&all(is.finite(tailcv$psrf))&&all(tailcv$psrf<1.1)
}
run_scope<-function(){
 cps<-list.files(file.path(ROOT,'checkpoints'),pattern='^ITER[0-9]{2}\\.rds$',full.names=TRUE);imp<-NULL
 if(length(cps))for(cp in rev(sort(cps))){
  meta<-paste0(cp,'.json');if(!file.exists(meta))next
  j<-fromJSON(meta);stopifnot(digest(file=cp,algo='sha256')==j$sha256,j$source_sha256==h0)
  imp<-readRDS(cp);stopifnot(imp$m==contract$m,identical(imp$data,d));progress('MI_RESUME',paste('verified iteration',imp$iteration,'same saved RNG'));break
 }
 if(is.null(imp)){
  fit_env$iteration<-1L;progress('MI_INITIALIZE','40 stochastic chains; original pilot imputations not reused')
  imp<-capture(mice(d,m=contract$m,maxit=1,method=a$method,predictorMatrix=a$predictors,visitSequence=a$visit,seed=contract$mi_seeds[[z]],data.init=a$initial,blots=a$blots,printFlag=FALSE));checkpoint(imp)
 }
 mixed<-ready(imp)
 while(imp$iteration<contract$maxit&&!mixed){
  fit_env$iteration<-imp$iteration+1L;progress('MI_ITERATION',paste(fit_env$iteration,'minimum',contract$minit,'maximum',contract$maxit))
  imp<-capture(mice.mids(imp,maxit=1,printFlag=FALSE));checkpoint(imp);mixed<-ready(imp)
 }
 saveRDS(imp,file.path(ROOT,'private/MIDS.rds'))
 write.csv(data.frame(variable=rownames(imp$predictorMatrix),imp$predictorMatrix,check.names=FALSE),file.path(ROOT,'audit/PREDICTORS_ACTUAL.csv'),row.names=FALSE)
 if(!is.null(imp$loggedEvents))write.csv(imp$loggedEvents,file.path(ROOT,'audit/LOGGED_EVENTS.csv'),row.names=FALSE)
 pm<-imp$predictorMatrix;essential<-all(pm['g',c('z0','z2','z_adl')]==1)&&all(pm['adl',c('g','z0','zg')]==1)&&all(pm[c('g','adl'),'cluster']==-2)&&pm['g','zg']==0&&pm['adl','z_adl']==0
 vals<-list();checks<-list();summ<-list()
 for(k in seq_len(contract$m)){
  v<-complete(imp,k);raw<-as.matrix(d);vv<-as.matrix(v);obs<-!is.na(raw)
  stopifnot(identical(unname(raw[obs]),unname(vv[obs])),!anyNA(vv),all(v$g%in%0:1),all(v$adl%in%0:6),all(v$adl[is.na(d$adl)]%in%d$adl[!is.na(d$adl)]),max(abs(v$zg-v$z0*v$g))<1e-12,max(abs(v$z_adl-v$z0*v$adl))<1e-12)
  b<-a$analysis;b$c7<-v$adl;b$g<-v$g;b$zg<-v$zg
  stopifnot(identical(b[setdiff(names(a$analysis),'c7')],a$analysis[setdiff(names(a$analysis),'c7')]))
  path<-file.path(ROOT,'private',sprintf('MI%02d.dat',k));write.table(b,path,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999');vals[[k]]<-b
  checks[[k]]<-data.frame(member=k,N=nrow(b),observed_preserved=TRUE,XY_masks_preserved=TRUE,passive_products=TRUE,ADL_support=TRUE,sha256=digest(file=path,algo='sha256'))
  summ[[k]]<-data.frame(scope=z,member=k,income_missing=sum(is.na(d$g)),imputed_G_mean=mean(v$g[is.na(d$g)]),imputed_ADL_mean=mean(v$adl[is.na(d$adl)]))
 }
 saveRDS(vals,file.path(ROOT,'private/COMPLETED.rds'));write.csv(do.call(rbind,checks),file.path(ROOT,'audit/MEMBER_VALIDATION.csv'),row.names=FALSE);write.csv(do.call(rbind,summ),file.path(ROOT,'results/MI_SUMMARIES.csv'),row.names=FALSE)
 b<-a$analysis;b$g<-d$g;b$zg<-d$zg;cc<-b[!is.na(d$g)&!is.na(d$adl),];stopifnot(!anyNA(cc[c(paste0('c',1:11),'g','zg')]))
 write.table(cc,file.path(ROOT,'private/CC.dat'),row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
 fits<-lapply(readLines(prior_log),fromJSON);fit_valid<-all(vapply(fits,function(f)isTRUE(f$valid),TRUE))
 stopifnot(digest(file=src,algo='sha256')==h0)
 pdf(file.path(ROOT,'results/MI_CHAINS.pdf'),width=10,height=7);print(plot(imp,c('g','adl')));dev.off()
 rec<-list(scope=z,passed=mixed&&essential&&fit_valid,m=contract$m,iterations=imp$iteration,N=nrow(b),N_CC=nrow(cc),communities=length(unique(b$cluster)),missing_income=sum(is.na(d$g)),missing_ADL=sum(is.na(d$adl)),mi_mixing_rule_pass=mixed,essential_predictors=essential,all_conditional_fits_valid=fit_valid,conditional_calls=length(fits),columns=names(b),compatibility=contract$compatibility,full_H4=FALSE)
 write_json(rec,file.path(ROOT,'audit/ADMISSION.json'),auto_unbox=TRUE,pretty=TRUE);print(rec)
}
tryCatch(run_scope(),error=function(e){write_json(list(scope=z,passed=FALSE,status='IMPUTATION_FAILED_NO_REPLACEMENT',error=conditionMessage(e)),file.path(ROOT,'audit/ADMISSION.json'),auto_unbox=TRUE,pretty=TRUE);stop(e)},finally={if(length(warnings))write.csv(do.call(rbind,warnings),file.path(ROOT,'audit/WARNINGS.csv'),row.names=FALSE);writeLines(capture.output(sessionInfo()),file.path(ROOT,'audit/R_SESSION_INFO.txt'))})
progress('MI_SCOPE_TERMINAL','Inspect saved admission; only complete40 can enter model family')
