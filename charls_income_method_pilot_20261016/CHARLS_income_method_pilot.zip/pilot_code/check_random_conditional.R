# 使用已保存拟合核对随机截距条件方差，无重新拟合。
ROOT <- 'C:/Users/LZHS/pp_lgcm_review/charls_income_mi_pilot_20261016'
.libPaths(c(file.path(ROOT,'library'),'C:/Users/LZHS/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
library(glmmTMB); library(lme4); library(jsonlite)
tt <- readRDS(file.path(ROOT,'private/sd_G_TMB_start.rds'))
ll <- readRDS(file.path(ROOT,'private/sd_G_LMER_warm.rds'))
rt <- ranef(tt,condVar=TRUE)$cond$cluster
rl <- ranef(ll,condVar=TRUE)$cluster
mf <- model.frame(tt); p <- as.numeric(fitted(tt)); psi <- as.numeric(VarCorr(tt)$cond$cluster[1,1])
cv <- 1/(tapply(p*(1-p),mf$cluster,sum)+1/psi)
vv <- as.numeric(attr(rt,'condVar'))
vl <- as.numeric(attr(rl,'postVar'))
stopifnot(identical(rownames(rt),rownames(rl)),identical(rownames(rt),names(cv)))
rec <- list(status='SAVED_FIT_CONDITIONAL_VARIANCE_CHECK',clusters=length(cv),TMB_attr_vs_conditional_max_relative=max(abs(vv-cv)/cv),lme4_attr_vs_conditional_max_relative=max(abs(vl-cv)/cv),TMB_attr_over_conditional_range=range(vv/cv),Mplus_calls=0,GLMM_refits=0)
write_json(rec,file.path(ROOT,'audit/RANDOM_CONDITIONAL_VARIANCE.json'),auto_unbox=TRUE,pretty=TRUE,digits=16)
write.csv(data.frame(conditional_variance=as.numeric(cv),TMB_sdreport_variance=vv,lme4_postVar=vl),file.path(ROOT,'private/RANDOM_CONDITIONAL_VARIANCE.csv'),row.names=FALSE)
print(rec)
