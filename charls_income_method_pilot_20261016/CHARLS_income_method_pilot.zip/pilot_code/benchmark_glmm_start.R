# 同一收入插补GLMM：TMB自动微分提供起点，再由原lme4完成估计；不删变量。
ROOT<-'C:/Users/LZHS/pp_lgcm_review/charls_income_mi_pilot_20261016'
.libPaths(c(file.path(ROOT,'library'),'C:/Users/LZHS/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
library(lme4);library(glmmTMB);library(jsonlite);library(digest)
warnings<-character();receipt<-list();total<-Sys.time()
b<-readRDS(file.path(ROOT,'private/sd_INPUTS.rds'));vars<-names(which(b$predictors['g',]==1));d<-b$initial[!is.na(b$data$g),];d$cluster<-factor(d$cluster)
f<-as.formula(paste('g~',paste(vars,collapse='+'),'+(1|cluster)'))
stopifnot(qr(model.matrix(lme4::nobars(f),d))$rank==length(vars)+1L)
capture<-function(expr)withCallingHandlers(expr,warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')})
fit_one<-function(name,expr){
 clauder_progress(paste0('income_benchmark_',name),paste('Same61-column income GLMM; cap120s;',name))
 t0<-Sys.time();setTimeLimit(elapsed=120,transient=TRUE)
 ans<-tryCatch(capture(expr),error=function(e)e)
 setTimeLimit(cpu=Inf,elapsed=Inf,transient=FALSE)
 r<-list(name=name,seconds=as.numeric(difftime(Sys.time(),t0,units='secs')),error=if(inherits(ans,'error'))conditionMessage(ans) else NULL)
 receipt[[name]]<<-r;write_json(receipt,file.path(ROOT,'audit/GLMM_BENCHMARK.json'),auto_unbox=TRUE,pretty=TRUE)
 if(inherits(ans,'error'))stop(ans);ans
}
tryCatch({
 tt<-fit_one('TMB',glmmTMB::glmmTMB(f,data=d,family=binomial(),control=glmmTMB::glmmTMBControl(parallel=1,rank_check='stop',optCtrl=list(iter.max=1000,eval.max=1000))))
 saveRDS(tt,file.path(ROOT,'private/sd_G_TMB_start.rds'));stopifnot(tt$fit$convergence==0,isTRUE(tt$sdr$pdHess))
 initial<-list(theta=sqrt(as.numeric(glmmTMB::VarCorr(tt)$cond$cluster[1,1])),fixef=glmmTMB::fixef(tt)$cond)
 ll<-fit_one('LMER_WARM',lme4::glmer(f,data=d,family=binomial(),start=initial,control=lme4::glmerControl(optimizer='bobyqa',nAGQ0initStep=FALSE,optCtrl=list(maxfun=100000))))
 saveRDS(ll,file.path(ROOT,'private/sd_G_LMER_warm.rds'))
 beta<-lme4::fixef(ll);tb<-glmmTMB::fixef(tt)$cond[names(beta)];se<-sqrt(diag(vcov(ll)));ts<-sqrt(diag(vcov(tt)$cond))[names(beta)]
 comp<-data.frame(term=names(beta),lme4=as.numeric(beta),TMB=as.numeric(tb),lme4_se=se,TMB_se=ts,difference_SE=abs(beta-tb)/se,SE_relative=abs(se-ts)/se)
 write.csv(comp,file.path(ROOT,'results/GLMM_BACKEND_COMPARISON.csv'),row.names=FALSE)
 re1<-lme4::ranef(ll,condVar=TRUE)$cluster;re2<-glmmTMB::ranef(tt,condVar=TRUE)$cond$cluster;re2<-re2[rownames(re1),,drop=FALSE]
 receipt$comparison<-list(logLik_abs=abs(as.numeric(logLik(ll)-logLik(tt))),max_coefficient_SE=max(comp$difference_SE),max_SE_relative=max(comp$SE_relative),random_variance_lme4=initial$theta^2,random_variance_TMB=as.numeric(lme4::VarCorr(ll)$cluster[1,1]),max_random_mode_abs=max(abs(re1[,1]-re2[,1])),lme4_optimizer=ll@optinfo$conv$opt,lme4_convergence_messages=ll@optinfo$conv$lme4$messages,TMB_optimizer=tt$fit$convergence,TMB_Hessian_PD=tt$sdr$pdHess)
 receipt$status<-'SAME_FORMULA_BACKEND_BENCHMARK_COMPLETE'
},error=function(e){receipt$status<<-'BENCHMARK_STOPPED';receipt$error<<-conditionMessage(e)})
receipt$warnings<-warnings;receipt$total_seconds<-as.numeric(difftime(Sys.time(),total,units='secs'));receipt$Mplus_calls<-0
write_json(receipt,file.path(ROOT,'audit/GLMM_BENCHMARK.json'),auto_unbox=TRUE,pretty=TRUE,digits=16);print(receipt)
