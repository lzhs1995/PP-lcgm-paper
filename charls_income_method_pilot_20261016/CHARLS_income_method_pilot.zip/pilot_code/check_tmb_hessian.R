# 同一Laplace模型：直接对自动微分梯度作中心差分，独立核对Hessian协方差。
ROOT<-'C:/Users/LZHS/pp_lgcm_review/charls_income_mi_pilot_20261016'
.libPaths(c(file.path(ROOT,'library'),'C:/Users/LZHS/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
library(lme4);library(glmmTMB);library(jsonlite)
b<-readRDS(file.path(ROOT,'private/sd_INPUTS.rds'));vars<-names(which(b$predictors['g',]==1));d<-b$initial[!is.na(b$data$g),];d$cluster<-factor(d$cluster);f<-as.formula(paste('g~',paste(vars,collapse='+'),'+(1|cluster)'))
old<-readRDS(file.path(ROOT,'private/sd_G_TMB_start.rds'));start<-list(beta=fixef(old)$cond,theta=log(sqrt(as.numeric(VarCorr(old)$cond$cluster[1,1]))))
t0<-Sys.time();setTimeLimit(elapsed=120,transient=TRUE)
rec<-tryCatch({
 clauder_progress('income_Hessian_check','Default non-profile TMB, existing converged start, same formula')
 fit<-glmmTMB(f,data=d,family=binomial(),start=start,control=glmmTMBControl(parallel=1,profile=FALSE,rank_check='stop',optCtrl=list(iter.max=1000,eval.max=1000)))
 fit_seconds<-as.numeric(difftime(Sys.time(),t0,units='secs'));saveRDS(fit,file.path(ROOT,'private/sd_G_TMB_verified.rds'))
 par<-fit$fit$par;H<-matrix(NA_real_,length(par),length(par));step<-1e-4
 for(i in seq_along(par)){
  plus<-minus<-par;plus[i]<-plus[i]+step;minus[i]<-minus[i]-step
  H[,i]<-(fit$obj$gr(plus)-fit$obj$gr(minus))/(2*step)
 }
 fit$obj$fn(par);V<-solve((H+t(H))/2);official<-fit$sdr$cov.fixed
 ii<-which(names(par)=='beta');stopifnot(length(ii)==length(fixef(fit)$cond))
 se1<-sqrt(diag(V)[ii]);se2<-sqrt(diag(official)[ii]);relative<-max(abs(se1-se2)/se2)
 passed<-fit$fit$convergence==0&&isTRUE(fit$sdr$pdHess)&&all(eigen((H+t(H))/2,symmetric=TRUE,only.values=TRUE)$values>0)&&relative<.001
 write.csv(data.frame(term=names(fixef(fit)$cond),finite_gradient_SE=se1,TMB_SE=se2),file.path(ROOT,'results/TMB_HESSIAN_CHECK.csv'),row.names=FALSE)
 write.table(H,file.path(ROOT,'results/TMB_FINITE_GRADIENT_HESSIAN.csv'),sep=',',row.names=FALSE,col.names=FALSE)
 list(status=if(passed)'DEFAULT_TMB_HESSIAN_VALIDATED'else'HESSIAN_CHECK_FAILED',fit_seconds=fit_seconds,total_seconds=as.numeric(difftime(Sys.time(),t0,units='secs')),max_SE_relative=relative,full_covariance_max_abs=max(abs(V-official)),optimizer=fit$fit$convergence,pdHess=fit$sdr$pdHess,finite_gradient_step=step,parameters=length(par),formula_unchanged=TRUE,Mplus_calls=0)
},error=function(e)list(status='HESSIAN_CHECK_ERROR',error=conditionMessage(e),Mplus_calls=0))
setTimeLimit(cpu=Inf,elapsed=Inf,transient=FALSE);write_json(rec,file.path(ROOT,'audit/TMB_HESSIAN_CHECK.json'),auto_unbox=TRUE,pretty=TRUE,digits=16);print(rec)
