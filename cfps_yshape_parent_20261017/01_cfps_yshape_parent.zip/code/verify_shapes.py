"""独立原始参数核验与同数据形状比较；不调用估计器。"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import hashlib,json,re,shutil,sys
import numpy as np
from scipy.stats import chi2
from raw_parameter_reader import raw_model
R=Path(__file__).resolve().parents[1]
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
public='--public' in sys.argv
parent=R/'references/linear_parent'
if not public:
 source=R.parent/'round2E_20261010/models/CFPS_SD_E0_01_base'
 parent.mkdir(parents=True,exist_ok=True)
 for name in ('model.inp','model.out','estimates.dat','tech3.dat','parameters_high_precision.csv','parameter_covariance.csv','key_paths.csv','receipt.json','input_contract.json'):
  assert (source/name).is_file(),name
  if (parent/name).exists():assert sha(parent/name)==sha(source/name)
  else:shutil.copyfile(source/name,parent/name)
def fit(text):
 t=text.split('MODEL FIT INFORMATION',1)[1].split('MODEL RESULTS',1)[0]
 def num(pattern):
  m=re.search(pattern,t);assert m,pattern;return float(m.group(1))
 return dict(P=int(num(r'Number of Free Parameters\s+(\d+)')),LL=num(r'H0 Value\s+([-\d.]+)'),scaling=num(r'H0 Scaling Correction Factor\s+([\d.]+)'),AIC=num(r'Akaike \(AIC\)\s+([\d.]+)'),BIC=num(r'Bayesian \(BIC\)\s+([\d.]+)'),CFI=num(r'CFI\s+([\d.]+)'),TLI=num(r'TLI\s+([\d.]+)'))
def load_model(d):
 text,mapping,q,se,v,paths,_=raw_model(d)
 return dict(text=text,mapping=mapping,q=q,se=se,v=v,paths=paths,fit=fit(text))
base=load_model(parent);assert base['fit']['P']==134
records=[];raw={}
for st in ('A','B'):
 d=R/'models'/('CFPS_SD_E0_FREEY_MI01_'+st)
 rec=load(d/'receipt.json');engine=load(d/'engine_receipt.json');job=load(d/'job.json')
 if not public:
  for name,h in job['hashes'].items():assert sha(d/name)==h
  assert sha(d/'model.out')==rec['output_sha256']==engine['output_sha256']
 assert job['hashes']['data.dat']=='aba3e18819adc647848159ec0f18b66a6e295bcb114c549eac01634b6e994dc8'
 row=dict(start=st,status=rec['status'],engine_seconds=engine['seconds'],peak_tree_rss=engine['peak_tree_rss'])
 if engine['status']=='EXITED' and (d/'parameters_high_precision.csv').exists():
  m=load_model(d);raw[st]=m;assert len(m['q'])==137
  def cell(mat,r,c):
   ix={x[3] for x in m['mapping'] if x[:3]==(mat,r,c)};assert len(ix)==1
   i=next(iter(ix))-1;assert i>=0
   return dict(estimate=float(m['q'][i]),SE=float(m['se'][i]),parameter=i+1)
  sy=cell('PSI','SY','SY');assert abs(sy['estimate']-rec['SY'])<1e-10
  loadings={f'Y{i}':cell('LAMBDA',f'Y{i}','SY') for i in (2,3,4)}
  row.update(fit=m['fit'],SY=sy,Y_loadings=loadings,normal='THE MODEL ESTIMATION TERMINATED NORMALLY' in m['text'],vcov_min_eigenvalue=float(np.linalg.eigvalsh(m['v']).min()))
  if rec['status']=='USABLE':
   assert row['normal'] and sy['estimate']>0 and row['vcov_min_eigenvalue']>0 and load(d/'validation.json')['passed']
   assert 'FIXED TO AVOID SINGULARITY' not in m['text']
 records.append(row)
contract=load(R/'contracts/RUN_CONTRACT.json');agreement=dict(passed=False,reason='two_legal_models_required')
comparison=dict(decision='NO_ADOPTION_INVALID_OR_UNSTABLE',full_MI=False)
if len(raw)==2 and all(r['status']=='USABLE' for r in records):
 a,b=raw['A'],raw['B'];assert a['mapping']==b['mapping']
 tol=contract['numerical_agreement'];dq=np.abs(a['q']-b['q']);ds=np.abs(a['se']-b['se'])/a['se'];dt=np.maximum(tol['parameter_absolute_floor'],tol['parameter_SE_fraction']*a['se'])
 agreement=dict(passed=bool(np.all(dq<=dt) and np.all(ds<=tol['SE_relative']) and abs(a['fit']['LL']-b['fit']['LL'])<=tol['LL_absolute']),max_parameter_difference_in_reference_SE=float(np.max(dq/a['se'])),max_SE_relative_difference=float(ds.max()),LL_difference=abs(a['fit']['LL']-b['fit']['LL']),all_137_parameters_compared=True)
 if agreement['passed']:
  f0=base['fit'];f1=a['fit'];df=f1['P']-f0['P'];assert df==3
  cd=(f0['P']*f0['scaling']-f1['P']*f1['scaling'])/(f0['P']-f1['P'])
  lr=-2*(f0['LL']-f1['LL'])/cd if cd>0 else None
  comparison=dict(decision='FREE_Y_PREFERRED_SINGLE_MI_DIAGNOSTIC' if f1['BIC']<f0['BIC'] else 'RETAIN_FIXED_Y_NO_AUTOMATIC_FOLLOWUP',fixed_Y=f0,free_Y=f1,BIC_free_minus_fixed=f1['BIC']-f0['BIC'],AIC_free_minus_fixed=f1['AIC']-f0['AIC'],scaled_MLR_LR_secondary=dict(correction=cd,statistic=lr,df=df,p=float(chi2.sf(lr,df)) if lr is not None and lr>=0 else None,precision='Uses printed LL and scaling factors; approximate single-MI comparison, not pooled inference'),full_MI=False)
term=load(R/'audit/BATCH_TERMINAL.json');assert term['new_calls']==2 and not term['automatic_followup']
result=dict(status='PASS',scope='Two starts of one new shape-parent diagnostic; not two MI members',new_Mplus_calls=2,total_engine_seconds=sum(r['engine_seconds'] for r in records),starts=records,agreement=agreement,comparison=comparison,full_original_four_moderation_complete=False,full_H4_complete=False,public_mode=public)
(R/'audit/INDEPENDENT_SHAPES.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
