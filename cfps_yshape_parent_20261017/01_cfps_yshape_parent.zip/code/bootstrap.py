"""在不重复既有自由形状诊断的前提下准备同数据条件父模型比较。"""
from pathlib import Path
import datetime,hashlib,json,os,re,shutil
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import numpy as np
R=Path(__file__).resolve().parents[1];P=R.parent/'cfps_h42_unrun_sd_20261017'
for name in ('audit','contracts','models','results','runtime','reports'):(R/name).mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
code=['r2e_local.R','r2e_tools.R','r2e_upstream_math.R','engine.py','run_one.R','windows_awake_guard.py','mplus_queue.py','process_ownership.py','raw_parameter_reader.py']
reuse=[]
for name in code:
 src=P/'code'/name;dst=R/'code'/name;assert not dst.exists();shutil.copy2(src,dst);reuse.append(dict(name=name,source=str(src),sha256=sha(src)))
parent=R.parent/'round2E_20261010/models/CFPS_SD_E0_01_base'
c=read(parent/'input_contract.json');rec=read(parent/'receipt.json')
assert rec['status']=='USABLE' and c['N']==3274 and c['expected_free']==134
assert sha(parent/'data.dat')==c['data_sha256'] and sha(parent/'model.inp')==c['input_sha256'] and sha(parent/'model.out')==rec['output_sha256']
univ=R.parent/'round2_20261006/models/D3274_U0_free/attempt01'
linear=R.parent/'round2_20261006/models/D3274_U0_linear/attempt01'
legacy=R.parent/'round2_20261006/models/D1981_P1_free/attempt03'
old=np.genfromtxt(univ/'data.dat',missing_values='.',filling_values=np.nan)
now=np.genfromtxt(parent/'data.dat',missing_values='.',filling_values=np.nan)
assert old.shape==(3274,6) and now.shape[0]==3274
y=now[:,6:11];oldy=old[:,1:6]
mask=np.isfinite(y[:,0])&np.isfinite(oldy[:,0]);design=np.c_[np.ones(mask.sum()),oldy[mask,0]]
coef=np.linalg.lstsq(design,y[mask,0],rcond=None)[0]
assert np.array_equal(old[:,0],now[:,0]),'Cluster order differs'
same_mask=np.array_equal(np.isnan(oldy),np.isnan(y));err=float(np.nanmax(np.abs(y-(coef[0]+coef[1]*oldy))))
assert same_mask and err<1e-8,(same_mask,err)
data_proof=dict(N=3274,old_shape=list(old.shape),current_shape=list(now.shape),cluster_order_equal=True,all_five_wave_missing_masks_equal=same_mask,baseline_affine_intercept=float(coef[0]),baseline_affine_slope=float(coef[1]),max_all_wave_absolute_error=err,tolerance=1e-8,interpretation='Numerical Y and cluster-row equivalence after common affine rescaling; not equivalence of univariate and adjusted joint models')
oldtext=(univ/'model.out').read_text(encoding='latin1');pattern=r'SY\s+\|\s*\n\s*Y1[^\n]+\n\s*Y2\s+([-\d.]+)[^\n]+\n\s*Y3\s+([-\d.]+)[^\n]+\n\s*Y4\s+([-\d.]+)'
match=re.search(pattern,oldtext);assert match;startB=[float(x)/10 for x in match.groups()]
rows=[]
roots=['20261005','round2_20261006','round2B_20261006','round2C_20261007','round2D_20261008','round2E_20261010','round2F_20261011','reopen_observed_charls_20261015','h41_mi_charls_covariates_20261015','charls_adjusted_h41_20261015','h41_remaining_charls_resources_20261015','cfps_h42_unrun_sd_20261017']
for name in roots:
 for inp in (R.parent/name).rglob('*.inp*'):
  if not inp.is_file() or inp.suffix.lower() not in ('.inp','.txt') or 'public_' in str(inp):continue
  text=inp.read_text(encoding='utf-8-sig',errors='replace');g=re.findall(r'(?im)^\s*iy\s+sy\s*\|\s*([^;]+);',text)
  if len(g)!=1 or not re.search(r'y[234]\s*\*',g[0],re.I):continue
  d=inp.parent/'data.dat';data_sha=sha(d) if d.exists() else None
  rows.append(dict(input=str(inp),input_sha256=sha(inp),data_sha256=data_sha,Y_growth=g[0].strip(),same_current_data_bytes=data_sha==c['data_sha256']))
assert not any(x['same_current_data_bytes'] for x in rows),'Existing equivalent-data free shape candidate requires review before estimate'
evidence=dict(parent=str(parent),parent_contract=c,parent_receipt=rec,univariate=str(univ),univariate_linear=str(linear),legacy_joint=str(legacy),legacy_joint_data_rows=1981,univariate_start_B=startB,univariate_comparison=data_proof,free_shape_inventory=rows,source_files=[dict(path=str(p),sha256=sha(p)) for d in (parent,univ,linear,legacy) for p in (d/'model.inp',d/'model.out',d/'data.dat')],reused_code=reuse)
(R/'audit/SOURCE_ADMISSION.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')
contract=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),authorization='Persistent authorized incomplete CFPS moderation/H4 research; science-led shape sensitivity, not unchanged failed-spec rerun',scope='Only SD E0 with free Y intermediate loadings; same corrected MI01, N3274, c1-c24, X free shape, observed Z0, all original regressions and same-wave residuals',change='Free Y2/Y3/Y4 time loadings; endpoints remain Y1@0 Y5@1; no new interaction or fixed variance',starts={'A':[.4,.6,.8],'B':startB},max_calls=2,total_engine_seconds=240,category_seconds={'YSHAPE_PARENT':240},per_call_seconds=120,resource_admission_revision={'owned_engine_slots':1,'max_external_mplus_at_admission':2,'minimum_available_gib':1,'minimum_commit_available_gib':2,'max_host_cpu_percent':85,'resource_wait_seconds':120,'foreign_processes_never_modified':True},numerical_agreement={'LL_absolute':.01,'parameter_SE_fraction':.05,'parameter_absolute_floor':.001,'SE_relative':.05},primary_model_comparison='BIC on identical data. Prefer the simpler frozen linear-Y parent unless legal stable free-Y model has lower BIC. No interaction p-value selection. Scaled MLR LL difference with 3 df is secondary, only if both legal and correction positive; this is MI01 diagnostic, not pooled MI.',gate='Both starts legal, no automatic fixing, positive covariance/SE and numerical agreement. Failure or no BIC preference ends this shape route. No automatic new shape or extra starts.',full_H4_complete=False,full_MI=False,original_files_immutable=True,publication='Aggregate evidence only; individual DAT and RDS excluded',primary_sources=['https://www.statmodel.com/HTML_UG/chapter6V8.htm','https://www.statmodel.com/chidiff.shtml'])
(R/'contracts/RUN_CONTRACT.json').write_text(json.dumps(contract,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(status='READY_FOR_BOUNDED_NEW_PARENT',historical_free_candidates=len(rows),same_current_data_candidates=0,univariate_data_equivalence=data_proof,starts=contract['starts'])))
