# 同一3274人数据，仅释放抑郁中间三期载荷；两起点、有界、不自动追加。
ROOT <- '<LOCAL_USER>/pp_lgcm_review/cfps_yshape_parent_20261017'
.libPaths(c('<LOCAL_USER>/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
Sys.setenv(R2E_ROOT=ROOT,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
source(file.path(ROOT,'code/r2e_local.R'),local=TRUE)
library(MplusAutomation);library(ps)
safe_progress<-function(stage,message) tryCatch(progress(stage,message),error=function(e){cat(conditionMessage(e),'\n');flush.console()})
main<-function(){
 contract<-rj(file.path(ROOT,'contracts/RUN_CONTRACT.json'))
 parent<-'<LOCAL_USER>/pp_lgcm_review/round2E_20261010/models/CFPS_SD_E0_01_base'
 stopifnot(hashf(file.path(parent,'data.dat'))=='aba3e18819adc647848159ec0f18b66a6e295bcb114c549eac01634b6e994dc8')
 base<-spec_info_r2e('SD','E0','c1-c24'); results<-list()
 owner<-list(pid=Sys.getpid(),created=as.numeric(ps::ps_create_time(ps::ps_handle())))
 wj(list(owner=owner),file.path(ROOT,'runtime/OWNER.json'))
 awake<-processx::process$new(PY,c('-X','utf8',file.path(ROOT,'code/windows_awake_guard.py'),'--owner-file',file.path(ROOT,'runtime/OWNER.json'),'--output',file.path(ROOT,'runtime/awake'),'--interval','5'),stdout=file.path(ROOT,'runtime/awake.log'),stderr='2>&1',cleanup=FALSE)
 on.exit({writeLines('release owned guard',file.path(ROOT,'runtime/awake/stop.request'));awake$wait(8000L)},add=TRUE)
 active<-FALSE
 for(i in 1:40){
  a<-rj(file.path(ROOT,'runtime/awake/identity.json'));hb<-rj(file.path(ROOT,'runtime/awake/heartbeat.json'))
  if(!is.null(a)&&!is.null(hb)&&a$owner$pid==owner$pid&&abs(a$owner$created-owner$created)<.01&&awake$is_alive()){active<-TRUE;break}
  if(!awake$is_alive())stop('Awake helper failed');Sys.sleep(.5)
 };stopifnot(active)
 for(st in c('A','B')){
  si<-base;ix<-grep('iy sy \\|',si$model,ignore.case=TRUE);stopifnot(length(ix)==1)
  v<-unlist(contract$starts[[st]])
  si$model[ix]<-sprintf('iy sy | y1@0 y2*%.12g y3*%.12g y4*%.12g y5@1;',v[1],v[2],v[3])
  stopifnot(identical(stmt_pairs(si$model),stmt_pairs(base$model)),!length(si$fixed_zero))
  mm<-make_model(si,parent);stopifnot(mm$expected_free==134L)
  added<-data.frame(op='BY',lhs='SY',rhs=paste0('Y',2:4),init=v,key=paste0('BY:SY:Y',2:4),value=v,source_value=v,action=if(st=='A')'calendar_start' else 'legacy_univariate_rescaled_start',source_sha256=NA_character_)
  mm$mapping<-rbind(mm$mapping,added)
  d<-file.path(ROOT,'models',paste0('CFPS_SD_E0_FREEY_MI01_',st));dir.create(d,showWarnings=FALSE)
  stopifnot(!file.exists(file.path(d,'model.inp')),!file.exists(file.path(d,'model.out')))
  inp<-inp_text(basename(d),si$use,analysis_r2e('linear',processors=1),mm$lines,kind='linear')
  writeLines(inp,file.path(d,'model.inp'));stopifnot(file.copy(file.path(parent,'data.dat'),file.path(d,'data.dat'),overwrite=FALSE))
  csv(mm$mapping,file.path(d,'start_mapping.csv'))
  j<-list(id=basename(d),root=ROOT,dest=d,spec='E0_FREEY',start=st,member=1,category='YSHAPE_PARENT',cap_seconds=120,rscript=file.path(R.home('bin'),'Rscript.exe'),mplus=MPLUS,expected_free=137L,parent=parent,hashes=list(model.inp=hashf(file.path(d,'model.inp')),data.dat=hashf(file.path(d,'data.dat'))))
  wj(j,file.path(d,'job.json'));safe_progress('YSHAPE_FIRST_COMPARISON',j$id)
  p<-processx::process$new(PY,c('-X','utf8',file.path(ROOT,'code/engine.py'),file.path(d,'job.json')),stdout=file.path(d,'supervisor.log'),stderr='2>&1',cleanup=FALSE)
  last<-0
  while(p$is_alive()){
   p$wait(1000L)
   if(as.numeric(Sys.time())-last>25){
    hb<-tryCatch(rj(file.path(ROOT,'runtime/progress.json')),error=function(e)NULL)
    msg<-if(is.null(hb))paste(j$id,'admission') else paste(j$id,hb$stage,if(!is.null(hb$elapsed_seconds))round(hb$elapsed_seconds,1) else '')
    if(exists('clauder_progress',mode='function'))try(clauder_progress('estimating',msg),silent=TRUE)
    cat(msg,'\n');flush.console();last<-as.numeric(Sys.time())
   }
  }
  er<-rj(file.path(d,'engine_receipt.json'));nr<-rj(file.path(d,'not_run.json'))
  rr<-list(id=j$id,start=st,member=1,full_MI=FALSE,status=if(!is.null(er))er$status else if(!is.null(nr))nr$status else 'SUPERVISOR_NO_RECEIPT',engine_exit=p$get_exit_status(),dest=d,engine=er)
  if(!is.null(er)&&er$status=='EXITED')rr<-tryCatch({
   native<-MplusAutomation::readModels(file.path(d,'model.out'),what='all',quiet=TRUE);saveRDS(native,file.path(d,'mplusautomation_readback.rds'))
   m<-read_mplus_raw(d);stopifnot(m$P==137L)
   dd<-read_dat(file.path(d,'data.dat'),R2D_NAMES);gt<-gate_r2e(m,si,range(dd$z0,na.rm=TRUE))
   rr$status<-classify_local(m,si,gt)
   if(any(grepl('FIXED TO AVOID SINGULARITY',m$lines,fixed=TRUE)))rr$status<-'AUTOFIX_REJECTED'
   rr$parameters<-m$P;rr$negative<-gt$negative;rr$SY<-mval(m,'PSI','SY','SY');rr$LL<-m$extra[['H0 Loglikelihood']]
   csv(m$par,file.path(d,'parameters_high_precision.csv'));csv(key_paths_r2e(m,si$key),file.path(d,'key_paths.csv'));csv(m$spec,file.path(d,'tech1_parameter_map.csv'));csv(m$values,file.path(d,'matrix_values.csv'))
   write.table(m$V,file.path(d,'parameter_covariance.csv'),sep=',',row.names=FALSE,col.names=FALSE)
   wj(gt,file.path(d,'validation.json'));wj(m$extra,file.path(d,'saved_fit.json'));rr
  },error=function(e){rr$status<-'READBACK_OR_ESTIMATION_FAILURE';rr$error<-conditionMessage(e);rr})
  if(file.exists(file.path(d,'model.out')))rr$output_sha256<-hashf(file.path(d,'model.out'))
  wj(rr,file.path(d,'receipt.json'));results[[st]]<-rr;wj(results,file.path(ROOT,'results/SHAPE_ATTEMPTS.json'))
  safe_progress('YSHAPE_ATTEMPT_FINISHED',paste(st,rr$status))
 }
 writeLines(capture.output(sessionInfo()),file.path(ROOT,'audit/R_SESSION_INFO.txt'))
 wj(list(status='TWO_SHAPE_ATTEMPTS_ADJUDICATED',starts=lapply(results,function(x)x[c('id','status','negative','SY','LL')]),new_calls=length(Filter(function(x)!is.null(x$engine),results)),full_H4_complete=FALSE,full_MI=FALSE,automatic_followup=FALSE),file.path(ROOT,'audit/BATCH_TERMINAL.json'))
 safe_progress('YSHAPE_NATIVE_TERMINAL','Two bounded starts finished; independent fit comparison follows; no automatic follow-up')
 cat('CFPS_YSHAPE_NATIVE_TERMINAL\n')
}
main()
