# 对实际ZIP解压结果复算；没有微观数据，也不启动Mplus。
local({
 root<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_sd_urban_family_recovery_20261019';library(jsonlite);library(ps)
 d<-file.path(root,'audit/public_verification');stopifnot(!file.exists(file.path(d,'OWNER.json')))
 h<-fromJSON(file.path(root,'audit/HOST_ADMISSION.json'));age<-as.numeric(difftime(Sys.time(),as.POSIXct(substr(h$utc,1,19),format='%Y-%m-%dT%H:%M:%S',tz='UTC'),units='secs'))
 stopifnot(h$admitted,is.finite(age),age>=0,age<120)
 ps_set_cpu_affinity(ps_handle(),as.integer(h$selected_cores))
 write_json(list(owner=list(pid=Sys.getpid(),created=as.numeric(ps_create_time(ps_handle())))),file.path(d,'OWNER.json'),auto_unbox=TRUE,digits=16)
 result<-tryCatch({
  target<-file.path(root,'public_replay');source(file.path(root,'verification/public_byte_cache.R'),local=TRUE)
  e<-make_public_byte_cache(target,parent=environment());source(file.path(target,'verification/verify_pooled_base.R'),local=e)
  e$verify_pooled_base(target,'EDU_URBAN',public=TRUE);write_json(e$cache_stats(),file.path(d,'CACHE_STATS.json'),auto_unbox=TRUE,pretty=TRUE)
  list(status='PASS')
 },error=function(e)list(status='FAILED',error=conditionMessage(e)))
 result$utc<-format(Sys.time(),tz='UTC');write_json(result,file.path(d,'TERMINAL.json'),auto_unbox=TRUE,pretty=TRUE)
 if(result$status!='PASS')stop(result$error)
 cat('RECOVERED_PUBLIC_REPLAY_NATIVE_TERMINAL\n')
})
