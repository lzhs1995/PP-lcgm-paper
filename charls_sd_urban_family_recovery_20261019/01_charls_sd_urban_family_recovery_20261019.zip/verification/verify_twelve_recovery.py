"""独立读回旧12项与新单家族，只允许一个家族替换；固定12项校正。"""
from pathlib import Path
import csv,hashlib,json,math,sys
R=Path(__file__).resolve().parents[1];public='--public' in sys.argv
old=R/'source_prior/TWELVE_H42_RESOURCES.csv' if public else R.parent/'charls_corrected_h42_income_models_20261018/results/TWELVE_H42_RESOURCES.csv'
def rows(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
a={r['family']:r for r in rows(old)};v=rows(R/'results/pool_EDU_URBAN/H42_REGISTERED.csv');assert len(v)==1 and v[0]['family']=='sd_URBAN'
assert a['sd_URBAN']['members']=='1';a['sd_URBAN']=v[0]
b={r['family']:r for r in rows(R/'results/TWELVE_H42_RESOURCES.csv')}
assert set(a)==set(b)=={f'{z}_{g}' for z in ('sd','gender','oldest','son') for g in ('EDU','URBAN','INC')}
def same(x,y):
 if x==y:return True
 try:return math.isclose(float(x),float(y),rel_tol=1e-10,abs_tol=1e-12)
 except (ValueError,TypeError):return False
for k in a:
 assert a[k]['members']==a[k]['m']
 for col in a[k]:
  if col not in ('Holm_12','Bonferroni_12'):assert same(a[k][col],b[k][col]),(k,col)
sortedp=sorted((float(v['p']),k) for k,v in a.items())
for rank,(p,k) in enumerate(sortedp):
 holm=min(1.,max((12-j)*pv for j,(pv,_) in enumerate(sortedp[:rank+1])))
 assert same(str(holm),b[k]['Holm_12']) and same(str(min(1.,12*p)),b[k]['Bonferroni_12'])
assert sum(int(x['members']) for x in b.values())==320
receipt=dict(status='PASS',registered=12,complete=12,members=320,replaced_family='sd_URBAN',unchanged_other_rows=11,all_intervals_include_zero=all(float(x['lower'])<=0<=float(x['upper']) for x in b.values()),original_four_complete=False,full_H4_complete=False,source_sha256=hashlib.sha256(old.read_bytes()).hexdigest(),result_sha256=hashlib.sha256((R/'results/TWELVE_H42_RESOURCES.csv').read_bytes()).hexdigest())
dest=R/'audit'/('PUBLIC_TWELVE_RESOURCES_INDEPENDENT.json' if public else 'TWELVE_RESOURCES_INDEPENDENT.json');assert not dest.exists();dest.write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(receipt))
