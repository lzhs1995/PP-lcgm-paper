"""显式、一次性MI20恢复修订。仅19份成功且旧作业确实退出后可应用。"""
from pathlib import Path
import datetime,hashlib,json,psutil,shutil,sqlite3,contextlib
R=Path(__file__).resolve().parents[1];A=R/'audit/final_member';A.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=R/'audit/resume_stage1'
assert read(prior/'GUARD_complete.json')['decision']=='PASS'
assert read(prior/'TERMINAL.json')['members']==19 and (prior/'NATIVE_TERMINAL.json').exists()
o=read(prior/'OWNER.json')['owner']
try:assert abs(psutil.Process(o['pid']).create_time()-o['created'])>.01
except psutil.NoSuchProcess:pass
assert not (R/'runtime/engine.lock').exists()
assert read(R/'results/FAMILY_STATUS.json')['sd_URBAN']['members']==19
calls=read(R/'results/CALL_RESULTS.json')
for k in range(1,20):
 name=f'CHARLS_SD_URBAN_H42_E1_MI{k:02}_A';v=calls[name]
 assert v['status']=='USABLE_SINGLE_DATASET' and sha(R/'models'/name/'model.out')==v['output_sha256']
candidate=read(R/'contracts/MI20_RECOVERY_AMENDMENT_CANDIDATE.json')
contract_path=R/'contracts/RUN_CONTRACT.json';contract=read(contract_path)
assert sha(contract_path)==candidate['original_contract_sha256'] and contract['max_mplus_calls']==17
p=R/'models/CHARLS_SD_URBAN_H42_E1_MI20_A'
assert not (p/'engine_receipt.json').exists() and not (p/'model.out').exists()
assert sha(p/'model.inp')==candidate['source_input_sha256'] and sha(p/'data.dat')==candidate['source_data_sha256']
with contextlib.closing(sqlite3.connect(R/'runtime/budget.sqlite')) as db:rows=db.execute('select id,state,seconds from calls').fetchall()
assert len(rows)==17 and all(v[1]=='EXITED' for v in rows)
assert sum(v[2] for v in rows)+240<contract['total_engine_seconds']
archive=R/'contracts/RUN_CONTRACT_STAGE1.json';assert not archive.exists();shutil.copyfile(contract_path,archive)
contract['max_calls']=contract['max_mplus_calls']=18
contract['scope']='CHARLS SD_URBAN one explicit final MI20 recovery call; original 176 plus one verified runtime-recovery replacement; no further retries'
contract['inherited_budget']['revised_combined_call_cap']=177
contract['inherited_budget']['additional_calls_explicit_amendment']=1
contract['inherited_budget']['prepared_unadmitted_members']=[]
contract['stops']=[s for s in contract['stops'] if not s.startswith('MI20 excluded')]+['MI20 only once; failure stops this family with no further recovery escalation']
contract['operational_amendment']='MI20_RECOVERY_AMENDMENT_APPLIED.json'
contract_path.write_text(json.dumps(contract,indent=2),encoding='utf-8')
candidate.update(status='APPLIED',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),revised_contract_sha256=sha(contract_path),remaining_seconds_before_MI20=contract['total_engine_seconds']-sum(v[2] for v in rows),stage1_guard=read(prior/'GUARD_complete.json')['evidence_id'])
(R/'contracts/MI20_RECOVERY_AMENDMENT_APPLIED.json').write_text(json.dumps(candidate,indent=2),encoding='utf-8')
print(json.dumps(candidate),flush=True)
