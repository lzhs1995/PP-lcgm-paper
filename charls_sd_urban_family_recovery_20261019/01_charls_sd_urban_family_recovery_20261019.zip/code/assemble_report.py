"""仅替换补齐的SD城乡一行，保留其余11项及原失败，重算固定12项多重检验。"""
from pathlib import Path
import csv,datetime,hashlib,json,math
R=Path(__file__).resolve().parents[1];H=R.parent/'charls_corrected_h42_models_20261018';N=R.parent/'charls_corrected_h42_income_models_20261018';S=R.parent/'charls_sd_urban_startup_recovery_20261019'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
assert read(R/'audit/POOL_INDEPENDENT_EDU_URBAN.json')['status']=='PASS'
assert read(R/'audit/final_member/GUARD_complete.json')['decision']=='PASS'
assert read(N/'audit/TWELVE_RESOURCES_INDEPENDENT.json')['status']=='PASS'
source=N/'results/TWELVE_H42_RESOURCES.csv';old=rows(source);new=rows(R/'results/pool_EDU_URBAN/H42_REGISTERED.csv');assert len(new)==1
v=new[0];assert v['family']=='sd_URBAN' and v['members']==v['m']=='20'
assert v['status']=='FULL_CONDITIONAL_MI_POOLED'
out=[dict(v) if x['family']=='sd_URBAN' else dict(x) for x in old]
assert len(out)==12 and len({x['family'] for x in out})==12
rank=sorted(range(12),key=lambda i:float(out[i]['p']));maximum=0.
for i,k in enumerate(rank):
 p=float(out[k]['p']);maximum=max(maximum,(12-i)*p);out[k]['Holm_12']=format(min(1.,maximum),'.17g');out[k]['Bonferroni_12']=format(min(1.,12*p),'.17g')
dest=R/'results/TWELVE_H42_RESOURCES.csv';assert not dest.exists()
with dest.open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(old[0]));w.writeheader();w.writerows(out)
assert sum(int(x['members']) for x in out)==320 and all(x['members']==x['m'] for x in out)
for a,b in zip(old,out):
 if a['family']!='sd_URBAN':assert all(a[k]==b[k] for k in a if k not in ('Holm_12','Bonferroni_12'))
(R/'audit/TWELVE_RECOVERY_LINEAGE.json').write_text(json.dumps(dict(status='PASS',replaced_family='sd_URBAN',unchanged_other_rows=11,prior_file=str(source),prior_sha256=sha(source),new_sha256=sha(dest),registered=12,complete=12,total_members=320,prior_failed_row=next(x for x in old if x['family']=='sd_URBAN')),indent=2),encoding='utf-8')
budgets=[read(x/'runtime/budget_status.json') for x in (H,S,R)];counts=[len(x['rows']) for x in budgets];seconds=sum(x['engine_seconds'] for x in budgets)
assert sum(counts)==177 and seconds<10800
nf=lambda x:f'{float(x):.6f}'
text=['# CHARLS SD×城乡恢复与12项H4.2工作插补家族汇总','',
'**四项调节完整推断、完整 H4 仍未完成。** 本次完成的是CHARLS观测基期差异Z₀的工作插补敏感性，不是原CFPS潜在初始状态调节或完整H4。冻结文稿、原始数据和已发布批次保持原样。','',
'## 本次新增成果','',
'SD_URBAN补齐20/20份，N=2744；全部正常结束、方差和协方差门槛通过，原MI01双起点继续有效。独立base-R从原始TECH1、RESULTS、TECH3重算全部20份参数、标准误、完整协方差Rubin合并、组内调节、直接组间差与支持范围内条件斜率。',
f"直接组间差 δ_G1−δ_G0={nf(v['estimate'])}，SE={nf(v['se'])}，95%条件MI区间[{nf(v['lower'])}, {nf(v['upper'])}]，p={nf(v['p'])}。区间跨零，不能推断没有效应或组间等价。",'',
'其余11项复用已发布结果，仅在原12项固定家族内重算多重检验。当前12/12、320份估计齐备；这不升级为原理论全部完成。','',
'|家族|m|组间差|95%条件MI区间|p|Holm(12)|','|---|---:|---:|---|---:|---:|']
for x in out:text.append(f"|{x['family']}|{x['m']}|{nf(x['estimate'])}|[{nf(x['lower'])}, {nf(x['upper'])}]|{nf(x['p'])}|{nf(x['Holm_12'])}|")
text+=['','## 为什么允许这一次恢复','',
'原MI02在约241.47秒总超时时限中，直到约208.40秒才实际创建Mplus，采样末段Mplus仅约25.61秒CPU。其输出只有INPUT READING TERMINATED NORMALLY，无正常模型终止和可采用TECH3；故保留失败而不冒充可用结果。启动阻塞证据不等于已唯一识别阻塞根因。',
'隔离恢复保持model.inp和DAT字节、原起点、q30、MLR和约束完全相同，仅按当前空闲CPU调度自有进程。恢复MI02用111.359秒并经88参数独立核验。MI03—12正常；MI13首次因物理可用低于1.2GiB未启动，不消耗估计额度。关闭原协调器、复核退出和输入后，从MI13继续，而不是重跑前12份。',
'一次gc和归档本会话终端history没有证实显著物理内存回收；任务管理器正常关闭请求未取得退出证明，wait返回AccessDenied，未强杀或提权。后续内存达1.74GiB是主机实测，不能归因于该失败操作。其他研究进程保持。',
f'调用账目为原H {counts[0]}次 + MI02恢复 {counts[1]}次 + MI03—20 {counts[2]}次 = {sum(counts)}次；累计清醒引擎墙钟{seconds:.3f}秒。保留原176次合同，仅在19份可用和原协调器退出后，显式记录MI20一次恢复修订至177；总10800秒与单次240秒不变，无自动递增预算或新规格。','',
'## 统计边界','',
'两条潜在增长轨迹加观测基期Z₀与资源组G，保留所有低阶项并估计SX×Z₀、SX×G、SX×Z₀G。社区聚类MLR，11个控制变量、同期残差关联；不新增零方差约束。完整TECH3用于δ_G0、δ_G1、两组直接差和支持域内条件斜率，不比较两组星号来推断组间差。',
'工作MI保留原观测、社区结构和扩展乘积辅助项；这是对当前插补模型有条件的推断，不证明MAR或与潜在交互严格相容。收入为40份、教育和城乡为20份。SON定义为唯一长子减其余所有子女（含女儿）。已完成H4.1十二家族和本次H4.2十二家族是CHARLS观测Z₀路线；CFPS及CHARLS潜在差异轨迹交互仍有既存失败/未完成项。',
'本轮没有原样重跑失败CFPS、重新生成MI、修改原稿、开启NLM审阅或追逐显著性。所有12个组间差区间均跨零；调整后检验仍保留全部预定家族。','',
'## 给网页审阅者','',
'单包不足25MB，仅含聚合参数、代码、原始模型输出和恢复证据；不含逐人DAT/RDS/MIDS。公开包可独立复算参数及合并，不能在没有微观数据时宣称重新拟合或核验逐人数据。先读FOR_WEB_REVIEWERS.md，核对PAYLOAD_MANIFEST.json。',
'先前11项的完整原始证据继续使用既有固定提交：[教育/城乡](https://github.com/lzhs1995/PP-lcgm-paper/tree/70822535f744283164a8496fe75e011c4192800a/charls_corrected_h42_models_20261018)、[收入与原12项汇总](https://github.com/lzhs1995/PP-lcgm-paper/tree/7a86d6554252eda8af2fcd7d6416ed74e3d5a525/charls_corrected_h42_income_models_20261018)。本包只补充SD_URBAN及更新汇总，不重复上传旧包。','']
(R/'reports').mkdir(exist_ok=True);(R/'reports/REPORT.md').write_text('\n'.join(text),encoding='utf-8')
(R/'audit/REPORT.json').write_text(json.dumps(dict(status='SAVED',new_complete_family='sd_URBAN',twelve_complete=12,members=320,total_combined_calls=sum(counts),total_engine_seconds=seconds,full_H4_complete=False,original_four_complete=False),indent=2),encoding='utf-8')
print(json.dumps(read(R/'audit/REPORT.json')))
