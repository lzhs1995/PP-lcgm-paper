# MplusAutomation仅在实际引擎runner加载；协调R用既有原始输出解析器，减少重复常驻包内存。
.libPaths(c('<WINDOWS_USERPROFILE>/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
library(jsonlite);library(digest);library(processx);library(ps)
ROOT<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_sd_urban_family_recovery_20261019'
Sys.setenv(R2E_ROOT=ROOT);source(file.path(ROOT,'code/r2e_local.R'),local=TRUE)
contract<-rj(file.path(ROOT,'contracts/RUN_CONTRACT.json'));parents<-rj(file.path(ROOT,'contracts/CC_PARENTS.json'))
growth<-function(p)paste0('i',p,' s',p,' | ',p,'1@0 ',p,'2@2 ',p,'3@4 ',p,'4@7 ',p,'5@9;')
specification<-function(e,type){
 b<-c(growth('x'),growth('y'),'iy ON ix (bii);','sy ON ix (bis);','sy ON sx (bss);','sy ON iy (bsyiy);','ix WITH sx;','sx WITH iy;',paste0('x',1:5,' WITH y',1:5,';'),'ix sx iy sy ON c1-c11;',
      'ix sx ON z0;','iy ON z0 (gi0);','sy ON z0 (gs0);','x1 y1 ON z0;','ix sx ON zg;','iy ON zg (gizg);','sy ON zg (gszg);','x1 y1 ON zg;')
 if(e$group=='INC')b<-c(b,'ix sx iy sy ON g;','x1 y1 ON g;')
 extra<-c('sxz | sx XWITH z0;',paste0('sxg | sx XWITH ',e$g_column,';'),'sxzg | sx XWITH zg;','sy ON sxz (dc);','sy ON sxg (bxg);','sy ON sxzg (dcg);')
 list(kind=if(type=='E0')'linear'else'lms_observed',fac=FAC_XY,obs=OBS_XY,fixed_zero=character(),g=e$g_column,parent=b,model=c(b,if(type=='E1')extra),
      key=rbind(KEY_XY,key_add(c('gi0','gs0','gizg','gszg'),c('IY','SY','IY','SY'),c('Z0','Z0','ZG','ZG')),if(type=='E1')key_add(c('dc','bxg','dcg'),rep('SY',3),c('SXZ','SXG','SXZG'))))
}
slots<-function(si){
 a<-list();add<-function(op,lhs,rhs='',init=0){a[[length(a)+1L]]<<-data.frame(op=op,lhs=toupper(lhs),rhs=toupper(rhs),init=init)}
 for(f in FAC_XY)add('MEAN',f);for(o in OBS_XY)add('VAR',o,init=.5);for(f in FAC_XY)add('VAR',f,init=.1)
 for(key in stmt_pairs(si$model)){t<-strsplit(toupper(key),' ',fixed=TRUE)[[1]];add(t[2],t[1],t[3])}
 x<-do.call(rbind,a);x$key<-paste(x$op,x$lhs,x$rhs,sep=':');stopifnot(!anyDuplicated(x$key));x
}
extract<-function(m,key){do.call(rbind,lapply(seq_len(nrow(key)),function(i){k<-key[i,];id<-pnum(m,'BETA',k$row,k$column);if(id==0)id<-pnum(m,'GAMMA',k$row,k$column);stopifnot(id>0);p<-m$par[m$par$parameter==id,];stopifnot(nrow(p)==1);data.frame(k,parameter=id,estimate=p$estimate,se=p$se)}))}
start_cache<-new.env(parent=emptyenv())
job_id<-function(f,type,k=1L,start='A'){
 id<-paste0('CHARLS_',toupper(f),'_H42_',type,'_MI',sprintf('%02d',k),'_',start)
 attempts<-rj(file.path(ROOT,'contracts/ATTEMPT_MAP.json'));if(!is.null(attempts[[id]]))attempts[[id]]else id
}
prepare<-function(f,type,k=1L,start='A'){
 e<-parents[[f]];z<-e$z;miroot<-file.path(contract$source_MI,'mi',z);ad<-rj(file.path(ROOT,'audit/MI_ADMISSIONS.json'))[[z]];stopifnot(isTRUE(ad$passed))
 id<-job_id(f,type,k,start);d<-file.path(ROOT,'models',id);dir.create(d,showWarnings=FALSE)
 if(file.exists(file.path(d,'job.json')))return(rj(file.path(d,'job.json')))
 data_source<-file.path(miroot,'private',sprintf('MI%02d.dat',k));nms<-unlist(ad$columns);a<-read.table(data_source,col.names=nms,na.strings='-9999');stopifnot(nrow(a)==ad$N,all(a[[e$g_column]]%in%0:1),length(unique(a$cluster))==ad$communities)
 prod<-a$z0*a[[e$g_column]];if('zg'%in%names(a))stopifnot(max(abs(a$zg-prod))<1e-12)else a$zg<-prod
 design<-cbind(1,as.matrix(a[c(paste0('c',1:11),'z0',if(e$group=='INC')'g','zg')]));stopifnot(!anyNA(design),qr(design)$rank==ncol(design))
 si<-specification(e,type);source_dir<-if(type=='E0')e$parent_dir else file.path(ROOT,'models',job_id(f,'E0'))
 if(type=='E0')for(n in names(e$parent_hashes))stopifnot(hashf(file.path(source_dir,n))==e$parent_hashes[[n]])
 cachekey<-digest(list(si,source_dir,hashf(file.path(source_dir,'model.out')),hashf(file.path(source_dir,'estimates.dat')),hashf(file.path(source_dir,'tech3.dat')),start),algo='sha256')
 if(exists(cachekey,start_cache,inherits=FALSE))mm<-get(cachekey,start_cache)else{
  mm<-make_model(si,source_dir,perturb=start=='B')
  if(type=='E1')for(rhs in c('SXZ','SXG','SXZG')){hit<-which(mm$mapping$key==paste0('ON:SY:',rhs));stopifnot(length(hit)==1);mm$mapping$value[hit]<-if(start=='A').1 else -.1;mm$mapping$action[hit]<-'registered_new_interaction_start';mm$lines[length(si$model)+hit]<-paste0('sy ON ',tolower(rhs),'*',mm$mapping$value[hit],';')}
  assign(cachekey,mm,start_cache)
 }
 stopifnot(mm$expected_free==e$parent_free+if(type=='E1')3L else 0L)
 analysis<-if(type=='E0')c('TYPE=COMPLEX; ESTIMATOR=MLR; PROCESSORS=1;','ITERATIONS=2000; COVERAGE=.005;')else c('TYPE=COMPLEX RANDOM; ESTIMATOR=MLR; PROCESSORS=1;','ALGORITHM=INTEGRATION; INTEGRATION=30; MCSEED=26101701;','ITERATIONS=2000; MITERATIONS=4000; COVERAGE=.005;','LOGCRITERION=.00001; RLOGCRITERION=.000000001; MCONVERGENCE=.00001;')
 inp<-c(paste0('TITLE: ',id,';'),'DATA: FILE=data.dat;','VARIABLE:',wrap90(paste('NAMES=',paste(nms,collapse=' '),';')),paste('USEVARIABLES=x1-x5 y1-y5 c1-c11 z0',if(e$group=='INC')'g'else'', 'zg;'),'MISSING=ALL(-9999);','CLUSTER=cluster;',if(!'zg'%in%nms)paste0('DEFINE: zg=z0*',e$g_column,';'),'ANALYSIS:',analysis,'MODEL:',mm$lines,'OUTPUT: TECH1 TECH3 TECH4 TECH8 SVALUES CINTERVAL;','SAVEDATA: RESULTS=estimates.dat; TECH3=tech3.dat;')
 stopifnot(all(nchar(inp)<=90),setequal(stmt_pairs(si$model),stmt_pairs(mm$lines)))
 writeLines(inp,file.path(d,'model.inp'));stopifnot(file.copy(data_source,file.path(d,'data.dat')));csv(mm$mapping,file.path(d,'start_mapping.csv'))
 support<-lapply(0:1,function(g){v<-a$z0[a[[e$g_column]]==g];list(g=g,N=length(v),min=min(v),max=max(v),points=sort(unique(c(range(v),quantile(v,c(.1,.5,.9),names=FALSE)))))})
 j<-list(id=id,root=ROOT,dest=d,family=f,z=z,group=e$group,type=type,member=k,start=start,N=ad$N,communities=ad$communities,columns=nms,expected_free=mm$expected_free,category='CHARLS_H42_MI',cap_seconds=contract$per_call_seconds,rscript=file.path(R.home('bin'),'Rscript.exe'),mplus=MPLUS,source_start=source_dir,source_data=data_source,support=support,zpoints=sort(unique(unlist(lapply(support,function(x)x$points)))),hashes=list(model.inp=hashf(file.path(d,'model.inp')),data.dat=hashf(file.path(d,'data.dat'))))
 wj(list(rank=qr(design)$rank,columns=ncol(design),source_cc_parent=e$parent_dir,MI_parent=source_dir,expected_free=mm$expected_free,groups=support),file.path(d,'design_check.json'));wj(j,file.path(d,'job.json'));j
}
number_observations<-function(lines){x<-grep('^\\s*Number of observations\\s+[0-9]+\\s*$',lines,value=TRUE);stopifnot(length(x)==1);as.integer(sub('.*?([0-9]+)\\s*$','\\1',x))}
review<-function(j){
 er<-rj(file.path(j$dest,'engine_receipt.json'));if(is.null(er))return(list(id=j$id,status='NOT_RUN_RESOURCE_OR_BUDGET',detail=rj(file.path(j$dest,'not_run.json'))))
 r<-list(id=j$id,family=j$family,z=j$z,group=j$group,type=j$type,member=j$member,start=j$start,N_expected=j$N,status=er$status,engine_status=er$status,seconds=er$seconds)
 if(er$status%in%c('EXITED','RECOVERED_SAVED_OUTPUT'))tryCatch({
  m<-read_mplus_raw(j$dest);si<-specification(parents[[j$family]],j$type);v<-gate_r2e(m,si,unlist(j$zpoints));r$status<-if(isTRUE(v$passed))'USABLE_SINGLE_DATASET'else'INADMISSIBLE';r$negative<-v$negative;r$N<-number_observations(m$lines);r$LL<-m$extra[['H0 Loglikelihood']];r$parameters<-m$P
  if(any(grepl('FIXED TO AVOID SINGULARITY',m$lines,fixed=TRUE)))r$status<-'AUTOFIX_REJECTED'
  if(r$N!=j$N)r$status<-'SAMPLE_MISMATCH';if(m$P!=j$expected_free)r$status<-'PARAMETER_CONTRACT_MISMATCH'
  if(j$type=='E1'){dims<-grep('Dimensions of numerical integration',m$lines,value=TRUE);r$integration_dimensions<-if(length(dims)==1)as.integer(sub('.*?([0-9]+)\\s*$','\\1',dims))else NA_integer_;if(!identical(r$integration_dimensions,1L))r$status<-'INTEGRATION_DIMENSION_MISMATCH'}
  wj(v,file.path(j$dest,'validation.json'));csv(m$par,file.path(j$dest,'parameters_high_precision.csv'));csv(m$values,file.path(j$dest,'matrix_values.csv'));csv(m$spec,file.path(j$dest,'tech1_parameter_map.csv'));csv(extract(m,si$key),file.path(j$dest,'key_paths.csv'));write.table(m$V,file.path(j$dest,'parameter_covariance.csv'),sep=',',row.names=FALSE,col.names=FALSE)
 },error=function(e){r$status<<-'READBACK_OR_ESTIMATION_FAILURE';r$error<<-conditionMessage(e)})
 r$output_sha256<-if(file.exists(file.path(j$dest,'model.out')))hashf(file.path(j$dest,'model.out'))else NULL;wj(r,file.path(j$dest,'receipt.json'));r
}
run<-function(j){
 for(n in names(j$hashes))stopifnot(hashf(file.path(j$dest,n))==j$hashes[[n]])
 if(file.exists(file.path(j$dest,'receipt.json'))){r<-rj(file.path(j$dest,'receipt.json'));if(!is.null(r$output_sha256))stopifnot(hashf(file.path(j$dest,'model.out'))==r$output_sha256);return(r)}
 if(file.exists(file.path(j$dest,'engine_receipt.json')))return(review(j))
 gc(full=TRUE);progress('H42_MI_ESTIMATE_START',j$id)
 # 引擎监督器已有独立240秒预算；R显示层退出不应把它杀掉并留下无回执的已完成输出。
 p<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/model_engine.py'),file.path(j$dest,'job.json')),stdout=file.path(j$dest,'supervisor.log'),stderr='2>&1',cleanup=FALSE)
 last<-0;while(p$is_alive()){p$wait(1000L);if(as.numeric(Sys.time())-last>25){tryCatch({h<-rj(file.path(ROOT,'runtime/progress.json'));if(exists('clauder_progress',mode='function'))clauder_progress(if(is.null(h))'H42_MI_STARTING'else h$stage,paste(j$id,if(is.null(h$elapsed_seconds))''else h$elapsed_seconds))},error=function(e){cat(format(Sys.time(),tz='UTC',usetz=TRUE),j$id,conditionMessage(e),'\n',file=file.path(ROOT,'runtime/NONCRITICAL_PROGRESS_ERRORS.log'),append=TRUE)});last<-as.numeric(Sys.time())}}
 r<-review(j);progress('H42_MI_READBACK',paste(j$id,r$status));r
}
compare_starts<-function(f){get<-function(s){d<-file.path(ROOT,'models',job_id(f,'E1',1,s));list(receipt=rj(file.path(d,'receipt.json')),key=read.csv(file.path(d,'key_paths.csv')))};v<-compare_numeric(get('A'),get('B'),'start',list(start_LL=.01,start_path_abs=.001,start_path_se=.05,integration_path_se=.05,se_rel=.05));wj(v,file.path(ROOT,'results',paste0(toupper(f),'_START_COMPARISON.json')));v}
