"""准入采样与guard分开，避免守卫耗时令资源快照过期。"""
from pathlib import Path
import json,ctypes,datetime,psutil,sys
R=Path(__file__).resolve().parents[1]
samples=[psutil.cpu_percent(interval=.5,percpu=True) for _ in range(3)]
avg=[sum(x[i] for x in samples)/len(samples) for i in range(len(samples[0]))]
cores=sorted(sorted(range(len(avg)),key=lambda i:avg[i])[:4])
class Mem(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ('total','available','page_total','page_available','virtual_total','virtual_available','extended')]
m=Mem();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
h=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),available_GiB=m.available/2**30,commit_available_GiB=m.page_available/2**30,per_core_cpu=avg,selected_cores=cores,admitted=m.available/2**30>=1.4 and m.page_available/2**30>=2 and sum(avg)/len(avg)<85)
dest=R/'audit'/sys.argv[1];dest.mkdir(exist_ok=True)
with (dest/'ADMISSION_OBSERVATIONS.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(h)+'\n')
if h['admitted']:
 old=R/'audit/HOST_ADMISSION.json'
 archive=dest/'PREVIOUS_HOST_ADMISSION.json'
 if old.exists() and not archive.exists():archive.write_bytes(old.read_bytes())
 old.write_text(json.dumps(h,indent=2),encoding='utf-8')
print(json.dumps(h),flush=True)
