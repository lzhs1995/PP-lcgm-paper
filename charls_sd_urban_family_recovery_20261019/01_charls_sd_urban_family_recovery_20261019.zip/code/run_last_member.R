# 单一最后成员；合并只在20份均有效后发生。
local({
 root<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_sd_urban_family_recovery_20261019'
 library(jsonlite);library(ps);library(digest)
 where<-file.path(root,'audit/final_member');h<-fromJSON(file.path(root,'audit/HOST_ADMISSION.json'))
 age<-as.numeric(difftime(Sys.time(),as.POSIXct(substr(h$utc,1,19),format='%Y-%m-%dT%H:%M:%S',tz='UTC'),units='secs'))
 stopifnot(h$admitted,is.finite(age),age>=0,age<120,!file.exists(file.path(where,'OWNER.json')))
 ps_set_cpu_affinity(ps_handle(),as.integer(h$selected_cores))
 write_json(list(owner=list(pid=Sys.getpid(),created=as.numeric(ps_create_time(ps_handle())))),file.path(where,'OWNER.json'),auto_unbox=TRUE,digits=16)
 source(file.path(root,'code/models.R'),local=TRUE)
 stopifnot(contract$max_mplus_calls==18,rj(file.path(root,'contracts/MI20_RECOVERY_AMENDMENT_APPLIED.json'))$status=='APPLIED')
 states<-rj(file.path(root,'results/FAMILY_STATUS.json'));st<-states$sd_URBAN;stopifnot(st$members==19L)
 calls<-rj(file.path(root,'results/CALL_RESULTS.json'));j<-rj(file.path(root,'models/CHARLS_SD_URBAN_H42_E1_MI20_A/job.json'))
 stopifnot(!file.exists(file.path(j$dest,'engine_receipt.json')))
 result<-run(j);calls[[j$id]]<-result;wj(calls,file.path(root,'results/CALL_RESULTS.json'))
 if(result$status=='USABLE_SINGLE_DATASET'){
  st$members<-20L;st$status<-'FULL_FAMILY_PENDING_POOLING';states$sd_URBAN<-st;wj(states,file.path(root,'results/FAMILY_STATUS.json'))
  source(file.path(root,'code/pool_h42.R'),local=TRUE);pool_h42('EDU_URBAN')
  writeLines('ALL20_USABLE_AND_POOLED; INDEPENDENT_VERIFICATION_PENDING',file.path(root,'runtime/MODELS_TERMINAL'))
  clauder_progress('FULL20_INDEPENDENT_PARAMETERS','Independent TECH1/TECH3 and Rubin calculations; zero new Mplus calls')
  source(file.path(root,'verification/verify_pooled_base.R'),local=TRUE);verify_pooled_base(root,'EDU_URBAN',public=FALSE)
  source(file.path(root,'code/plot_recovered.R'),local=TRUE);plot_recovered(root)
 }else{st$status<-paste('LAST_MEMBER_NOT_USABLE',result$status,sep=':');states$sd_URBAN<-st;wj(states,file.path(root,'results/FAMILY_STATUS.json'))}
 wj(list(status='ATTEMPT_COMPLETED',family_status=st$status,members=st$members,target=20,full_H4_complete=FALSE,utc=format(Sys.time(),tz='UTC')),file.path(where,'TERMINAL.json'))
 cat('SD_URBAN_LAST_MEMBER_NATIVE_TERMINAL',st$status,st$members,'of20\n')
})
