# 资源准入未启动成员的接续；复用原输入与预算，不重新估计成功成员。
local({
 root<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_sd_urban_family_recovery_20261019'
 library(jsonlite);library(ps);library(digest)
 stage<-'resume_stage1';where<-file.path(root,'audit',stage)
 h<-fromJSON(file.path(root,'audit/HOST_ADMISSION.json'))
 age<-as.numeric(difftime(Sys.time(),as.POSIXct(substr(h$utc,1,19),format='%Y-%m-%dT%H:%M:%S',tz='UTC'),units='secs'))
 stopifnot(h$admitted,is.finite(age),age>=0,age<120,!file.exists(file.path(where,'OWNER.json')))
 ps_set_cpu_affinity(ps_handle(),as.integer(h$selected_cores))
 write_json(list(owner=list(pid=Sys.getpid(),created=as.numeric(ps_create_time(ps_handle())))),file.path(where,'OWNER.json'),auto_unbox=TRUE,digits=16)
 source(file.path(root,'code/models.R'),local=TRUE)
 stopifnot(contract$max_mplus_calls==17)
 originals<-rj(file.path(root,'audit/REUSED_SOURCE_FILES.json'))
 check_sources<-function()stopifnot(all(vapply(originals,function(p)hashf(p$source)==p$sha256&&hashf(p$copy)==p$sha256,TRUE)))
 check_sources()
 jobs<-rj(file.path(root,'audit/PREPARED_JOBS.json'))
 states<-rj(file.path(root,'results/FAMILY_STATUS.json'));st<-states$sd_URBAN
 stopifnot(st$members==12L)
 calls<-rj(file.path(root,'results/CALL_RESULTS.json'))
 for(k in 1:12){id<-job_id('sd_URBAN','E1',k,'A');stopifnot(calls[[id]]$status=='USABLE_SINGLE_DATASET',hashf(file.path(root,'models',id,'model.out'))==calls[[id]]$output_sha256)}
 for(j in jobs){
  if(j$member<13L||j$member>19L)next
  stopifnot(!file.exists(file.path(j$dest,'engine_receipt.json')),!file.exists(file.path(j$dest,'model.out')))
  result<-run(j);calls[[j$id]]<-result;wj(calls,file.path(root,'results/CALL_RESULTS.json'))
  if(result$status!='USABLE_SINGLE_DATASET'){st$status<-paste(if(result$status=='NOT_RUN_RESOURCE_OR_BUDGET')'UNSTARTED_RESOURCE_OR_BUDGET'else'MEMBER_FAILED',j$id,result$status,sep=':');break}
  st$members<-j$member;st$status<-'RUNNING';states$sd_URBAN<-st;wj(states,file.path(root,'results/FAMILY_STATUS.json'))
 }
 if(st$members==19L)st$status<-'ORIGINAL_CALL_LIMIT_PENDING_MI20'
 states$sd_URBAN<-st;wj(states,file.path(root,'results/FAMILY_STATUS.json'));check_sources()
 wj(list(status='ATTEMPT_COMPLETED',family_status=st$status,members=st$members,target=st$m,full_H4_complete=FALSE,utc=format(Sys.time(),tz='UTC')),file.path(where,'TERMINAL.json'))
 cat('SD_URBAN_UNSTARTED_RESUME_TERMINAL',st$status,st$members,'of',st$m,'\n')
})
