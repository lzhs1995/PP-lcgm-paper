# 由保存的合并结果绘图，不再拟合。
plot_recovered<-function(root){
 d<-file.path(root,'results/pool_EDU_URBAN');v<-read.csv(file.path(d,'sd_URBAN/GROUP_MODERATION_CONTRASTS.csv'))
 draw<-function(){
  par(mar=c(5,10,4,2));at<-rev(seq_len(nrow(v)));xr<-range(c(0,v$lower,v$upper));pad<-diff(xr)*.08
  plot(v$estimate,at,xlim=xr+c(-pad,pad),ylim=c(.5,nrow(v)+.5),yaxt='n',ylab='',xlab='Coefficient and 95% conditional MI interval',pch=19,main='CHARLS: baseline relative SD by urban status')
  axis(2,at=at,labels=v$contrast,las=1,cex.axis=.8);abline(v=0,lty=2,col='gray50');segments(v$lower,at,v$upper,at,lwd=2)
  mtext('20 original imputations; working-MI sensitivity. No claim of complete CFPS H4.',side=1,line=3.7,cex=.75)
 }
 pdf(file.path(d,'RECOVERED_GROUP_CONTRASTS.pdf'),width=9,height=5);draw();dev.off()
 png(file.path(d,'RECOVERED_GROUP_CONTRASTS.png'),width=1620,height=900,res=180);draw();dev.off()
}
