# gender_INCOME: complete40 conditional working MI

Run `python code/verify_family.py gender_INCOME --public --report-dir audit_recomputed` after extraction. This independently rebuilds all43 parameter/covariance transformations and Rubin/D1 contrasts; it does not fit Mplus or check absent participant data. Python numpy/pandas/scipy required. Parent calibrations and MI01 B are not MI members.

FAMILY_STATUS is the preserved pre-pooling estimation marker. Final scope is in WORKING_MI_ACCEPTANCE.json, POOLING_RECEIPT.json and INDEPENDENT_VERIFICATION.json; the original four latent moderation families and full H4 remain incomplete.
