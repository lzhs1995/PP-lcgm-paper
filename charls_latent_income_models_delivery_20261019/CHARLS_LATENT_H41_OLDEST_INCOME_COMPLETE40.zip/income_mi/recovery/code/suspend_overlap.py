"""只根据Windows实际507睡眠事件核算观察空档，不排除无证据的卡顿。"""
import datetime,json,sys
from active_clock import power_sleep_events
start,end=[datetime.datetime.fromtimestamp(float(v),datetime.timezone.utc) for v in sys.argv[1:3]]
events=power_sleep_events(start,end);seconds=sum(x['overlap_seconds'] for x in events)
assert 0<=seconds<=(end-start).total_seconds()+2
print(json.dumps(dict(start=start.isoformat(),end=end.isoformat(),wall_gap=(end-start).total_seconds(),sleep_seconds=seconds,events=events)))
