# mice 3.19.10二层二元抽样公式保持；GLMM拟合/访问器改为经Hessian核验的TMB后端。
# 这是明确记录的方法实现变更，不能标为官方原样2l.bin。仅缓存精确相同的确定性拟合。
fit_env<-new.env(parent=asNamespace('mice'));fit_env$ROOT<-ROOT;fit_env$scope<-'';fit_env$iteration<-0L;fit_env$fit_n<-0L;fit_env$progress<-progress
fit_env$last_fit_valid<-FALSE;fit_env$target<-'';fit_env$warm<-new.env(parent=emptyenv());fit_env$cache<-new.env(parent=emptyenv())
fit_env$record<-function(rec){cat(jsonlite::toJSON(rec,auto_unbox=TRUE,null='null',na='null',digits=16),'\n',file=file.path(ROOT,'audit/FIT_LOG.jsonl'),append=TRUE)}
environment(fit_env$record)<-fit_env
fit_env$fit_tmb<-function(...){
 fit_n<<-fit_n+1L;last_fit_valid<<-FALSE;target<<-'g';t0<-Sys.time();args<-list(...);f<-args[[1]];d<-args$data
 stopifnot(fit_n<=contract$max_conditional_calls);progress('income_TMB_conditional',paste(scope,'iteration',iteration,'draw',fit_n))
 key<-digest::digest(list(formula=deparse(f),data=d,family='binomial_logit',profile=FALSE),algo='sha256')
 cache_hit<-exists(key,envir=cache,inherits=FALSE);cpu0<-proc.time();cat(jsonlite::toJSON(list(event='BEGIN',fit_n=fit_n,iteration=iteration,target='g',data_spec_hash=key,utc=format(Sys.time(),tz='UTC',usetz=TRUE)),auto_unbox=TRUE),'\n',file=file.path(ROOT,'audit/FIT_BEGIN.jsonl'),append=TRUE)
 ww<-character();setTimeLimit(cpu=120,elapsed=Inf,transient=TRUE);on.exit(setTimeLimit(cpu=Inf,elapsed=Inf,transient=FALSE))
 ans<-tryCatch({
  if(cache_hit){fit<-get(key,envir=cache)}else{
   start<-if(exists(scope,envir=warm,inherits=FALSE))get(scope,envir=warm) else NULL
   fit<-withCallingHandlers(glmmTMB::glmmTMB(f,data=d,family=binomial(),start=start,
     control=glmmTMB::glmmTMBControl(parallel=1,profile=FALSE,rank_check='stop',optCtrl=list(iter.max=1000,eval.max=1000))),warning=function(w){ww<<-c(ww,conditionMessage(w))})
  }
  V<-as.matrix(stats::vcov(fit)$cond);ev<-eigen((V+t(V))/2,symmetric=TRUE,only.values=TRUE)$values
  re<-random_tmb(fit,condVar=TRUE)[[1]];psi<-as.numeric(glmmTMB::VarCorr(fit)$cond[[1]][1,1]);pv<-attr(re,'postVar')
  valid<-fit$fit$convergence==0&&isTRUE(fit$sdr$pdHess)&&all(is.finite(ev))&&min(ev)>0&&is.finite(psi)&&psi>0&&all(is.finite(pv))&&all(pv>=0)
  record(list(scope=scope,iteration=iteration,fit_n=fit_n,target='g',backend='glmmTMB_default_Laplace',cpu_seconds=as.numeric(sum((proc.time()-cpu0)[1:2])),seconds=as.numeric(difftime(Sys.time(),t0,units='secs')),optimizer_code=fit$fit$convergence,convergence_messages=NULL,warnings=ww,vcov_positive=min(ev)>0,pdHess=fit$sdr$pdHess,fixed_parameters=length(glmmTMB::fixef(fit)$cond),random_intercept_variance=psi,max_abs_gradient=max(abs(fit$sdr$gradient.fixed)),cache_hit=cache_hit,data_spec_hash=key,valid=valid))
  stopifnot(valid)
  assign(scope,list(beta=glmmTMB::fixef(fit)$cond,theta=log(sqrt(psi))),envir=warm)
  if(!cache_hit){if(length(ls(cache))>=2L)rm(list=ls(cache)[1],envir=cache);assign(key,fit,envir=cache)}
  last_fit_valid<<-TRUE;fit
 },error=function(e){record(list(scope=scope,iteration=iteration,fit_n=fit_n,target='g',backend='glmmTMB_default_Laplace',data_spec_hash=key,cpu_seconds=as.numeric(sum((proc.time()-cpu0)[1:2])),error=conditionMessage(e),seconds=as.numeric(difftime(Sys.time(),t0,units='secs')),valid=FALSE));stop(e)})
 ans
}
environment(fit_env$fit_tmb)<-fit_env;fit_env$contract<-contract
fit_env$fixed_tmb<-function(object)glmmTMB::fixef(object)$cond
fit_env$variance_tmb<-function(object)glmmTMB::VarCorr(object)$cond
fit_env$vcov<-function(object)as.matrix(stats::vcov(object)$cond)
fit_env$random_tmb<-function(object,condVar=FALSE){
 x<-glmmTMB::ranef(object,condVar=FALSE)$cond
 stopifnot(length(x)==1L,ncol(x[[1]])==1L,names(x)=='cluster',family(object)$family=='binomial',family(object)$link=='logit')
 if(condVar){
  # 给定固定效应与方差参数的条件Laplace曲率；不能把sdreport边际不确定性直接传作postVar。
  mf<-model.frame(object);xx<-model.matrix(object,component='cond')
  eta<-as.numeric(xx%*%glmmTMB::fixef(object)$cond)+x[[1]][match(as.character(mf$cluster),rownames(x[[1]])),1]
  off<-model.offset(mf);if(!is.null(off))eta<-eta+off
  pr<-plogis(eta);psi<-as.numeric(glmmTMB::VarCorr(object)$cond[[1]][1,1])
  wt<-model.weights(mf);if(is.null(wt))wt<-rep(1,nrow(mf));stopifnot(all(wt==1))
  curv<-tapply(pr*(1-pr),mf$cluster,sum);v<-1/(curv[rownames(x[[1]])]+1/psi)
  stopifnot(length(v)==nrow(x[[1]]),all(is.finite(v)),all(v>0))
  attr(x[[1]],'postVar')<-array(as.numeric(v),c(1L,1L,length(v)))
 }
 x
}
bin_original<-mice::mice.impute.2l.bin;bin_tmb<-bin_original;replacements<-c(glmer=0L,fixef=0L,VarCorr=0L,ranef=0L)
swap<-function(x){
 if(is.call(x))for(n in names(replacements))if(identical(x[[1]],call('::',as.name('lme4'),as.name(n)))){
  x[[1]]<-as.name(c(glmer='fit_tmb',fixef='fixed_tmb',VarCorr='variance_tmb',ranef='random_tmb')[[n]]);replacements[n]<<-replacements[n]+1L;return(x)
 }
 if(is.call(x)||is.expression(x))for(i in seq_along(x))if(!identical(x[[i]],quote(expr=)))x[[i]]<-swap(x[[i]])
 x
}
body(bin_tmb)<-swap(body(bin_tmb));stopifnot(replacements['glmer']==1L,replacements['fixef']==1L,replacements['VarCorr']>=1L,replacements['ranef']==1L);environment(bin_tmb)<-fit_env
mice.impute.2l.bin.logged<-function(y,ry,x,type,wy=NULL,...){
 fit_env$last_fit_valid<-FALSE
 out<-bin_tmb(y,ry,x,type,wy=wy,random.effects='laplace')
 stopifnot(fit_env$last_fit_valid,length(out)==sum(if(is.null(wy))!ry else wy),!anyNA(out),all(out%in%0:1));out
}
pmm_env<-new.env(parent=asNamespace('miceadds'));pmm_env$fit_env<-fit_env;pmm_env$contract<-contract
pmm_env$mice_multilevel_doCall_suppressWarnings<-function(what,args,warnings=TRUE){
 stopifnot(identical(what,lme4::lmer));fit_env$fit_n<-fit_env$fit_n+1L;fit_env$target<-'adl';stopifnot(fit_env$fit_n<=contract$max_conditional_calls);t0<-Sys.time();ww<-character();setTimeLimit(cpu=120,elapsed=Inf,transient=TRUE);on.exit(setTimeLimit(cpu=Inf,elapsed=Inf,transient=FALSE))
 fit_env$progress('ADL_conditional_fit',paste(fit_env$scope,'iteration',fit_env$iteration,'draw',fit_env$fit_n))
 cat(jsonlite::toJSON(list(event='BEGIN',fit_n=fit_env$fit_n,iteration=fit_env$iteration,target='adl',utc=format(Sys.time(),tz='UTC',usetz=TRUE)),auto_unbox=TRUE),'\n',file=file.path(fit_env$ROOT,'audit/FIT_BEGIN.jsonl'),append=TRUE)
 fit<-withCallingHandlers(do.call(what,args),warning=function(w){ww<<-c(ww,conditionMessage(w))})
 cv<-fit@optinfo$conv;V<-as.matrix(stats::vcov(fit));ev<-eigen((V+t(V))/2,symmetric=TRUE,only.values=TRUE)$values
 valid<-cv$opt==0&&length(cv$lme4$messages)==0&&all(is.finite(ev))&&min(ev)>0
 fit_env$record(list(scope=fit_env$scope,iteration=fit_env$iteration,fit_n=fit_env$fit_n,target='adl',backend='miceadds_lmer_PMM5',seconds=as.numeric(difftime(Sys.time(),t0,units='secs')),optimizer_code=cv$opt,convergence_messages=cv$lme4$messages,warnings=ww,vcov_positive=min(ev)>0,valid=valid))
 stopifnot(valid);fit
}
environment(pmm_env$mice_multilevel_doCall_suppressWarnings)<-pmm_env
pmm_env$mice_imputation_2l_lmer<-miceadds:::mice_imputation_2l_lmer;environment(pmm_env$mice_imputation_2l_lmer)<-pmm_env
mice.impute.2l.pmm.logged<-miceadds::mice.impute.2l.pmm;environment(mice.impute.2l.pmm.logged)<-pmm_env
# mice内部try()会吞掉拟合前的文件/进度错误；完整保存后再原样抛出。
fit_env$fit_original<-fit_env$fit_tmb
fit_env$fit_tmb<-function(...){tryCatch(fit_original(...),error=function(e){record(list(target='g',fit_n=fit_n,error=conditionMessage(e),call=paste(deparse(conditionCall(e)),collapse=' '),max_allowed=contract$max_conditional_calls,valid=FALSE));stop(e)})}
environment(fit_env$fit_tmb)<-fit_env
assign('mice.impute.2l.bin.logged',mice.impute.2l.bin.logged,envir=.GlobalEnv)
assign('mice.impute.2l.pmm.logged',mice.impute.2l.pmm.logged,envir=.GlobalEnv)
write_json(list(original_body_sha256=digest(body(bin_original),algo='sha256'),adapted_body_sha256=digest(body(bin_tmb),algo='sha256'),replacements=as.list(replacements),covariance_change='TMB joint observed Hessian instead of unavailable-lme4-Hessian RX fallback; independently finite-gradient verified',random_draw_rules='Original mice3.19.10 fixed coefficients, IW random variance, conditional Laplace random effect and Bernoulli draws retained; random intercept conditional curvature explicitly computed',cache='At most2 exact deterministic fits; new random draws every call; no approximate data hashing'),file.path(ROOT,'audit/IMPUTER_INSTRUMENTATION.json'),auto_unbox=TRUE,pretty=TRUE)
