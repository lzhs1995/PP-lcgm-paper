"""只准入已终止q1的唯一接续worker，q2仍按原归属继续。"""
from pathlib import Path
import ctypes,json,psutil,sys
from engine import Memory,write,utc
D=Path(__file__).resolve().parents[1];S=D.parents[1]
scope=sys.argv[1];pid=int(sys.argv[2]);born=float(sys.argv[3]);current=psutil.Process(pid)
assert abs(current.create_time()-born)<.01 and not psutil.pid_exists(28452)
live={};seen=set()
for p in list((S/'runtime').glob('QUEUE_OWNER_q*.json'))+[D/'runtime/QUEUE_OWNER_q1.json']:
 j=json.loads(p.read_text())
 try:
  proc=psutil.Process(j['pid'])
  if abs(proc.create_time()-float(j.get('created_exact',j['created'])))<.01:
   assert not seen.intersection(j['scopes']);seen.update(j['scopes']);live[proc.pid]=j
 except psutil.NoSuchProcess:pass
assert pid in live and scope in live[pid]['scopes'] and len(live)<=2
m=Memory();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m));cpu=psutil.cpu_percent(.5)
# 实测原SD峰值约.58GiB，保守增量.65GiB；其他在途worker实际占用已含于available。
v=current.memory_info();required=1.25+max(0,.65-v.rss/2**30);crequired=2+max(0,.7-v.private/2**30)
ok=m.avail/2**30>=required and m.commit_avail/2**30>=crequired and cpu<85
rec=dict(at=utc(),passed=ok,scope=scope,pid=pid,live_MI_workers=list(live),available_gib=m.avail/2**30,commit_available_gib=m.commit_avail/2**30,required_gib=required,commit_required_gib=crequired,cpu_percent=cpu)
write(D/'audit/RESOURCE_ADMISSION.json',rec)
with (D/'audit/RESOURCE_HISTORY.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
print(json.dumps(rec));raise SystemExit(0 if ok else 2)
