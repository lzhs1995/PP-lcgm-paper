# 独立回到原基期和五期子女名册，核对40份实际DAT；不复用输入构造函数。
local({
 BATCH<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_income_mi_20261019';R<-file.path(BATCH,'mi',MI_SCOPE)
 library(mice);library(jsonlite);library(digest)
 ad<-fromJSON(file.path(R,'audit/MI_ADMISSION.json'));stopifnot(ad$status=='ADMITTED_WORKING_MI',ad$m==40)
 a<-readRDS(file.path(BATCH,'private',paste0(MI_SCOPE,'_INPUTS.rds')))
 stopifnot(digest(file=a$source_file,algo='sha256')==a$source_sha256,digest(file=a$definition_template,algo='sha256')==a$definition_template_sha256)
 src<-readRDS(a$source_file);ix<-match(as.character(a$pid),as.character(src$pid));stopifnot(!anyNA(ix),!anyDuplicated(ix))
 same<-function(x,y){x<-as.matrix(x);y<-as.matrix(y);stopifnot(identical(dim(x),dim(y)),identical(unname(is.na(x)),unname(is.na(y))));d<-max(abs(x-y),na.rm=TRUE);stopifnot(d<1e-10);d}
 fixed<-setdiff(names(src$analysis),'z0');same(a$analysis[fixed],src$analysis[ix,fixed])
 same(a$data$g,as.numeric(src$income_raw[ix]>8730));same(a$data$adl,src$analysis$c7[ix]);same(a$analysis$c12,a$data$g)
 strictfile<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_trajectory_readiness_20261018/private/STRICT_FIVEWAVE_CONTRASTS.rds'
 stopifnot(digest(file=strictfile,algo='sha256')==a$strict_source_sha256);strict<-readRDS(strictfile);yr<-c(2011,2013,2015,2018,2020)
 count<-integer(length(ix))
 for(k in 1:5){b<-strict[strict$indicator==MI_SCOPE&strict$year==yr[k],];j<-match(as.character(a$pid),as.character(b$pid));stopifnot(!anyNA(j),!any(grepl('^STRUCTURAL_',b$status[j])),!any(b$status[j]=='AMBIGUOUS_EARLIEST_BIRTH_YEAR'));same(a$analysis[[paste0('z',k)]],(b$absolute[j]-src$z_mean)/src$z_sd);count<-count+as.integer(b$status[j]=='DEFINED')}
 stopifnot(all(count>=2));imp<-readRDS(ad$mids_path);stopifnot(digest(file=ad$mids_path,algo='sha256')==ad$mids_sha256,identical(imp$data,a$data))
 checks<-list();og<-!is.na(a$data$g);oa<-!is.na(a$data$adl)
 for(k in 1:40){
  v<-complete(imp,k);expected<-a$analysis;expected$c12<-v$g;expected$c7<-v$adl
  same(v$g[og],a$data$g[og]);same(v$adl[oa],a$data$adl[oa]);stopifnot(all(v$g%in%0:1),all(v$adl[!oa]%in%a$data$adl[oa]))
  for(n in names(a$passive))stopifnot(max(abs(v[[n]]-v[[a$passive[[n]][1]]]*v[[a$passive[[n]][2]]]))<1e-12)
  p<-file.path(R,'private',sprintf('MI%02d.dat',k));delta<-same(read.table(p,na.strings='-9999'),expected)
  checks[[k]]<-data.frame(member=k,N=nrow(expected),maximum_export_difference=delta,source_masks_and_observed_values_preserved=TRUE,sha256=digest(file=p,algo='sha256'))
 }
 cc<-a$analysis[og&oa,];same(read.table(file.path(R,'private/CC.dat'),na.strings='-9999'),cc)
 cc_sources<-fromJSON(file.path(BATCH,'contracts/CC_SOURCES.json'),simplifyVector=FALSE);same(read.table(cc_sources[[MI_SCOPE]]$data,na.strings='-9999'),cc)
 stopifnot(digest(file=a$source_file,algo='sha256')==a$source_sha256,digest(file=strictfile,algo='sha256')==a$strict_source_sha256)
 tab<-do.call(rbind,checks);write.csv(tab,file.path(R,'audit/INDEPENDENT_MI_MEMBERS.csv'),row.names=FALSE)
 write_json(list(status='PASS',scope=MI_SCOPE,m=40,N=nrow(a$data),missing_income_group=sum(!og),missing_ADL=sum(!oa),both_missing=sum(!og&!oa),maximum_export_difference=max(tab$maximum_export_difference),original_sources_unchanged=TRUE,old_completed_MI_reused=FALSE,not_proof_of_MAR_or_exact_latent_compatibility=TRUE,new_Mplus_calls=0),file.path(R,'audit/INDEPENDENT_MI.json'),auto_unbox=TRUE,pretty=TRUE,digits=16)
 cat('INDEPENDENT_SCOPE_MI_PASS',MI_SCOPE,'\n')
})
