# 原生ClaudeR两个互斥范围队列，各队列内部串行：四范围各40份，先10轮、必要时原链延长至20轮。
# 仅缺失处理；本脚本不启动任何Mplus，也不改原数据及已经完成的家族。
local({
 BATCH<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_income_mi_20261019'
 Sys.setenv(OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1,MKL_NUM_THREADS=1)
 library(jsonlite);library(processx);library(ps);stopifnot(exists('QUEUE_ID'),QUEUE_ID%in%c('q1','q2'));Sys.setenv(PP_LGCM_INCOME_DISPATCH='v2');scopes<-if(QUEUE_ID=='q1')c('sd','oldest')else c('gender','son')
 # 先确认旧协调器真实结束，再登记互斥范围；PID复用由创建时间排除。
 dispatch<-fromJSON(file.path(BATCH,'contracts/FULL_DISPATCH.json'));stopifnot(dispatch['max_parallel']==2);scopes<-unlist(dispatch['queues'][[1]][[QUEUE_ID]])
 alive<-function(pid,born)tryCatch(abs(as.numeric(ps::ps_create_time(ps::ps_handle(pid)))-born)<.01,error=function(e)FALSE)
 ownerfile<-file.path(BATCH,'runtime',paste0('QUEUE_OWNER_',QUEUE_ID,'.json'))
 if(file.exists(ownerfile)){old<-fromJSON(ownerfile);stopifnot(!alive(old$pid,old$created));stop('Existing completed queue owner; reconcile before a new launch')}
 write_json(list(pid=Sys.getpid(),created=as.numeric(ps::ps_create_time(ps::ps_handle())),queue=QUEUE_ID,scopes=scopes),ownerfile,auto_unbox=TRUE,pretty=TRUE)
 PY<-'C:/Users/LZHS/AppData/Local/Programs/Python/Python314/python.exe'
 ps::ps_set_cpu_affinity(ps::ps_handle(),if(QUEUE_ID=='q1')0:7 else 8:15)
 statusfile<-file.path(BATCH,'results',paste0('SCOPE_STATUS_',QUEUE_ID,'.json'));dir.create(dirname(statusfile),showWarnings=FALSE)
 states<-if(file.exists(statusfile))fromJSON(statusfile,simplifyVector=FALSE)else list()
 save_states<-function()write_json(states,statusfile,auto_unbox=TRUE,pretty=TRUE)
 admit<-function(z){
  started<-Sys.time()
  repeat{
   p<-processx::run(PY,c('-u','-X','utf8',file.path(BATCH,'code/admit_scope_v2.py'),z,Sys.getpid(),sprintf('%.6f',as.numeric(ps::ps_create_time(ps::ps_handle())))),error_on_status=FALSE,timeout=60,echo=FALSE)
   if(p$status==0L)return(invisible(TRUE))
   if(p$status!=2L)stop('Resource probe failed; preserve checkpoint: ',p$stderr)
   clauder_progress('income_resource_wait',paste(z,'Windows headroom below existing admission floor'))
   if(as.numeric(difftime(Sys.time(),started,units='secs'))>120)stop('RESOURCE_HOLD_NO_NEW_FIT')
   Sys.sleep(10)
  }
 }
 for(z in scopes){
  root<-file.path(BATCH,'mi',z);done<-file.path(root,'audit/INDEPENDENT_MI.json')
  if(file.exists(done)&&fromJSON(done)$status=='PASS'){states[[z]]<-list(status='FULL40_INDEPENDENT_PASS_REUSED');save_states();next}
  if(!isTRUE(fromJSON(file.path(BATCH,'pilot',z,'audit/PILOT_TERMINAL.json'))$passed)){states[[z]]<-list(status='PILOT_NOT_PASSED');save_states();next}
  states[[z]]<-list(status='RUNNING_40_CHAINS');save_states()
  result<-tryCatch({
   for(it in c(10L,20L)){
    for(block in c('a','b')){
     term<-file.path(root,block,'audit',paste0('ITER',it,'_TERMINAL.json'))
     if(file.exists(term)){stopifnot(fromJSON(term)$passed);next}
     gc();admit(z);clauder_progress('income_full_family',paste(z,'block',block,'to iteration',it))
     local({MI_SCOPE<-z;MI_BLOCK<-block;MI_STOP_ITER<-it;source(file.path(BATCH,'code/run_mi_worker.R'),local=TRUE)})
    }
    clauder_progress('income_combined_diagnostics',paste(z,'40 original chains at',it,'iterations'))
    local({MI_SCOPE<-z;MI_STOP_ITER<-it;source(file.path(BATCH,'code/combine_scope.R'),local=TRUE)})
    combined<-fromJSON(file.path(root,'audit',paste0('COMBINED_ITER',it,'.json')))
    if(combined$status=='ADMITTED_WORKING_MI'){
     local({MI_SCOPE<-z;source(file.path(BATCH,'code/verify_scope_mi.R'),local=TRUE)})
     break
    }
   }
   list(status=if(combined$status=='ADMITTED_WORKING_MI')'FULL40_INDEPENDENT_PASS' else combined$status,m=40,iterations=it,max_tail_PSRF=combined$max_tail_PSRF,new_Mplus=0,full_H4=FALSE)
  },error=function(e)list(status='STOPPED_PRESERVE_CHECKPOINT_AND_FAILURE',reason=conditionMessage(e),full_H4=FALSE))
  states[[z]]<-result;save_states();clauder_progress('income_scope_disposition',paste(z,result$status));gc()
 }
 writeLines(paste('Queue',QUEUE_ID,'scope states saved; no Mplus called'),file.path(BATCH,'runtime',paste0('SCOPES_TERMINAL_',QUEUE_ID)))
 clauder_progress('LATENT_INCOME_FCS_TERMINAL',paste(QUEUE_ID,'scope dispositions saved; complete40 only where independent checks pass'))
 cat('LATENT_INCOME_FCS_TERMINAL\n')
})
