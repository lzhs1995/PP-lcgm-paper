# 两个串行家族队列：仅消费已独立验收的完整40份；等待不触发重插补。
local({
 ROOT<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_income_models_20261019'
 MI<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_income_mi_20261019'
 PY<-'C:/Users/LZHS/AppData/Local/Programs/Python/Python314/python.exe'
 library(jsonlite);library(processx);library(ps)
 stopifnot(exists('QUEUE_ID'),QUEUE_ID%in%c('q1','q2'))
 qid<-QUEUE_ID;scopes<-if(qid=='q1')c('sd','oldest')else c('gender','son')
 Sys.setenv(OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1,MKL_NUM_THREADS=1)
 rj<-function(p)fromJSON(p,simplifyVector=FALSE)
 wj<-function(x,p)write_json(x,p,auto_unbox=TRUE,pretty=TRUE,digits=NA,null='null')
 owner<-file.path(ROOT,'runtime',paste0('QUEUE_OWNER_',qid,'.json'));stopifnot(!file.exists(owner))
 created<-as.numeric(ps_create_time(ps_handle()))
 wj(list(pid=Sys.getpid(),created_exact=sprintf('%.17g',created),queue=qid,scopes=scopes),owner)
 # 只改变当前自有worker，逐核采样选择有余量的一半逻辑核；不固定CPU编号。
 a<-processx::run(PY,c('-X','utf8',file.path(ROOT,'code/select_affinity.py'),Sys.getpid(),sprintf('%.17g',created),qid),error_on_status=TRUE,timeout=60)
 cat(a$stdout);flush.console()
 states<-list();statefile<-file.path(ROOT,'results',paste0('QUEUE_',qid,'.json'))
 save_states<-function()wj(states,statefile)
 mark<-function(stage,message){clauder_progress(stage,message);wj(list(stage=stage,message=message,at=format(Sys.time(),tz='UTC')),file.path(ROOT,'runtime',paste0('QUEUE_PROGRESS_',qid,'.json')))}
 for(z in scopes){
  states[[z]]<-list(status='WAITING_COMPLETE40_INDEPENDENT_MI');save_states()
  mark('income_model_wait',paste(z,'waiting for original complete40 MI; no resubmission'))
  admit<-file.path(MI,'mi',z,'audit/MI_ADMISSION.json');ind<-file.path(MI,'mi',z,'audit/INDEPENDENT_MI.json')
  # 有界等待现存上游worker；重启/死亡仅记录，绝不重提其任务。
  waitstart<-Sys.time();last<-waitstart
  repeat{
   if(file.exists(admit)&&file.exists(ind)){
    aa<-rj(admit);ii<-rj(ind)
    if(aa$status=='ADMITTED_WORKING_MI'&&aa$m==40&&ii$status=='PASS'&&ii$m==40)break
   }
   stfile<-file.path(MI,'results',paste0('SCOPE_STATUS_',qid,'.json'))
   if(file.exists(stfile)){
    upstream<-rj(stfile)[[z]]
    if(!is.null(upstream)&&!upstream$status%in%c('RUNNING_40_CHAINS','FULL40_INDEPENDENT_PASS','FULL40_INDEPENDENT_PASS_REUSED')){
     states[[z]]<-list(status='UPSTREAM_NOT_ADMITTED',upstream=upstream);save_states();break
    }
   }
   own<-rj(file.path(ROOT,'contracts/UPSTREAM_OWNERS.json'))[[qid]]
   live<-tryCatch(ps_is_running(ps_handle(own$pid,as.POSIXct(as.numeric(own$created_exact),origin='1970-01-01',tz='UTC'))),error=function(e)NA)
   if(!isTRUE(live)){
    states[[z]]<-list(status='UPSTREAM_EXIT_OR_IDENTITY_UNRESOLVED_NO_RESUBMISSION');save_states();break
   }
   if(difftime(Sys.time(),waitstart,units='hours')>24){states[[z]]<-list(status='UPSTREAM_WAIT_LEASE_EXPIRED');save_states();break}
   if(difftime(Sys.time(),last,units='secs')>60){mark('income_model_wait',paste(z,'original MI still active; full40 gate pending'));last<-Sys.time()}
   Sys.sleep(10)
  }
  if(states[[z]]$status!='WAITING_COMPLETE40_INDEPENDENT_MI')next
  states[[z]]<-list(status='ESTIMATING_COMPLETE40');save_states()
  result<-tryCatch({local({FAMILY<-paste0(z,'_INCOME');source(file.path(ROOT,'code/run_family.R'),local=TRUE)});rj(file.path(ROOT,'results',paste0(z,'_INCOME'),'FAMILY_STATUS.json'))},error=function(e)list(status='DRIVER_ERROR_PRESERVE_OUTPUT',error=conditionMessage(e)))
  proof<-file.path(ROOT,'results',paste0(z,'_INCOME'),'INDEPENDENT_VERIFICATION.json')
  if(file.exists(proof)&&rj(proof)$status=='PASS'){
   result$independent_readback<-'PASS'
   result$estimation_status<-result$status
   pooled<-rj(file.path(ROOT,'results',paste0(z,'_INCOME'),'POOLING_RECEIPT.json'))
   result$status<-if(pooled$MCSE_over_SE_max<.1)'FULL40_INDEPENDENT_PASS'else'FULL40_MCSE_LIMIT_RETAINED'
  }
  states[[z]]<-result;save_states();mark('income_model_scope_terminal',paste(z,result$status));gc()
 }
 mark('INCOME_MODEL_QUEUE_TERMINAL',paste(qid,'all scope dispositions saved'))
 wj(list(queue=qid,states=states,original_four_complete=FALSE,full_H4_complete=FALSE),file.path(ROOT,'runtime',paste0('QUEUE_TERMINAL_',qid,'.json')))
 cat('INCOME_MODEL_QUEUE_TERMINAL\n')
})
