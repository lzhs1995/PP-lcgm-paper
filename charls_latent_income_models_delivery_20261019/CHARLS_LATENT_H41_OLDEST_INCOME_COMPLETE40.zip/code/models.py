"""从合法CC原语法编译完整MI成员；变动只限标题、起点、数据。"""
from pathlib import Path
import hashlib,json,re,shutil
import numpy as np
import pandas as pd
import validated_income_models as base
R=Path(__file__).resolve().parents[1];base.R=R;base.ref.R=R
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def modeldir(z,kind,k=1,start='A'):
 return R/'models'/f'CHARLS_{z.upper()}_LATENT_INCOME_{kind}_MI{k:02d}_{start}'

def template(source,kind,start,modelid):
 job=read(source/'job.json');par=pd.read_csv(source/'parameters_high_precision.csv');slots=read(source/'normalized_slots.json')
 n=138 if kind=='INCOME' else 132;assert len(par)==len(slots)==job['expected_free']==n
 q=par.estimate.to_numpy().copy();se=par.se.to_numpy()
 if start=='B':
  for i,s in enumerate(slots):
   if s['op'] in ('MEAN','ON','BY'):q[i]+=(1 if i%2 else -1)*.02*se[i]
 val={s['key']:float(v) for s,v in zip(slots,q)};starts={}
 for s,v in zip(slots,q):
  op=s['op'];a=s['lhs'];b=s['rhs']
  if kind=='ORDINARY':starts[s['label']]=float(v);continue
  if b in ('IXG','SXG','IZG','SZG') or (op=='ON' and b=='C12'):continue
  if op=='MEAN':
   starts[a.lower()+'0']=float(v);starts[a.lower()+'1']=float(v)+val['ON:'+a+':C12']
  elif kind=='INCOME' and op=='ON' and (a,b) in base.targets:
   starts[s['label']]=float(v);starts[s['label']+'0']=float(v);starts[s['label']+'1']=float(v)+val['ON:'+a+':'+b+'G']
  else:starts[s['label']]=float(v)
 assert len(starts)==n+(6 if kind=='INCOME' else 0)
 inp=(source/'model.inp').read_text();seen=set()
 def replace(m):
  label=m.group(3);assert label in starts;seen.add(label);return '*'+format(starts[label],'.12g')+m.group(2)+' ('+label+')'
 new=re.sub(r'\*([-+0-9.eE]+)(\]?) \((\w+)\)',replace,inp)
 assert seen==set(starts),(set(starts)-seen)
 new=new.replace('TITLE: '+source.name+';','TITLE: '+modelid+';')
 scrub=lambda x:re.sub(r'TITLE:[^;]*;','TITLE:;',re.sub(r'\*[-+0-9.eE]+(?=\]? \()','*START',x))
 assert scrub(inp)==scrub(new) and max(map(len,new.splitlines()))<=90
 return new,slots,job

def prepare(z,kind,k,start):
 k=int(k);c=read(R/'contracts/RUN_CONTRACT.json');P=Path(c['pilot_root']);M=Path(c['mi_root'])
 assert z in c['indicators'] and kind in c['model_groups'] and 1<=k<=40 and start in ('A','B')
 assert (kind=='INCOME' or (k==1 and start=='A')) and (start=='A' or k==1)
 ad=read(M/'mi'/z/'audit/MI_ADMISSION.json');ind=read(M/'mi'/z/'audit/INDEPENDENT_MI.json')
 assert ad['status']=='ADMITTED_WORKING_MI' and ad['m']==40 and ind['status']=='PASS' and ind['m']==40
 assert read(P/'results/FAMILY_STATUS.json')[z]['status']=='TWO_START_CC_FEASIBLE_NOT_MI'
 source=P/'models'/f'CHARLS_{z.upper()}_LATENT_INCOME_{kind}_{start}'
 frozen=read(R/'contracts/TEMPLATE_MODELS.json')[source.name]
 for n,h in frozen.items():assert sha(source/n)==h
 rec=read(source/'receipt.json');assert rec['status']=='USABLE'
 d=modeldir(z,kind,k,start);new,slots,job0=template(source,kind,start,d.name)
 data=M/'mi'/z/'private'/f'MI{k:02d}.dat';members=pd.read_csv(M/'mi'/z/'audit/MI_MEMBERS.csv');entry=members.loc[members.member==k];assert len(entry)==1 and sha(data)==entry.iloc[0].sha256 and entry.iloc[0]['columns']==28
 d.mkdir(exist_ok=False);shutil.copyfile(data,d/'data.dat');(d/'model.inp').write_text(new,encoding='ascii');(d/'normalized_slots.json').write_text(json.dumps(slots,indent=2))
 job={**job0,'id':d.name,'root':str(R),'dest':str(d),'member':k,'start':start,'N':ad['N'],'cap_seconds':180 if kind=='INCOME' else 120,'source_CC':str(source),'source_CC_output_sha256':rec['output_sha256'],'hashes':{n:sha(d/n) for n in ['model.inp','data.dat']}}
 (d/'job.json').write_text(json.dumps(job,indent=2))
 (d/'STRUCTURE_IDENTITY.json').write_text(json.dumps(dict(passed=True,only_title_starts_data_differ=True,source=str(source),source_input_sha256=frozen['model.inp'],source_output_sha256=frozen['model.out']),indent=2))
 # 合并/公开核验只需这份聚合准入，不复制MIDS或逐人数据到audit。
 meta=R/'mi'/z/'audit';meta.mkdir(parents=True,exist_ok=True)
 for name in ['MI_ADMISSION.json','INDEPENDENT_MI.json','MI_MEMBERS.csv']:
  target=meta/name;src=M/'mi'/z/'audit'/name
  if target.exists():assert sha(target)==sha(src)
  else:shutil.copyfile(src,target)
 return str(d)

def normalize(d):return base.normalize(Path(d))
def agree(a,b,target):return base.agree_full(a,b,target)
def calibrate(z):
 a=modeldir(z,'ORDINARY');b=modeldir(z,'PARENT')
 assert read(a/'receipt.json')['status']==read(b/'receipt.json')['status']=='USABLE'
 assert read(a/'job.json')['hashes']['data.dat']==read(b/'job.json')['hashes']['data.dat']
 out=base.ref.compare_full(a,b);out.update(same_data=True,class_constant='fixed -N log2 removed')
 (R/'results'/f'{z}_CALIBRATION.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
