"""收入G为第12项控制：普通父132、等价分组父132、六路径组差138参数。"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import hashlib,json,re,shutil,sys
import numpy as np
import pandas as pd
from scipy.linalg import cho_factor,cho_solve
from calibrated_reader import matrices,pid
import validated_reference_models as ref
R=Path(__file__).resolve().parents[1];ref.R=R
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
fac=ref.fac;obs=ref.obs;targets=ref.targets
controls=[f'C{k}' for k in range(1,13)]
columns=['cluster']+[f'x{k}' for k in range(1,6)]+[f'y{k}' for k in range(1,6)]+[c.lower() for c in controls]+[f'z{k}' for k in range(1,6)]
key_specs=[('bii','IY','IX'),('bis','SY','IX'),('bss','SY','SX'),('bsyiy','SY','IY'),('bzi','IY','IZ'),('biz','SY','IZ'),('bsz','SY','SZ'),('dii','IY','IXG'),('dis','SY','IXG'),('dss','SY','SXG'),('dzi','IY','IZG'),('diz','SY','IZG'),('dsz','SY','SZG')]

def modeldir(z,g,st):return R/'models'/f'CHARLS_{z.upper()}_LATENT_INCOME_{g}_{st}'

def rows_from_frame(df,start):
    rows=[]
    for i,r in enumerate(df.itertuples()):
        mat=r.matrix.upper();a=r.row;b=r.column
        if mat=='ALPHA':op='MEAN';a=b;b=''
        elif mat=='LAMBDA':op='BY';a,b=b,a
        elif mat in ('THETA','PSI'):op='VAR' if a==b else 'WITH'
        elif mat in ('BETA','GAMMA'):op='ON'
        else:raise ValueError(mat)
        v=float(r.estimate)
        if op=='VAR':assert v>0
        if start=='B' and op in ('MEAN','ON','BY'):v+=.02*float(r.se)*(1 if i%2 else -1)
        rows.append(dict(op=op,lhs=a,rhs=b,key=op+':'+a+':'+b,label=f'p{i+1:03d}',value=v))
    return rows

def prepare(z,group,start):
    assert group in ('ORDINARY','PARENT','INCOME') and start in ('A','B')
    assert group=='INCOME' or start=='A'
    e=read(R/'contracts/SOURCES.json')[z];original=e['starting_parent'];source=Path(original['parent'])
    for n,h in original['hashes'].items():assert sha(source/n)==h
    ordinary=group=='ORDINARY';interaction=group=='INCOME';g='C12'
    if ordinary:
        df=pd.read_csv(source/'parameters_high_precision.csv');rows=rows_from_frame(df,'A');assert len(rows)==126
        rows.extend(dict(op='ON',lhs=a,rhs=g,key='ON:'+a+':'+g,label=f'g{k}',value=0.) for k,a in enumerate(fac))
    else:
        source=modeldir(z,'ORDINARY','A');assert read(source/'receipt.json')['status']=='USABLE'
        assert read(source/'job.json')['hashes']['data.dat']==e['data_sha256']
        df=pd.read_csv(source/'parameters_high_precision.csv');rows=rows_from_frame(df,start)
    assert len(rows)==132 and len({r['key'] for r in rows})==132
    assert sum(r['op']=='ON' and r['rhs']=='C12' for r in rows)==6
    d=modeldir(z,group,start);d.mkdir(exist_ok=False)
    assert sha(e['data'])==e['data_sha256'];shutil.copyfile(e['data'],d/'data.dat')
    fixed=[]
    for i,a in enumerate(fac):
        for b in fac[:i]:
            if not any(r['op']=='WITH' and {r['lhs'],r['rhs']}=={a,b} for r in rows):fixed.append(f'{a.lower()} WITH {b.lower()}@0;')
    lines=['TITLE: '+d.name+';','DATA: FILE=data.dat;','VARIABLE: NAMES=cluster x1-x5 y1-y5 c1-c12 z1-z5;',
        'USEVARIABLES=x1-x5 y1-y5 z1-z5 '+('c1-c12;' if ordinary else 'c1-c11;'),'MISSING=ALL(-9999); CLUSTER=cluster;']
    if not ordinary:lines+=['CLASSES=cg(2); KNOWNCLASS=cg(c12=0 c12=1);']
    lines+=['ANALYSIS: TYPE=COMPLEX'+(';' if ordinary else ' MIXTURE;'),'ESTIMATOR=MLR; PROCESSORS=1; COVERAGE=.005; ITERATIONS=2000;']
    if not ordinary:lines+=['STARTS=0; MITERATIONS=2000;']
    lines+=['MODEL:']+([] if ordinary else ['%OVERALL%'])
    lines+=['ix sx | x1@0 x2@2 x3@4 x4@7 x5@9;','iy sy | y1@0 y2@2 y3@4 y4@7 y5@9;','iz sz | z1@0 z2*2 z3*4 z4*7 z5@9;',
        '[x1-x5@0 y1-y5@0 z1-z5@0];',*fixed]
    if ordinary:lines += [ref.stmt(r) for r in rows]
    else:
        common=[r for r in rows if r['op']!='MEAN' and not(r['op']=='ON' and r['rhs']==g)]
        means=[r for r in rows if r['op']=='MEAN'];gm={r['lhs']:r['value'] for r in rows if r['op']=='ON' and r['rhs']==g}
        assert len(means)==len(gm)==6
        lines+=['[cg#1@0];',*[ref.stmt(r) for r in common]]
        for cls in (0,1):
            lines += [f'%cg#{cls+1}%','[x1-x5@0 y1-y5@0 z1-z5@0];',*fixed]
            for r in common:
                target=targets.get((r['lhs'],r['rhs'])) if interaction and r['op']=='ON' else None
                lines.append(ref.stmt(r,r['value']+cls*(.005 if start=='A' else -.005),r['label']+str(cls)) if target else ref.stmt(r))
            lines += [ref.stmt(r,r['value']+cls*gm[r['lhs']],r['lhs'].lower()+str(cls)) for r in means]
    lines+=['OUTPUT: TECH1 TECH3 TECH8 CINTERVAL SVALUES;','SAVEDATA: RESULTS=estimates.dat; TECH3=tech3.dat;']
    assert max(map(len,lines))<=90
    (d/'model.inp').write_text('\n'.join(lines)+'\n',encoding='ascii')
    slots=rows.copy()
    if interaction:slots.extend(dict(op='ON',lhs=a,rhs=b+'G',key='ON:'+a+':'+b+'G',label=lab,value=.005 if start=='A' else -.005) for (a,b),lab in targets.items())
    (d/'normalized_slots.json').write_text(json.dumps(slots,indent=2))
    job=dict(id=d.name,root=str(R),dest=str(d),indicator=z,group=group,member=0,start=start,category=group,cap_seconds=180 if interaction else 120,expected_free=len(slots),g=g,ordinary=ordinary,interaction=interaction,source_parent=str(source),N=e['N'],columns=columns,hashes={n:sha(d/n) for n in ['model.inp','data.dat']})
    (d/'job.json').write_text(json.dumps(job,indent=2));print(json.dumps(dict(prepared=d.name,parameters=len(slots),N=e['N'])))
    return d

def checks_moments(q,slots,data):
    assert data.shape[1]==len(columns)==28
    L=np.zeros((15,6))
    for j in range(3):L[j*5:(j+1)*5,j*2]=1;L[j*5:(j+1)*5,j*2+1]=[0,2,4,7,9]
    TH=np.zeros((15,15));PSI=np.zeros((6,6));B=np.zeros((6,6));D=np.zeros((6,6));Gamma=np.zeros((6,12));alpha=np.zeros(6)
    for r,value in zip(slots,q):
        op=r['op'];a=r['lhs'];b=r['rhs']
        if op=='BY':L[obs.index(b),fac.index(a)]=value
        elif op=='MEAN':alpha[fac.index(a)]=value
        elif op in ('VAR','WITH'):
            b=a if op=='VAR' else b;m=PSI if a in fac else TH;ns=fac if a in fac else obs;i=ns.index(a);j=ns.index(b);m[i,j]=m[j,i]=value
        elif b in ('IXG','SXG','IZG','SZG'):D[fac.index(a),fac.index(b[:2])]=value
        elif b in fac:B[fac.index(a),fac.index(b)]=value
        else:Gamma[fac.index(a),controls.index(b)]=value
    def mineig(m):
        if np.any(np.diag(m)<=0):return float(np.linalg.eigvalsh(m).min())
        return float(np.linalg.eigvalsh(m/np.sqrt(np.outer(m.diagonal(),m.diagonal()))).min())
    geometry={'PSI':mineig(PSI),'THETA':mineig(TH)};ll=0.
    for g in (0,1):
        A=np.linalg.inv(np.eye(6)-B-g*D);G=A@PSI@A.T;S=L@G@L.T+TH
        geometry['G'+str(g)]=mineig(G);geometry['SIGMA'+str(g)]=mineig(S)
        if min(geometry.values())<=1e-7:return geometry,None
        dd=data[data[:,columns.index('c12')]==g]
        mu=(alpha+dd[:,[columns.index(c.lower()) for c in controls]]@Gamma.T)@A.T@L.T
        y=dd[:,[columns.index(o.lower()) for o in obs]];mask=np.isfinite(y)
        for pattern in np.unique(mask,axis=0):
            ids=np.all(mask==pattern,axis=1);j=np.flatnonzero(pattern)
            if not len(j):continue
            ch=cho_factor(S[np.ix_(j,j)],lower=True);err=y[ids][:,j]-mu[ids][:,j]
            ll-=.5*(len(err)*(len(j)*np.log(2*np.pi)+2*np.log(np.diag(ch[0])).sum())+np.sum(err*cho_solve(ch,err.T).T))
    return geometry,float(ll)

def normalize(d):
    d=Path(d);job=read(d/'job.json');engine=read(d/'engine_receipt.json');rec=dict(id=d.name,dest=str(d),indicator=job['indicator'],group=job['group'],start=job['start'],engine=engine,status=engine['status'])
    if (d/'model.out').exists():rec['output_sha256']=sha(d/'model.out')
    if engine['status']!='EXITED':(d/'receipt.json').write_text(json.dumps(rec,indent=2));return
    if not (d/'model.out').exists():
        rec['status']='OUTPUT_MISSING';(d/'receipt.json').write_text(json.dumps(rec,indent=2));return
    text=' '.join((d/'model.out').read_text(encoding='latin1').split())
    failure=None
    if '*** ERROR' in text:failure='INPUT_ERROR'
    elif 'THE MODEL ESTIMATION TERMINATED NORMALLY' not in text:failure='NO_NORMAL_TERMINATION'
    elif re.search(r'STANDARD ERRORS.{0,100}COULD NOT BE COMPUTED',text):failure='SE_FAILURE'
    if failure:
        rec['status']=failure;(d/'receipt.json').write_text(json.dumps(rec,indent=2));print(json.dumps(dict(id=d.name,status=failure)));return
    try:
        txt,mp,q,se,V,ll=matrices(d);slots=read(d/'normalized_slots.json');n=len(slots)
        assert len(q)==n==job['expected_free'] and len(mp)==(1 if job['ordinary'] else 2)
        J=np.zeros((n,n));meta=[]
        for i,r in enumerate(slots):
            op=r['op'];a=r['lhs'];b=r['rhs'];row=a;col=b
            if not job['ordinary'] and op=='ON' and b==job['g']:
                J[i,pid(mp[2],'ALPHA','1',a)]=1;J[i,pid(mp[1],'ALPHA','1',a)]=-1;mat='BETA'
            elif op=='ON' and b in ('IXG','SXG','IZG','SZG'):
                J[i,pid(mp[2],'BETA',a,b[:2])]=1;J[i,pid(mp[1],'BETA',a,b[:2])]=-1;mat='BETA'
            else:
                if op=='BY':mat='LAMBDA';row=b;col=a
                elif op=='MEAN':mat='ALPHA';row='1';col=a
                elif op in ('VAR','WITH'):mat='PSI' if a in fac else 'THETA';col=a if op=='VAR' else b
                elif op=='ON':mat='BETA'
                else:raise ValueError(op)
                k=pid(mp[1],mat,row,col);J[i,k]=1
                if not job['ordinary'] and op!='MEAN':
                    if job['interaction'] and op=='ON' and (a,b) in targets:assert k!=pid(mp[2],mat,row,col)
                    else:assert k==pid(mp[2],mat,row,col)
            meta.append(dict(parameter=i+1,matrix=mat.lower(),row=row,column=col))
        assert np.linalg.matrix_rank(J)==n
        nq=J@q;NV=J@V@J.T;nse=np.sqrt(NV.diagonal());eig=float(np.linalg.eigvalsh(NV/np.outer(nse,nse)).min())
        data=np.genfromtxt(d/'data.dat');data[data==-9999]=np.nan
        geometry,analytic=checks_moments(nq,slots,data);adjusted=ll+(0 if job['ordinary'] else len(data)*np.log(2))
        negative=[r['lhs'] for r,v in zip(slots,nq) if r['op']=='VAR' and v<0]
        normal='THE MODEL ESTIMATION TERMINATED NORMALLY' in txt;no_autofix='FIXED TO AVOID SINGULARITY' not in txt
        fatal=any(t in ' '.join(txt.split()) for t in ['STANDARD ERRORS COULD NOT BE COMPUTED','MAY NOT BE TRUSTWORTHY','THE MODEL ESTIMATION DID NOT TERMINATE NORMALLY','SADDLE POINT','*** ERROR'])
        ll_ok=analytic is not None and abs(adjusted-analytic)<.02
        passed=normal and not fatal and no_autofix and len(data)==job['N'] and eig>1e-10 and min(geometry.values())>1e-7 and not negative and ll_ok
        rec.update(status='USABLE' if passed else 'INADMISSIBLE',parameters=n,N=len(data),communities=len(np.unique(data[:,0])),negative=negative,geometry=geometry,vcov_min_correlation_eigenvalue=eig,normal=normal,no_autofix=no_autofix,LL=adjusted,analytic_LL=analytic,likelihood_identity=bool(ll_ok),normalized_parameters=True)
        par=pd.DataFrame(meta);par['estimate']=nq;par['se']=nse;par.to_csv(d/'parameters_high_precision.csv',index=False)
        pd.DataFrame(NV).to_csv(d/'parameter_covariance.csv',header=False,index=False);pd.DataFrame(J).to_csv(d/'parameter_transform.csv',header=False,index=False)
        keys=[]
        for lab,a,b in (key_specs if job['interaction'] else key_specs[:7]):
            v=par[(par.matrix=='beta')&(par.row==a)&(par.column==b)];assert len(v)==1;k=v.iloc[0].to_dict();k['label']=lab;keys.append(k)
        pd.DataFrame(keys).to_csv(d/'key_paths.csv',index=False)
        (d/'validation.json').write_text(json.dumps(dict(passed=bool(passed),geometry=geometry,vcov_min=eig,negative=negative,likelihood_identity=bool(ll_ok)),indent=2))
    except Exception as exc:rec.update(status='READBACK_FAILED',error=repr(exc))
    (d/'receipt.json').write_text(json.dumps(rec,indent=2));print(json.dumps({k:rec[k] for k in ('id','status','error','parameters') if k in rec}))

def calibrate(z):
    a=modeldir(z,'ORDINARY','A');b=modeldir(z,'PARENT','A')
    assert read(a/'receipt.json')['status']==read(b/'receipt.json')['status']=='USABLE'
    assert read(a/'job.json')['hashes']['data.dat']==read(b/'job.json')['hashes']['data.dat']
    out=ref.compare_full(a,b);out.update(same_data=True,class_constant='fixed -N log2 removed')
    (R/'results'/f'{z}_CALIBRATION.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))

def agree_full(a,b,target):return ref.agree_full(a,b,target)

if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare(*sys.argv[2:5])
    elif sys.argv[1]=='normalize':normalize(sys.argv[2])
    elif sys.argv[1]=='calibrate':calibrate(sys.argv[2])
    elif sys.argv[1]=='agree':agree_full(*sys.argv[2:5])
