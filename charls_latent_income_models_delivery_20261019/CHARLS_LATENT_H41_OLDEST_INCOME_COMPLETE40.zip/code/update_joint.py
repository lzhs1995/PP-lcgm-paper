"""锁内原子发布计划12检验的Holm；不把缺失家族伪造为成功。"""
from pathlib import Path
import csv,hashlib,json,os,time
from engine_slots import exclusive
R=Path(__file__).resolve().parents[1]
with exclusive(R/'runtime/joint_results'):
 p=R/'results/REUSED_H41_D1.csv';f=json.loads((R/'contracts/REUSED_H41_D1.json').read_text());assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
 with p.open() as h:rows=list(csv.DictReader(h))
 assert len(rows)==24 and len({x['family'] for x in rows})==8
 for p in sorted((R/'results').glob('*_INCOME/JOINT_D1.csv')):
  receipt=p.parent/'POOLING_RECEIPT.json'
  if not receipt.exists():continue
  assert json.loads(receipt.read_text())['m']==40
  with p.open() as h:rows.extend(csv.DictReader(h))
 assert len({(r['family'],r['test_set']) for r in rows})==len(rows)
 for key in sorted({r['test_set'] for r in rows}):
  group=sorted([r for r in rows if r['test_set']==key],key=lambda r:float(r['p']));assert len(group)<=12
  previous=0
  for i,r in enumerate(group):previous=min(1,max(previous,float(r['p'])*(12-i)));r['holm_p_planned12']=previous
 target=R/'results/JOINT_D1_ALL_COMPLETE_FAMILIES.csv';tmp=target.with_suffix('.tmp')
 names=list(dict.fromkeys(n for r in rows for n in r))
 with tmp.open('w',newline='') as h:
  w=csv.DictWriter(h,fieldnames=names);w.writeheader();w.writerows(rows)
 for attempt in range(25):
  try:os.replace(tmp,target);break
  except PermissionError:
   if attempt==24:raise
   time.sleep(.2)
 print('JOINT_D1_UPDATED',len({r['family'] for r in rows}),'of12')
