"""独立数值读回也使用已有清醒时钟，读回失败绝不重估模型。"""
from pathlib import Path
import json,sys
from bounded_child_awake import run_child
R=Path(__file__).resolve().parents[1];family=sys.argv[1]
assert family in ['sd_INCOME','gender_INCOME','oldest_INCOME','son_INCOME']
d=R/'results'/family
out=run_child([sys.executable,'-X','utf8',str(R/'code/verify_family.py'),family],d/'readback_execution',600,working_directory=R)
(d/'READBACK_PROCESS_RECEIPT.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out));assert out['state']=='EXITED' and out['exitcode']==0
