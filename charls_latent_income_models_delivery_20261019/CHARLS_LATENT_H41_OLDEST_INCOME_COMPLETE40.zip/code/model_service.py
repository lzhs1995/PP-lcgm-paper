"""本批受限编译/读回助手；不可直接启动估计引擎。"""
import contextlib,io,json,os,sys,traceback
from pathlib import Path
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
emit=lambda j:print(json.dumps(j),flush=True)
emit(dict(kind='starting',pid=os.getpid()))
import models
R=Path(__file__).resolve().parents[1];assert models.R==R
emit(dict(kind='ready',pid=os.getpid(),root=str(R)))
for line in sys.stdin:
 request=json.loads(line);i=request['id'];args=request['args'];log=io.StringIO()
 if args==['shutdown']:emit(dict(kind='result',id=i,status=0,stdout='SHUTDOWN'));break
 try:
  with contextlib.redirect_stdout(log):
   if args[0]=='prepare' and len(args)==5:print(models.prepare(*args[1:]))
   elif args[0]=='normalize' and len(args)==2:
    assert Path(args[1]).resolve().is_relative_to(R/'models');models.normalize(args[1])
   elif args[0]=='calibrate' and len(args)==2:models.calibrate(args[1])
   elif args[0]=='agree' and len(args)==4:
    assert all(Path(p).resolve().is_relative_to(R) for p in args[1:]);models.agree(*args[1:])
   else:raise ValueError('Unsupported operation')
  emit(dict(kind='result',id=i,status=0,stdout=log.getvalue()))
 except Exception:emit(dict(kind='result',id=i,status=1,stdout=log.getvalue(),stderr=traceback.format_exc()))
