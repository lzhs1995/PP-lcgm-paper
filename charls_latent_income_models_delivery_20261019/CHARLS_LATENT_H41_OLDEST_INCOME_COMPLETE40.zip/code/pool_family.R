# 40份完整家族的参数/完整协方差合并；不平均P值，不合并成功子集。
# 调用方在局部环境提供FAMILY。
local({
 ROOT<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_income_models_20261019'
 library(jsonlite);library(digest);library(mitml)
 source(file.path(ROOT,'code/mi_pool_math.R'),local=TRUE)
 fam<-get('FAMILY',inherits=TRUE);parts<-strsplit(fam,'_',fixed=TRUE)[[1]];z<-parts[1];g<-parts[2]
 out<-file.path(ROOT,'results',fam);rj<-function(p)fromJSON(p,simplifyVector=FALSE)
 f<-rj(file.path(out,'FAMILY_STATUS.json'));a<-rj(file.path(ROOT,'mi',z,'audit/MI_ADMISSION.json'))
 stopifnot(f$status=='FORTY_USABLE_PENDING_POOLING',f$usable_members==40L,a$m==40L,a$status=='ADMITTED_WORKING_MI',!file.exists(file.path(out,'POOLING_RECEIPT.json')))
 labs<-c('bii','bis','bss','bsyiy','bzi','biz','bsz','dii','dis','dss','dzi','diz','dsz')
 Q<-matrix(NA_real_,40,length(labs),dimnames=list(NULL,labs));U<-list();sources<-list()
 for(k in 1:40){
  d<-file.path(ROOT,'models',sprintf('CHARLS_%s_LATENT_INCOME_%s_MI%02d_A',toupper(z),g,k));rec<-rj(file.path(d,'receipt.json'));job<-rj(file.path(d,'job.json'))
  stopifnot(rec$status=='USABLE',rec$N==a$N,rec$output_sha256==digest(file=file.path(d,'model.out'),algo='sha256'))
  for(n in names(job$hashes))stopifnot(job$hashes[[n]]==digest(file=file.path(d,n),algo='sha256'))
  p<-read.csv(file.path(d,'key_paths.csv'));p<-p[match(labs,p$label),];stopifnot(identical(p$label,labs))
  V<-as.matrix(read.csv(file.path(d,'parameter_covariance.csv'),header=FALSE));stopifnot(all(dim(V)==138L))
  Q[k,]<-p$estimate;U[[k]]<-V[p$parameter,p$parameter];dimnames(U[[k]])<-list(labs,labs)
  stopifnot(max(abs(diag(U[[k]])-p$se^2))<1e-8)
  sources[[k]]<-data.frame(member=k,model=basename(d),output_sha256=rec$output_sha256,input_sha256=job$hashes[['model.inp']],data_sha256=job$hashes[['data.dat']])
 }
 po<-rubin_pool(Q,U);tab<-data.frame(family=fam,label=labs,po$table,row.names=NULL)
 csv<-function(x,n)write.csv(x,file.path(out,n),row.names=FALSE)
 csv(tab,'POOLED_PATHS.csv');csv(data.frame(label=labs,rubin_pool(Q,U,nu_com=a$communities-1)$table,row.names=NULL),'CLUSTER_DF_SENSITIVITY.csv')
 sets<-list(primary_Z=c('dzi','diz','dsz'),secondary_X=c('dii','dis','dss'),diagnostic_all_six=c('dii','dis','dss','dzi','diz','dsz'))
 joints<-do.call(rbind,lapply(names(sets),function(n){t<-mitml::testConstraints(qhat=lapply(1:40,function(k)setNames(Q[k,],labs)),uhat=U,constraints=sets[[n]],method='D1');data.frame(family=fam,test_set=n,F=t$test[1,1],df1=t$test[1,2],df2=t$test[1,3],p=t$test[1,4],RIV=t$test[1,5],bonferroni_p_planned12=min(1,12*t$test[1,4]))}))
 csv(joints,'JOINT_D1.csv')
 paths<-list(IX_IY=c('bii','dii'),IX_SY=c('bis','dis'),SX_SY=c('bss','dss'),IZ_IY=c('bzi','dzi'),IZ_SY=c('biz','diz'),SZ_SY=c('bsz','dsz'))
 cs<-list()
 for(n in names(paths))for(group in c('G0','G1','difference')){
  v<-setNames(rep(0,length(labs)),labs);pair<-paths[[n]]
  if(group!='difference')v[pair[1]]<-1
  if(group!='G0')v[pair[2]]<-1
  cs[[paste(n,group)]]<-data.frame(family=fam,path=n,contrast=group,pool_contrast(Q,U,v),row.names=NULL)
 }
 contrasts<-do.call(rbind,cs);csv(contrasts,'GROUP_CONTRASTS.csv')
 csv(data.frame(member=1:40,Q),'MEMBER_ESTIMATES.csv')
 csv(do.call(rbind,lapply(1:40,function(k)data.frame(member=k,expand.grid(row=labs,column=labs,stringsAsFactors=FALSE),covariance=as.vector(U[[k]])))),'MEMBER_COVARIANCES.csv')
 csv(do.call(rbind,sources),'MEMBER_SOURCES.csv')
 csv(data.frame(row=labs,po$T,check.names=FALSE),'POOLED_COVARIANCE.csv')
 maxmc<-max(c(tab$MCSE_over_SE,contrasts$MCSE_over_SE))
 receipt<-list(status=if(maxmc<.1)'FORTY_CONDITIONAL_WORKING_MI_POOLED'else'FORTY_POOLED_MCSE_LIMIT_RETAINED',family=fam,N=a$N,communities=a$communities,m=40,MCSE_over_SE_max=maxmc,primary_test='Three latent Z-path resource differences; separate from latent X-by-Z moderation',knownclass='Observed binary resource; no latent class discovery; shared measurement and covariance parameters',missing_boundary=rj(file.path(ROOT,'contracts/MI_CONTRACT.json'))$compatibility,original_four_complete=FALSE,full_H4_complete=FALSE)
 write_json(receipt,file.path(out,'POOLING_RECEIPT.json'),auto_unbox=TRUE,pretty=TRUE,digits=NA)
 # 跨家族Holm由锁定的update_joint.py更新，复用既有八家族，不并发改写同一CSV。
 # 同一组差的区间图；不将跨零解释为证明零效应。
 d<-contrasts[contrasts$contrast=='difference',];d<-d[rev(seq_len(nrow(d))),]
 zlabel<-c(sd='absolute child-contact SD',gender='sons minus daughters contact',oldest='unique oldest minus remaining children contact',son='unique oldest son minus remaining children contact')[[z]]
 draw<-function(){par(mar=c(4,8,4,1));plot(d$estimate,seq_len(nrow(d)),xlim=range(c(d$lower,d$upper,0)),yaxt='n',ylab='',xlab='Group1 minus group0 path coefficient (95% conditional MI interval)',pch=19,col='#276782',main=paste('CHARLS latent growth paths:',fam));axis(2,at=seq_len(nrow(d)),labels=gsub('_',' -> ',d$path),las=1);segments(d$lower,seq_len(nrow(d)),d$upper,seq_len(nrow(d)),col='#276782',lwd=2);abline(v=0,lty=2,col='gray50');mtext(paste('Z:',zlabel,'; N=',a$N,'; m=40; G1 income >8730. No latent X-by-Z interaction.'),side=3,cex=.7)}
 png(file.path(out,'RESOURCE_PATH_DIFFERENCES.png'),width=1600,height=900,res=170);draw();dev.off()
 pdf(file.path(out,'RESOURCE_PATH_DIFFERENCES.pdf'),width=9.4,height=5.3);draw();dev.off()
 cat('LATENT_INCOME_FULL_MI_POOLED',fam,'N',a$N,'m40\n');print(joints[c('test_set','F','df1','df2','p')])
})
