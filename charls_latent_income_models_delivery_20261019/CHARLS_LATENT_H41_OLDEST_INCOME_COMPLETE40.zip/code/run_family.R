# 四十份主MI全部可采用才合并；两个MI01父校准和第二起点单列，不充作MI成员。
local({
 ROOT<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_income_models_20261019'
 PY<-'C:/Users/LZHS/AppData/Local/Programs/Python/Python314/python.exe'
 stopifnot(exists('FAMILY',inherits=TRUE));fam<-get('FAMILY',inherits=TRUE);z<-strsplit(fam,'_',fixed=TRUE)[[1]][1]
 stopifnot(fam==paste0(z,'_INCOME'),z%in%c('sd','gender','oldest','son'))
 Sys.setenv(OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1,MKL_NUM_THREADS=1)
 .libPaths(c('C:/Users/LZHS/pp_lgcm_runs/20260908/library_mplusautomation_20260926','C:/Users/LZHS/pp_lgcm_review/charls_income_mi_pilot_20261016/library','C:/Users/LZHS/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
 library(jsonlite);library(MplusAutomation);library(processx);library(ps);library(digest)
 rj<-function(p)fromJSON(p,simplifyVector=FALSE);wj<-function(x,p)write_json(x,p,auto_unbox=TRUE,pretty=TRUE,digits=NA,null='null')
 progress<-function(stage,message){cat(format(Sys.time(),tz='UTC'),stage,message,'\n');flush.console();clauder_progress(stage,message);wj(list(stage=stage,message=message,at=format(Sys.time(),tz='UTC')),file.path(ROOT,'runtime',paste0(fam,'_PROGRESS.json')))}
 source(file.path(ROOT,'code/model_service_client.R'),local=TRUE)
 main<-function(){
  on.exit(helper_close(),add=TRUE)
  lock<-file.path(ROOT,'runtime',paste0(fam,'_RESERVED.json'));stopifnot(!file.exists(lock))
  created<-as.numeric(ps_create_time(ps_handle()));wj(list(pid=Sys.getpid(),created=created,created_exact=sprintf('%.17g',created),family=fam,package_version=as.character(getNamespaceVersion('MplusAutomation'))),lock)
  c<-rj(file.path(ROOT,'contracts/RUN_CONTRACT.json'));ad<-rj(file.path(c$mi_root,'mi',z,'audit/MI_ADMISSION.json'));stopifnot(ad$status=='ADMITTED_WORKING_MI',ad$m==40)
  stopifnot(rj(file.path(c$mi_root,'mi',z,'audit/INDEPENDENT_MI.json'))$status=='PASS')
  dest<-file.path(ROOT,'results',fam);dir.create(dest,showWarnings=FALSE);calls<-list()
  run<-function(kind,k=1L,st='A'){
   id<-sprintf('CHARLS_%s_LATENT_INCOME_%s_MI%02d_%s',toupper(z),kind,k,st);d<-file.path(ROOT,'models',id)
   if(file.exists(file.path(d,'receipt.json'))){
    rec<-rj(file.path(d,'receipt.json'));j<-rj(file.path(d,'job.json'));stopifnot(rec$status=='USABLE',rec$output_sha256==digest(file=file.path(d,'model.out'),algo='sha256'))
    for(n in names(j$hashes))stopifnot(digest(file=file.path(d,n),algo='sha256')==j$hashes[[n]])
    calls[[id]]<<-rec;progress('INCOME_MI_REUSED',id);return(rec)
   }
   stopifnot(!file.exists(file.path(d,'engine_receipt.json')))
   if(!file.exists(file.path(d,'job.json')))helper_call('models.py',c('prepare',z,kind,as.character(k),st),file.path(ROOT,'runtime',paste0(id,'_prepare.log')))
   # 家族内复用已加载的数值助手；其驻留内存计入每次引擎实时准入。
   # 家族终止或进入合并阶段才关闭，避免每个成员重复加载NumPy/SciPy。
   gc(FALSE)
   cmd<-file.path(d,'launch.cmd');writeLines(c('@echo off',paste0('"',PY,'" -X utf8 "',ROOT,'/code/adapter.py" "%~dp0job.json" "%~1"'),'exit /b %ERRORLEVEL%'),cmd)
   warnings<-character();error<-NULL;progress('INCOME_MI_ESTIMATING',id)
   withCallingHandlers(tryCatch(MplusAutomation::runModels(file.path(d,'model.inp'),recursive=FALSE,showOutput=TRUE,replaceOutfile='never',Mplus_command=cmd,killOnFail=FALSE,logFile=file.path(d,'MplusAutomation.log')),error=function(e)error<<-conditionMessage(e)),warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')})
   wj(list(warnings=warnings,error=error),file.path(d,'R_WRAPPER_RETURN.json'));stopifnot(file.exists(file.path(d,'engine_receipt.json')))
   helper_call('models.py',c('normalize',d),file.path(ROOT,'runtime',paste0(id,'_normalize.log')))
   rec<-rj(file.path(d,'receipt.json'));calls[[id]]<<-rec;wj(calls,file.path(dest,'CALL_RESULTS.json'));progress('INCOME_MI_MEMBER_TERMINAL',paste(id,rec$status));rec
  }
  estimate<-function(){
   a<-run('ORDINARY');if(a$status!='USABLE')return(paste0('ORDINARY_',a$status))
   b<-run('PARENT');if(b$status!='USABLE')return(paste0('PARENT_',b$status))
   helper_call('models.py',c('calibrate',z),file.path(ROOT,'runtime',paste0(z,'_calibrate.log')))
   if(!isTRUE(rj(file.path(ROOT,'results',paste0(z,'_CALIBRATION.json')))$passed))return('PARENT_CALIBRATION_FAILED')
   a<-run('INCOME');if(a$status!='USABLE')return(paste0('MI01_A_',a$status))
   b<-run('INCOME',1L,'B');if(b$status!='USABLE')return(paste0('MI01_B_',b$status))
   cmp<-file.path(ROOT,'results',paste0(fam,'_MI01_START_COMPARISON.json'))
   helper_call('models.py',c('agree',a$dest,b$dest,cmp),file.path(ROOT,'runtime',paste0(fam,'_agree.log')))
   if(!isTRUE(rj(cmp)$passed))return('MI01_START_CHECK_FAILED')
   for(k in 2:40){rec<-run('INCOME',k);if(rec$status!='USABLE')return(paste0('MI',sprintf('%02d',k),'_',rec$status))}
   'FORTY_USABLE_PENDING_POOLING'
  }
  failure<-NULL;state<-tryCatch(estimate(),error=function(e){failure<<-conditionMessage(e);'DRIVER_ERROR_PRESERVED'})
  usable<-sum(vapply(calls,function(x)x$status=='USABLE'&&x$group=='INCOME'&&x$start=='A',TRUE))
  wj(list(status=state,error=failure,family=fam,usable_members=usable,expected_members=40,actual_engine_calls=sum(vapply(calls,function(x)x$engine$actual_engine_calls,numeric(1))),N=ad$N,communities=ad$communities,complete_inference=FALSE,original_four_complete=FALSE,full_H4_complete=FALSE),file.path(dest,'FAMILY_STATUS.json'))
  if(state=='FORTY_USABLE_PENDING_POOLING'){
   helper_close();helper_state$p<-NULL;progress('INCOME_MI_POOLING',fam)
   source(file.path(ROOT,'code/pool_family.R'),local=TRUE)
   p<-processx::run(PY,c('-X','utf8',file.path(ROOT,'code/update_joint.py')),timeout=60,error_on_status=TRUE,stdout=file.path(dest,'JOINT_UPDATE.log'),stderr='2>&1')
   progress('INCOME_MI_INDEPENDENT_READBACK',fam)
   p<-processx::run(PY,c('-X','utf8',file.path(ROOT,'code/run_readback_awake.py'),fam),timeout=Inf,error_on_status=TRUE,stdout=file.path(dest,'INDEPENDENT_READBACK.log'),stderr='2>&1')
   stopifnot(rj(file.path(dest,'INDEPENDENT_VERIFICATION.json'))$status=='PASS')
  }
  progress('INCOME_MI_FAMILY_TERMINAL',paste(fam,state,'usable',usable,'of40'));cat('INCOME_MI_FAMILY_DONE\n')
 }
 main()
})
