# 完整核心队列；仅ADL缺失。缓存同一条件拟合，每份重抽参数与供体。
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_mean_resources_20261018'
Sys.setenv(OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1,MKL_NUM_THREADS=1)
.libPaths(c('<LOCAL_USER>/pp_lgcm_review/charls_income_mi_pilot_20261016/library','<LOCAL_USER>/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
library(mice);library(miceadds);library(lme4);library(jsonlite);library(digest)
stopifnot(packageVersion('mice')=='3.19.10')
progress<-function(stage,message){cat(stage,message,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(stage,message)}
stopifnot(!file.exists(file.path(ROOT,'audit/MI_ADMISSION.json')))
P<-'<LOCAL_USER>/pp_lgcm_review/charls_adjusted_h41_20261015'
contract<-fromJSON(file.path(ROOT,'contracts/RUN_CONTRACT.json'))
source_hashes<-fromJSON(file.path(ROOT,'audit/SOURCE_HASHES.json'))
for(p in names(source_hashes))stopifnot(identical(digest(file=p,algo='sha256'),source_hashes[[p]]))
z<-readRDS(file.path(ROOT,'private/SOURCE_INPUTS.rds'));cc<-z$controls_and_auxiliaries
stopifnot(nrow(cc)==2983L,sum(is.na(cc$adl))==19L,identical(names(which(colSums(is.na(cc))>0)),'adl'))
aux<-names(cc)[grepl('^obs_|^missing_',names(cc))]
for(g in c('edu','urban'))for(v in aux)cc[[paste0(g,'_',v)]]<-cc[[g]]*cc[[v]]
method<-make.method(cc);method[]<-'';method['adl']<-'2l.pmm.cached'
pm<-matrix(0,ncol(cc),ncol(cc),dimnames=list(names(cc),names(cc)));pm['adl',setdiff(names(cc),c('adl','cluster'))]<-1;pm['adl','cluster']<--2
saveRDS(list(data=cc,methods=method,predictors=pm,source=source_hashes),file.path(ROOT,'private/MI_INPUTS.rds'))
source(file.path(ROOT,'code/mi_exact_fit_cache.R'),local=TRUE)
warnings<-character();progress('MI_conditional_draws','20 independent draws of the only incomplete covariate; observed resource products included')
imp<-withCallingHandlers(mice(cc,m=contract$m,maxit=1,method=method,predictorMatrix=pm,seed=contract$mi_seed,donors=5,printFlag=FALSE,remove.collinear=TRUE),warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')})
saveRDS(imp,file.path(ROOT,'private/MIDS.rds'));saveRDS(.Random.seed,file.path(ROOT,'private/RNG_FINAL.rds'))
fit<-readRDS(file.path(ROOT,'private/MI_ADL_CONDITIONAL_LMER.rds'))
fit_ok<-is.null(fit@optinfo$conv$lme4$messages)&&fit@optinfo$conv$opt==0
write.csv(data.frame(variable=rownames(imp$predictorMatrix),imp$predictorMatrix,check.names=FALSE),file.path(ROOT,'audit/PREDICTORS_ACTUAL.csv'),row.names=FALSE)
if(!is.null(imp$loggedEvents))write.csv(imp$loggedEvents,file.path(ROOT,'audit/LOGGED_EVENTS.csv'),row.names=FALSE)
writeLines(warnings,file.path(ROOT,'audit/MI_WARNINGS.txt'))
members<-list();summ<-list();original<-z$analysis_with_original_ADL_mask[,c('cluster',paste0('x',1:5),paste0('y',1:5),paste0('c',1:11))]
observed<-!is.na(cc$adl);stopifnot(nrow(original)==nrow(cc),identical(as.numeric(original$c7[observed]),as.numeric(cc$adl[observed])))
for(k in seq_len(contract$m)){
 v<-complete(imp,k);stopifnot(identical(v$adl[observed],cc$adl[observed]),all(v$adl%in%0:6),all(v$adl[!observed]%in%cc$adl[observed]))
 for(n in setdiff(names(v),'adl'))stopifnot(identical(v[[n]],cc[[n]]))
 d<-original;d$c7<-v$adl;stopifnot(identical(d[setdiff(names(d),'c7')],original[setdiff(names(original),'c7')]))
 f<-file.path(ROOT,'private',sprintf('MI%02d.dat',k));write.table(d,f,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
 members[[k]]<-data.frame(member=k,N=nrow(d),source_observed_preserved=TRUE,XY_masks_preserved=TRUE,sha256=digest(file=f,algo='sha256'))
 summ[[k]]<-data.frame(member=k,imputed_ADL_mean=mean(v$adl[!observed]),imputed_ADL_min=min(v$adl[!observed]),imputed_ADL_max=max(v$adl[!observed]))
}
write.csv(do.call(rbind,members),file.path(ROOT,'audit/MI_MEMBERS.csv'),row.names=FALSE);write.csv(do.call(rbind,summ),file.path(ROOT,'results/MI_SUMMARY.csv'),row.names=FALSE)
products<-grep('^(edu|urban)_(obs|missing)_',names(cc),value=TRUE);retained<-products[imp$predictorMatrix['adl',products]!=0]
passed<-isTRUE(fit_ok)&&cache_env$misses==1&&cache_env$hits==19&&all(vapply(c('edu','urban'),function(g)any(startsWith(retained,paste0(g,'_'))),TRUE))&&imp$predictorMatrix['adl','cluster']==-2
rec<-list(status=if(passed)'ADMITTED_WORKING_MI'else'NOT_ADMITTED',N=nrow(cc),communities=length(unique(cc$cluster)),m=imp$m,iterations=imp$iteration,single_incomplete_target='adl',missing=sum(!observed),fit_ok=fit_ok,fit_singular=isSingular(fit),conditional_fit_cache_misses=cache_env$misses,fresh_draws=cache_env$misses+cache_env$hits,retained_resource_products=retained,dropped_resource_products=setdiff(products,retained),logged_events=imp$loggedEvents,warnings=warnings,compatibility=contract$mi_boundary)
write_json(rec,file.path(ROOT,'audit/MI_ADMISSION.json'),auto_unbox=TRUE,pretty=TRUE,digits=16,na='null')
for(p in names(source_hashes))stopifnot(identical(digest(file=p,algo='sha256'),source_hashes[[p]]))
writeLines(capture.output(sessionInfo()),file.path(ROOT,'audit/MI_R_SESSION_INFO.txt'))
progress('CHARLS_MEAN_MI_TERMINAL',rec$status);cat('CHARLS_MEAN_MI_TERMINAL\n')
