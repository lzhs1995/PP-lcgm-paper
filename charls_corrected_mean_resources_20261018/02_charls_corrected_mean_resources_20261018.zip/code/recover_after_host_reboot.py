"""保全重启证据并重建本任务RStudio界面；不提交估计、不动其他任务。"""
from pathlib import Path
import datetime,hashlib,json,psutil
R=Path(__file__).resolve().parents[1];old=R.parent/'charls_h42_mi_20261017/verification'
assert not psutil.pid_exists(11644) and not psutil.pid_exists(29300)
record={'boot_utc':datetime.datetime.fromtimestamp(psutil.boot_time(),datetime.timezone.utc).isoformat(),'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'lost_native_job':'9c779345','old_main_pid':11644,'old_owner_pid':29300,'old_identities_alive':False,'completed_receipts':[],'unstarted':[]}
for d in sorted((R/'models').iterdir()):
 j=json.loads((d/'job.json').read_text());assert all(hashlib.sha256((d/n).read_bytes()).hexdigest()==h for n,h in j['hashes'].items())
 if (d/'receipt.json').exists():
  v=json.loads((d/'receipt.json').read_text());assert v['status']=='USABLE';assert hashlib.sha256((d/'model.out').read_bytes()).hexdigest()==v['output_sha256'];record['completed_receipts'].append(d.name)
 else:
  assert not (d/'model.out').exists() and not (d/'engine_receipt.json').exists();record['unstarted'].append(d.name)
assert len(record['completed_receipts'])==8 and record['unstarted']==['CHARLS_MEAN_EDU_MI07_A']
(R/'audit/HOST_REBOOT_RECOVERY.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
for name in ['launch_recovery_rstudio.py','activate_recovery_addin.py']:
 s=(old/name).read_text(encoding='utf-8').replace('charls_h42_mi_20261017',R.name).replace('pp_lgcm_h42','pp_lgcm_corrected')
 if name.startswith('launch'):s=s.replace("cwd=P)","cwd=P,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)")
 (R/'code'/name).write_text(s,encoding='utf-8')
exec(compile((R/'code/launch_recovery_rstudio.py').read_text(encoding='utf-8'),str(R/'code/launch_recovery_rstudio.py'),'exec'),{'__file__':str(R/'code/launch_recovery_rstudio.py'),'__name__':'__main__'})
