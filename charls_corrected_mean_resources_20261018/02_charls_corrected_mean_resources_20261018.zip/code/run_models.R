# 修正来源的EDU/URBAN完整20家族；父模型、双起点和逐成员合法性门。
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_mean_resources_20261018'
.libPaths(c('<LOCAL_USER>/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
library(jsonlite);library(processx);library(ps);library(digest)
PY<-'<LOCAL_USER>/AppData/Local/Programs/Python/Python314/python.exe'
rj<-function(p)if(file.exists(p))fromJSON(p,simplifyVector=FALSE)else NULL
wj<-function(x,p)write_json(x,p,auto_unbox=TRUE,pretty=TRUE,digits=16)
progress<-function(s,m){cat(s,m,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(s,m)}
source(file.path(ROOT,'code/model_service_client.R'),local=TRUE);py<-helper_call
run_one<-function(g,k,st){
 id<-sprintf('CHARLS_MEAN_%s_MI%02d_%s',g,k,st);if(g=='URBAN'&&k==5L&&st=='A')id<-paste0(id,'_R1');d<-file.path(ROOT,'models',id)
 if(file.exists(file.path(d,'receipt.json'))){rr<-rj(file.path(d,'receipt.json'));j<-rj(file.path(d,'job.json'));stopifnot(rr$output_sha256==digest(file=file.path(d,'model.out'),algo='sha256'));for(n in names(j$hashes))stopifnot(j$hashes[[n]]==digest(file=file.path(d,n),algo='sha256'));progress('reuse_adjudicated',id);return(rr)}
 if(!file.exists(file.path(d,'job.json')))py('models.py',c('prepare',g,as.character(k),st),file.path(ROOT,'audit',paste0(id,'_prepare.log')))
 else{j<-rj(file.path(d,'job.json'));stopifnot(!file.exists(file.path(d,'model.out')),!file.exists(file.path(d,'engine_receipt.json')));for(n in names(j$hashes))stopifnot(j$hashes[[n]]==digest(file=file.path(d,n),algo='sha256'))}
 j<-rj(file.path(d,'job.json'));j$rscript<-file.path(R.home('bin'),'Rscript.exe');wj(j,file.path(d,'job.json'))
 p<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/model_engine.py'),file.path(d,'job.json')),stdout=file.path(d,'supervisor.log'),stderr='2>&1',cleanup=FALSE);last<-0
 while(p$is_alive()){p$wait(1000L);if(as.numeric(Sys.time())-last>25){h<-rj(file.path(ROOT,'runtime/progress.json'));progress('estimating',paste(id,h$stage));last<-as.numeric(Sys.time())}}
 if(!file.exists(file.path(d,'engine_receipt.json')))return(list(id=id,dest=d,group=g,member=k,start=st,status='NOT_STARTED',not_run=rj(file.path(d,'not_run.json'))))
 py('models.py',c('normalize',d),file.path(d,'readback.log'));rr<-rj(file.path(d,'receipt.json'));progress('adjudicated',paste(id,rr$status));rr
}
main<-function(){
 on.exit(helper_close(),add=TRUE)
 stopifnot(file.exists(file.path(ROOT,'contracts/RUNTIME_RECOVERY.json')),rj(file.path(ROOT,'audit/INDEPENDENT_MI.json'))$status=='PASS')
 tag<-if(exists('MODEL_RUN_ID'))MODEL_RUN_ID else 'FIRST'
 op<-file.path(ROOT,'runtime',paste0('MODEL_OWNER_',tag,'.json'))
 wj(list(owner=list(pid=Sys.getpid(),created=as.numeric(ps::ps_create_time(ps::ps_handle())))),op)
 awpath<-file.path(ROOT,'runtime',paste0('awake_',tag));stopifnot(!dir.exists(awpath))
 awake<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/windows_awake_guard.py'),'--owner-file',op,'--output',awpath,'--interval','5'),stdout=file.path(ROOT,'runtime',paste0('awake_',tag,'.log')),stderr='2>&1',cleanup=FALSE)
 on.exit({if(dir.exists(awpath))writeLines('release',file.path(awpath,'stop.request'));awake$wait(8000L)},add=TRUE)
 for(i in 1:50){if(file.exists(file.path(awpath,'identity.json')))break;stopifnot(awake$is_alive());awake$wait(100L)}
 stopifnot(awake$is_alive(),file.exists(file.path(awpath,'identity.json')))
 attempts<-rj(file.path(ROOT,'results/ATTEMPTS.json'));if(is.null(attempts))attempts<-list()
 save_attempt<-function(rr){attempts[[rr$id]]<<-rr;wj(attempts,file.path(ROOT,'results/ATTEMPTS.json'));if(rr$status=='NOT_STARTED')stop('Resource hold, no statistical failure: ',rr$id)}
 parent<-run_one('PARENT',1,'A');save_attempt(parent)
 families<-list()
 for(g in c('EDU','URBAN')){
  f<-list(group=g,status='STARTING',complete_MI=FALSE,usable_members=0L,planned_members=20L)
  if(parent$status!='USABLE'){f$status<-'PARENT_INADMISSIBLE';families[[g]]<-f;next}
  a<-run_one(g,1,'A');save_attempt(a)
  if(a$status!='USABLE'){f$status<-'FIRST_MEMBER_INADMISSIBLE';families[[g]]<-f;next}
  b<-run_one(g,1,'B');save_attempt(b)
  if(b$status!='USABLE'){f$status<-'SECOND_START_INADMISSIBLE';families[[g]]<-f;next}
  agree<-file.path(ROOT,'results',paste0(g,'_START_AGREEMENT.json'))
  py('models.py',c('agree',a$dest,b$dest,agree),file.path(ROOT,'audit',paste0(g,'_agreement.log')))
  if(!isTRUE(rj(agree)$passed)){f$status<-'START_DISAGREEMENT';families[[g]]<-f;next}
  members<-list(a);f$usable_members<-1L;f$status<-'EXTENDING_MI'
  for(k in 2:20){rr<-run_one(g,k,'A');save_attempt(rr);if(rr$status!='USABLE'){f$status<-'MI_FAMILY_INCOMPLETE';f$failed_member<-k;break};members[[k]]<-rr;f$usable_members<-k;families[[g]]<-f;wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'))}
  f$complete_MI<-f$usable_members==20L;if(f$complete_MI)f$status<-'COMPLETE_CONDITIONAL_WORKING_MI'
  f$member_paths<-vapply(members,function(x)x$dest,'');families[[g]]<-f;wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'))
 }
 wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'));source(file.path(ROOT,'code/pool_results.R'),local=TRUE)
 wj(list(status='CORRECTED_EDU_URBAN_ADJUDICATED',families=families,budget=rj(file.path(ROOT,'runtime/budget_status.json')),original_four_complete=FALSE,full_H4_complete=FALSE),file.path(ROOT,'audit/BATCH_TERMINAL.json'))
 progress('CORRECTED_RESOURCES_MODELS_DONE','Both registered families adjudicated');cat('CORRECTED_RESOURCES_MODELS_DONE\n')
}
main()
