# 全部20份合法成员才合并；组间差异使用完整协方差。
local({
library(jsonlite);library(mitml)
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_mean_resources_20261018'
fs<-fromJSON(file.path(ROOT,'results/FAMILY_STATUS.json'),simplifyVector=FALSE)
stopifnot(length(fs)==2L)
labs<-c('bii','bis','bss','bsyiy','dii','dis','dss');all_paths<-list();all_joint<-list();all_contrasts<-list()
pool<-function(Q,U){
 m<-nrow(Q);q<-colMeans(Q);W<-Reduce('+',U)/m;B<-cov(Q);T<-W+(1+1/m)*B;se<-sqrt(diag(T));r<-(1+1/m)*diag(B)/diag(W);df<-ifelse(r>0,(m-1)*(1+1/r)^2,Inf)
 data.frame(estimate=q,se=se,df=df,lower=q-qt(.975,df)*se,upper=q+qt(.975,df)*se,p=2*pt(-abs(q/se),df),RIV=r,lambda=r/(1+r),FMI=(r+2/(df+3))/(1+r),row.names=NULL)
}
for(g in names(fs)){
 f<-fs[[g]];if(!isTRUE(f$complete_MI))next
 dirs<-unlist(f$member_paths);stopifnot(length(dirs)==20L)
 Q<-matrix(NA_real_,20,7,dimnames=list(NULL,labs));U<-list()
 for(k in 1:20){
  rr<-fromJSON(file.path(dirs[k],'receipt.json'));stopifnot(rr$status=='USABLE',rr$member==k)
  p<-read.csv(file.path(dirs[k],'key_paths.csv'));p<-p[match(labs,p$label),];V<-as.matrix(read.csv(file.path(dirs[k],'parameter_covariance.csv'),header=FALSE));Q[k,]<-p$estimate;U[[k]]<-V[p$parameter,p$parameter];dimnames(U[[k]])<-list(labs,labs)
 }
 all_paths[[g]]<-data.frame(group=g,label=labs,pool(Q,U))
 d1<-mitml::testConstraints(qhat=lapply(1:20,function(k)setNames(Q[k,],labs)),uhat=U,constraints=c('dii','dis','dss'),method='D1')
 all_joint[[g]]<-data.frame(group=g,F=d1$test[1,1],df1=d1$test[1,2],df2=d1$test[1,3],p=d1$test[1,4],RIV=d1$test[1,5])
 cs<-list(IY_IX_G0=c(bii=1),IY_IX_G1=c(bii=1,dii=1),IY_IX_difference=c(dii=1),SY_IX_G0=c(bis=1),SY_IX_G1=c(bis=1,dis=1),SY_IX_difference=c(dis=1),SY_SX_G0=c(bss=1),SY_SX_G1=c(bss=1,dss=1),SY_SX_difference=c(dss=1))
 all_contrasts[[g]]<-do.call(rbind,lapply(names(cs),function(n){a<-setNames(rep(0,7),labs);a[names(cs[[n]])]<-cs[[n]];U1<-lapply(U,function(v)matrix(drop(t(a)%*%v%*%a),1,1));data.frame(group=g,contrast=n,pool(matrix(Q%*%a,ncol=1),U1))}))
 dest<-file.path(ROOT,'results',g);dir.create(dest,showWarnings=FALSE)
 write.csv(data.frame(member=1:20,Q),file.path(dest,'MEMBER_ESTIMATES.csv'),row.names=FALSE)
 write.csv(do.call(rbind,lapply(1:20,function(k)data.frame(member=k,expand.grid(row=labs,column=labs,stringsAsFactors=FALSE),covariance=as.vector(U[[k]])))),file.path(dest,'MEMBER_COVARIANCES.csv'),row.names=FALSE)
}
if(length(all_joint)){
 j<-do.call(rbind,all_joint) # 三项校正待修正收入结果独立核验后统一生成
 write.csv(j,file.path(ROOT,'results/JOINT_D1.csv'),row.names=FALSE);write.csv(do.call(rbind,all_paths),file.path(ROOT,'results/POOLED_PATHS.csv'),row.names=FALSE);write.csv(do.call(rbind,all_contrasts),file.path(ROOT,'results/GROUP_CONTRASTS.csv'),row.names=FALSE)
}
write_json(list(status='CHARLS_MEAN_POOLING_ADJUDICATED',registered=2,complete=length(all_joint),failed_groups=setdiff(names(fs),names(all_joint)),conditional_working_MI=TRUE,original_four_complete=FALSE,full_H4_complete=FALSE),file.path(ROOT,'results/POOLING_RECEIPT.json'),auto_unbox=TRUE,pretty=TRUE)
cat('CHARLS_MEAN_POOLING_DONE complete',length(all_joint),'of2\n')
})
