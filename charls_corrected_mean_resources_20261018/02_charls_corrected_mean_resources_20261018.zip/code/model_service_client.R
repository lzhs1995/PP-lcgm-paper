# processx::run 超时单位是秒；process$wait/poll_io 单位是毫秒。
# helper 只执行原有模型编译和读回，不启动Mplus或改变统计计算。
helper_state<-new.env(parent=emptyenv());helper_state$p<-NULL;helper_state$id<-0L
helper_wait<-function(kind,id=NULL) {
 start<-Sys.time();last<-0
 repeat {
  p<-helper_state$p;p$poll_io(1000L)
  lines<-p$read_output_lines()
  for(line in lines){j<-jsonlite::fromJSON(line,simplifyVector=FALSE);if(identical(j$kind,kind)&&(is.null(id)||identical(j$id,id)))return(j)}
  if(!p$is_alive())stop('Persistent model helper exited: ',p$get_exit_status())
  elapsed<-as.numeric(difftime(Sys.time(),start,units='secs'))
  if(elapsed>600)stop('Persistent helper operation exceeded 600 seconds')
  if(elapsed-last>25){progress('model_helper',paste(kind,'elapsed',round(elapsed),'seconds'));last<-elapsed}
 }
}
helper_start<-function(){
 if(!is.null(helper_state$p)){stopifnot(helper_state$p$is_alive());return(invisible(NULL))}
 helper_state$p<-processx::process$new(PY,c('-u','-X','utf8',file.path(ROOT,'code/model_service.py')),stdin='|',stdout='|',stderr=file.path(ROOT,'runtime',paste0('model_helper_',Sys.getpid(),'.log')),cleanup=TRUE)
 rec<-helper_wait('ready');stopifnot(normalizePath(rec$root,winslash='/')==normalizePath(ROOT,winslash='/'))
 jsonlite::write_json(rec,file.path(ROOT,'audit',paste0('MODEL_HELPER_',Sys.getpid(),'.json')),auto_unbox=TRUE,pretty=TRUE)
}
helper_call<-function(script,args,log){
 stopifnot(identical(script,'models.py'));helper_start();helper_state$id<-helper_state$id+1L
 progress('model_helper',paste(args,collapse=' '))
 helper_state$p$write_input(paste0(jsonlite::toJSON(list(id=jsonlite::unbox(helper_state$id),args=unname(args)),auto_unbox=FALSE),'\n'))
 rec<-helper_wait('result',helper_state$id)
 writeLines(c(rec$stdout,if(!is.null(rec$stderr))rec$stderr else ''),log)
 if(rec$status!=0)stop('Model helper failed: ',log)
 rec
}
helper_close<-function(){
 if(!is.null(helper_state$p)&&helper_state$p$is_alive()){
  helper_state$p$write_input('{"id":0,"args":["shutdown"]}\n');helper_state$p$wait(5000L)
  if(helper_state$p$is_alive())helper_state$p$kill()
 }
 invisible(NULL)
}
