# 只整合三个已独立验收的修正来源家族；不混用历史输入结果。
local({
 R<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_mean_resources_20261018';N<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_h41_20261018'
 library(jsonlite);library(digest)
 for(root in c(N,R))stopifnot(fromJSON(file.path(root,'audit/INDEPENDENT_RESULTS.json'))$status=='PASS')
 j<-rbind(read.csv(file.path(N,'results/JOINT_D1.csv')),read.csv(file.path(R,'results/JOINT_D1.csv')))
 stopifnot(nrow(j)==3L,setequal(j$group,c('INCOME','EDU','URBAN')));j$holm_planned3<-p.adjust(j$p,method='holm',n=3)
 write.csv(j,file.path(R,'results/CORRECTED_THREE_RESOURCE_JOINT_D1.csv'),row.names=FALSE)
 v<-rbind(read.csv(file.path(N,'results/GROUP_CONTRASTS.csv')),read.csv(file.path(R,'results/GROUP_CONTRASTS.csv')))
 v<-v[grepl('_difference$',v$contrast),];v$imputations<-ifelse(v$group=='INCOME',40L,20L);stopifnot(nrow(v)==9L)
 write.csv(v,file.path(R,'results/CORRECTED_THREE_RESOURCE_PLOT_DATA.csv'),row.names=FALSE)
 draw<-function(){
  par(mar=c(6.5,12,4,2));keys<-c('IY_IX_difference','SY_IX_difference','SY_SX_difference');z<-v[order(match(v$contrast,keys),match(v$group,c('EDU','URBAN','INCOME'))),];y<-rev(seq_len(nrow(z)));rng<-range(c(0,z$lower,z$upper));pad<-max(.05,diff(rng)*.08);col<-c(EDU='#135e83',URBAN='#b46016',INCOME='#58752a')[z$group]
  plot(z$estimate,y,xlim=rng+c(-pad,pad),ylim=c(.5,length(y)+.5),yaxt='n',ylab='',xlab='Higher-resource minus lower-resource path coefficient (95% conditional MI CI)',pch=19,col=col,main='CHARLS corrected contact source: H4.1 resource differences')
  abline(v=0,lty=2,col='grey60');segments(z$lower,y,z$upper,y,col=col,lwd=2);axis(2,at=y,labels=paste(sub('_difference$','',z$contrast),z$group,sep=' | '),las=1,cex.axis=.82)
  mtext('N = 2,983; 440 communities. EDU/URBAN: 20 imputations; INCOME: 40. Working MI; not full H4.',side=1,line=5,cex=.72)
 }
 png(file.path(R,'reports/CORRECTED_RESOURCE_DIFFERENCES.png'),width=1650,height=1050,res=150);draw();dev.off()
 pdf(file.path(R,'reports/CORRECTED_RESOURCE_DIFFERENCES.pdf'),width=11,height=7);draw();dev.off()
 bindings<-setNames(lapply(c(N,R),function(root)digest(file=file.path(root,'results/JOINT_D1.csv'),algo='sha256')),c('corrected_income','corrected_education_urban'))
 write_json(list(status='PASS',complete_registered_mean_resource_families=3,source_sha256=fromJSON(file.path(R,'contracts/RUN_CONTRACT.json'))$corrected_source_sha256,source_result_hashes=bindings,old_input_pvalues_reused=FALSE,original_four_complete=FALSE,full_H4_complete=FALSE),file.path(R,'audit/JOINT_SCOPE_RECEIPT.json'),auto_unbox=TRUE,pretty=TRUE)
 print(j);cat('CORRECTED_THREE_RESOURCE_SUMMARY_DONE\n')
})
