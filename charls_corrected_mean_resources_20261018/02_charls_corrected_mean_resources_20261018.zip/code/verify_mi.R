# 复用已独立核验的新来源，逐份核对20个ADL条件插补及实际DAT。
local({
 R<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_mean_resources_20261018';N<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_h41_20261018'
 .libPaths(c('<LOCAL_USER>/pp_lgcm_review/charls_income_mi_pilot_20261016/library',.libPaths()))
 library(mice);library(jsonlite);library(digest)
 stopifnot(fromJSON(file.path(N,'audit/INDEPENDENT_MI.json'))$status=='PASS',digest(file=file.path(R,'private/SOURCE_INPUTS.rds'),algo='sha256')==digest(file=file.path(N,'private/SOURCE_INPUTS.rds'),algo='sha256'))
 src<-readRDS(file.path(R,'private/SOURCE_INPUTS.rds'));imp<-readRDS(file.path(R,'private/MIDS.rds'));ad<-fromJSON(file.path(R,'audit/MI_ADMISSION.json'));stopifnot(ad$status=='ADMITTED_WORKING_MI',imp$m==20,imp$iteration==1,ad$fresh_draws==20)
 cols<-c('cluster',paste0('x',1:5),paste0('y',1:5),paste0('c',1:11));base<-src$analysis_with_original_ADL_mask[,cols];obs<-!is.na(src$controls_and_auxiliaries$adl);checks<-list()
 for(k in 1:20){
  v<-complete(imp,k);stopifnot(identical(v$adl[obs],src$controls_and_auxiliaries$adl[obs]),all(v$adl[!obs]%in%v$adl[obs]),!anyNA(v))
  for(n in setdiff(names(v),'adl'))stopifnot(identical(v[[n]],imp$data[[n]]))
  expected<-as.matrix(base);expected[,'c7']<-v$adl;p<-file.path(R,'private',sprintf('MI%02d.dat',k));got<-as.matrix(read.table(p,na.strings='-9999'))
  stopifnot(identical(dim(got),dim(expected)),identical(unname(is.na(got)),unname(is.na(expected))))
  delta<-max(abs(got-expected),na.rm=TRUE);stopifnot(delta<1e-10)
  checks[[k]]<-data.frame(member=k,N=nrow(got),communities=length(unique(got[,1])),maximum_difference=delta,observed_preserved=TRUE,donor_support_preserved=TRUE,resource_products_preserved=TRUE,sha256=digest(file=p,algo='sha256'))
 }
 tab<-do.call(rbind,checks);write.csv(tab,file.path(R,'audit/INDEPENDENT_MI_MEMBERS.csv'),row.names=FALSE)
 for(p in names(src$source_hashes))stopifnot(digest(file=p,algo='sha256')==src$source_hashes[[p]])
 write_json(list(status='PASS',m=20,N=nrow(base),communities=length(unique(base$cluster)),missing_ADL=sum(!obs),only_missing_target='ADL',maximum_export_difference=max(tab$maximum_difference),old_completed_MI_reused=FALSE,source_reused_from_independent_corrected_verification=TRUE,not_proof_of_MAR_or_exact_latent_compatibility=TRUE),file.path(R,'audit/INDEPENDENT_MI.json'),auto_unbox=TRUE,pretty=TRUE,digits=16)
 cat('CORRECTED_EDU_URBAN_MI_INDEPENDENT_PASS\n')
})
