"""验收已完成的修正来源家族；不把原生接口、模型与科学范围合并为一个声明。"""
from pathlib import Path
import contextlib,datetime,io,json,sys,psutil
R=Path(__file__).resolve().parents[1];N=R.parent/'charls_corrected_h41_20261018'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sys.path.insert(0,'<LOCAL_USER>/.codex/skills/clauder-rstudio-workbench')
from clauder_workbench.cli import main
for root,tags,awake in [(N,['models_full','verification_replay'],'awake_FULL'),(R,['models_runtime_recovery','postprocess'],'awake_RUNTIME_RECOVERY')]:
 verify=read(root/'audit/INDEPENDENT_RESULTS.json');assert verify['status']=='PASS' and read(root/'audit/INDEPENDENT_MI.json')['status']=='PASS'
 for tag in tags:assert read(root/'audit'/('GUARD_'+tag+'_complete.json'))['decision']=='PASS'
 assert not (root/'runtime/engine.lock').exists()
 assert read(root/'runtime'/awake/'completion.json')['released']
 live=[]
 for p in list((root/'models').glob('*/process.json'))+list((root/'runtime').glob('MODEL_OWNER_*.json')):
  x=read(p);x=x.get('owner',x)
  if not isinstance(x,dict) or 'pid' not in x:continue
  try:
   proc=psutil.Process(x['pid'])
   if abs(proc.create_time()-x['created'])<.01:live.append(proc.pid)
  except psutil.NoSuchProcess:pass
 assert not live,live
 terminal={'status':'CORRECTED_REGISTERED_FAMILIES_ADJUDICATED','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'family':read(root/'results/FAMILY_STATUS.json'),'independent_results':verify,'MI':read(root/'audit/INDEPENDENT_MI.json'),'owned_model_processes_live':live,'original_four_complete':False,'full_H4_complete':False}
 (root/'audit/ACCEPTED_BATCH.json').write_text(json.dumps(terminal,indent=2),encoding='utf-8')
 b=io.StringIO()
 with contextlib.redirect_stdout(b):rc=main(['completion-check','--mode','formal','--require-file','terminal::'+str(root/'audit/ACCEPTED_BATCH.json')+',max_age_h=24','--require-file','validation::'+str(root/'audit/INDEPENDENT_RESULTS.json')+',max_age_h=24'])
 (root/'audit/COMPLETION_CHECK.json').write_text(b.getvalue(),encoding='utf-8');j=json.loads(b.getvalue());assert rc==0 and j['decision']=='PASS'
 print(json.dumps({'root':root.name,'decision':j['decision'],'calls':verify['calls']}),flush=True)
assert read(R/'audit/JOINT_SCOPE_RECEIPT.json')['complete_registered_mean_resource_families']==3
