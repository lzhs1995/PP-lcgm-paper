# 独立从核验过的逐波重建数据、基期控制和冻结尺度重建实际DAT期望值。
local({
  ROOT <- '<LOCAL_USER>/pp_lgcm_review/charls_corrected_h41_20261018'
  Q <- '<LOCAL_USER>/pp_lgcm_review/charls_latent_trajectory_readiness_20261018'
  P <- '<LOCAL_USER>/pp_lgcm_review/charls_adjusted_h41_20261015'
  .libPaths(c('<LOCAL_USER>/pp_lgcm_review/charls_income_mi_pilot_20261016/library',file.path(P,'library'),.libPaths()))
  library(mice);library(data.table);library(jsonlite);library(digest)
  rec <- fromJSON(file.path(ROOT,'audit/MI_ADMISSION.json'));stopifnot(rec$status=='ADMITTED_WORKING_MI')
  stopifnot(fromJSON(file.path(Q,'audit/INDEPENDENT_REBUILD_VERIFICATION.json'))$status=='PASS')
  z <- readRDS(file.path(P,'private/charls_core_mi_inputs.rds'))
  d <- readRDS(file.path(Q,'private/charls_cohort_roster_candidate.rds'))
  b <- readRDS('<LOCAL_USER>/pp_lgcm_review/charls_roster_moderation_20261015/private/CONSTRUCTED_BASELINE_CONTRASTS.rds')
  sc <- read.csv('<LOCAL_USER>/pp_lgcm_review/reopen_observed_charls_20261015/results/CHARLS_BASELINE_SCALING.csv')
  stopifnot(identical(as.character(z$raw$pid),as.character(d$pid)))
  keep <- b$legacy_keys_compatible & !is.na(d$x1) & !is.na(d$y1) & rowSums(!is.na(d[paste0('x',1:5)]))>=2 & rowSums(!is.na(d[paste0('y',1:5)]))>=2
  stopifnot(sum(keep)==rec$N,digest(file=rec$mids_path,algo='sha256')==rec$mids_sha256)
  imp <- readRDS(rec$mids_path);a <- readRDS(file.path(ROOT,'private/MI_INPUTS.rds'));src <- readRDS(file.path(ROOT,'private/SOURCE_INPUTS.rds'))
  stopifnot(identical(as.character(src$pid),as.character(d$pid[keep])),length(unique(d$pid[keep]))==sum(keep))
  cols <- c('cluster',paste0('x',1:5),paste0('y',1:5),paste0('c',1:11),'g')
  base <- as.data.frame(matrix(NA_real_,sum(keep),length(cols)));names(base)<-cols
  base$cluster <- z$data$cluster[keep]
  for(pair in list(c('x','X_contact_mean'),c('y','Y_CESD10'))){ii<-match(pair[2],sc$process);for(k in 1:5){nm<-paste0(pair[1],k);base[[nm]]<-(d[[nm]][keep]-sc$mean[ii])/sc$sd[ii]}}
  map<-c(c1='age',c2='female',c3='edu',c4='urban',c5='partner',c6='nchild',c7='adl',c8='health2',c9='health3',c10='health4',c11='health5')
  for(n in names(map))base[[n]]<-z$data[[map[[n]]]][keep]
  cut<-fromJSON(file.path(ROOT,'contracts/RUN_CONTRACT.json'))$threshold_CNY
  stopifnot(cut==median(z$raw$hh_income,na.rm=TRUE))
  inc<-z$raw$hh_income[keep];base$g<-ifelse(is.na(inc),NA_real_,as.numeric(inc>cut))
  same<-function(x,y){x<-as.matrix(x);y<-as.matrix(y);stopifnot(identical(dim(x),dim(y)),identical(unname(is.na(x)),unname(is.na(y))));e<-max(abs(x-y),na.rm=TRUE);stopifnot(e<1e-10);e}
  same(base,a$analysis[cols]);same(base$g,imp$data$g);same(base$c7,imp$data$adl)
  rd<-function(p){v<-fread(p,header=FALSE,data.table=FALSE,showProgress=FALSE);names(v)<-cols;for(n in cols)v[[n]][v[[n]]==-9999]<-NA_real_;v}
  og<-!is.na(base$g);oa<-!is.na(base$c7);checks<-list()
  for(k in 1:40){
    v<-complete(imp,k);expected<-base;expected$c7<-v$adl;expected$g<-v$g;p<-file.path(ROOT,'private',sprintf('MI%02d.dat',k));got<-rd(p);delta<-same(got,expected)
    stopifnot(identical(as.numeric(v$g[og]),base$g[og]),identical(as.numeric(v$adl[oa]),as.numeric(base$c7[oa])),all(v$g%in%0:1),all(v$adl[!oa]%in%base$c7[oa]))
    for(n in names(a$passive))stopifnot(max(abs(v[[n]]-v[[a$passive[[n]][1]]]*v[[a$passive[[n]][2]]]))<1e-12)
    checks[[k]]<-data.frame(member=k,N=nrow(got),communities=length(unique(got$cluster)),export_max_difference=delta,observed_income_group_unchanged=TRUE,observed_ADL_unchanged=TRUE,corrected_XY_and_controls=TRUE,all_passive_products=TRUE,sha256=digest(file=p,algo='sha256'))
  }
  cc<-base[og&oa,];same(cc,rd(file.path(ROOT,'private/CC.dat')))
  for(p in names(src$source_hashes))stopifnot(digest(file=p,algo='sha256')==src$source_hashes[[p]])
  tab<-do.call(rbind,checks);write.csv(tab,file.path(ROOT,'audit/INDEPENDENT_MI_MEMBERS.csv'),row.names=FALSE)
  ans<-list(status='PASS',m=nrow(tab),N=nrow(base),communities=length(unique(base$cluster)),threshold=cut,missing_income_group=sum(!og),missing_ADL=sum(!oa),both_missing=sum(!og&!oa),observed_low=sum(base$g==0,na.rm=TRUE),observed_high=sum(base$g==1,na.rm=TRUE),negative_raw_income=sum(inc<0,na.rm=TRUE),zero_raw_income=sum(inc==0,na.rm=TRUE),max_export_difference=max(tab$export_max_difference),CC_N=nrow(cc),original_sources_unchanged=TRUE,old_completed_MI_reused=FALSE,posterior_validity_or_MAR_not_proven=TRUE,new_engine_calls=0)
  write_json(ans,file.path(ROOT,'audit/INDEPENDENT_MI.json'),auto_unbox=TRUE,pretty=TRUE,digits=16);cat('INDEPENDENT_MI_PASS',toJSON(ans,auto_unbox=TRUE),'\n')
})
