"""编译同一二元交互模型、按原目标参数变换高精度估计及完整协方差。"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import csv,hashlib,json,shutil,sys
import numpy as np
import pandas as pd
from scipy.linalg import cho_factor,cho_solve
from calibrated_reader import matrices,pid
R=Path(__file__).resolve().parents[1];P=R.parent/'cfps_mean_h41_20261017'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
fac=['IX','SX','IY','SY'];obs=[f'{p}{i}' for p in ['X','Y'] for i in range(1,6)]
targets={('IY','IX'):'dii',('SY','IX'):'dis',('SY','SX'):'dss'}
def parent_cell(df,mat,r,c):
 s=df[(df.matrix.str.upper()==mat)&(df.row==r)&(df.column.fillna('')==c)]
 if s.empty and mat in ('BETA','GAMMA'):s=df[df.matrix.str.upper().isin(['BETA','GAMMA'])&(df.row==r)&(df.column==c)]
 if s.empty and mat in ('THETA','PSI'):s=df[(df.matrix.str.upper()==mat)&(df.row==c)&(df.column==r)]
 assert len(s)==1,(mat,r,c);return float(s.estimate.iloc[0])
def stmt(r,v=None,lab=None):
 v=r['value'] if v is None else v;lab=r['label'] if lab is None else lab;a=r['lhs'].lower();b=r['rhs'].lower();v=f'{v:.12g}'
 if r['op']=='MEAN':return f'[{a}*{v}] ({lab});'
 if r['op']=='VAR':return f'{a}*{v} ({lab});'
 return f'{a} {r["op"]} {b}*{v} ({lab});'
def prepare(group,member,start):
 assert group in ('CC','PARENT','INCOME') and start in ('A','B')
 interaction=group!='PARENT';g='G'
 admission=read(R/'audit/CC_INPUT.json') if group=='CC' else read(R/'audit/MI_ADMISSION.json')
 if group=='CC':assert admission['status']=='OBSERVED_COMPLETE_CASES_ONLY'
 else:assert admission['status']=='ADMITTED_WORKING_MI' and admission['m']==40
 source=R/'models/CHARLS_INCOME_PARENT_MI01_A' if group=='INCOME' else R.parent/'charls_mean_resource_20261017/models/CHARLS_MEAN_PARENT_MI01_A'
 assert read(source/'receipt.json')['status']=='USABLE'
 bindings=read(R/'audit/MODEL_SOURCE_BINDINGS.json')
 if group!='INCOME':
  for name in ('model.out','parameters_high_precision.csv','estimates.dat','tech3.dat'):
   assert sha(source/name)==bindings[str(source/name)]
 df=pd.read_csv(source/'parameters_high_precision.csv');rows=[]
 for i,r in enumerate(df.itertuples()):
  mat=r.matrix.upper();a=r.row;b=r.column
  if mat=='ALPHA':op='MEAN';a=b;b=''
  elif mat in ('THETA','PSI'):op='VAR' if a==b else 'WITH'
  elif mat in ('BETA','GAMMA'):op='ON'
  else:raise ValueError(mat)
  v=float(r.estimate)
  if op=='VAR':assert v>0
  if start=='B' and op in ('MEAN','ON'):v+=.005*(1 if i%2 else -1)
  rows.append(dict(op=op,lhs=a,rhs=b,key=op+':'+a+':'+b,label=f'p{i+1:03d}',value=v))
 if len(rows)==73:
  for a in fac:rows.append(dict(op='ON',lhs=a,rhs='G',key='ON:'+a+':G',label=f'p{len(rows)+1:03d}',value=.005 if start=='B' else 0.))
 assert len(rows)==77 and len([r for r in rows if r['op']=='ON' and r['rhs']=='G'])==4
 d=R/'models'/f'CHARLS_INCOME_{group}_MI{member:02d}_{start}';d.mkdir(parents=True,exist_ok=False)
 data=R/'private/CC.dat' if group=='CC' else R/'private'/f'MI{member:02d}.dat'
 if group=='CC':assert sha(data)==admission['sha256']
 else:
  audit=pd.read_csv(R/'audit/MI_MEMBERS.csv');assert sha(data)==audit.loc[audit.member==member,'sha256'].iloc[0]
 shutil.copyfile(data,d/'data.dat')
 common=[r for r in rows if r['op']!='MEAN' and not(r['op']=='ON' and r['rhs']==g)]
 means=[r for r in rows if r['op']=='MEAN'];gm={r['lhs']:r['value'] for r in rows if r['op']=='ON' and r['rhs']==g}
 controls=[f'c{i}' for i in range(1,12)]
 lines=['TITLE: '+d.name+';','DATA: FILE="data.dat";','VARIABLE: NAMES=cluster x1-x5 y1-y5 c1-c11 g;',
  'USEVARIABLES=x1-x5 y1-y5 '+' '.join(controls)+';',
  'MISSING=ALL(-9999); CLUSTER=cluster; CLASSES=cg(2);','KNOWNCLASS=cg(g=0 g=1);',
  'ANALYSIS: TYPE=COMPLEX MIXTURE; ESTIMATOR=MLR; STARTS=0;',
  'PROCESSORS=1; COVERAGE=.005; ITERATIONS=2000; MITERATIONS=2000;',
  'MODEL:','%OVERALL%','ix sx | x1@0 x2@2 x3@4 x4@7 x5@9;',
  'iy sy | y1@0 y2@2 y3@4 y4@7 y5@9;','[cg#1@0];','[x1-x5@0 y1-y5@0];',*[stmt(r) for r in common]]
 for cls in (0,1):
  lines += [f'%cg#{cls+1}%','[x1-x5@0 y1-y5@0];']
  for r in common:
   target=targets.get((r['lhs'],r['rhs'])) if interaction and r['op']=='ON' else None
   lines.append(stmt(r,r['value']+cls*(.01 if start=='A' else -.01),r['label']+str(cls)) if target else stmt(r))
  for r in means:lines.append(stmt(r,r['value']+cls*gm[r['lhs']],r['lhs'].lower()+str(cls)))
 lines+=['OUTPUT: TECH1 TECH3 TECH8 CINTERVAL SVALUES;','SAVEDATA: RESULTS=estimates.dat; TECH3=tech3.dat;']
 assert max(map(len,lines))<=90
 (d/'model.inp').write_text('\n'.join(lines)+'\n',encoding='ascii')
 normalized=rows.copy()
 if interaction:normalized += [dict(op='ON',lhs=a,rhs='IXG' if b=='IX' else 'SXG',key='ON:'+a+':'+('IXG' if b=='IX' else 'SXG'),label=lab,value=.01 if start=='A' else -.01) for (a,b),lab in targets.items()]
 (d/'normalized_slots.json').write_text(json.dumps(normalized,indent=2),encoding='utf-8')
 job=dict(id=d.name,root=str(R),dest=str(d),group=group,member=member,start=start,category='INCOME',cap_seconds=120,expected_free=len(normalized),g=g,interaction=interaction,source_parent=str(source),mplus='<LOCAL_USER>/Downloads/Mplus/mplus9/ducument/Mplus.exe',hashes={n:sha(d/n) for n in ['model.inp','data.dat']})
 (d/'job.json').write_text(json.dumps(job,indent=2),encoding='utf-8');print(str(d))

def checks_moments(q,slots,data,gcol):
 L=np.zeros((10,4));L[:5,0]=1;L[5:,2]=1;L[:5,1]=[0,2,4,7,9];L[5:,3]=[0,2,4,7,9]
 TH=np.zeros((10,10));PSI=np.zeros((4,4));B=np.zeros((4,4));D=np.zeros((4,4));Gamma=np.zeros((4,12));alpha=np.zeros(4)
 for r,value in zip(slots,q):
  op=r['op'];a=r['lhs'];b=r['rhs']
  if op=='BY':L[obs.index(b),fac.index(a)]=value
  elif op=='MEAN':alpha[fac.index(a)]=value
  elif op in ('VAR','WITH'):
   b=a if op=='VAR' else b;m=PSI if a in fac else TH;ns=fac if a in fac else obs;i=ns.index(a);j=ns.index(b);m[i,j]=m[j,i]=value
  elif b in ('IXG','SXG'):D[fac.index(a),fac.index(b[:2])]=value
  elif b in fac:B[fac.index(a),fac.index(b)]=value
  else:Gamma[fac.index(a),11 if b=='G' else int(b[1:])-1]=value
 def mineig(m):
  if np.any(np.diag(m)<=0):return float(np.linalg.eigvalsh(m).min())
  return float(np.linalg.eigvalsh(m/np.sqrt(np.outer(m.diagonal(),m.diagonal()))).min())
 geometry={'PSI':mineig(PSI),'THETA':mineig(TH)};ll=0.
 for g in (0,1):
  A=np.linalg.inv(np.eye(4)-B-g*D);G=A@PSI@A.T;S=L@G@L.T+TH
  geometry['G'+str(g)]=mineig(G);geometry['SIGMA'+str(g)]=mineig(S)
  if min(geometry.values())<=1e-7:return geometry,None
  dd=data[data[:,gcol]==g];mu=(alpha+dd[:,11:23]@Gamma.T)@A.T@L.T;y=dd[:,1:11];mask=np.isfinite(y)
  for pattern in np.unique(mask,axis=0):
   ids=np.all(mask==pattern,axis=1);j=np.flatnonzero(pattern)
   if not len(j):continue
   ch=cho_factor(S[np.ix_(j,j)],lower=True);e=y[ids][:,j]-mu[ids][:,j]
   ll-=.5*(len(e)*(len(j)*np.log(2*np.pi)+2*np.log(np.diag(ch[0])).sum())+np.sum(e*cho_solve(ch,e.T).T))
 return geometry,float(ll)
def normalize(d):
 d=Path(d);job=read(d/'job.json');er=read(d/'engine_receipt.json');rr=dict(id=d.name,dest=str(d),group=job['group'],member=job['member'],start=job['start'],engine=er,status=er['status'])
 if (d/'model.out').exists():rr['output_sha256']=sha(d/'model.out')
 if er['status']!='EXITED':(d/'receipt.json').write_text(json.dumps(rr,indent=2),encoding='utf-8');return
 try:
  txt,mp,q,se,V,ll=matrices(d);slots=read(d/'normalized_slots.json');n=len(slots);assert len(q)==n==job['expected_free'] and len(mp)==2
  J=np.zeros((n,n));normmeta=[]
  for i,r in enumerate(slots):
   op=r['op'];a=r['lhs'];b=r['rhs'];mat=None;row=a;col=b
   if op=='ON' and b==job['g']:
    J[i,pid(mp[2],'ALPHA','1',a)]=1;J[i,pid(mp[1],'ALPHA','1',a)]=-1;mat='BETA'
   elif op=='ON' and b in ('IXG','SXG'):
    base=b[:2];J[i,pid(mp[2],'BETA',a,base)]=1;J[i,pid(mp[1],'BETA',a,base)]=-1;mat='BETA'
   else:
    if op=='BY':mat='LAMBDA';row=b;col=a
    elif op=='MEAN':mat='ALPHA';row='1';col=a
    elif op in ('VAR','WITH'):mat='PSI' if a in fac else 'THETA';col=a if op=='VAR' else b
    elif op=='ON':mat='BETA'
    j=pid(mp[1],mat,row,col);J[i,j]=1
    if op!='MEAN':
     if job['interaction'] and op=='ON' and (a,b) in targets:assert j!=pid(mp[2],mat,row,col)
     else:assert j==pid(mp[2],mat,row,col)
   normmeta.append(dict(parameter=i+1,matrix=mat.lower(),row=row,column=col))
  assert np.linalg.matrix_rank(J)==n
  nq=J@q;NV=J@V@J.T;nse=np.sqrt(NV.diagonal());scale=np.sqrt(np.outer(NV.diagonal(),NV.diagonal()))
  eig=float(np.linalg.eigvalsh(NV/scale).min());data=np.genfromtxt(d/'data.dat',missing_values='-9999',filling_values=np.nan);data[data==-9999]=np.nan
  geometry,alll=checks_moments(nq,slots,data,{'G':22}[job['g']])
  negative=[r['lhs'] for r,v in zip(slots,nq) if r['op']=='VAR' and v<0]
  normal='THE MODEL ESTIMATION TERMINATED NORMALLY' in txt
  no_autofix='FIXED TO AVOID SINGULARITY' not in txt
  ll_ok=alll is not None and abs(ll+len(data)*np.log(2)-alll)<.02
  passed=normal and no_autofix and eig>1e-10 and min(geometry.values())>1e-7 and not negative and ll_ok
  rr.update(status='USABLE' if passed else 'INADMISSIBLE',parameters=n,negative=negative,geometry=geometry,vcov_min_correlation_eigenvalue=eig,normal=normal,no_autofix=no_autofix,LL=ll+len(data)*np.log(2),analytic_LL=alll,likelihood_identity=bool(ll_ok),normalized_parameters=True,N=len(data),communities=len(np.unique(data[:,0])))
  par=pd.DataFrame(normmeta);par['estimate']=nq;par['se']=nse;par.to_csv(d/'parameters_high_precision.csv',index=False)
  pd.DataFrame(NV).to_csv(d/'parameter_covariance.csv',header=False,index=False);pd.DataFrame(J).to_csv(d/'parameter_transform.csv',header=False,index=False)
  keys=[('bii','IY','IX'),('bis','SY','IX'),('bss','SY','SX'),('bsyiy','SY','IY'),('dii','IY','IXG'),('dis','SY','IXG'),('dss','SY','SXG')]
  rows=[]
  for lab,a,b in (keys if job['interaction'] else keys[:4]):
   match=par[(par.matrix=='beta')&(par.row==a)&(par.column==b)];assert len(match)==1;r=match.iloc[0].to_dict();r['label']=lab;rows.append(r)
  pd.DataFrame(rows).to_csv(d/'key_paths.csv',index=False)
  (d/'validation.json').write_text(json.dumps(dict(passed=bool(passed),geometry=geometry,vcov_min=eig,negative=negative,likelihood_identity=bool(ll_ok)),indent=2),encoding='utf-8')
 except Exception as exc:rr['status']='READBACK_FAILED';rr['error']=repr(exc)
 (d/'receipt.json').write_text(json.dumps(rr,indent=2),encoding='utf-8');print(json.dumps({k:rr[k] for k in ('id','status','negative','error') if k in rr}))
def agree(a,b,target):
 a=Path(a);b=Path(b);ra=read(a/'receipt.json');rb=read(b/'receipt.json');assert ra['status']==rb['status']=='USABLE'
 pa=pd.read_csv(a/'parameters_high_precision.csv');pb=pd.read_csv(b/'parameters_high_precision.csv');assert pa[['matrix','row','column']].equals(pb[['matrix','row','column']])
 diff=np.abs(pa.estimate-pb.estimate);sd=np.abs(pa.se-pb.se)/pa.se
 ok=np.all(diff<=np.maximum(.001,.05*pa.se)) and np.all(sd<=.05) and abs(ra['LL']-rb['LL'])<=.02
 result=dict(passed=bool(ok),all_parameters=len(pa),max_difference_over_SE=float(np.max(diff/pa.se)),max_SE_relative=float(sd.max()),LL_difference=abs(ra['LL']-rb['LL']))
 Path(target).write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare(sys.argv[2],int(sys.argv[3]),sys.argv[4])
 elif sys.argv[1]=='normalize':normalize(sys.argv[2])
 elif sys.argv[1]=='agree':agree(*sys.argv[2:5])
