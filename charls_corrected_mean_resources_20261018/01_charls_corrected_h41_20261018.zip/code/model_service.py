"""单个已授权批次内复用数值库；协议只允许现有编译、读回与起点比较。"""
import contextlib,io,json,os,sys,traceback
from pathlib import Path
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
def emit(value):print(json.dumps(value,ensure_ascii=False),flush=True)
emit({'kind':'starting','pid':os.getpid()})
import models
R=Path(__file__).resolve().parents[1]
assert models.R==R
emit({'kind':'ready','pid':os.getpid(),'root':str(R)})
for line in sys.stdin:
    request=json.loads(line);identity=request['id'];args=request['args'];log=io.StringIO()
    if args==['shutdown']:
        emit({'kind':'result','id':identity,'status':0,'stdout':'SHUTDOWN'});break
    try:
        with contextlib.redirect_stdout(log):
            if args[0]=='prepare' and len(args)==4:models.prepare(args[1],int(args[2]),args[3])
            elif args[0]=='normalize' and len(args)==2:
                assert Path(args[1]).resolve().is_relative_to(R/'models');models.normalize(args[1])
            elif args[0]=='agree' and len(args)==4:
                assert all(Path(x).resolve().is_relative_to(R) for x in args[1:]);models.agree(*args[1:])
            else:raise ValueError('Unsupported model operation')
        emit({'kind':'result','id':identity,'status':0,'stdout':log.getvalue()})
    except Exception:
        emit({'kind':'result','id':identity,'status':1,'stdout':log.getvalue(),'stderr':traceback.format_exc()})
