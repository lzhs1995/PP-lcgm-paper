from pathlib import Path
import contextlib,io,json,sys
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,'<LOCAL_USER>/.codex/skills/clauder-rstudio-workbench')
from clauder_workbench.cli import main
mode=sys.argv[1];iteration=sys.argv[2] if len(sys.argv)>2 else '10'
args=[mode,'--contract',str(R/'contracts'/('FANOUT_ITER'+iteration+'.json'))]
args+=['--parent-evidence',str(R/'audit/NATIVE_PROOF.json')]
b=io.StringIO()
with contextlib.redirect_stdout(b):rc=main(args)
(R/'audit'/('FANOUT_'+iteration+'_'+mode+'.json')).write_text(b.getvalue(),encoding='utf-8')
j=json.loads(b.getvalue());print(json.dumps(j,ensure_ascii=False));sys.exit(rc)
