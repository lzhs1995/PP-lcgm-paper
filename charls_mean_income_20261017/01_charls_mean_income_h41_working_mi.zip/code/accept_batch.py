"""本批实测终态及独立验证齐备后验收；总H4状态仍未完成。"""
from pathlib import Path
import contextlib,datetime,io,json,sys,psutil
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert read(R/'audit/INDEPENDENT_RESULTS.json')['status']=='PASS'
assert read(R/'audit/INDEPENDENT_MI.json')['status']=='PASS'
for tag in ['full','postprocess','combine4','mi_b10_resume','cc_recovery']:
 assert read(R/'audit'/('GUARD_'+tag+'_complete.json'))['decision']=='PASS'
assert not (R/'runtime/engine.lock').exists()
awake=R/'runtime/awake_FULL/completion.json'
if awake.is_file():
 assert read(awake)['released'];power_status='ACQUIRED_AND_RELEASED'
else:
 # 原子程序在导入阶段退出，未执行Windows电源API；不能伪造release回执。
 failure=(R/'runtime/awake_FULL.log').read_text(encoding='utf-8')
 assert "ModuleNotFoundError: No module named 'mplus_queue'" in failure
 assert not (R/'runtime/awake_FULL/identity.json').exists()
 assert read(R/'audit/AWAKE_HELPER_REPAIR.json')['status']=='PASS'
 power_status='NOT_ACQUIRED_IMPORT_FAILURE; future helper repaired and smoke tested'
live=[]
paths=list((R/'models').glob('*/process.json'))+list(R.glob('mi*/[ab]/runtime/lease.json'))+[R/'runtime/MODEL_OWNER_FULL.json']
for p in paths:
 x=read(p);x=x.get('owner',x)
 try:
  proc=psutil.Process(x['pid'])
  if abs(proc.create_time()-x['created'])<.01:live.append(proc.pid)
 except psutil.NoSuchProcess:pass
assert not live,live
for proc in psutil.process_iter(['pid','cmdline']):
 cmd=' '.join(proc.info['cmdline'] or [])
 assert not ('windows_awake_guard.py' in cmd and 'awake_FULL' in cmd and str(R).lower() in cmd.lower()),proc.pid
power=dict(status=power_status,owned_model_processes_live=live,not_retroactive=True)
(R/'audit/POWER_HELPER_CLOSURE.json').write_text(json.dumps(power,indent=2),encoding='utf-8')
terminal=dict(status='CHARLS_MEAN_INCOME_BATCH_ADJUDICATED',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),family=read(R/'results/FAMILY_STATUS.json'),MI=read(R/'audit/MI_ADMISSION.json'),budget=read(R/'runtime/budget_status.json'),owned_processes_live=[],original_four_complete=False,full_H4_complete=False)
(R/'audit/BATCH_TERMINAL.json').write_text(json.dumps(terminal,indent=2),encoding='utf-8')
sys.path.insert(0,'<LOCAL_USER>/.codex/skills/clauder-rstudio-workbench')
from clauder_workbench.cli import main
b=io.StringIO()
with contextlib.redirect_stdout(b):rc=main(['completion-check','--mode','formal','--require-file','terminal::'+str(R/'audit/BATCH_TERMINAL.json')+',max_age_h=24','--require-file','validation::'+str(R/'audit/INDEPENDENT_RESULTS.json')+',max_age_h=24'])
(R/'audit/COMPLETION_CHECK.json').write_text(b.getvalue(),encoding='utf-8');j=json.loads(b.getvalue());assert rc==0 and j['decision']=='PASS';print(json.dumps({'decision':j['decision'],'evidence_id':j['evidence_id']}))
