"""仅恢复已证实被待机看门狗中断的A起点；B合法输出保持原样。"""
from pathlib import Path
import hashlib,json,shutil,sqlite3
from model_engine import budget_adjustment
R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
am=json.loads((R/'contracts/HOST_PAUSE_RECOVERY.json').read_text())
old=R/'models'/am['credit_call'];b=R/'models/CHARLS_INCOME_CC_MI00_B'
assert not (old/'model.out').exists()
br=json.loads((b/'receipt.json').read_text());assert br['status']=='USABLE' and sha(b/'model.out')==br['output_sha256']
with sqlite3.connect(R/'runtime/budget.sqlite') as db:rows=db.execute('SELECT id,category,state,seconds FROM calls').fetchall()
credit,extra=budget_adjustment(R,rows);assert extra==1 and abs(credit-1904.5082733000017)<1e-6
bad=[list(x) for x in rows];bad[0][3]+=1
try:budget_adjustment(R,bad)
except AssertionError:rejected=True
else:raise AssertionError('Corrupted ledger accepted')
dest=R/'models/CHARLS_INCOME_CC_MI00_A_RECOVERY';assert not dest.exists();dest.mkdir()
j=json.loads((old/'job.json').read_text())
for name in ['model.inp','data.dat','normalized_slots.json']:
 shutil.copy2(old/name,dest/name);assert sha(old/name)==sha(dest/name)
j.update(id=dest.name,dest=str(dest),host_recovery_of=am['credit_call'])
(dest/'job.json').write_text(json.dumps(j,indent=2),encoding='utf-8')
files=['active_clock.py','mi_watch.py','run_mi_worker.R','income_imputers.R','model_engine.py','prepare_host_resume.py','prepare_cc_recovery.py']
receipt=dict(status='PASS',recovery=dest.name,reused_B=str(b),model_input_and_data_identical=True,credit_seconds=credit,extra_calls=extra,tampered_ledger_rejected=rejected,code_sha256={n:sha(R/'code'/n) for n in files})
(R/'audit/HOST_RESUME_BINDINGS.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(receipt))
