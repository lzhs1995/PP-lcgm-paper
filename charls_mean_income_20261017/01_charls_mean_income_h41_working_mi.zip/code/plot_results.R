# 按实际完成的家族出图；完整案例与40份工作MI明确区分。
local({
 ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_mean_income_20261017';library(jsonlite)
 stopifnot(fromJSON(file.path(ROOT,'audit/MODEL_CC_RECOVERY_TERMINAL.json'))$passed)
 d<-file.path(ROOT,'models/CHARLS_INCOME_CC_MI00_A_RECOVERY');p<-read.csv(file.path(d,'key_paths.csv'));V<-as.matrix(read.csv(file.path(d,'parameter_covariance.csv'),header=FALSE));labs<-c('bii','bis','bss','bsyiy','dii','dis','dss');p<-p[match(labs,p$label),];U<-V[p$parameter,p$parameter];q<-p$estimate
 cs<-list(IY_IX_G0=c(bii=1),IY_IX_G1=c(bii=1,dii=1),IY_IX_difference=c(dii=1),SY_IX_G0=c(bis=1),SY_IX_G1=c(bis=1,dis=1),SY_IX_difference=c(dis=1),SY_SX_G0=c(bss=1),SY_SX_G1=c(bss=1,dss=1),SY_SX_difference=c(dss=1))
 cc<-do.call(rbind,lapply(names(cs),function(n){a<-setNames(rep(0,7),labs);a[names(cs[[n]])]<-cs[[n]];est<-sum(a*q);se<-sqrt(drop(t(a)%*%U%*%a));data.frame(group='INCOME_CC',contrast=n,estimate=est,se=se,lower=est-qnorm(.975)*se,upper=est+qnorm(.975)*se,p=2*pnorm(-abs(est/se)))}))
 write.csv(cc,file.path(ROOT,'results/CC_GROUP_CONTRASTS.csv'),row.names=FALSE)
 cc<-cc[grepl('_difference$',cc$contrast),];cc$method<-'Observed complete cases (N=2260)'
 all<-cc[,c('contrast','estimate','se','lower','upper','p','method')]
 if(file.exists(file.path(ROOT,'results/GROUP_CONTRASTS.csv'))){z<-read.csv(file.path(ROOT,'results/GROUP_CONTRASTS.csv'));z<-z[grepl('_difference$',z$contrast),];z$method<-'40 working imputations (N=3006)';all<-rbind(all,z[names(all)])}
 write.csv(all,file.path(ROOT,'results/PLOT_DATA.csv'),row.names=FALSE)
 draw<-function(){
  par(mar=c(5,14,4,2));keys<-c('IY_IX_difference','SY_IX_difference','SY_SX_difference');ord<-order(match(all$contrast,keys),all$method);v<-all[ord,];y<-rev(seq_len(nrow(v)));x<-range(c(0,v$lower,v$upper));pad<-max(.05,diff(x)*.08);color<-ifelse(grepl('40 ',v$method),'#135e83','#777777')
  labels<-paste(sub('_difference$','',v$contrast),v$method,sep=' | ')
  plot(v$estimate,y,xlim=x+c(-pad,pad),ylim=c(.5,length(y)+.5),yaxt='n',ylab='',xlab='Higher-income minus lower-income path coefficient (95% CI)',pch=19,col=color,main='CHARLS mean contact: baseline household-income differences')
  abline(v=0,lty=2,col='grey60');segments(v$lower,y,v$upper,y,col=color,lwd=2);axis(2,at=y,labels=labels,las=1,cex.axis=.72)
  mtext('Fixed observed median: CNY 8,730. Working FCS; contact frequency is not emotional closeness.',side=1,line=3.5,cex=.69)
 }
 png(file.path(ROOT,'reports/INCOME_GROUP_DIFFERENCES.png'),width=1650,height=950,res=150);draw();dev.off()
 pdf(file.path(ROOT,'reports/INCOME_GROUP_DIFFERENCES.pdf'),width=11,height=6.4);draw();dev.off()
 cat('CHARLS_INCOME_PLOT_DONE',nrow(all),'contrasts\n')
})
