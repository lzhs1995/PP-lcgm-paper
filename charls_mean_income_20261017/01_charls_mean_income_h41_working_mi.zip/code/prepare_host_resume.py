"""只恢复明确中断的B块；复用A及B的完整第6轮，不更换成员或种子。"""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil,psutil
from active_clock import parse_power_sleep
R=Path(__file__).resolve().parents[1];old=R/'mi_v2/b';new=R/'mi_resume/b'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
watch=read(old/'runtime/WATCH_TERMINAL.json');assert watch['status']=='OWNED_CONDITIONAL_FIT_TIMEOUT'
try:
 p=psutil.Process(watch['owner_pid']);assert abs(p.create_time()-watch['created'])>.01,'Old worker still alive'
except psutil.NoSuchProcess:pass
assert read(R/'audit/ACTIVE_CLOCK_TEST.json')['status']=='PASS'
events=parse_power_sleep((R/'audit/WINDOWS_POWER_EVENTS.xml').read_text(encoding='utf-8-sig'),datetime(2026,10,18,1,43,54,tzinfo=timezone.utc),datetime(2026,10,18,2,17,40,tzinfo=timezone.utc))
sleep=sum(x['overlap_seconds'] for x in events);assert 1900<sleep<2000
cp=old/'checkpoints/ITER06.rds';meta=read(Path(str(cp)+'.json'));assert sha(cp)==meta['sha256'] and meta['iteration']==6 and meta['m']==20
assert not new.exists()
for n in ('audit','runtime','private','results','checkpoints'):(new/n).mkdir(parents=True,exist_ok=True)
for suffix in ('','.json','.warm.rds'):shutil.copyfile(Path(str(cp)+suffix),new/'checkpoints'/('ITER06.rds'+suffix))
lines=(old/'audit/FIT_LOG.jsonl').read_text().splitlines();records=[json.loads(x) for x in lines];prefix=[line for line,row in zip(lines,records) if row['fit_n']<=meta['fit_n']]
assert len(prefix)==240 and [json.loads(x)['fit_n'] for x in prefix]==list(range(1,241)) and all(json.loads(x)['valid'] for x in prefix)
(new/'audit/FIT_LOG.jsonl').write_text('\n'.join(prefix)+'\n',encoding='utf-8')
rec=dict(status='VERIFIED_CHECKPOINT_RESUME',source_checkpoint=str(cp),checkpoint_sha256=meta['sha256'],input_sha256=meta['source_sha256'],original_fit_log_sha256=sha(old/'audit/FIT_LOG.jsonl'),retained_complete_conditional_calls=240,interrupted_iteration_calls=len(records)-240,interrupted_call_n=275,original_worker_wall_seconds=watch['elapsed_seconds'],verified_sleep_seconds=sleep,previous_active_charge_seconds=watch['elapsed_seconds']-sleep,restored_seed_from_saved_mids=True,first_block_reused=True,statistical_specifications_unchanged=True)
(new/'audit/RECOVERY_SOURCE.json').write_text(json.dumps(rec,indent=2),encoding='utf-8')
(R/'contracts/MI_BLOCK_ROOTS.json').write_text(json.dumps({'a':str(R/'mi_v2/a'),'b':str(new)},indent=2),encoding='utf-8')
er=read(R/'models/CHARLS_INCOME_CC_MI00_A/engine_receipt.json');assert er['status']=='TIMEOUT' and not (R/'models/CHARLS_INCOME_CC_MI00_A/model.out').exists()
credit=max(0,er['seconds']-120);assert credit<sleep
amend=dict(reason='Verified Modern Standby interrupted workers and old wall-clock watchdogs fired on wake',power_events=events,original_contract_sha256=sha(R/'contracts/RUN_CONTRACT.json'),credit_call='CHARLS_INCOME_CC_MI00_A',original_receipt_sha256=sha(R/'models/CHARLS_INCOME_CC_MI00_A/engine_receipt.json'),old_wall_seconds=er['seconds'],budget_credit_seconds=credit,conservative_old_call_charge_seconds=120,additional_engine_calls=1,only_recovery='CC A exact existing input/data; B reused',new_budget_clock='awake wall including launch/IO; QueryUnbiasedInterruptTime plus verified S0 sleep events; gross wall retained',model_specs_and_MI_seeds_unchanged=True)
(R/'contracts/HOST_PAUSE_RECOVERY.json').write_text(json.dumps(amend,indent=2),encoding='utf-8');print(json.dumps(rec))
