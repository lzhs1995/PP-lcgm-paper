# 构造两目标FCS入口；轨迹辅助量不进入正式Mplus模型。
local({
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_mean_income_20261017'
.libPaths(c('<LOCAL_USER>/pp_lgcm_review/charls_income_mi_pilot_20261016/library','<LOCAL_USER>/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
library(mice);library(jsonlite);library(digest)
stopifnot(!file.exists(file.path(ROOT,'private/MI_INPUTS.rds')),packageVersion('mice')=='3.19.10')
source<-file.path(ROOT,'private/SOURCE_INPUTS.rds');z<-readRDS(source);receipt<-fromJSON(file.path(ROOT,'audit/SOURCE_PREPARATION.json'))
stopifnot(digest(file=source,algo='sha256')==receipt$input_sha256)
d<-z$controls_and_auxiliaries;d$g<-z$income_group;base<-setdiff(names(d),'g');controls<-c('age','female','edu','urban','partner','nchild',paste0('health',2:5));aux<-grep('^(obs|missing)_',names(d),value=TRUE)
times<-c(0,2,4,7,9);scores<-matrix(NA_real_,nrow(d),4,dimnames=list(NULL,c('qiX','qsX','qiY','qsY')))
for(i in seq_len(nrow(d)))for(pr in c('x','y')){
 y<-as.numeric(z$analysis_with_original_ADL_mask[i,paste0(pr,1:5)]);ok<-!is.na(y);stopifnot(sum(ok)>=2)
 fit<-lm.fit(cbind(1,times[ok]),y[ok]);scores[i,if(pr=='x')1:2 else 3:4]<-fit$coefficients
}
centers<-colMeans(scores);scales<-apply(scores,2,sd);stopifnot(all(scales>0),all(is.finite(scores)))
scores<-sweep(sweep(scores,2,centers,'-'),2,scales,'/');sn<-colnames(scores)
for(n in sn)d[[n]]<-scores[,n]
quad<-character();cp<-character()
for(i in seq_along(sn))for(j in i:length(sn)){nm<-paste0('q_',sn[i],'_',sn[j]);d[[nm]]<-d[[sn[i]]]*d[[sn[j]]];quad<-c(quad,nm)}
for(cn in controls)for(q in sn){nm<-paste0('cq_',cn,'_',q);d[[nm]]<-d[[cn]]*d[[q]];cp<-c(cp,nm)}
passive<-list()
for(v in c(controls,aux)){nm<-paste0('g_',v);d[[nm]]<-d$g*d[[v]];passive[[nm]]<-c('g',v)}
for(q in sn){nm<-paste0('adl_',q);d[[nm]]<-d$adl*d[[q]];passive[[nm]]<-c('adl',q)}
method<-make.method(d);method[]<-'';method['g']<-'2l.bin.logged';method['adl']<-'2l.pmm.logged'
for(n in names(passive))method[n]<-paste0('~I(',paste(passive[[n]],collapse='*'),')')
pm<-matrix(0,ncol(d),ncol(d),dimnames=list(names(d),names(d)))
gpred<-c(setdiff(base,'cluster'),sn,quad,cp,paste0('adl_',sn));apred<-c(setdiff(base,c('cluster','adl')),'g',paste0('g_',c(controls,aux)))
pm['g',gpred]<-1;pm['adl',apred]<-1;pm[c('g','adl'),'cluster']<--2
initial<-d;initial$g[is.na(initial$g)]<-0;initial$adl[is.na(initial$adl)]<-median(initial$adl,na.rm=TRUE)
for(n in names(passive))initial[[n]]<-initial[[passive[[n]][1]]]*initial[[passive[[n]][2]]]
stopifnot(!anyNA(initial),all(is.finite(as.matrix(initial))))
visit<-c('g',grep('^g_',names(passive),value=TRUE),'adl',grep('^adl_',names(passive),value=TRUE))
blots<-make.blots(d);blots$adl<-alist(donors=5)
out<-list(data=d,analysis=z$analysis_with_original_ADL_mask,method=method,predictors=pm,visit=visit,initial=initial,blots=blots,passive=passive,essential_G=c(sn,quad,paste0('adl_',sn)),essential_ADL=c('g',paste0('g_',aux)),source_sha256=digest(file=source,algo='sha256'),score_centers=centers,score_scales=scales)
saveRDS(out,file.path(ROOT,'private/MI_INPUTS.rds'))
write.csv(data.frame(variable=rownames(pm),pm,check.names=FALSE),file.path(ROOT,'audit/PREDICTORS_REQUESTED.csv'),row.names=FALSE)
write_json(list(status='INPUTS_PREPARED_NOT_FITTED',N=nrow(d),columns=ncol(d),G_predictors=sum(pm['g',]==1),ADL_predictors=sum(pm['adl',]==1),passive_products=length(passive),OLS_auxiliary_variables=sn,OLS_centers=as.list(centers),OLS_scales=as.list(scales),quadratic_terms=quad,observed_wave_auxiliaries=aux,raw_income_not_imputed=TRUE,source_unchanged=digest(file=source,algo='sha256')==receipt$input_sha256,input_sha256=digest(file=file.path(ROOT,'private/MI_INPUTS.rds'),algo='sha256')),file.path(ROOT,'audit/INPUT_PREPARATION.json'),auto_unbox=TRUE,pretty=TRUE)
cat('INCOME_MI_INPUTS_READY G predictors',sum(pm['g',]==1),'ADL',sum(pm['adl',]==1),'new_fit0\n')
})
