# 仅修正诊断图的2×2排版，避免默认2×3布局隐藏迭代轴。
local({
 ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_mean_income_20261017';library(mice);library(jsonlite)
 a<-fromJSON(file.path(ROOT,'audit/MI_ADMISSION.json'));imp<-readRDS(a$mids_path)
 out<-file.path(ROOT,'results',paste0('MI_CHAINS_ITER',a$iterations,'.pdf'))
 backup<-file.path(ROOT,'audit/MI_CHAINS_INITIAL_LAYOUT.pdf');if(!file.exists(backup))stopifnot(file.copy(out,backup))
 pdf(out,width=10,height=7);print(plot(imp,c('g','adl'),layout=c(2,2)));dev.off()
 cat('CHAIN_PLOT_2x2_DONE no_new_imputation\n')
})
