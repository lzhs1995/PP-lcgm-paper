"""修复已完成批次的后续启动器；不改历史输出，不重新估计。"""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
import psutil
R=Path(__file__).resolve().parents[1]
saved=R/'audit/awake_original_code';saved.mkdir(exist_ok=False)
for n in ['windows_awake_guard.py','run_models.R']:
 shutil.copy2(R/'code'/n,saved/n)
p=R/'code/windows_awake_guard.py';s=p.read_text(encoding='utf-8')
s=s.replace('from mplus_queue import atomic_replace','''import os

def atomic_replace(source: Path, target: Path) -> None:
    for attempt in range(16):
        try:
            os.replace(source, target)
            return
        except PermissionError:
            if attempt == 15:
                raise
            time.sleep(min(.05 * 2 ** attempt, .4))''')
p.write_text(s,encoding='utf-8')
p=R/'code/run_models.R';s=p.read_text(encoding='utf-8')
old="awakepath<-file.path(ROOT,'runtime',paste0('awake_',RUN_TAG));dir.create(awakepath,showWarnings=FALSE)"
assert old in s
s=s.replace(old,"awakepath<-file.path(ROOT,'runtime',paste0('awake_',RUN_TAG));stopifnot(!dir.exists(awakepath))")
old=" on.exit({writeLines('release',file.path(awakepath,'stop.request'));aw$wait(8000L)},add=TRUE)"
assert old in s
new=""" on.exit({if(dir.exists(awakepath))writeLines('release',file.path(awakepath,'stop.request'));aw$wait(8000L)},add=TRUE)
 for(i in seq_len(50L)){if(file.exists(file.path(awakepath,'identity.json'))||!aw$is_alive())break;aw$wait(100L)}
 if(!aw$is_alive()||!file.exists(file.path(awakepath,'identity.json')))stop('Awake helper did not acquire its request; inspect native log before model launch')"""
s=s.replace(old,new);p.write_text(s,encoding='utf-8')
# 真实Windows线程取得并释放请求；故意不创建output目录，拒绝重用同目录。
test=R/'runtime/awake_smoke';owner=R/'runtime/AWAKE_SMOKE_OWNER.json'
owner.write_text(json.dumps({'owner':{'pid':os.getpid(),'created':psutil.Process().create_time()}}),encoding='utf-8')
cmd=[sys.executable,'-X','utf8',str(R/'code/windows_awake_guard.py'),'--owner-file',str(owner),'--output',str(test),'--interval','0.1']
with (R/'audit/AWAKE_SMOKE.log').open('w',encoding='utf-8') as log:
 proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
 try:
  for _ in range(100):
   if (test/'identity.json').exists() or proc.poll() is not None:break
   time.sleep(.1)
  assert (test/'identity.json').exists() and proc.poll() is None
  (test/'stop.request').write_text('release',encoding='utf-8')
  assert proc.wait(timeout=10)==0
 finally:
  if proc.poll() is None:
   (test/'stop.request').write_text('release',encoding='utf-8');proc.wait(timeout=10)
terminal=json.loads((test/'completion.json').read_text());assert terminal['released'] and terminal['reason']=='stop_requested'
duplicate=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',timeout=10)
assert duplicate.returncode!=0 and 'FileExistsError' in duplicate.stderr
syntax=subprocess.run([sys.executable,'-m','py_compile',str(R/'code/windows_awake_guard.py')],capture_output=True,text=True,timeout=10);assert syntax.returncode==0
(R/'audit/AWAKE_HELPER_REPAIR.json').write_text(json.dumps({'status':'PASS','native_smoke':terminal,'duplicate_directory_rejected':True,'new_mplus_calls':0,'original_code':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in saved.iterdir()}},indent=2),encoding='utf-8')
print('AWAKE_HELPER_REPAIR_PASS: actual acquire/release; duplicate directory rejected; Mplus calls 0')
