"""根据Windows真实余量和试运行峰值准入；不回收其他研究进程。"""
from pathlib import Path
import json,sys,psutil
from engine import profile,write
R=Path(__file__).resolve().parents[1];block=sys.argv[1]
contract=json.loads((R/'contracts/RUN_CONTRACT.json').read_text(encoding='utf-8-sig'))
pilot=json.loads((R/'pilot_scopefix/runtime/WATCH_TERMINAL.json').read_text())
cfg=contract['resource_admission'];pf=profile();owned=[]
for lease in R.glob('mi*/[ab]/runtime/lease.json'):
    j=json.loads(lease.read_text())
    try:
        p=psutil.Process(j['pid'])
        if abs(p.create_time()-j['created'])<.01:
            assert j['block']!=block,'Block already owns a live process'
            owned.append(dict(block=j['block'],pid=p.pid,rss=p.memory_info().rss))
    except psutil.NoSuchProcess:pass
observed=[pilot]+[json.loads(p.read_text()) for p in R.glob('mi*/[ab]/runtime/WATCH_TERMINAL.json')]
peak=max(x.get('peak_rss_bytes',0) for x in observed)/2**30;private=max(x.get('peak_private_bytes',0) for x in observed)/2**30
required=cfg['minimum_available_gib']+peak
passed=len(owned)<2 and pf['available_gib']>=required and pf['commit_available_gib']>=cfg['minimum_commit_available_gib']+private and pf['cpu_percent']<cfg['max_cpu_percent']
rec=dict(block=block,passed=passed,resource=pf,owned=owned,pilot_peak_gib=peak,pilot_private_gib=private,required_before_launch_gib=required,foreign_processes_modified=False)
write(R/'audit'/('RESOURCE_ADMISSION_'+block+'.json'),rec)
with (R/'audit/RESOURCE_ADMISSION_HISTORY.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec)+'\n')
print(json.dumps(rec));sys.exit(0 if passed else 2)
