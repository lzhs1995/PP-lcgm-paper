# 通过MplusAutomation读回现有输出；中断无OUT明确单列，不重新估计。
local({
 ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_mean_income_20261017'
 .libPaths(c('<LOCAL_USER>/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
 library(MplusAutomation);library(jsonlite);library(digest)
 dirs<-list.dirs(file.path(ROOT,'models'),recursive=FALSE);rows<-list()
 for(i in seq_along(dirs)){
  d<-dirs[i];out<-file.path(d,'model.out');receipt<-file.path(d,'MPLUS_AUTOMATION_READBACK.json')
  if(!file.exists(out)){rows[[i]]<-data.frame(id=basename(d),status='NO_OUTPUT_PRESERVED',printed_rows=0,N=NA_integer_,parameters=NA_integer_);next}
  h<-digest(file=out,algo='sha256')
  if(file.exists(receipt)){rr<-fromJSON(receipt);stopifnot(rr$output_sha256==h);rows[[i]]<-as.data.frame(rr$row);next}
  m<-suppressWarnings(readModels(out,what=c('summaries','parameters'),quiet=TRUE));p<-m$parameters$unstandardized
  rr<-fromJSON(file.path(d,'receipt.json'));if(rr$status=='USABLE')stopifnot(nrow(p)>0)
  if(!is.null(p))write.csv(p,file.path(d,'mplusautomation_printed_parameters.csv'),row.names=FALSE)
  rows[[i]]<-data.frame(id=basename(d),status=rr$status,printed_rows=if(is.null(p))0L else nrow(p),N=m$summaries$Observations,parameters=m$summaries$Parameters)
  write_json(list(status='READ_BACK',output_sha256=h,row=as.list(rows[[i]][1,]),package=as.character(packageVersion('MplusAutomation'))),receipt,auto_unbox=TRUE,pretty=TRUE)
  if(i%%5==0){cat('READBACK',i,'/',length(dirs),'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress('readback',paste(i,'of',length(dirs)))}
 }
 tab<-do.call(rbind,rows);write.csv(tab,file.path(ROOT,'audit/MPLUS_AUTOMATION_READBACK.csv'),row.names=FALSE)
 write_json(list(status='PASS',models_with_output=sum(tab$status!='NO_OUTPUT_PRESERVED'),no_output_preserved=sum(tab$status=='NO_OUTPUT_PRESERVED'),new_engine_calls=0,package=as.character(packageVersion('MplusAutomation'))),file.path(ROOT,'audit/MPLUS_AUTOMATION_READBACK.json'),auto_unbox=TRUE,pretty=TRUE)
 cat('CHARLS_INCOME_READBACK_DONE',nrow(tab),'attempts\n')
})
