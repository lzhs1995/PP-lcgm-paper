# 从原始队列入口独立验证插补及40份实际DAT；不输出个人记录。
local({
 ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_mean_income_20261017'
 P<-'<LOCAL_USER>/pp_lgcm_review/charls_adjusted_h41_20261015'
 .libPaths(c('<LOCAL_USER>/pp_lgcm_review/charls_income_mi_pilot_20261016/library',file.path(P,'library'),.libPaths()))
 library(mice);library(data.table);library(jsonlite);library(digest)
 rec<-fromJSON(file.path(ROOT,'audit/MI_ADMISSION.json'));stopifnot(rec$status=='ADMITTED_WORKING_MI')
 z<-readRDS(file.path(P,'private/charls_core_mi_inputs.rds'));stopifnot(digest(file=rec$mids_path,algo='sha256')==rec$mids_sha256);imp<-readRDS(rec$mids_path);a<-readRDS(file.path(ROOT,'private/MI_INPUTS.rds'))
 cols<-c('cluster',paste0('x',1:5),paste0('y',1:5),paste0('c',1:11))
 rd<-function(path,nm){d<-fread(path,header=FALSE,data.table=FALSE,showProgress=FALSE);names(d)<-nm;for(n in names(d))d[[n]][d[[n]]==-9999]<-NA_real_;d}
 base<-rd(file.path(P,'models/CHARLS_CORE_MI01/data.dat'),cols)
 map<-c(c1='age',c2='female',c3='edu',c4='urban',c5='partner',c6='nchild',c7='adl',c8='health2',c9='health3',c10='health4',c11='health5')
 for(n in names(map)){v<-z$data[[map[[n]]]];o<-!is.na(v);stopifnot(max(abs(base[[n]][o]-v[o]))<1e-10)}
 stopifnot(identical(as.numeric(base$cluster),as.numeric(z$data$cluster)),nrow(z$data)==3006L,length(unique(z$raw$fid))==3006L,!anyNA(z$raw$fid))
 inc<-z$raw$hh_income;cut<-median(inc,na.rm=TRUE);g<-ifelse(is.na(inc),NA_real_,as.numeric(inc>cut));stopifnot(cut==8730,identical(g,as.numeric(imp$data$g)),sum(is.na(g))==734L)
 obs_g<-!is.na(g);obs_a<-!is.na(z$data$adl);check<-list()
 for(k in 1:40){
  v<-complete(imp,k);d<-rd(file.path(ROOT,'private',sprintf('MI%02d.dat',k)),c(cols,'g'));expect<-base;expect$c7<-v$adl;expect$g<-v$g
  b<-as.matrix(expect);dd<-as.matrix(d);mask<-is.na(b);stopifnot(identical(dim(dd),dim(b)),identical(unname(is.na(dd)),unname(mask)));delta<-max(abs(dd[!mask]-b[!mask]));stopifnot(delta<1e-10)
  stopifnot(identical(as.numeric(v$g[obs_g]),g[obs_g]),identical(as.numeric(v$adl[obs_a]),as.numeric(z$data$adl[obs_a])),all(v$g%in%0:1),all(v$adl[!obs_a]%in%z$data$adl[obs_a]))
  for(n in names(a$passive))stopifnot(max(abs(v[[n]]-v[[a$passive[[n]][1]]]*v[[a$passive[[n]][2]]]))<1e-12)
  check[[k]]<-data.frame(member=k,N=nrow(d),communities=length(unique(d$cluster)),export_max_difference=delta,observed_income_group_unchanged=TRUE,observed_ADL_unchanged=TRUE,XY_and_other_controls_unchanged=TRUE,all_passive_products=TRUE,imputed_high_income=sum(v$g[!obs_g]),imputed_ADL_mean=mean(v$adl[!obs_a]),sha256=digest(file=file.path(ROOT,'private',sprintf('MI%02d.dat',k)),algo='sha256'))
 }
 tab<-do.call(rbind,check);write.csv(tab,file.path(ROOT,'audit/INDEPENDENT_MI_MEMBERS.csv'),row.names=FALSE)
 cc<-base;cc$c7<-z$data$adl;cc$g<-g;cc<-cc[obs_g&obs_a,];got<-rd(file.path(ROOT,'private/CC.dat'),c(cols,'g'));stopifnot(identical(dim(cc),dim(got)),identical(unname(is.na(as.matrix(cc))),unname(is.na(as.matrix(got)))),max(abs(as.matrix(cc)-as.matrix(got)),na.rm=TRUE)<1e-10)
 hashes<-fromJSON(file.path(ROOT,'audit/SOURCE_PREPARATION.json'))$source_hashes;for(p in names(hashes))stopifnot(digest(file=p,algo='sha256')==hashes[[p]])
 ans<-list(status='PASS',m=nrow(tab),N=nrow(base),communities=length(unique(base$cluster)),unique_retained_households=length(unique(z$raw$fid)),threshold=cut,missing_income_group=sum(!obs_g),missing_ADL=sum(!obs_a),both_missing=sum(!obs_g&!obs_a),observed_low=sum(g==0,na.rm=TRUE),observed_high=sum(g==1,na.rm=TRUE),negative_raw_income=sum(inc<0,na.rm=TRUE),zero_raw_income=sum(inc==0,na.rm=TRUE),max_export_difference=max(tab$export_max_difference),CC_N=nrow(cc),imputed_high_group_range=range(tab$imputed_high_income),original_sources_unchanged=TRUE,posterior_validity_or_MAR_not_proven=TRUE,new_engine_calls=0)
 write_json(ans,file.path(ROOT,'audit/INDEPENDENT_MI.json'),auto_unbox=TRUE,pretty=TRUE,digits=16);cat('INDEPENDENT_MI_PASS',toJSON(ans,auto_unbox=TRUE),'\n')
})
