# 完整核心队列收入分支的数据入口；只准备，不插补、不拟合。
local({
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_mean_income_20261017'
P<-'<LOCAL_USER>/pp_lgcm_review/charls_adjusted_h41_20261015'
library(jsonlite);library(digest)
for(d in c('private','audit','contracts','reports','runtime'))dir.create(file.path(ROOT,d),recursive=TRUE,showWarnings=FALSE)
stopifnot(!file.exists(file.path(ROOT,'audit/SOURCE_PREPARATION.json')))
src<-file.path(P,'private/charls_core_mi_inputs.rds');old<-file.path(P,'models/CHARLS_CORE_MI01/data.dat')
hashes<-setNames(vapply(c(src,old),function(p)digest(file=p,algo='sha256'),''),c(src,old))
z<-readRDS(src);cc<-z$data;inc<-z$raw$hh_income;cut<-median(inc,na.rm=TRUE)
stopifnot(nrow(cc)==3006L,cut==8730,sum(is.na(inc))==734L,sum(is.na(cc$adl))==20L,length(unique(cc$cluster))==440L)
g<-ifelse(is.na(inc),NA_integer_,as.integer(inc>cut))
analysis<-read.table(old,na.strings='-9999',col.names=c('cluster',paste0('x',1:5),paste0('y',1:5),paste0('c',1:11)))
stopifnot(nrow(analysis)==nrow(cc),identical(as.numeric(analysis$cluster),as.numeric(cc$cluster)))
observed<-!is.na(cc$adl);stopifnot(identical(as.numeric(analysis$c7[observed]),as.numeric(cc$adl[observed])))
original_analysis<-analysis;analysis$c7<-cc$adl;analysis$g<-g
stopifnot(identical(analysis[setdiff(names(original_analysis),'c7')],original_analysis[setdiff(names(original_analysis),'c7')]))
inputs<-list(controls_and_auxiliaries=cc,analysis_with_original_ADL_mask=analysis,income_group=g,income_raw=inc,income_missing=is.na(inc),adl_missing=is.na(cc$adl),threshold=cut,rule='income > fixed observed full-core median',source_hashes=hashes,mi_prepared=FALSE)
tmp<-file.path(ROOT,'private/SOURCE_INPUTS.rds.tmp');dest<-file.path(ROOT,'private/SOURCE_INPUTS.rds')
stopifnot(!file.exists(dest));saveRDS(inputs,tmp);stopifnot(file.rename(tmp,dest))
check<-readRDS(dest);stopifnot(identical(check,inputs),sum(is.na(check$analysis_with_original_ADL_mask$c7))==20L,sum(is.na(check$analysis_with_original_ADL_mask$g))==734L)
summary<-data.frame(variable=c('income_group','ADL','both'),missing=c(sum(is.na(g)),sum(is.na(cc$adl)),sum(is.na(g)&is.na(cc$adl))))
write.csv(summary,file.path(ROOT,'reports/MISSINGNESS.csv'),row.names=FALSE)
for(p in names(hashes))stopifnot(digest(file=p,algo='sha256')==hashes[[p]])
receipt<-list(status='SOURCE_PREPARED_NOT_IMPUTED',N=nrow(cc),communities=440,source_hashes=as.list(hashes),input_sha256=digest(file=dest,algo='sha256'),income_threshold=cut,operator='>',observed_low=sum(g==0,na.rm=TRUE),observed_high=sum(g==1,na.rm=TRUE),equal_to_threshold=sum(inc==cut,na.rm=TRUE),missing_income=sum(is.na(g)),missing_ADL=sum(is.na(cc$adl)),both_missing=sum(is.na(g)&is.na(cc$adl)),negative_observed=sum(inc<0,na.rm=TRUE),zero_observed=sum(inc==0,na.rm=TRUE),original_ADL_missing_mask_restored=TRUE,all_other_analysis_columns_unchanged=TRUE,new_MI=0L,new_Mplus=0L,source_files_unchanged=TRUE)
write_json(receipt,file.path(ROOT,'audit/SOURCE_PREPARATION.json'),auto_unbox=TRUE,pretty=TRUE)
writeLines(capture.output(sessionInfo()),file.path(ROOT,'audit/R_SESSION_INFO.txt'))
cat('CHARLS_MEAN_INCOME_SOURCE_READY N',receipt$N,'missing income',receipt$missing_income,'ADL',receipt$missing_ADL,'new_MI0 new_Mplus0\n')
})
