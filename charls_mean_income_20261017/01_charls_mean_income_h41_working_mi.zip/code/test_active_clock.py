"""真实Windows时钟接口 + 模拟33分钟主机暂停，不实际使电脑睡眠。"""
from pathlib import Path
import json,time
from active_clock import BudgetClock,parse_power_sleep
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1]
clock=BudgetClock();time.sleep(1.1);actual=clock.sample()
assert actual['active_seconds']>=1 and abs(actual['wall_seconds']-actual['active_seconds'])<.2
state={'a':0.,'w':0.};c=BudgetClock(lambda:state['a'],lambda:state['w'])
state.update(a=10.,w=1990.);paused=c.sample();assert not c.expired(120) and paused['excluded_suspend_seconds']==1980
state.update(a=121.,w=2101.);assert c.expired(120)
events=parse_power_sleep((R/'audit/WINDOWS_POWER_EVENTS.xml').read_text(encoding='utf-8-sig'),datetime(2026,10,18,1,43,54,tzinfo=timezone.utc),datetime(2026,10,18,2,17,40,tzinfo=timezone.utc))
sleep=sum(x['overlap_seconds'] for x in events);assert 1900<sleep<2000
record=dict(status='PASS',real_windows_API=actual,simulated_suspend=paused,actual_power_events=events,observed_sleep_seconds=sleep,active_timeout_still_enforced=True,actual_host_suspend_not_triggered=True,source='https://learn.microsoft.com/en-us/windows/win32/api/realtimeapiset/nf-realtimeapiset-queryunbiasedinterrupttime')
(R/'audit/ACTIVE_CLOCK_TEST.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record))
