# 只读完整家族结果，独立复算并生成图表/报告；不启动Mplus。
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_mean_income_20261017'
library(jsonlite);library(processx)
stopifnot(file.exists(file.path(ROOT,'audit/MODEL_FULL_TERMINAL.json')),fromJSON(file.path(ROOT,'audit/INDEPENDENT_MI.json'))$status=='PASS')
source(file.path(ROOT,'code/readback.R'),local=TRUE)
source(file.path(ROOT,'code/plot_results.R'),local=TRUE)
PY<-'<LOCAL_USER>/AppData/Local/Programs/Python/Python314/python.exe'
for(n in c('verify_results.py','build_delivery.py')){
 if(exists('clauder_progress',mode='function'))clauder_progress('postprocess',n)
 z<-processx::run(PY,c('-X','utf8',file.path(ROOT,'code',n)),timeout=900000,error_on_status=FALSE)
 writeLines(c(z$stdout,z$stderr),file.path(ROOT,'audit',paste0(n,'.log')));cat(z$stdout,z$stderr);stopifnot(z$status==0)
}
if(exists('clauder_progress',mode='function'))clauder_progress('CHARLS_INCOME_POSTPROCESS_DONE','raw results and contrasts independently verified; no new fits')
cat('CHARLS_INCOME_POSTPROCESS_DONE\n')
