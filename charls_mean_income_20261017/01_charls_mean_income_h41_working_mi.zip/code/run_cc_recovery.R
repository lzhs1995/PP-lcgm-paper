# 只执行被主机待机中断的A；保留合法B及旧中断记录。
local({
 ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_mean_income_20261017'
 library(processx);library(jsonlite);library(digest)
 PY<-'<LOCAL_USER>/AppData/Local/Programs/Python/Python314/python.exe'
 d<-file.path(ROOT,'models/CHARLS_INCOME_CC_MI00_A_RECOVERY');b<-file.path(ROOT,'models/CHARLS_INCOME_CC_MI00_B')
 out<-file.path(ROOT,'audit/MODEL_CC_RECOVERY_TERMINAL.json');stopifnot(!file.exists(out),!file.exists(file.path(d,'engine_receipt.json')))
 progress<-function(s,m){cat(s,m,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(s,m)}
 j<-fromJSON(file.path(d,'job.json'));for(n in names(j$hashes))stopifnot(j$hashes[[n]]==digest(file=file.path(d,n),algo='sha256'))
 br<-fromJSON(file.path(b,'receipt.json'));stopifnot(br$status=='USABLE',digest(file=file.path(b,'model.out'),algo='sha256')==br$output_sha256)
 p<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/model_engine.py'),file.path(d,'job.json')),stdout=file.path(d,'supervisor.log'),stderr='2>&1',cleanup=FALSE)
 progress('CC_HOST_RECOVERY','exact interrupted A input; valid B reused')
 while(p$is_alive())p$wait(1000L)
 stopifnot(file.exists(file.path(d,'engine_receipt.json')))
 z<-processx::run(PY,c('-X','utf8',file.path(ROOT,'code/models.py'),'normalize',d),timeout=30000,error_on_status=FALSE);writeLines(c(z$stdout,z$stderr),file.path(d,'readback.log'));stopifnot(z$status==0)
 ar<-fromJSON(file.path(d,'receipt.json'),simplifyVector=FALSE);pass<-ar$status=='USABLE';ap<-file.path(ROOT,'results/CC_RECOVERED_START_AGREEMENT.json')
 if(pass){z<-processx::run(PY,c('-X','utf8',file.path(ROOT,'code/models.py'),'agree',d,b,ap),timeout=30000,error_on_status=FALSE);writeLines(c(z$stdout,z$stderr),file.path(ROOT,'audit/CC_recovered_agreement.log'));stopifnot(z$status==0);pass<-isTRUE(fromJSON(ap)$passed)}
 write_json(list(status=if(pass)'CC_SENSITIVITY_USABLE' else 'CC_SENSITIVITY_NOT_ADOPTED',passed=pass,a=ar,b_reused=br,full_MI=FALSE,supersedes_decision_only='MODEL_CC_TERMINAL.json; historical artifacts retained'),out,auto_unbox=TRUE,pretty=TRUE,digits=16)
 progress('CC_RECOVERY_DONE',paste(ar$status,'agreement',pass))
})
