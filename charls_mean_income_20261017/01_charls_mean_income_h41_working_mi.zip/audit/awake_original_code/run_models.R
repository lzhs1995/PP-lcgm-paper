# 两个有界阶段：完整案例敏感性；插补通过后完整40成员家族。
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_mean_income_20261017';stopifnot(exists('MODEL_PHASE'),MODEL_PHASE%in%c('CC','FULL'))
RUN_TAG<-if(exists('MODEL_RUN_ID'))MODEL_RUN_ID else MODEL_PHASE
.libPaths(c('<LOCAL_USER>/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
library(jsonlite);library(processx);library(ps);library(digest)
PY<-'<LOCAL_USER>/AppData/Local/Programs/Python/Python314/python.exe'
rj<-function(p)if(file.exists(p))fromJSON(p,simplifyVector=FALSE)else NULL
wj<-function(x,p)write_json(x,p,auto_unbox=TRUE,pretty=TRUE,digits=16)
progress<-function(s,m){cat(s,m,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(s,m)}
py<-function(script,args,log){z<-processx::run(PY,c('-X','utf8',file.path(ROOT,'code',script),args),error_on_status=FALSE,timeout=120000);writeLines(c(z$stdout,z$stderr),log);if(z$status!=0)stop('stage failed: ',log);z}
run_one<-function(g,k,st){
 id<-sprintf('CHARLS_INCOME_%s_MI%02d_%s',g,k,st);d<-file.path(ROOT,'models',id)
 if(file.exists(file.path(d,'receipt.json'))){rr<-rj(file.path(d,'receipt.json'));j<-rj(file.path(d,'job.json'));stopifnot(rr$output_sha256==digest(file=file.path(d,'model.out'),algo='sha256'));for(n in names(j$hashes))stopifnot(j$hashes[[n]]==digest(file=file.path(d,n),algo='sha256'));progress('reuse_adjudicated',id);return(rr)}
 if(!file.exists(file.path(d,'job.json')))py('models.py',c('prepare',g,as.character(k),st),file.path(ROOT,'audit',paste0(id,'_prepare.log')))
 else{j<-rj(file.path(d,'job.json'));stopifnot(!file.exists(file.path(d,'model.out')),!file.exists(file.path(d,'engine_receipt.json')));for(n in names(j$hashes))stopifnot(j$hashes[[n]]==digest(file=file.path(d,n),algo='sha256'))}
 j<-rj(file.path(d,'job.json'));j$rscript<-file.path(R.home('bin'),'Rscript.exe');wj(j,file.path(d,'job.json'))
 p<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/model_engine.py'),file.path(d,'job.json')),stdout=file.path(d,'supervisor.log'),stderr='2>&1',cleanup=FALSE);last<-0
 while(p$is_alive()){p$wait(1000L);if(as.numeric(Sys.time())-last>25){h<-rj(file.path(ROOT,'runtime/progress.json'));progress('estimating',paste(id,h$stage));last<-as.numeric(Sys.time())}}
 if(!file.exists(file.path(d,'engine_receipt.json')))return(list(id=id,dest=d,group=g,member=k,start=st,status='NOT_STARTED',not_run=rj(file.path(d,'not_run.json'))))
 py('models.py',c('normalize',d),file.path(d,'readback.log'));rr<-rj(file.path(d,'receipt.json'));progress('adjudicated',paste(id,rr$status));rr
}
main<-function(){
 stopifnot(!file.exists(file.path(ROOT,'audit',paste0('MODEL_',MODEL_PHASE,'_TERMINAL.json'))))
 own<-list(pid=Sys.getpid(),created=as.numeric(ps::ps_create_time(ps::ps_handle())));op<-file.path(ROOT,'runtime',paste0('MODEL_OWNER_',RUN_TAG,'.json'));wj(list(owner=own),op)
 awakepath<-file.path(ROOT,'runtime',paste0('awake_',RUN_TAG));dir.create(awakepath,showWarnings=FALSE)
 aw<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/windows_awake_guard.py'),'--owner-file',op,'--output',awakepath,'--interval','5'),stdout=file.path(ROOT,'runtime',paste0('awake_',RUN_TAG,'.log')),stderr='2>&1',cleanup=FALSE)
 on.exit({writeLines('release',file.path(awakepath,'stop.request'));aw$wait(8000L)},add=TRUE)
 attempts<-rj(file.path(ROOT,'results/ATTEMPTS.json'));if(is.null(attempts))attempts<-list()
 save_attempt<-function(rr){attempts[[rr$id]]<<-rr;wj(attempts,file.path(ROOT,'results/ATTEMPTS.json'))}
 if(MODEL_PHASE=='CC'){
  aa<-run_one('CC',0,'A');save_attempt(aa)
  if(aa$status=='NOT_STARTED')stop('CC resource hold; no estimation failure')
  bb<-run_one('CC',0,'B');save_attempt(bb)
  if(bb$status=='NOT_STARTED')stop('CC B resource hold; no estimation failure')
  pass<-aa$status=='USABLE'&&bb$status=='USABLE'
  if(pass){p<-file.path(ROOT,'results/CC_START_AGREEMENT.json');py('models.py',c('agree',aa$dest,bb$dest,p),file.path(ROOT,'audit/CC_agreement.log'));pass<-isTRUE(rj(p)$passed)}
  wj(list(status=if(pass)'CC_SENSITIVITY_USABLE' else 'CC_SENSITIVITY_NOT_ADOPTED',passed=pass,a=aa,b=bb,full_MI=FALSE),file.path(ROOT,'audit/MODEL_CC_TERMINAL.json'))
 }else{
  stopifnot(rj(file.path(ROOT,'audit/MI_ADMISSION.json'))$status=='ADMITTED_WORKING_MI')
  f<-list(group='INCOME',status='STARTING',complete_MI=FALSE,usable_members=0L,planned_members=40L)
  parent<-run_one('PARENT',1,'A');save_attempt(parent)
  if(parent$status=='NOT_STARTED')stop('Parent resource hold; no estimation failure')
  if(parent$status!='USABLE'){f$status<-'PARENT_INADMISSIBLE'}else{
   aa<-run_one('INCOME',1,'A');save_attempt(aa)
   if(aa$status=='NOT_STARTED')stop('MI01 resource hold')
   if(aa$status!='USABLE')f$status<-'FIRST_MEMBER_INADMISSIBLE' else{
    bb<-run_one('INCOME',1,'B');save_attempt(bb)
    if(bb$status=='NOT_STARTED')stop('MI01 B resource hold')
    if(bb$status!='USABLE')f$status<-'SECOND_START_INADMISSIBLE' else{
     p<-file.path(ROOT,'results/INCOME_START_AGREEMENT.json');py('models.py',c('agree',aa$dest,bb$dest,p),file.path(ROOT,'audit/INCOME_agreement.log'))
     if(!isTRUE(rj(p)$passed))f$status<-'START_DISAGREEMENT' else{
      members<-list(aa);f$usable_members<-1L;f$status<-'EXTENDING_MI'
      for(k in 2:40){rr<-run_one('INCOME',k,'A');save_attempt(rr);if(rr$status=='NOT_STARTED')stop('Unstarted MI resource hold');if(rr$status!='USABLE'){f$status<-'MI_FAMILY_INCOMPLETE';f$failed_member<-k;break};members[[k]]<-rr;f$usable_members<-k;wj(list(INCOME=f),file.path(ROOT,'results/FAMILY_STATUS.json'))}
      f$member_paths<-vapply(members,function(x)x$dest,'');f$complete_MI<-f$usable_members==40L;if(f$complete_MI)f$status<-'COMPLETE_CONDITIONAL_WORKING_MI'
     }
    }
   }
  }
  wj(list(INCOME=f),file.path(ROOT,'results/FAMILY_STATUS.json'));source(file.path(ROOT,'code/pool_results.R'),local=TRUE)
  wj(list(status='INCOME_FAMILY_ADJUDICATED',family=f,budget=rj(file.path(ROOT,'runtime/budget_status.json')),original_four_complete=FALSE,full_H4_complete=FALSE),file.path(ROOT,'audit/MODEL_FULL_TERMINAL.json'))
 }
 progress('CHARLS_INCOME_MODELS_DONE',MODEL_PHASE);cat('CHARLS_INCOME_MODELS_DONE\n')
}
main()
