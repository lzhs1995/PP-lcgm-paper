"""仅恢复未启动引擎的资源拒绝；保持统计规格和有限调用合同。"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil
r=Path(__file__).resolve().parents[1];old=r.parent/'charls_latent_em_only_20261019'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
id='E1_EM_Q15_A';source=old/'models'/id
assert read(source/'LAUNCH_RECEIPT.json')['actual_engine_calls']==0
assert read(source/'receipt.json')['status']=='NOT_RUN_RESOURCE_HOLD'
assert not (source/'execution').exists()
for name in ['audit','contracts','models','results','runtime','reports']:(r/name).mkdir(exist_ok=True)
assert not (r/'contracts/RUN_CONTRACT.json').exists()
for name in ['adapter.py','bounded_child.py','harness.py','r2e_tools.R','r2e_upstream_math.R','raw_tech1.py','parse_trace.py']:
    shutil.copyfile(old/'code'/name,r/'code'/name)
text=(old/'code/run_calibration.R').read_text(encoding='utf-8')
(r/'code/run_calibration.R').write_text(text.replace(old.as_posix(),r.as_posix()),encoding='utf-8')
d=r/'models'/id;d.mkdir()
for name in ['model.inp','data.dat','job.json']:shutil.copyfile(source/name,d/name)
(d/'launch.cmd').write_text((source/'launch.cmd').read_text().replace(old.as_posix(),r.as_posix()))
for name in ['E0_CALIBRATION.json']:shutil.copyfile(old/'results'/name,r/'results'/name)
for name in ['NATIVE_PROOF.json','DOCTOR.json','PARENT_INDEPENDENT_READBACK.json']:shutil.copyfile(old/'audit'/name,r/'audit'/name)
c=read(old/'contracts/RUN_CONTRACT.json');c.update(recovery_of=str(old),recovery_reason='Previous attempt consumed zero engine calls; reclaim verified idle owned UI before one re-admission',same_logical_engine_cap=True)
(r/'contracts/RUN_CONTRACT.json').write_text(json.dumps(c,indent=2))
(r/'audit/RECOVERY_IDENTITY.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),previous_engine_calls=0,max_total_em_calls=1,input_sha256=sha(d/'model.inp'),source_input_sha256=sha(source/'model.inp'),data_sha256=sha(d/'data.dat'),source_data_sha256=sha(source/'data.dat'),previous_receipt_sha256=sha(source/'LAUNCH_RECEIPT.json'),specification_changed=False),indent=2))
assert sha(d/'model.inp')==sha(source/'model.inp') and sha(d/'data.dat')==sha(source/'data.dat')
(r/'audit/CODE_MANIFEST.json').write_text(json.dumps({p.name:sha(p) for p in (r/'code').glob('*') if p.is_file()},indent=2))
print('RECOVERY_PREPARED same input/data; previous actual engines 0; remaining EM budget 1 x 240 seconds')
