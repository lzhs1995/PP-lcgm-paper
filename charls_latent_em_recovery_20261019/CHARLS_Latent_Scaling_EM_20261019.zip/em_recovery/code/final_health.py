"""Windows 同句柄退出核验；可查询 PID 本身并非存活证据。"""
from pathlib import Path
from datetime import datetime,timezone
from ctypes import wintypes as w
import ctypes,json,sys,psutil
r=Path(__file__).resolve().parents[1]
sys.path.insert(0,'C:/Users/RESEARCH_USER/Desktop/cnm/tasks/01_R_analysis/work/ch4_archived_replay_20261016')
from windows_process_terminal import process_state
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
lease=r/'audit/cc_memory_lease';restore=read(lease/'RESTORED.json')
children=read(lease/'INTENT.json')['children']
rows=[process_state(x['pid'],x['created']) for x in children]
protected=[process_state(8764,1792308599.6514845),process_state(18112,1792308603.0035183)]
engine=read(r/'audit/LIVE_OBSERVATION.json')['models'][0]['owned_direct_children'][0]
owned=[process_state(engine['pid'],engine['created']),process_state(read(r/'audit/EXECUTION_RUNTIME.json')['pid'])]
user=ctypes.WinDLL('user32',use_last_error=True);cbtype=ctypes.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
user.EnumWindows.argtypes=[cbtype,w.LPARAM];user.GetWindowThreadProcessId.argtypes=[w.HWND,ctypes.POINTER(w.DWORD)]
user.GetWindowTextW.argtypes=[w.HWND,w.LPWSTR,ctypes.c_int];user.IsWindowVisible.argtypes=[w.HWND];user.ShowWindow.argtypes=[w.HWND,ctypes.c_int]
windows=[]
@cbtype
def cb(hwnd,_):
    pid=w.DWORD();user.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
    if pid.value==restore['pid']:
        buf=ctypes.create_unicode_buffer(512);user.GetWindowTextW(hwnd,buf,512)
        if buf.value:
            before=bool(user.IsWindowVisible(hwnd))
            if not before:user.ShowWindow(hwnd,5)
            windows.append(dict(title=buf.value,visible_before=before,visible_after=bool(user.IsWindowVisible(hwnd))))
    return True
assert process_state(restore['pid'],restore['created'])['state']=='active'
user.EnumWindows(cb,0)
mplus=[dict(pid=p.pid,created=p.create_time()) for p in psutil.process_iter(['name']) if (p.info['name'] or '').lower()=='mplus.exe' and process_state(p.pid)['state']=='active']
out=dict(at=datetime.now(timezone.utc).isoformat(),old_webview_states=rows,protected=protected,owned=owned,restored_manager=restore,restored_windows=windows,active_mplus=mplus,available_gib=psutil.virtual_memory().available/2**30)
out['passed']=all(x['state']=='active' for x in protected) and all(x['state'] in ['exited','absent','reused'] for x in owned) and not mplus and any(x['visible_after'] for x in windows)
p=r/'audit/FINAL_PROCESS_HEALTH.json';assert not p.exists();p.write_text(json.dumps(out,indent=2));print(json.dumps(out));assert out['passed']
