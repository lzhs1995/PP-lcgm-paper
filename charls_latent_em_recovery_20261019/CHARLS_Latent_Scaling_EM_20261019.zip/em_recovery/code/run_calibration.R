# 在原生ClaudeR后台worker一次加载，先校准后才尝试一个潜变量交互。
local({
 ROOT<-'C:/Users/RESEARCH_USER/pp_lgcm_review/charls_latent_em_recovery_20261019'
 .libPaths(c('C:/Users/RESEARCH_USER/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
 library(jsonlite)
 wj<-function(x,p)write_json(x,p,auto_unbox=TRUE,pretty=TRUE,digits=NA,null='null')
 say<-function(stage,message){cat(format(Sys.time(),tz='UTC'),stage,message,'\n');flush.console();
  if(exists('clauder_progress',mode='function',inherits=TRUE))clauder_progress(stage,message)
  wj(list(stage=stage,message=message,at=format(Sys.time(),tz='UTC')),file.path(ROOT,'runtime/PROGRESS.json'))}
 begin<-Sys.time();say('LOADING','One worker, MplusAutomation plus existing output validator')
 Sys.setenv(OPENBLAS_NUM_THREADS=1,MKL_NUM_THREADS=1,OMP_NUM_THREADS=4,R2E_ROOT=ROOT)
 library(MplusAutomation);library(ps);library(digest)
 ps_set_cpu_affinity(ps_handle(),8:11)
 source(file.path(ROOT,'code/r2e_tools.R'),local=TRUE)
 wj(list(pid=Sys.getpid(),version=as.character(packageVersion('MplusAutomation')),package_path=find.package('MplusAutomation'),loading_seconds=as.numeric(difftime(Sys.time(),begin,units='secs'))),file.path(ROOT,'audit/EXECUTION_RUNTIME.json'))
 con<-fromJSON(file.path(ROOT,'contracts/RUN_CONTRACT.json'));stopifnot(!file.exists(file.path(ROOT,'runtime/ATTEMPT_RESERVED')))
 writeLines('one coordinator submission',file.path(ROOT,'runtime/ATTEMPT_RESERVED'))
 FAC<-c('IX','SX','IY','SY','IZ','SZ');OBS<-c(paste0('X',1:5),paste0('Y',1:5),paste0('Z',1:5))
 canon<-function(p)vapply(seq_len(nrow(p)),function(i){a<-toupper(p$row[i]);b<-toupper(p$column[i]);mat<-tolower(p$matrix[i]);
  if(mat%in%c('psi','theta')){s<-sort(c(a,b));a<-s[1];b<-s[2]};paste(mat,a,b,sep=':')},'')
 results<-list()
 run_one<-function(id){
  d<-file.path(ROOT,'models',id);j<-fromJSON(file.path(d,'job.json'));say('RUNMODELS',id)
  warn<-character();err<-NULL;at<-Sys.time()
  withCallingHandlers(tryCatch(MplusAutomation::runModels(target=file.path(d,'model.inp'),recursive=FALSE,showOutput=TRUE,replaceOutfile='never',Mplus_command=file.path(d,'launch.cmd'),killOnFail=FALSE,logFile=file.path(d,'MplusAutomation.log')),error=function(e)err<<-conditionMessage(e)),warning=function(w){warn<<-c(warn,conditionMessage(w));invokeRestart('muffleWarning')})
  wj(list(error=err,warnings=warn,seconds=as.numeric(difftime(Sys.time(),at,units='secs'))),file.path(d,'R_WRAPPER_RETURN.json'))
  if(!file.exists(file.path(d,'LAUNCH_RECEIPT.json')))stop('Missing launcher receipt; do not resubmit')
  e<-fromJSON(file.path(d,'LAUNCH_RECEIPT.json'));ans<-list(id=id,accepted=FALSE,complete_MI=FALSE,engine=e)
  if(identical(e$status,'NOT_RUN_RESOURCE_HOLD')){ans$status<-e$status;wj(ans,file.path(d,'receipt.json'));return(ans)}
  if(e$state!='EXITED'||e$exitcode!=0||!isTRUE(e$process_exited)){ans$status<-paste0('ENGINE_',e$state);wj(ans,file.path(d,'receipt.json'));return(ans)}
  say('READBACK',id)
  tryCatch({
   m<-read_mplus_raw(d);stopifnot(identical(as.integer(m$par$parameter),seq_len(m$P)));si<-list(kind=if(grepl('E1',id))'lms_latent'else'linear',fac=FAC,obs=OBS,fixed_zero=character())
   gate<-gate_r2e(m,si);native<-MplusAutomation::readModels(file.path(d,'model.out'),what='summaries',quiet=TRUE)
   write.csv(m$par,file.path(d,'parameters_high_precision.csv'),row.names=FALSE);write.csv(m$spec,file.path(d,'tech1_parameter_map.csv'),row.names=FALSE)
   write.csv(m$values,file.path(d,'matrix_values.csv'),row.names=FALSE);write.table(m$V,file.path(d,'parameter_covariance.csv'),sep=',',row.names=FALSE,col.names=FALSE)
   wj(gate,file.path(d,'validation.json'));wj(native$summaries,file.path(d,'fit.json'))
   ans$LL<-m$extra[['H0 Loglikelihood']];ans$N<-native$summaries$Observations;ans$free_parameters<-m$P;ans$negative<-gate$negative
   ans$accepted<-isTRUE(gate$passed)&&ans$N==j$N&&m$P==j$expected_free&&!any(grepl('FIXED TO AVOID SINGULARITY',m$lines,fixed=TRUE))
   ans$status<-if(ans$accepted)'USABLE_SINGLE_CC_DIAGNOSTIC'else'INADMISSIBLE_OR_CONTRACT_FAILURE'
   if(ans$accepted && id=='E0_SCALE'){
    old<-read.csv(file.path(con$source_parent,'parameters_high_precision.csv'));ref<-fromJSON(file.path(con$source_parent,'receipt.json'))
    stopifnot(identical(as.integer(old$parameter),seq_len(m$P)))
    map<-read.csv(file.path(ROOT,'audit/PARENT_TRANSFORM.csv'));idx<-match(canon(old),canon(m$par));ji<-match(canon(old),canon(map))
    stopifnot(!anyNA(idx),!anyNA(ji),!anyDuplicated(canon(m$par)),nrow(old)==m$P)
    jac<-map$jacobian_diagonal[ji];q<-m$par$estimate[idx]/jac;s<-m$par$se[idx]/jac
    V0<-as.matrix(read.csv(file.path(con$source_parent,'parameter_covariance.csv'),header=FALSE));V<-m$V[idx,idx]/outer(jac,jac)
    checks<-list(LL=abs(ans$LL-ref$LL),parameter_over_SE=max(abs(q-old$estimate)/old$se),SE_relative=max(abs(s-old$se)/old$se),normalized_vcov=max(abs(V-V0)/sqrt(outer(diag(V0),diag(V0)))))
    tt<-con$tolerances;passed<-checks$LL<=tt$LL_absolute&&checks$parameter_over_SE<=tt$parameter_difference_in_reference_SE&&checks$SE_relative<=tt$SE_relative&&checks$normalized_vcov<=tt$normalized_vcov_difference
    wj(list(passed=passed,checks=checks,tolerances=tt,all_free_parameters=m$P,source_output_sha256=digest::digest(file=file.path(con$source_parent,'model.out'),algo='sha256')),file.path(ROOT,'results/E0_CALIBRATION.json'))
    write.csv(data.frame(key=canon(old),reference_estimate=old$estimate,back_estimate=q,reference_se=old$se,back_se=s,jacobian=jac),file.path(ROOT,'results/E0_PARAMETER_COMPARISON.csv'),row.names=FALSE)
    if(!passed){ans$accepted<-FALSE;ans$status<-'EQUIVALENCE_CALIBRATION_FAILED'}
   }
  },error=function(x){ans$status<<-'READBACK_FAILURE';ans$error<<-conditionMessage(x);ans$accepted<<-FALSE})
  if(file.exists(file.path(d,'model.out')))ans$output_sha256<-digest::digest(file=file.path(d,'model.out'),algo='sha256')
  wj(ans,file.path(d,'receipt.json'));ans
 }
 for(id in con$sequence){a<-run_one(id);results[[id]]<-a;wj(results,file.path(ROOT,'results/CALL_RESULTS.json'));say('MODEL_TERMINAL',paste(id,a$status));if(!a$accepted)break}
 wj(list(terminal=TRUE,calls=results,full_MI=FALSE,original_four_complete=FALSE,full_H4_complete=FALSE),file.path(ROOT,'results/BATCH_RECEIPT.json'))
 say('SCALING_BATCH_TERMINAL','Read individual results; a single CC interaction is not full inference');cat('SCALING_BATCH_DONE\n')
})
