"""撤回刚才窗口恢复时对自有输入法辅助窗口的过宽显示操作。"""
from pathlib import Path
import ctypes,json
from ctypes import wintypes as w
import psutil
r=Path(__file__).resolve().parents[1];j=json.loads((r/'audit/FINAL_PROCESS_HEALTH.json').read_text());m=j['restored_manager']
assert abs(psutil.Process(m['pid']).create_time()-m['created'])<.001
targets={x['title'] for x in j['restored_windows'] if not x['visible_before'] and x['title']!='CC Switch'}
u=ctypes.WinDLL('user32',use_last_error=True);cbtype=ctypes.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
u.EnumWindows.argtypes=[cbtype,w.LPARAM];u.GetWindowThreadProcessId.argtypes=[w.HWND,ctypes.POINTER(w.DWORD)]
u.GetWindowTextW.argtypes=[w.HWND,w.LPWSTR,ctypes.c_int];u.ShowWindow.argtypes=[w.HWND,ctypes.c_int];u.IsWindowVisible.argtypes=[w.HWND]
rows=[]
@cbtype
def cb(hwnd,_):
    pid=w.DWORD();u.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
    if pid.value==m['pid']:
        b=ctypes.create_unicode_buffer(512);u.GetWindowTextW(hwnd,b,512)
        if b.value in targets:u.ShowWindow(hwnd,0);rows.append(dict(title=b.value,visible=bool(u.IsWindowVisible(hwnd))))
    return True
u.EnumWindows(cb,0);assert {x['title'] for x in rows}==targets and not any(x['visible'] for x in rows)
(r/'audit/AUXILIARY_VISIBILITY_RESTORED.json').write_text(json.dumps(dict(status='PASS_OWN_VISIBILITY_CORRECTION',windows=rows),indent=2));print('PASS_OWN_VISIBILITY_CORRECTION')
