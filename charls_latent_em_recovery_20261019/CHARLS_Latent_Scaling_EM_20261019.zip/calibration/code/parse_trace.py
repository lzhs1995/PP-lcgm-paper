"""读取Mplus屏幕迭代轨迹；不据此判定模型收敛或数值合法。"""
import re
HEADER = re.compile(r'\bITER\s+LOGLIKELIHOOD\s+ABS CHANGE\s+REL CHANGE\s+ALGO\s+TIME\s+TOTAL TIME\b')
ROW = re.compile(r'^\s*(\d+)\s+([-+]?\d+\.\d+[DE][-+]?\d+)\s+([-+]?\d+\.\d+)\s+([-+]?\d+\.\d+)\s+(\w+)\s+([\d.]+)\s+([\d.]+)\s*$',re.M)
def parse_trace(raw, final=False):
    text=raw.decode('utf-8',errors='replace') if isinstance(raw,bytes) else raw
    if not final and text and not text.endswith(('\n','\r')):
        text=text.rsplit('\n',1)[0] if '\n' in text else ''
    header=HEADER.search(text)
    if not header:return []
    return [dict(iteration=int(m[0]),loglikelihood=float(m[1].replace('D','E')),
                 absolute_change=float(m[2]),relative_change=float(m[3]),algorithm=m[4],
                 step_seconds=float(m[5]),total_seconds=float(m[6])) for m in ROW.findall(text[header.end():])]
