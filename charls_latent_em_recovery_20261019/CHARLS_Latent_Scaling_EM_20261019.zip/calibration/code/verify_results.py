"""直接读原始TECH1/RESULTS/TECH3复核；不调用Mplus。"""
from pathlib import Path
import csv,hashlib,json,os,re,sys
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
import numpy as np
from raw_tech1 import tech1
r=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
contract=read(r/'contracts/RUN_CONTRACT.json');ref=r/'source_parent' if (r/'source_parent').exists() else r.parent/'source_parent' if (r.parent/'source_parent').exists() else Path(contract['source_parent'])
def read_model(d):
 text=(d/'model.out').read_text(encoding='latin1');mapping=tech1(text);n=max(v[3] for v in mapping)
 assert set(v[3] for v in mapping if v[3])==set(range(1,n+1))
 a=np.fromstring((d/'estimates.dat').read_text(),sep=' ');t=np.fromstring((d/'tech3.dat').read_text(),sep=' ')
 assert len(a)>=2*n and len(t)==n*(n+1)//2
 V=np.zeros((n,n));V[np.tril_indices(n)]=t;V=V+V.T-np.diag(V.diagonal())
 assert np.allclose(np.sqrt(V.diagonal()),a[n:2*n],rtol=1e-6,atol=1e-8)
 p=list(csv.DictReader((d/'parameters_high_precision.csv').open()));assert len(p)==n
 assert np.allclose([float(x['estimate']) for x in p],a[:n],rtol=0,atol=1e-12)
 assert np.allclose([float(x['se']) for x in p],a[n:2*n],rtol=0,atol=1e-12)
 assert np.allclose(np.loadtxt(d/'parameter_covariance.csv',delimiter=','),V,rtol=1e-12,atol=1e-12)
 def canon(mat,row,col):
  if mat.lower() in ['theta','psi']:row,col=sorted([row.upper(),col.upper()])
  return (mat.lower(),row.upper(),col.upper())
 keys=[canon(x['matrix'],x['row'],x['column']) for x in p];assert len(set(keys))==n
 for i,k in enumerate(keys):assert {z[3] for z in mapping if z[3] and canon(*z[:3])==k}=={i+1}
 assert 'THE MODEL ESTIMATION TERMINATED NORMALLY' in text and '*** ERROR' not in text
 return keys,a[:n],a[n:2*n],V,a[2*n+1]
rk,rq,rs,rV,rLL=read_model(ref);result=[]
for case in contract['sequence']:
 d=r/'models'/case;rec=d/'receipt.json'
 if not rec.exists():continue
 a=read(rec);e=read(d/'LAUNCH_RECEIPT.json')
 assert e['input_sha256']==sha(d/'model.inp') if 'input_sha256' in e else e['actual_engine_calls']==0
 if (d/'data.dat').exists():assert sha(d/'data.dat')==contract['source_data_sha256']
 for stream in ['stdout','stderr']:
  if (d/'execution'/f'{stream}.log').exists():assert sha(d/'execution'/f'{stream}.log')==e[stream+'_sha256']
 item=dict(id=case,status=a['status'],accepted=a['accepted'])
 if a['accepted']:
  keys,q,se,V,LL=read_model(d);item['parameters']=len(keys)
  if case=='E0_SCALE':
   assert set(keys)==set(rk) and len(keys)==126
   ix=[keys.index(k) for k in rk]
   def scale(name):return 9. if name in ['SX','SY','SZ'] else 1.
   def jac(k):
    m,row,col=k
    return 1/scale(col) if m=='lambda' else scale(row)/scale(col) if m=='beta' else scale(row)*scale(col) if m=='psi' else scale(col) if m=='alpha' else 1.
   J=np.array([jac(k) for k in rk]);back=q[ix]/J;backse=se[ix]/J;backV=V[np.ix_(ix,ix)]/np.outer(J,J)
   checks=dict(LL=float(abs(LL-rLL)),parameter_over_SE=float(max(abs(back-rq)/rs)),SE_relative=float(max(abs(backse-rs)/rs)),normalized_vcov=float(np.max(abs(backV-rV)/np.sqrt(np.outer(rV.diagonal(),rV.diagonal())))))
   rr=read(r/'results/E0_CALIBRATION.json');assert rr['passed']
   for k,v in checks.items():assert abs(v-rr['checks'][k])<1e-8,(k,v,rr['checks'][k])
   item['independent_comparison']=checks
 else:
  assert a['status'] in ['ENGINE_TIMEOUT','NOT_RUN_RESOURCE_HOLD','INADMISSIBLE_OR_CONTRACT_FAILURE','EQUIVALENCE_CALIBRATION_FAILED','READBACK_FAILURE']
 result.append(item)
out=dict(status='PASS_INDEPENDENT_RAW_READBACK',models=result,new_MI=0,full_moderation_inference=False,full_H4=False)
print(json.dumps(out))
