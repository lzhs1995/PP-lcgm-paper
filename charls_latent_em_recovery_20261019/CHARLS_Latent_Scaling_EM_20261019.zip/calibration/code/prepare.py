"""仅从已验收父模型生成等价量纲校准；源文件只读。"""
from pathlib import Path
import csv,datetime,hashlib,json,shutil
r=Path(__file__).resolve().parents[1];base=r.parent
src=base/'charls_corrected_latent_feasibility_20261018/models/CHARLS_LATENT_SD_E0_LATENT_BASIS_A'
sc=base/'charls_latent_scaling_readback_20261019';b=base/'mplus_bounded_adapter_20261019'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['audit','contracts','models','results','runtime','reports']:(r/name).mkdir(exist_ok=True)
assert not (r/'contracts/RUN_CONTRACT.json').exists()
proof=json.loads((sc/'results/VALIDATION.json').read_text());assert proof['status']=='PASS_SAVED_PARENT_LINEAR_TRANSFORM'
for f,h in proof['sources'].items():assert sha(src/f)==h
sj=json.loads((src/'job.json').read_text());assert sha(src/'data.dat')==sj['hashes']['data.dat']
for f in ['bounded_child.py','harness.py']:shutil.copyfile(b/'code'/f,r/'code'/f)
for f in ['r2e_tools.R','r2e_upstream_math.R']:shutil.copyfile(base/'charls_latent_integration_calibration_20261018/code'/f,r/'code'/f)
shutil.copyfile(sc/'results/PARAMETER_TRANSFORM.csv',r/'audit/PARENT_TRANSFORM.csv')
shutil.copyfile(sc/'results/VALIDATION.json',r/'audit/SCALING_BASIS.json')
rows=list(csv.DictReader((sc/'results/PARAMETER_TRANSFORM.csv').open()));starts=[]
for p in rows:
 v=format(float(p['transformed_estimate']),'.14g');a=p['row'].lower();c=p['column'].lower();m=p['matrix']
 if m=='alpha':s=f'[{c}*{v}];'
 elif m=='beta':s=f'{a} ON {c}*{v};'
 elif m=='lambda':s=f'{c} BY {a}*{v};'
 elif m in ['theta','psi']:s=f'{a}*{v};' if a==c else f'{a} WITH {c}*{v};'
 else:raise ValueError(m)
 starts.append(s)
original=(src/'model.inp').read_text();core=original.split('sz BY z2*',1)[0]
assert core.count('MODEL:')==1 and len(starts)==126
for p in ['x','y','z']:
 for k,t in [(2,2),(3,4),(4,7),(5,9)]:
  sign='*' if p=='z' and k<5 else '@'
  old=f'{p}{k}{sign}{t}';new=f'{p}{k}{sign}{t/9:.14g}';assert old in core;core=core.replace(old,new)
fixed='iy WITH ix@0 iz@0 sy@0;\nsy WITH ix@0 sx@0 iz@0 sz@0;\n'
tail='OUTPUT: TECH1 TECH3 TECH4 TECH8 SVALUES CINTERVAL;\nSAVEDATA: RESULTS=estimates.dat; TECH3=tech3.dat;\n'
jobs={}
for case,cap in [('E0_SCALE',120),('E1_SCALE_Q15_A',240)]:
 d=r/'models'/case;d.mkdir();c=core.replace(core.splitlines()[0],f'TITLE: {case} restricted CC equivalent time units;')
 if case.startswith('E1'):
  c=c.replace('TYPE=COMPLEX; ESTIMATOR=MLR; PROCESSORS=1;','TYPE=COMPLEX RANDOM; ESTIMATOR=MLR; PROCESSORS=4;\nALGORITHM=INTEGRATION; INTEGRATION=15; MCSEED=26101891;')
  c=c.replace('ITERATIONS=2000; COVERAGE=.005;','ITERATIONS=2000; MITERATIONS=4000; COVERAGE=.005;\nLOGCRITERION=.00001; RLOGCRITERION=.000000001; MCONVERGENCE=.00001;')
  c+='sxiz | sx XWITH iz;\nsy ON sxiz (dc);\n'
 c+='\n'.join(starts)+'\n'+('sy ON sxiz*0.1;\n' if case.startswith('E1') else '')+fixed+tail
 assert max(map(len,c.splitlines()))<=90
 (d/'model.inp').write_text(c,encoding='ascii');shutil.copyfile(src/'data.dat',d/'data.dat')
 j=dict(id=case,kind='licensed_mplus',cap_seconds=cap,expected_free=127 if case.startswith('E1') else 126,N=2672,
  input_sha256=sha(d/'model.inp'),data_sha256=sha(d/'data.dat'),source_parent=str(src),complete_MI=False)
 (d/'job.json').write_text(json.dumps(j,indent=2));jobs[case]=j
 (d/'launch.cmd').write_text('@echo off\n"C:/Users/RESEARCH_USER/AppData/Local/Programs/Python/Python314/python.exe" -X utf8 "'+r.as_posix()+'/code/adapter.py" "%~dp0job.json" "%~1"\nexit /b %ERRORLEVEL%\n')
bc=json.loads((b/'contracts/RUN_CONTRACT.json').read_text())
contract=dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),purpose='Equivalent time-unit calibration followed only on pass by one SD latent interaction feasibility call',
 max_mplus_calls=2,total_engine_seconds=360,maximum_owned_engines=1,sequence=['E0_SCALE','E1_SCALE_Q15_A'],new_MI=0,
 minimum_available_gib=1.2,minimum_commit_available_gib=2,max_cpu_percent=85,resource_wait_seconds=30,
 executable=bc['executable'],executable_sha256=bc['executable_sha256'],source_data_sha256=sj['hashes']['data.dat'],source_parent=str(src),
 tolerances=dict(LL_absolute=.01,parameter_difference_in_reference_SE=.05,SE_relative=.05,normalized_vcov_difference=.05),
 stop_rules=['Any hold, timeout, fatal error, illegal solution or E0 calibration failure stops dependent E1.',
 'No auto restart, no variance fixing, no new estimator/data/MI. Single E1 is not complete inference.',
 'All free parameters and full robust VCOV mapped by semantic identities; project tolerances are not statistical laws.'])
assert sha(Path(contract['executable']))==contract['executable_sha256']
(r/'contracts/RUN_CONTRACT.json').write_text(json.dumps(contract,indent=2))
(r/'audit/PREPARATION.json').write_text(json.dumps(dict(status='PASS',source_hashes=proof['sources'],data_sha256=sj['hashes']['data.dat'],mapped_starts=126,jobs=jobs),indent=2))
print('PREPARED_EQUIVALENT_SCALE_CALIBRATION max_calls=2 unchanged_data=TRUE')
