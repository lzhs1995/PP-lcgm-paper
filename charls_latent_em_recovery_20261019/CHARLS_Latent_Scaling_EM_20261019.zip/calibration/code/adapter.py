"""复用已验证直接子进程控制；每个登记模型仅一次领取。"""
from pathlib import Path
import ctypes,datetime,hashlib,json,os,sys,time,psutil
from bounded_child import run_child
ROOT=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def publish(p,j):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(j,indent=2));os.replace(t,p)
class Memory(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(k,ctypes.c_ulonglong) for k in ['total','avail','commit_limit','commit_avail','virtual','virtual_avail','extended']]
def resource():
 m=Memory();m.length=ctypes.sizeof(m)
 if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):raise OSError('Windows memory unavailable')
 return dict(at=utc(),available_gib=m.avail/2**30,commit_available_gib=m.commit_avail/2**30,cpu_percent=psutil.cpu_percent(interval=.3),mplus_pids=[p.pid for p in psutil.process_iter(['name']) if (p.info['name'] or '').lower()=='mplus.exe'])
def main():
 started=time.monotonic();p=Path(sys.argv[1]).resolve();j=json.loads(p.read_text());d=p.parent;c=json.loads((ROOT/'contracts/RUN_CONTRACT.json').read_text())
 assert d.parent==ROOT/'models' and d.name in c['sequence'] and Path(sys.argv[2]).name=='model.inp'
 assert not (d/'LAUNCH_RECEIPT.json').exists() and not (d/'execution').exists()
 assert sha(d/'model.inp')==j['input_sha256'] and sha(d/'data.dat')==j['data_sha256']==c['source_data_sha256']
 assert sha(c['executable'])==c['executable_sha256']
 if d.name.startswith('E1'):assert json.loads((ROOT/'results/E0_CALIBRATION.json').read_text())['passed']
 with (d/'RESERVATION.json').open('x') as f:json.dump(dict(at=utc(),pid=os.getpid(),job=j['id']),f)
 pf=resource();waiting=time.monotonic()
 while pf['available_gib']<c['minimum_available_gib'] or pf['commit_available_gib']<c['minimum_commit_available_gib'] or pf['cpu_percent']>c['max_cpu_percent'] or pf['mplus_pids']:
  if time.monotonic()-waiting>=c['resource_wait_seconds']:
   publish(d/'LAUNCH_RECEIPT.json',dict(status='NOT_RUN_RESOURCE_HOLD',resource=pf,at=utc(),actual_engine_calls=0));return 75
  time.sleep(2);pf=resource()
 publish(d/'RESOURCE_ADMITTED.json',pf)
 awake=bool(ctypes.windll.kernel32.SetThreadExecutionState(0x80000001))
 try:
  pre=time.monotonic()-started
  result=run_child([c['executable'],'model.inp'],d/'execution',j['cap_seconds'],working_directory=d)
  result.update(at=utc(),kind='licensed_mplus',actual_engine_calls=1,adapter_preflight_seconds=pre,adapter_total_seconds=time.monotonic()-started,input_sha256=j['input_sha256'],data_sha256=j['data_sha256'],stdout_sha256=sha(d/'execution/stdout.log'),stderr_sha256=sha(d/'execution/stderr.log'))
  publish(d/'LAUNCH_RECEIPT.json',result);return 124 if result['state']=='TIMEOUT' else result['exitcode']
 finally:
  if awake:ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
if __name__=='__main__':raise SystemExit(main())
