"""独立读取保存的完整迭代行，阶段成本不是收敛判定。"""
from pathlib import Path
import csv,hashlib,json,sys
from parse_trace import parse_trace
r=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
result=[]
for d in sorted((r/'models').iterdir()):
 f=d/'execution/stdout.log'
 if not f.exists():continue
 b=f.read_bytes();rows=parse_trace(b,final=True);er=json.loads((d/'LAUNCH_RECEIPT.json').read_text())
 by={a:dict(completed_rows=sum(x['algorithm']==a for x in rows),printed_step_seconds=sum(x['step_seconds'] for x in rows if x['algorithm']==a)) for a in sorted(set(x['algorithm'] for x in rows))}
 rec=dict(id=d.name,engine_state=er['state'],engine_seconds=er['exit_confirmed_seconds'],trace_rows=len(rows),by_algorithm=by,last_printed_row=rows[-1] if rows else None,stdout_sha256=hashlib.sha256(b).hexdigest(),normal_estimation='THE MODEL ESTIMATION TERMINATED NORMALLY' in b.decode(errors='replace'))
 if rows:
  with (d/'ITERATIONS.csv').open('w',newline='') as out:w=csv.DictWriter(out,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
 prefix=d/'LIVE_OBSERVED_STDOUT.log'
 if prefix.exists():rec['live_prefix_matches_final']=b.startswith(prefix.read_bytes());assert rec['live_prefix_matches_final']
 result.append(rec)
out=r/'results/TRACE_DIAGNOSTIC.json';assert not out.exists();out.write_text(json.dumps(result,indent=2));print(json.dumps(result))
