"""公开聚合包的独立回算：不访问个人数据、不调用 Mplus。"""
from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
for f in read(r/'MANIFEST.json')['files']:
    b=(r/f['path']).read_bytes();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
results=[]
for case in ['calibration','initial_hold','em_recovery']:
    q=subprocess.run([sys.executable,str(r/'calibration/code/verify_results.py'),str(r/case)],capture_output=True,text=True,encoding='utf-8',timeout=45)
    assert q.returncode==0,(case,q.stderr);results.append(dict(case=case,result=json.loads(q.stdout)))
calls=sum(read(r/p)['actual_engine_calls'] for p in ['calibration/models/E0_SCALE/LAUNCH_RECEIPT.json','calibration/models/E1_SCALE_Q15_A/LAUNCH_RECEIPT.json','initial_hold/models/E1_EM_Q15_A/LAUNCH_RECEIPT.json','em_recovery/models/E1_EM_Q15_A/LAUNCH_RECEIPT.json'])
assert calls==3
assert read(r/'initial_hold/models/E1_EM_Q15_A/LAUNCH_RECEIPT.json')['actual_engine_calls']==0
for case in ['calibration','em_recovery']:
    for row in read(r/case/'results/TRACE_DIAGNOSTIC.json'):
        assert hashlib.sha256((r/case/'models'/row['id']/'execution/stdout.log').read_bytes()).hexdigest()==row['stdout_sha256']
assert read(r/'em_recovery/audit/FINAL_PROCESS_HEALTH.json')['passed']
assert not any(p.name=='data.dat' or p.suffix.lower() in ['.rds','.rdata','.sav','.dta'] for p in r.rglob('*'))
print(json.dumps(dict(status='PASS_PUBLIC_AGGREGATE_REPLAY',payload_files=len(read(r/'MANIFEST.json')['files']),licensed_calls=calls,new_MI=0,models=results,full_moderation=False,full_H4=False)))
