@echo off
"C:/Users/RESEARCH_USER/AppData/Local/Programs/Python/Python314/python.exe" -X utf8 "C:/Users/RESEARCH_USER/pp_lgcm_review/charls_latent_em_only_20261019/code/adapter.py" "%~dp0job.json" "%~1"
exit /b %ERRORLEVEL%
