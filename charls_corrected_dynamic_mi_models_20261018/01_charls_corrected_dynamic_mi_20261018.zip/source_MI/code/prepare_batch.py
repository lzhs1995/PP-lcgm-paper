"""从已验证代码生成修正来源的专用MI入口；所有新写入均限独立目录。"""
from pathlib import Path
import json, hashlib, shutil, datetime
R=Path(__file__).resolve().parents[1]
BASE=R.parent
OLD=BASE/'charls_h42_mi_20261017'
Z=BASE/'charls_corrected_baseline_h41_20261018'
I=BASE/'charls_corrected_baseline_income_20261018'
C=BASE/'charls_latent_integration_calibration_20261018'
for n in ['audit','contracts','private','runtime','results','reports']:(R/n).mkdir(exist_ok=True)
def put(p,s):
    assert not p.exists(),p
    p.write_text(s,encoding='utf-8')
def jput(p,s):put(p,json.dumps(s,ensure_ascii=False,indent=2)+'\n')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
contract=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 scope='Corrected CHARLS observed baseline Z dynamic and EDU/URBAN H4.2 enriched working ADL MI; income input preparation only',
 indicators=['sd','gender','oldest','son'],m=20,iterations=1,
 mi_seeds=dict(sd=26101881,gender=26101882,oldest=26101883,son=26101884),
 compatibility='Observed-product working conditional imputation; not exact latent-interaction substantive compatibility, not proof of MAR. Analysis outcomes retain original FIML masks.',
 imputation='Only ADL incomplete; community random-intercept PMM5. Fixed controls, Z squared, Z by wave auxiliaries, EDU/URBAN by wave and EDU/URBAN by Z by wave. Cache identical deterministic fits only; fresh coefficient/random-effect/donor draws.',
 rank_policy='Exact redundancy removal only when reconstructed over all observed and prediction rows below 1e-8; no p-value selection',
 income_scope='Prepare enriched income and ADL input matrices from current corrected sources; no FCS draws in this batch',
 H41_existing_reused_as_results=True,new_Mplus_calls=0,original_four_complete=False,full_H4_complete=False,
 max_native_worker_seconds=1800,workers=1,original_directories_modified=False,preregistration_claim=False)
jput(R/'contracts/RUN_CONTRACT.json',contract)
shutil.copyfile(Z/'contracts/SOURCE_ENTRIES.json',R/'contracts/SOURCE_ENTRIES.json')
hashes={str(p).replace('\\','/'):h(p) for p in [OLD/'code/prepare_adl.R',OLD/'code/prepare_income_inputs.R',OLD/'code/mi_exact_fit_cache.R',Z/'contracts/SOURCE_ENTRIES.json',I/'contracts/INPUT_SOURCES.json']}
for e in json.loads((Z/'contracts/SOURCE_ENTRIES.json').read_text()).values():hashes[e['file']]=h(Path(e['file']))
jput(R/'audit/SOURCE_HASHES.json',hashes)
for n in ['mi_exact_fit_cache.R']:shutil.copyfile(OLD/'code'/n,R/'code'/n)
for n in ['windows_awake_guard.py','active_clock.py']:shutil.copyfile(C/'code'/n,R/'code'/n)
s=(OLD/'code/prepare_adl.R').read_text(encoding='utf-8-sig')
s=s.replace(str(OLD).replace('\\','/'),R.as_posix()).replace("OLD<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_h41_mi_20261016'", "OLD<-'"+Z.as_posix()+"'")
s=s.replace("src<-file.path(OLD,'mi',z,'private/INPUTS.rds')", "src<-file.path(OLD,'private',paste0(toupper(z),'_SOURCE_INPUTS.rds'))")
s=s.replace("if(!is.null(a$original_cc))a$original_cc else rep(NA,nrow(cc))", "a$original_complete_case")
s=s.replace("tmp<-paste0(cp,'.tmp');saveRDS(imp,tmp);stopifnot(file.rename(tmp,cp))", "tmp<-paste0(cp,'.tmp');saveRDS(imp,tmp);stopifnot(file.rename(tmp,cp));saveRDS(.Random.seed,file.path(ROOT,'private/RNG_FINAL.rds'))")
s=s.replace("source_unstandardized=a$data,scaling", "source_unstandardized=a$data,expanded_unstandardized=expanded,scaling")
s=s.replace("# 标准化仅用于插补条件设计", "expanded<-cc\n # 标准化仅用于插补条件设计")
s=s.replace("cat('H42_ADL_MI_NATIVE_TERMINAL\\n')", "cat('CORRECTED_DYNAMIC_H42_ADL_MI_TERMINAL\\n')")
assert 'expanded<-cc' in s and "a$original_complete_case" in s
put(R/'code/prepare_adl.R',s)
s=(OLD/'code/prepare_income_inputs.R').read_text(encoding='utf-8-sig').replace(OLD.as_posix(),R.as_posix())
s=s.replace('<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_income_mi_pilot_20261016/attempt3/private',I.as_posix()+'/private')
assert I.as_posix()+'/private' in s
put(R/'code/prepare_income_inputs.R',s)
put(R/'code/native_gate.py', '''"""真实工具回执登记；不模拟原生MCP调用。"""
from pathlib import Path
import sys,json,io,contextlib
R=Path(__file__).resolve().parents[1];D=R/'audit/native';D.mkdir(exist_ok=True)
sys.path.insert(0,'<WINDOWS_USERPROFILE>/.codex/skills/clauder-rstudio-workbench')
from clauder_workbench.cli import main
key='pp-lgcm-corrected-dynamic-h42-mi-20261018'
def run(args,name):
 b=io.StringIO()
 with contextlib.redirect_stdout(b):rc=main(args)
 (D/name).write_text(b.getvalue(),encoding='utf-8');j=json.loads(b.getvalue())
 print(json.dumps(dict(step=name,decision=j.get('decision'),evidence_id=j.get('evidence_id'))),flush=True)
 assert rc==0 and j['decision']=='PASS',j
mode=sys.argv[1]
if mode=='start':
 run(['doctor','--expect-client','codex','--check-toml-parse'],'DOCTOR.json')
 run(['native-smoke','start','--task-key',key,'--session-name','default','--agent','codex','--require-raw-file'],'START.json')
elif mode=='finish':
 job=sys.argv[2]
 for step,extra in [('list_sessions',['--session-name','default','--session-count','2']),('execute_r',['--marker','DYNAMIC_NATIVE_OK','--pid','8764']),('execute_r_async',['--job-id',job]),('get_async_result',['--job-id',job,'--marker','DYNAMIC_SMOKE_DONE'])]:
  run(['native-smoke','record','--task-key',key,'--step',step,'--ok',*extra,'--raw-file',str(D/(step+'_RAW.json'))],step+'_RECORD.json')
 run(['native-smoke','complete','--task-key',key,'--max-age-min','60'],'PROOF.json')
elif mode in ['pre-submit','register-job','complete']:
 args=['async-guard',mode,'--task-key',key]
 if mode!='complete':args+=['--session-name','default','--io-mode','durable_files']
 if len(sys.argv)>2:args+=['--job-id',sys.argv[2]]
 if mode=='complete':args+=['--reason','Actual native terminal and independent working MI verification saved']
 run(args,'GUARD_'+mode+'.json')
''')
put(R/'code/run_mi.R', '''# 新任务仅生成专用工作插补和收入设计，不启动任何Mplus估计。
local({
 R<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_dynamic_h42_adl_20261018'
 Sys.setenv(OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1,MKL_NUM_THREADS=1)
 .libPaths(c('<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_income_mi_pilot_20261016/library',.libPaths()))
 library(jsonlite);library(ps);library(processx)
 stopifnot(!file.exists(file.path(R,'runtime/MI_OWNER.json')))
 host<-fromJSON(file.path(R,'audit/HOST_ADMISSION.json'))
 stopifnot(isTRUE(host$admitted))
 h<-ps_handle();before<-ps_get_cpu_affinity(h);ps_set_cpu_affinity(h,unlist(host$selected_cores))
 write_json(list(before=before,after=ps_get_cpu_affinity(h)),file.path(R,'audit/WORKER_AFFINITY.json'),auto_unbox=TRUE)
 op<-file.path(R,'runtime/MI_OWNER.json');write_json(list(owner=list(pid=Sys.getpid(),created=as.numeric(ps_create_time(h)))),op,auto_unbox=TRUE,digits=16)
 py<-'<WINDOWS_USERPROFILE>/AppData/Local/Programs/Python/Python314/python.exe'
 aw<-file.path(R,'runtime/awake_MI');a<-process$new(py,c('-X','utf8',file.path(R,'code/windows_awake_guard.py'),'--owner-file',op,'--output',aw,'--interval','5'),stdout=file.path(R,'runtime/awake.log'),stderr='2>&1',cleanup=FALSE)
 on.exit({if(dir.exists(aw))writeLines('release',file.path(aw,'stop.request'));a$wait(8000L)},add=TRUE)
 w<-process$new(py,c('-X','utf8',file.path(R,'code/watchdog.py')),stdout=file.path(R,'runtime/watchdog.log'),stderr='2>&1',cleanup=FALSE)
 on.exit({writeLines('done',file.path(R,'runtime/watchdog.stop'));w$wait(8000L)},add=TRUE)
 clauder_progress('working_MI_prepare','Corrected sources; frozen expanded design; 4 x 20 fresh draws')
 source(file.path(R,'code/prepare_adl.R'),local=TRUE);prepare_inputs();run_adl()
 source(file.path(R,'code/prepare_income_inputs.R'),local=TRUE);prepare_income_inputs()
 source(file.path(R,'code/verify_mi.R'),local=TRUE)
 writeLines('COMPLETE',file.path(R,'runtime/MI_TERMINAL'))
 clauder_progress('CORRECTED_MI_TERMINAL','Four ADL working MI families independently checked; income inputs prepared, not imputed')
 cat('CORRECTED_MI_NATIVE_TERMINAL\\n')
})
''')
print(json.dumps(dict(root=R.as_posix(),prepared=True,new_MI=0,new_Mplus=0)))
