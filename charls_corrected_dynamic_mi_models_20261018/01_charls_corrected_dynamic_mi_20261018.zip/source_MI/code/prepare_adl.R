# 三重交互信息进入ADL工作插补；只删所有预测行上均精确线性冗余的列。
.libPaths(c('<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
library(jsonlite);library(digest);library(mice);library(miceadds);library(lme4)
BATCH<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_dynamic_h42_adl_20261018'
OLD<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_baseline_h41_20261018'
contract<-fromJSON(file.path(BATCH,'contracts/RUN_CONTRACT.json'),simplifyVector=FALSE)
pj<-function(x,p)write_json(x,p,auto_unbox=TRUE,pretty=TRUE,digits=16,na='null')
progress<-function(stage,message){pj(list(stage=stage,message=message,updated_at=format(Sys.time(),tz='UTC',usetz=TRUE),pid=Sys.getpid()),file.path(BATCH,'runtime/progress.json'));cat(stage,message,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(stage,message)}
build_input<-function(z){
 ROOT<-file.path(BATCH,'mi',z);for(n in c('private','audit','runtime'))dir.create(file.path(ROOT,n),recursive=TRUE,showWarnings=FALSE)
 src<-file.path(OLD,'private',paste0(toupper(z),'_SOURCE_INPUTS.rds'));h<-digest(file=src,algo='sha256');a<-readRDS(src);cc<-a$data
 stopifnot(identical(names(which(colSums(is.na(cc))>0)),'adl'),all(cc$edu%in%0:1),all(cc$urban%in%0:1))
 aux<-grep('^(obs_|missing_)',names(cc),value=TRUE)
 for(v in aux){cc[[paste0('z_',v)]]<-cc$z0*cc[[v]];for(g in c('edu','urban')){cc[[paste0(g,'_',v)]]<-cc[[g]]*cc[[v]];cc[[paste0(g,'_z_',v)]]<-cc[[g]]*cc$z0*cc[[v]]}}
 cc$z_squared<-cc$z0^2
 expanded<-cc
 # 标准化仅用于插补条件设计；实际分析DAT不改变尺度。
 candidates<-setdiff(names(cc),c('adl','cluster'));X<-as.matrix(cc[candidates]);center<-colMeans(X);scale<-apply(X,2,sd);scale[!is.finite(scale)|scale==0]<-1
 X<-sweep(sweep(X,2,center,'-'),2,scale,'/');X<-cbind(`(Intercept)`=1,X);observed<-!is.na(cc$adl)
 qr_obs<-qr(X[observed,,drop=FALSE],tol=1e-9,LAPACK=FALSE);keep<-sort(qr_obs$pivot[seq_len(qr_obs$rank)]);drop<-setdiff(seq_len(ncol(X)),keep)
 stopifnot(1L%in%keep)
 map<-qr.coef(qr(X[observed,keep,drop=FALSE],tol=1e-10),X[observed,,drop=FALSE]);err<-max(abs(X[,keep,drop=FALSE]%*%map-X))
 stopifnot(is.finite(err),err<1e-8)
 kept<-colnames(X)[setdiff(keep,1L)];notkept<-setdiff(candidates,kept)
 for(v in candidates)cc[[v]]<-(cc[[v]]-center[v])/scale[v]
 pm<-matrix(0,ncol(cc),ncol(cc),dimnames=list(names(cc),names(cc)));pm['adl',kept]<-1;pm['adl','cluster']<--2
 methods<-make.method(cc);methods[]<-'';methods['adl']<-'2l.pmm.cached'
 core_cc<-a$original_complete_case
 receipt<-list(scope=z,N=nrow(cc),missing_ADL=sum(!observed),communities=length(unique(cc$cluster)),candidate_columns=ncol(X),rank=qr_obs$rank,retained=kept,exact_redundant=notkept,all_row_reconstruction_max_error=err,source_sha256=h,
  historical_cc_count=sum(core_cc,na.rm=TRUE),ADL_observed_count=sum(observed),historical_cc_vs_ADL=unclass(table(historical_cc=core_cc,ADL_observed=observed)),
  conditional_scope='EDU and URBAN resource products jointly included; zero auxiliary values never exported as X/Y',compatibility=contract$compatibility)
 saveRDS(list(data=cc,analysis=a$analysis,methods=methods,predictors=pm,source=src,source_sha256=h,source_unstandardized=a$data,expanded_unstandardized=expanded,scaling=list(center=center,scale=scale),rank_map=map),file.path(ROOT,'private/INPUTS.rds'))
 write.csv(data.frame(variable=candidates,center=center,scale=scale,retained=candidates%in%kept),file.path(ROOT,'audit/CONDITIONAL_SCALING.csv'),row.names=FALSE)
 pj(receipt,file.path(ROOT,'audit/DESIGN.json'));stopifnot(digest(file=src,algo='sha256')==h);receipt
}
prepare_inputs<-function(){
 receipts<-setNames(lapply(unlist(contract$indicators),build_input),unlist(contract$indicators));pj(receipts,file.path(BATCH,'audit/ADL_DESIGNS.json'))
 progress('H42_ADL_INPUTS_READY','Four full column-space checks; zero imputation draws and zero Mplus estimates')
 cat('H42_MI_INPUT_NATIVE_TERMINAL\n')
}
run_adl<-function(){
 admissions<-list()
 for(z in unlist(contract$indicators)){
  ROOT<-file.path(BATCH,'mi',z);path<-file.path(ROOT,'audit/ADMISSION.json')
  if(file.exists(path)){admissions[[z]]<-fromJSON(path,simplifyVector=FALSE);next}
  a<-readRDS(file.path(ROOT,'private/INPUTS.rds'));cc<-a$data;cp<-file.path(ROOT,'private/MIDS.rds')
  stopifnot(digest(file=a$source,algo='sha256')==a$source_sha256)
  source(file.path(BATCH,'code/mi_exact_fit_cache.R'),local=TRUE)
  warnings<-character();progress('H42_ADL_MI_START',paste(z,'20 independent draws; cached deterministic conditional fit'))
  result<-tryCatch({
   if(file.exists(cp)){imp<-readRDS(cp);stopifnot(identical(imp$data,cc),imp$m==20,imp$iteration==1)}else{
    imp<-withCallingHandlers(mice(cc,m=20,maxit=1,method=a$methods,predictorMatrix=a$predictors,seed=contract$mi_seeds[[z]],donors=5,printFlag=FALSE,remove.collinear=FALSE,remove.constant=FALSE),warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')})
    tmp<-paste0(cp,'.tmp');saveRDS(imp,tmp);stopifnot(file.rename(tmp,cp));saveRDS(.Random.seed,file.path(ROOT,'private/RNG_FINAL.rds'))
    pj(list(cache_hits=cache_env$hits,cache_misses=cache_env$misses,m=imp$m),file.path(ROOT,'audit/DRAW_EXECUTION.json'))
   }
   fit<-readRDS(file.path(ROOT,'private/MI_ADL_CONDITIONAL_LMER.rds'));draw<-fromJSON(file.path(ROOT,'audit/DRAW_EXECUTION.json'));design<-fromJSON(file.path(ROOT,'audit/DESIGN.json'))
   retained<-identical(unname(imp$predictorMatrix['adl',]),unname(a$predictors['adl',]))
   vc<-as.matrix(vcov(fit));passed<-fit@optinfo$conv$opt==0&&length(fit@optinfo$conv$lme4$messages)==0&&is.null(attr(getME(fit,'X'),'col.dropped'))&&retained&&min(eigen(vc,symmetric=TRUE,only.values=TRUE)$values)>0&&draw$cache_hits==19&&draw$cache_misses==1
   obs<-!is.na(cc$adl);checks<-list();summ<-list()
   for(k in 1:20){
    v<-complete(imp,k);stopifnot(all(vapply(setdiff(names(v),'adl'),function(n)identical(as.numeric(v[[n]]),as.numeric(cc[[n]])),TRUE)),identical(v$adl[obs],cc$adl[obs]),all(v$adl[!obs]%in%cc$adl[obs]),all(v$adl%in%0:6))
    b<-a$analysis;b$c7<-v$adl;stopifnot(identical(b[setdiff(names(b),'c7')],a$analysis[setdiff(names(a$analysis),'c7')]))
    data_path<-file.path(ROOT,'private',sprintf('MI%02d.dat',k));write.table(b,data_path,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
    checks[[k]]<-data.frame(member=k,N=nrow(b),observed_preserved=TRUE,XY_masks_preserved=TRUE,sha256=digest(file=data_path,algo='sha256'))
    summ[[k]]<-data.frame(scope=z,member=k,imputed_ADL_mean=mean(v$adl[!obs]),imputed_ADL_sd=sd(v$adl[!obs]))
   }
   write.csv(do.call(rbind,checks),file.path(ROOT,'audit/MEMBER_VALIDATION.csv'),row.names=FALSE);write.csv(do.call(rbind,summ),file.path(ROOT,'audit/DRAW_SUMMARY.csv'),row.names=FALSE)
   write.csv(data.frame(variable=rownames(imp$predictorMatrix),imp$predictorMatrix,check.names=FALSE),file.path(ROOT,'audit/PREDICTORS_ACTUAL.csv'),row.names=FALSE)
   if(!is.null(imp$loggedEvents))write.csv(imp$loggedEvents,file.path(ROOT,'audit/LOGGED_EVENTS.csv'),row.names=FALSE)
   stopifnot(digest(file=a$source,algo='sha256')==a$source_sha256)
   list(scope=z,passed=passed,N=nrow(cc),communities=length(unique(cc$cluster)),missing_ADL=sum(!obs),m=20,iterations=1,columns=names(a$analysis),conditional_rank=design$rank,all_rows_reconstruction_error=design$all_row_reconstruction_max_error,random_intercept_boundary=isSingular(fit),warnings=warnings,cache_hits=draw$cache_hits,cache_misses=draw$cache_misses,compatibility=contract$compatibility,mice_version=as.character(packageVersion('mice')),miceadds_version=as.character(packageVersion('miceadds')))
  },error=function(e)list(scope=z,passed=FALSE,status='IMPUTATION_FAILED_NO_REPLACEMENT',error=conditionMessage(e),warnings=warnings))
  pj(result,path);admissions[[z]]<-result;pj(admissions,file.path(BATCH,'audit/ADL_ADMISSIONS.json'));progress('H42_ADL_MI_DONE',paste(z,'admitted',result$passed));rm(a,cc);gc()
 }
 writeLines(capture.output(sessionInfo()),file.path(BATCH,'audit/ADL_SESSION_INFO.txt'));progress('H42_ADL_MI_TERMINAL',paste(sum(vapply(admissions,function(x)isTRUE(x$passed),TRUE)),'of4 scopes admitted'))
 cat('CORRECTED_DYNAMIC_H42_ADL_MI_TERMINAL\n')
}
