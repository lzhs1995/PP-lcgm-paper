# 从原始冻结来源独立重建辅助列，核验全部80个实际DAT及原观测/缺失掩码。
local({
 R<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_dynamic_h42_adl_20261018'
 library(mice);library(jsonlite);library(digest)
 entries<-fromJSON(file.path(R,'contracts/SOURCE_ENTRIES.json'),simplifyVector=FALSE)
 hashes<-fromJSON(file.path(R,'audit/SOURCE_HASHES.json'),simplifyVector=FALSE)
 for(p in names(hashes))stopifnot(digest(file=p,algo='sha256')==hashes[[p]])
 checks<-list();scopes<-list()
 for(z in names(entries)){
  e<-entries[[z]];stopifnot(digest(file=e$file,algo='sha256')==e$sha256)
  src<-readRDS(e$file);root<-file.path(R,'mi',z);a<-readRDS(file.path(root,'private/INPUTS.rds'))
  imp<-readRDS(file.path(root,'private/MIDS.rds'));ad<-fromJSON(file.path(root,'audit/ADMISSION.json'))
  stopifnot(isTRUE(ad$passed),imp$m==20,imp$iteration==1,ad$cache_hits==19,ad$cache_misses==1)
  expected<-src$data;aux<-grep('^(obs_|missing_)',names(expected),value=TRUE)
  for(v in aux){expected[[paste0('z_',v)]]<-expected$z0*expected[[v]];for(g in c('edu','urban')){expected[[paste0(g,'_',v)]]<-expected[[g]]*expected[[v]];expected[[paste0(g,'_z_',v)]]<-expected[[g]]*expected$z0*expected[[v]]}}
  expected$z_squared<-expected$z0^2
  stopifnot(identical(expected,a$expanded_unstandardized))
  for(n in names(a$scaling$center))expected[[n]]<-(expected[[n]]-a$scaling$center[n])/a$scaling$scale[n]
  stopifnot(identical(expected,imp$data),identical(imp$predictorMatrix,a$predictors))
  allX<-cbind(`(Intercept)`=1,as.matrix(expected[names(a$scaling$center)]))
  retained<-rownames(a$rank_map);err<-max(abs(allX[,retained,drop=FALSE]%*%a$rank_map-allX));stopifnot(err<1e-8)
  obs<-!is.na(src$data$adl)
  for(k in 1:20){
   v<-complete(imp,k);stopifnot(!anyNA(v),identical(v$adl[obs],src$data$adl[obs]),all(v$adl[!obs]%in%src$data$adl[obs]))
   for(n in setdiff(names(v),'adl'))stopifnot(identical(as.numeric(v[[n]]),as.numeric(expected[[n]])))
   exp<-src$analysis;exp$c7<-v$adl;p<-file.path(root,'private',sprintf('MI%02d.dat',k));got<-as.matrix(read.table(p,na.strings='-9999'));want<-as.matrix(exp)
   stopifnot(identical(dim(got),dim(want)),identical(unname(is.na(got)),unname(is.na(want))))
   delta<-max(abs(got-want),na.rm=TRUE);stopifnot(delta<1e-10)
   checks[[length(checks)+1L]]<-data.frame(scope=z,member=k,N=nrow(got),maximum_export_difference=delta,observed_and_XY_masks_preserved=TRUE,source_sha256=e$sha256,sha256=digest(file=p,algo='sha256'))
  }
  scopes[[z]]<-list(status='PASS',N=nrow(src$data),missing_ADL=sum(!obs),m=20,reconstruction_max_error=err,source_sha256=e$sha256)
  if(exists('clauder_progress',mode='function'))clauder_progress('corrected_MI_verified',paste(z,'20 members; observed cells and original X/Y masks unchanged'))
 }
 tab<-do.call(rbind,checks);stopifnot(nrow(tab)==80)
 write.csv(tab,file.path(R,'audit/INDEPENDENT_MI_MEMBERS.csv'),row.names=FALSE)
 write_json(list(status='PASS',scopes=scopes,member_files=80,maximum_export_difference=max(tab$maximum_export_difference),income_FCS_included=FALSE,not_proof_of_MAR_or_exact_latent_compatibility=TRUE,new_Mplus=0),file.path(R,'audit/INDEPENDENT_MI.json'),auto_unbox=TRUE,pretty=TRUE,digits=16)
 cat('CORRECTED_DYNAMIC_H42_ADL_INDEPENDENT_PASS\n')
})
