"""汇总已完成工作插补，不追加拟合或改变结果。"""
from pathlib import Path
import json,sys,io,contextlib,hashlib
R=Path(__file__).resolve().parents[1]
a=json.loads((R/'audit/ADL_ADMISSIONS.json').read_text())
v=json.loads((R/'audit/INDEPENDENT_MI.json').read_text());assert v['status']=='PASS'
income=json.loads((R/'audit/INCOME_INPUT_DESIGNS.json').read_text());assert len(income)==4
versions={z:(x['mice_version'],x['miceadds_version']) for z,x in a.items()}
# 实际命名空间优先于启动器路径意图：保留已验证结果，不为了版本标签重抽80份。
(R/'audit/ACTUAL_PACKAGE_VERSIONS.json').write_text(json.dumps(dict(versions=versions,observed_mice='3.19.0',reason='prepare_adl.R prepended the existing adjusted_h41 library before loading mice; outer launcher had not yet loaded mice',scope='This batch contract did not pin mice 3.19.10. Report actual version; do not call results 3.19.10. Income FCS will use its separately frozen fresh-process runtime.',statistical_outputs_recomputed=False),indent=2),encoding='utf-8')
lines=['# 修正来源下的动态调节与H4.2工作插补','',
'**四项调节完整推断、完整 H4 仍未完成。** 本报告只关闭本批ADL工作插补及收入输入设计，不关闭研究推断。','',
'四个范围各20份，共80份实际DAT经独立读取核验。原观测ADL、其他控制值、实际X/Y及FIML缺失位置保留。导出最大差异 '+str(v['maximum_export_difference'])+'。原始数据目录没有写入。','',
'|范围|N|社区|ADL缺失|成员|条件设计秩|','|---|---:|---:|---:|---:|---:|']
for z,x in a.items():lines.append(f"|{z}|{x['N']}|{x['communities']}|{x['missing_ADL']}|{x['m']}|{x['conditional_rank']}|")
lines+=['','每范围只拟合一次相同的确定性社区随机截距模型，缓存命中19次；20次系数、随机效应与供体抽样仍各自执行。四个拟合无所记录的收敛警告，随机截距未处边界。辅助设计仅去除在观察行和全部预测行均可精确重建的列，最大误差小于1e-8。',
'','加入Z×波次、Z²以及教育/城乡×Z×波次辅助量。这是更丰富的工作条件插补，并非与潜在SX交互精确相容或MAR成立的证明。模型结果只能在该插补模型条件下解释。',
'','实际版本：mice 3.19.0，miceadds 3.20.10。内层脚本调整库路径先于包加载，所以没有使用外层优先路径中的mice 3.19.10；本批合同未固定该版本，不能把执行结果标成3.19.10。已保存实际sessionInfo和独立值检查。后续收入FCS采用独立冻结运行环境。',
'','收入原40份属于H4.1设计。实测ADL条件未使用Z×波次，缺G×波次、G×Z×波次及斜率辅助代理，不能改标签充当本轮H4.2专用MI。新的四个收入输入已构造，G条件秩67、ADL条件秩86，含G=0/1与ADL端点的列空间核对通过；尚未生成新的收入插补成员。',
'','原生job d5532ae8已完成，真实终态已消费；防休眠助手已释放，watchdog正常退出。没有Mplus调用。下一估计批使用新命名空间和原生job 322a8b5c；其状态由自己的台账判定。',
'','RStudio恢复的已验证技术经验已合并guide PR41、PR43、PR45。保留“Running不等于可执行”“提交未知先找回原job”“恢复后重绑PID”“缓冲日志静止不等于停算”的规则；不重复重启或重提已完成任务。']
(R/'reports/REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
sys.path.insert(0,'<WINDOWS_USERPROFILE>/.codex/skills/clauder-rstudio-workbench')
from clauder_workbench.cli import main
b=io.StringIO()
with contextlib.redirect_stdout(b):rc=main(['completion-check','--mode','formal','--require-file','validation::'+str(R/'audit/INDEPENDENT_MI_MEMBERS.csv')+',min_rows=80,max_age_h=24'])
(R/'audit/COMPLETION_CHECK.json').write_text(b.getvalue(),encoding='utf-8');j=json.loads(b.getvalue());assert rc==0 and j['decision']=='PASS',j
print(json.dumps(dict(status='ADL_MI_COMPLETE_INCOME_INPUTS_ONLY',member_files=80,formal_completion=j['decision'],new_Mplus=0)))
