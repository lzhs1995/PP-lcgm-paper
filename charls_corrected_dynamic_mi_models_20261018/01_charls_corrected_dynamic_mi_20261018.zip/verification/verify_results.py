"""独立复读原始TECH1/参数/TECH3和实际输入，不再次估计。"""
from pathlib import Path
import hashlib,json,re,sys
import numpy as np
import pandas as pd
from scipy.stats import t
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'code'))
from raw_parameter_reader import raw_model
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
labs=['bii','bis','bss','bsyiy','gi0','gs0','dc']
fields=['estimate','se','df','lower','upper','p','lambda','MCSE_over_SE']
def main(public=False):
 calls=read(R/'results/CALL_RESULTS.json');families=read(R/'results/FAMILY_STATUS.json');admit=read(R/'audit/MI_ADMISSIONS.json');parsed={};models={};pooled={}
 if not public:
  mi=Path(read(R/'contracts/RUN_CONTRACT.json')['source_MI'])
  v=read(mi/'audit/INDEPENDENT_MI.json');assert v['status']=='PASS' and v['member_files']==80
  ledger=pd.read_csv(mi/'audit/INDEPENDENT_MI_MEMBERS.csv')
  for row in ledger.itertuples():
   p=mi/'mi'/row.scope/'private'/f'MI{row.member:02d}.dat'
   assert sha(p)==row.sha256
   assert admit[row.scope]['cache_misses']==1 and admit[row.scope]['cache_hits']==19 and admit[row.scope]['passed']
 for name,c in calls.items():
  d=R/'models'/name
  if not (d/'engine_receipt.json').exists():assert c['status']=='NOT_RUN_RESOURCE_OR_BUDGET';continue
  if c.get('output_sha256'):assert sha(d/'model.out')==c['output_sha256']
  else:assert c['status']!='USABLE_SINGLE_DATASET'
  if c['status']!='USABLE_SINGLE_DATASET':models[name]={'status':c['status']};continue
  j=read(d/'job.json')
  if not public:
   assert sha(d/'data.dat')==j['hashes']['data.dat'];assert sha(d/'data.dat')==sha(mi/'mi'/j['z']/'private'/f'MI{j["member"]:02d}.dat')
  out,mapping,q,se,v,key,ll=raw_model(d)
  assert int(re.search(r'Number of observations\s+(\d+)',out,re.I).group(1))==c['N']==admit[j['z']]['N']
  assert 'THE MODEL ESTIMATION TERMINATED NORMALLY' in out and 'FIXED TO AVOID SINGULARITY' not in out
  assert not any(q[k-1]<0 for mat,a,b,k in mapping if mat in ('PSI','THETA') and a==b and k>0)
  assert np.linalg.eigvalsh(v/np.outer(np.sqrt(v.diagonal()),np.sqrt(v.diagonal()))).min()>0
  if j['type']=='E1':
   key=key.set_index('label').loc[labs];ix=key.parameter.to_numpy(dtype=int)-1
   parsed[name]=(q[ix],v[np.ix_(ix,ix)],se[ix],ll)
  models[name]={'status':'PASS','free_parameters':len(q),'N':c['N']}
 for z,f in families.items():
  a=parsed.get(f'CHARLS_{z.upper()}_E1_MI01_A');b=parsed.get(f'CHARLS_{z.upper()}_E1_MI01_B')
  if a is not None and b is not None:
   ok=abs(a[3]-b[3])<=.01 and np.all(abs(a[0]-b[0])<=np.maximum(.001,.05*np.maximum(a[2],b[2]))) and np.all(abs(a[2]-b[2])/np.maximum(a[2],b[2])<=.05)
   assert bool(ok)==read(R/'results'/f'{z.upper()}_START_COMPARISON.json')['passed']
  if f['status']!='TWENTY_USABLE_PENDING_POOLING':continue
  xs=[parsed[f'CHARLS_{z.upper()}_E1_MI{k:02d}_A'] for k in range(1,21)]
  Q=np.array([x[0] for x in xs]);U=np.array([x[1] for x in xs]);m=len(Q);W=U.mean(0);B=np.cov(Q,rowvar=False,ddof=1);T=W+(1+1/m)*B;e=Q.mean(0)
  def scalar(a,dfcom=np.inf):
   est=float(a@e);se=float(np.sqrt(a@T@a));r=(1+1/m)*(a@B@a)/(a@W@a);lam=(1+1/m)*(a@B@a)/(a@T@a)
   df=(m-1)*(1+1/r)**2 if r>0 else np.inf
   if np.isfinite(dfcom):df=1/(1/df+1/((dfcom+1)/(dfcom+3)*dfcom*(1-lam)))
   return [est,se,df,est-t.ppf(.975,df)*se,est+t.ppf(.975,df)*se,2*t.sf(abs(est/se),df),lam,np.sqrt(a@B@a/m)/se]
  d=R/'results'/z;ref=pd.read_csv(d/'POOLED_PATHS.csv').set_index('label').loc[labs]
  calc=np.array([scalar(a) for a in np.eye(7)]);assert np.allclose(calc,ref[fields],rtol=1e-8,atol=1e-10)
  finite=pd.read_csv(d/'CLUSTER_DF_SENSITIVITY.csv').set_index('label').loc[labs]
  assert np.allclose([scalar(a,admit[z]['communities']-1) for a in np.eye(7)],finite[fields],rtol=1e-8,atol=1e-10)
  curves=pd.read_csv(d/'CONDITIONAL_SLOPES.csv')
  for _,row in curves.iterrows():
   aa=np.zeros(7);aa[2]=1;aa[6]=row.z;assert np.allclose(scalar(aa),row[fields].to_numpy(dtype=float),rtol=1e-8,atol=1e-10)
  pooled[z]={'status':'PASS','members':m,'interaction':dict(zip(fields,map(float,calc[6]))),'conditional_points':len(curves)}
 if pooled:
  summary=pd.read_csv(R/'results/FOUR_MODERATIONS.csv').set_index('scope')
  assert set(summary.index)==set(pooled)
  names=list(pooled);pv=np.array([pooled[z]['interaction']['p'] for z in names]);order=np.argsort(pv);holm=np.empty(len(pv));holm[order]=np.minimum(1,np.maximum.accumulate((4-np.arange(len(pv)))*pv[order]))
  for i,z in enumerate(names):
   assert np.isclose(summary.loc[z,'holm_p_fixed4'],holm[i],rtol=1e-8,atol=1e-10)
   assert np.isclose(summary.loc[z,'bonferroni_p_fixed4'],min(1,4*pv[i]),rtol=1e-8,atol=1e-10)
 out=dict(status='PASS',mode='PUBLIC_RAW_PARAMETERS' if public else 'PRIVATE_INPUTS_AND_RAW_PARAMETERS',models=models,pooled_families=pooled,full_H4_complete=False,full_four_moderation_inference_complete=False)
 target=R/'audit'/('PUBLIC_PARAMETER_REPLAY.json' if public else 'INDEPENDENT_VERIFICATION.json');target.write_text(json.dumps(out,indent=2),encoding='utf-8')
 print(json.dumps({'status':'PASS','models':len(models),'pooled':pooled}))
if __name__=='__main__':main('--public' in sys.argv)
