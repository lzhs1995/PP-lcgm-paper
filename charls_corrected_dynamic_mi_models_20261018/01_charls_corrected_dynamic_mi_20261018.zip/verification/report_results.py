"""只呈现当前来源的完整家族；不将历史不同数据的差异归因于单一修改。"""
from pathlib import Path
import json,hashlib
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
v=read(R/'audit/INDEPENDENT_VERIFICATION.json');assert v['status']=='PASS'
ad=read(R/'audit/MI_ADMISSIONS.json');families=read(R/'results/FAMILY_STATUS.json');eng=[read(p) for p in (R/'models').glob('*/engine_receipt.json')]
d=pd.read_csv(R/'results/FOUR_MODERATIONS.csv') if (R/'results/FOUR_MODERATIONS.csv').exists() else pd.DataFrame()
cn={'sd':'见面频率绝对SD','gender':'儿子−女儿差','oldest':'最年长子女−其余子女','son':'长子−其余所有子女（含女儿）'}
en={'sd':'SD','gender':'Son minus daughter','oldest':'Oldest minus others','son':'Eldest son minus all others'}
lines=['# CHARLS修正来源：四个观测基期动态调节工作MI家族','', '**四项调节完整推断、完整 H4 仍未完成。**','',
'本批沿用2026-10-18修正后的基期控制与子女名册来源，采用四个范围各20份新工作ADL插补，未修改已交付H4.1结果、冻结论文或CFPS失败规格。估计SX×观测Z0→SY；不等于SX×潜在IZ，也未完成三重交互H4.2或原研究完整H4。','',
f'实际{len(eng)}次调用；含Rscript启动的累计清醒引擎墙钟{sum(x["seconds"] for x in eng):.3f}秒。完整可合并家族{len(v["pooled_families"])}/4。双起点只用于MI01检查，不计为两份插补。','',
'|基期指标|N|成员状态|调节系数|95%条件MI区间|原始P|固定4项Holm P|', '|---|---:|---|---:|---|---:|---:|']
for z,f in families.items():
 rows=d[d.scope==z] if len(d) else pd.DataFrame()
 if len(rows):
  a=rows.iloc[0];lines.append(f'|{cn[z]}|{ad[z]["N"]}|20/20|{a.estimate:.6f}|[{a.lower:.6f}, {a.upper:.6f}]|{a.p:.6g}|{a.holm_p_fixed4:.6g}|')
 else:lines.append(f'|{cn[z]}|{ad[z]["N"]}|{f["status"]}; {f["members"]}/20|—|—|—|—|')
if len(d):
 fig,ax=plt.subplots(figsize=(8.6,4.6));positions=[];labels=[]
 for i,(z,f) in enumerate(families.items()):
  positions.append(i);labels.append(en[z]);rows=d[d.scope==z]
  if len(rows):
   a=rows.iloc[0];ax.errorbar(a.estimate,i,xerr=[[a.estimate-a.lower],[a.upper-a.estimate]],fmt='o',capsize=3,color='#2369a0')
  else:ax.text(0,i,'Incomplete family',va='center',color='#777777')
 ax.set_yticks(positions,labels);ax.invert_yaxis();ax.axvline(0,color='black',linewidth=.7);ax.set_xlabel('SX × observed baseline Z → SY: conditional MI estimate and 95% interval');ax.set_title('Corrected-source CHARLS working-imputation sensitivity')
 fig.text(.03,.02,'Pointwise intervals; fixed four-test Holm values in table. No exact latent-interaction compatibility claim.',fontsize=8);fig.tight_layout(rect=(0,.06,1,1));fig.savefig(R/'results/FOUR_MODERATIONS.png',dpi=160);fig.savefig(R/'results/FOUR_MODERATIONS.pdf');plt.close(fig)
 lines+=['',f'完整家族中名义P<.05共{int((d.p<.05).sum())}项，固定四项Holm校正后共{int((d.holm_p_fixed4<.05).sum())}项。区间含零不证明无效应；不以显著性决定是否报告或追加模型。']
lines+=['','模型保留0、2、4、7、9年载荷、11列基期控制、社区MLR、同期X/Y残差关联、Z0低阶路径及x1/y1 ON Z0。没有新固定零方差约束。CHARLS见面频率不等于CFPS情感亲近度；SD为绝对离散，其他Z有方向，潜截距Z路径也不是基期实测结局的全部关联。','',
'ADL条件插补增加Z×波次、Z²、教育/城乡×Z×波次及低阶辅助量。80份实际DAT经独立核对，只有ADL缺失被填补，X/Y继续保留原FIML掩码。实际mice 3.19.0、miceadds 3.20.10；内层库路径覆盖了启动器预期顺序，已明确记录实际版本。工作PMM不证明MAR或与潜变量交互精确相容。','',
'原始TECH1、保存参数与TECH3独立复读；全部采用成员的N、估计、SE、协方差、两起点判定、Rubin合并、有限社区自由度敏感性、条件斜率bss+dc×Z、四项校正逐项核验。完整家族之外不作MI推断。','',
'本轮不直接比较旧来源CC结果与当前MI来声称某一项修正造成变化。曾经完成的H4.1继续沿用；三重交互和新收入工作MI另有准入及预算，不混用本批成员状态。','',
'运行保留一个自有Mplus槽位、独占锁、SQLite预算、按PID创建时间识别进程树、清醒时间限额、防休眠释放和真实原生作业回执。Windows showOutput仍为缓冲，日志静止不表示引擎停止；不据此重复提交。','',
'交付只包含汇总、方法代码及模型参数证据，不公开个人DAT、RDS、MIDS、逐人记录。工程通过不代替未完成的科学推断。']
(R/'reports/REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
(R/'reports/RECEIPT.json').write_text(json.dumps(dict(status='CORRECTED_DYNAMIC_WORKING_MI_ADJUDICATED',calls=len(eng),pooled=len(v['pooled_families']),full_four_moderation_inference_complete=False,full_H4_complete=False),indent=2),encoding='utf-8')
print(json.dumps(dict(report_ready=True,pooled=len(v['pooled_families']))))
