"""只登记真实原生异步任务，复用当前原生证据。"""
from pathlib import Path
import contextlib,datetime,io,json,sys
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,'<WINDOWS_USERPROFILE>/.codex/skills/clauder-rstudio-workbench')
from clauder_workbench.cli import main
mode=sys.argv[1];args=['async-guard',mode,'--task-key','pp-lgcm-charls-corrected-dynamic-20261018']
if mode=='pre-submit':
 p=json.loads((R/'audit/NATIVE_PROOF.json').read_text())
 assert p['decision']=='PASS' and p['transport_class']=='NATIVE_MCP_OK' and p['pid']=='8764'
 assert (datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(p['timestamp_utc'].replace('Z','+00:00'))).total_seconds()<10800
if mode in ('pre-submit','register-job'):args+=['--session-name','default','--io-mode','durable_files']
if len(sys.argv)>2:args+=['--job-id',sys.argv[2]]
if mode=='complete':args+=['--reason','Actual native terminal and complete-family adjudications saved']
b=io.StringIO()
with contextlib.redirect_stdout(b):rc=main(args)
(R/'audit'/('GUARD_'+mode+'.json')).write_text(b.getvalue(),encoding='utf-8')
j=json.loads(b.getvalue());assert rc==0 and j['decision']=='PASS',j
print(json.dumps({k:j[k] for k in ['decision','evidence_id','harness_name']}))
