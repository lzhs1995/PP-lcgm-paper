# 一个协调器、完整20份才合并；失败不换成员、不改约束。
source('<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_dynamic_mi_models_20261018/code/model_functions.R',local=TRUE)
main<-function(){
 begun<-Sys.time();calls<-rj(file.path(ROOT,'results/CALL_RESULTS.json'));if(is.null(calls))calls<-list()
 families<-rj(file.path(ROOT,'results/FAMILY_STATUS.json'));if(is.null(families))families<-setNames(lapply(names(entries),function(z)list(status='NOT_STARTED',members=0L,N=entries[[z]]$N)),names(entries))
 for(z in names(entries)){
  f<-families[[z]];if(!f$status%in%c('NOT_STARTED','RESOURCE_DEFERRED','RUNNING'))next
  seqs<-c(list(list(type='E0',start='A',k=1L),list(type='E1',start='A',k=1L),list(type='E1',start='B',k=1L)),lapply(2:20,function(k)list(type='E1',start='A',k=k)))
  for(a in seqs){
   if(as.numeric(difftime(Sys.time(),begun,units='secs'))>8700){f$status<-'BATCH_WALL_LIMIT';break}
   j<-prepare(z,a$type,a$start,a$k);r<-run(j);calls[[j$id]]<-r;wj(calls,file.path(ROOT,'results/CALL_RESULTS.json'))
   if(r$status=='NOT_RUN_RESOURCE_OR_BUDGET'){f$status<-'RESOURCE_DEFERRED';break}
   if(r$status!='USABLE_SINGLE_DATASET'){f$status<-paste('MEMBER_FAILED',j$id,r$status,sep=':');break}
   if(a$type=='E1'&&a$start=='A')f$members<-a$k
   if(a$type=='E1'&&a$start=='B'){
    check<-compare_starts(z);if(!isTRUE(check$passed)){f$status<-'START_DIFFERENCE_NO_RETRY';break}
   }
   f$status<-if(f$members==20L)'TWENTY_USABLE_PENDING_POOLING'else'RUNNING'
   families[[z]]<-f;wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'))
  }
  families[[z]]<-f;wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'))
 }
 progress('MODELS_TERMINAL','Registered four families adjudicated; no failed-member replacement')
}
main()
source(file.path(ROOT,'code/pool.R'),local=TRUE)
writeLines('COMPLETE',file.path(ROOT,'runtime/MODELS_TERMINAL'))
cat('CORRECTED_DYNAMIC_MODELS_NATIVE_TERMINAL\n')
