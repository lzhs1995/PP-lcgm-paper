"""适配已有独立核验器，复用数学；更换冻结数据来源并保留无输出失败。"""
from pathlib import Path
import json
R=Path(__file__).resolve().parents[1];M=R.parent/'charls_corrected_dynamic_h42_adl_20261018';O=R.parent/'charls_dynamic_mi_sensitivity_20261016'
V=R/'verification';V.mkdir(exist_ok=True)
s=(O/'verification/verify_results.py').read_text(encoding='utf-8-sig')
start=s.index(' if not public:\n');end=s.index(' for name,c in calls.items():',start)
s=s[:start]+''' if not public:
  mi=Path(read(R/'contracts/RUN_CONTRACT.json')['source_MI'])
  v=read(mi/'audit/INDEPENDENT_MI.json');assert v['status']=='PASS' and v['member_files']==80
  ledger=pd.read_csv(mi/'audit/INDEPENDENT_MI_MEMBERS.csv')
  for row in ledger.itertuples():
   p=mi/'mi'/row.scope/'private'/f'MI{row.member:02d}.dat'
   assert sha(p)==row.sha256
   assert admit[row.scope]['cache_misses']==1 and admit[row.scope]['cache_hits']==19 and admit[row.scope]['passed']
'''+s[end:]
s=s.replace("  assert sha(d/'model.out')==c['output_sha256']", "  if c.get('output_sha256'):assert sha(d/'model.out')==c['output_sha256']\n  else:assert c['status']!='USABLE_SINGLE_DATASET'")
s=s.replace("sha(R/'mi'/j['z']/'private'/f'MI{j[\"member\"]:02d}.dat')", "sha(mi/'mi'/j['z']/'private'/f'MI{j[\"member\"]:02d}.dat')")
s=s.replace(" out=dict(status='PASS'", """ if pooled:
  summary=pd.read_csv(R/'results/FOUR_MODERATIONS.csv').set_index('scope')
  assert set(summary.index)==set(pooled)
  names=list(pooled);pv=np.array([pooled[z]['interaction']['p'] for z in names]);order=np.argsort(pv);holm=np.empty(len(pv));holm[order]=np.minimum(1,np.maximum.accumulate((4-np.arange(len(pv)))*pv[order]))
  for i,z in enumerate(names):
   assert np.isclose(summary.loc[z,'holm_p_fixed4'],holm[i],rtol=1e-8,atol=1e-10)
   assert np.isclose(summary.loc[z,'bonferroni_p_fixed4'],min(1,4*pv[i]),rtol=1e-8,atol=1e-10)
 out=dict(status='PASS'""")
p=V/'verify_results.py';assert not p.exists();p.write_text(s,encoding='utf-8');compile(s,str(p),'exec')
print(json.dumps(dict(verifier_prepared=True,executed=False)))
