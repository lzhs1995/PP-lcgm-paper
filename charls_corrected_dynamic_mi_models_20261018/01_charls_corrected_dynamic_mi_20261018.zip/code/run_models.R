# 单协调器使用已验收80份ADL插补；不改变源目录或其他研究进程。
local({
 ROOT<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_dynamic_mi_models_20261018'
 M<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_dynamic_h42_adl_20261018'
 Sys.setenv(OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1,MKL_NUM_THREADS=1)
 library(jsonlite);library(processx);library(ps)
 stopifnot(fromJSON(file.path(M,'audit/INDEPENDENT_MI.json'))$status=='PASS',!file.exists(file.path(ROOT,'runtime/OWNER.json')))
 host<-fromJSON(file.path(ROOT,'audit/HOST_ADMISSION.json'));stopifnot(isTRUE(host$admitted))
 h<-ps_handle();ps_set_cpu_affinity(h,unlist(host$selected_cores))
 op<-file.path(ROOT,'runtime/OWNER.json');write_json(list(owner=list(pid=Sys.getpid(),created=as.numeric(ps_create_time(h)))),op,auto_unbox=TRUE,digits=16)
 aw<-file.path(ROOT,'runtime/awake_MODELS');a<-process$new('<WINDOWS_USERPROFILE>/AppData/Local/Programs/Python/Python314/python.exe',c('-X','utf8',file.path(ROOT,'code/windows_awake_guard.py'),'--owner-file',op,'--output',aw,'--interval','5'),stdout=file.path(ROOT,'runtime/awake.log'),stderr='2>&1',cleanup=FALSE)
 on.exit({if(dir.exists(aw))writeLines('release',file.path(aw,'stop.request'));a$wait(8000L)},add=TRUE)
 clauder_progress('corrected_dynamic_start','One owned engine; four families; 88 calls and 5400 active engine seconds maximum')
 source(file.path(ROOT,'code/queue.R'),local=TRUE)
})
