# 保留完整TECH3、单项及有限社区自由度、条件斜率和四项多重检验。
library(jsonlite)
ROOT<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_dynamic_mi_models_20261018';Sys.setenv(R2E_ROOT=ROOT)
source(file.path(ROOT,'code/r2e_local.R'),local=TRUE)
families<-rj(file.path(ROOT,'results/FAMILY_STATUS.json'));admission<-rj(file.path(ROOT,'audit/MI_ADMISSIONS.json'));entries<-rj(file.path(ROOT,'contracts/DATA_ENTRIES.json'))
labs<-c('bii','bis','bss','bsyiy','gi0','gs0','dc');overview<-list();allpaths<-list();allslopes<-list()
for(z in names(families)){
 f<-families[[z]];overview[[z]]<-data.frame(scope=z,status=f$status,members=f$members,N=f$N)
 if(f$status!='TWENTY_USABLE_PENDING_POOLING')next
 dest<-file.path(ROOT,'results',z);dir.create(dest,showWarnings=FALSE);Q<-matrix(NA_real_,20,7,dimnames=list(NULL,labs));U<-list();src<-list()
 for(k in 1:20){
  d<-file.path(ROOT,'models',sprintf('CHARLS_%s_E1_MI%02d_A',toupper(z),k));r<-rj(file.path(d,'receipt.json'));stopifnot(r$status=='USABLE_SINGLE_DATASET',r$N==f$N,identical(r$output_sha256,hashf(file.path(d,'model.out'))))
  p<-read.csv(file.path(d,'key_paths.csv'));p<-p[match(labs,p$label),];V<-as.matrix(read.csv(file.path(d,'parameter_covariance.csv'),header=FALSE));Q[k,]<-p$estimate;U[[k]]<-V[p$parameter,p$parameter];dimnames(U[[k]])<-list(labs,labs)
  stopifnot(max(abs(diag(U[[k]])-p$se^2))<1e-6);src[[k]]<-data.frame(member=k,source_dir=d,output_sha256=r$output_sha256,data_sha256=hashf(file.path(d,'data.dat')))
 }
 tab<-data.frame(scope=z,label=labs,rubin_pool(Q,U)$table,row.names=NULL)
 csv(tab,file.path(dest,'POOLED_PATHS.csv'));csv(data.frame(label=labs,rubin_pool(Q,U,nu_com=admission[[z]]$communities-1)$table,row.names=NULL),file.path(dest,'CLUSTER_DF_SENSITIVITY.csv'))
 j<-rj(file.path(ROOT,'models',sprintf('CHARLS_%s_E1_MI01_A',toupper(z)),'job.json'));zp<-unlist(j$zpoints)
 slopes<-do.call(rbind,lapply(zp,function(v){a<-setNames(rep(0,7),labs);a['bss']<-1;a['dc']<-v;data.frame(scope=z,z=v,pool_contrast(Q,U,a),row.names=NULL)}))
 csv(slopes,file.path(dest,'CONDITIONAL_SLOPES.csv'));csv(data.frame(member=1:20,Q),file.path(dest,'MEMBER_ESTIMATES.csv'));csv(do.call(rbind,src),file.path(dest,'MEMBER_SOURCES.csv'))
 csv(do.call(rbind,lapply(1:20,function(k)data.frame(member=k,expand.grid(row=labs,column=labs,stringsAsFactors=FALSE),covariance=as.vector(U[[k]])))),file.path(dest,'MEMBER_COVARIANCES.csv'))
 rec<-list(status='TWENTY_WORKING_MI_SENSITIVITY_POOLED',N=f$N,m=20,communities=admission[[z]]$communities,max_MCSE_over_SE=max(c(tab$MCSE_over_SE,slopes$MCSE_over_SE)),compatibility=admission[[z]]$compatibility,full_four_moderation_inference_complete=FALSE,full_H4_complete=FALSE)
 wj(rec,file.path(dest,'RECEIPT.json'));overview[[z]]$status<-rec$status;allpaths[[z]]<-tab;allslopes[[z]]<-slopes
}
csv(do.call(rbind,overview),file.path(ROOT,'results/FAMILY_OVERVIEW.csv'))
if(length(allpaths)){
 p<-do.call(rbind,allpaths);csv(p,file.path(ROOT,'results/POOLED_PATHS.csv'));csv(do.call(rbind,allslopes),file.path(ROOT,'results/CONDITIONAL_SLOPES.csv'))
 d<-p[p$label=='dc',];d$holm_p_fixed4<-p.adjust(d$p,'holm',n=4);d$bonferroni_p_fixed4<-pmin(1,4*d$p);csv(d,file.path(ROOT,'results/FOUR_MODERATIONS.csv'))
}
wj(list(status='FOUR_REGISTERED_SENSITIVITIES_ADJUDICATED',pooled=length(allpaths),m=20,full_four_moderation_inference_complete=FALSE,full_H4_complete=FALSE,manuscript_changed=FALSE),file.path(ROOT,'results/POOLING_RECEIPT.json'))
cat('DYNAMIC_MI_POOL_TERMINAL',length(allpaths),'families\n')
