"""复用已验证模型编译与合并器，只绑定修正来源的新工作插补。"""
from pathlib import Path
import json,hashlib,shutil,datetime
R=Path(__file__).resolve().parents[1];B=R.parent
M=B/'charls_corrected_dynamic_h42_adl_20261018';D=B/'charls_dynamic_mi_sensitivity_20261016';Z=B/'charls_corrected_baseline_h41_20261018';C=B/'charls_latent_integration_calibration_20261018'
for n in ['audit','contracts','runtime','results','reports','models']:(R/n).mkdir(exist_ok=True)
def put(p,s):
 assert not p.exists(),p
 p.write_text(s,encoding='utf-8')
def jp(p,s):put(p,json.dumps(s,ensure_ascii=False,indent=2)+'\n')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
gate=json.loads((M/'audit/INDEPENDENT_MI.json').read_text());assert gate['status']=='PASS' and gate['member_files']==80
ad=json.loads((M/'audit/ADL_ADMISSIONS.json').read_text());sources=json.loads((M/'contracts/SOURCE_ENTRIES.json').read_text())
entries={}
for z,e in sources.items():
 assert ad[z]['passed'] and ad[z]['m']==20
 parent=Z/'models'/f'CHARLS_{z.upper()}_H41_PARENT_MI01_A'
 receipt=json.loads((parent/'receipt.json').read_text());assert receipt['status']=='USABLE_SINGLE_DATASET'
 entries[z]=dict(e,columns=ad[z]['columns'],communities=ad[z]['communities'],source_MI=M.as_posix(),source_parent=parent.as_posix(),source_parent_sha256=h(parent/'model.out'))
jp(R/'contracts/DATA_ENTRIES.json',entries);jp(R/'audit/MI_ADMISSIONS.json',ad)
c=json.loads((D/'contracts/RUN_CONTRACT.json').read_text());c.update(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Corrected-source CHARLS four observed-baseline dynamic working MI sensitivities; no CFPS re-estimation or full-H4 claim',source_MI=M.as_posix(),max_mplus_calls=88,resource_admission=dict(minimum_available_gib=1.2,minimum_commit_available_gib=2,max_cpu_percent=85),compilation_cache='Same model semantic slots, source output hash and independent-start option only; never random draws')
c.pop('resource_admission_revision',None);c.pop('source_public_commits',None)
jp(R/'contracts/RUN_CONTRACT.json',c)
for n in ['r2e_local.R','r2e_tools.R','r2e_upstream_math.R']:shutil.copyfile(D/'code'/n,R/'code'/n)
for n in ['model_engine.py','run_one.R','active_clock.py','windows_awake_guard.py','raw_parameter_reader.py']:shutil.copyfile(C/'code'/n,R/'code'/n)
shutil.copyfile(M/'code/host_admission.py',R/'code/host_admission.py')
f=(D/'code/model_functions.R').read_text(encoding='utf-8-sig').replace(D.as_posix(),R.as_posix())
f=f.replace("file.path(ROOT,'mi',z,'private',sprintf('MI%02d.dat',member))","file.path(contract$source_MI,'mi',z,'private',sprintf('MI%02d.dat',member))")
f=f.replace("if(type=='E0')'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_adjusted_h41_20261015/models/CHARLS_CC_COMMUNITY'", "if(type=='E0')e$source_parent ")
f=f.replace("mm<-make_model(si,source_dir,perturb=start=='B')", "if(type=='E0')stopifnot(hashf(file.path(source_dir,'model.out'))==e$source_parent_sha256)\n mm<-cached_model(si,source_dir,perturb=start=='B')")
f=f.replace("what='all'", "what='summaries'")
f=f.replace("file.path(ROOT,'code/engine.py')", "file.path(ROOT,'code/model_engine.py')")
f=f.replace("if(file.exists(file.path(j$dest,'receipt.json')))return(rj(file.path(j$dest,'receipt.json')))","for(n in names(j$hashes))stopifnot(hashf(file.path(j$dest,n))==j$hashes[[n]])\n if(file.exists(file.path(j$dest,'receipt.json'))){r<-rj(file.path(j$dest,'receipt.json'));if(!is.null(r$output_sha256))stopifnot(hashf(file.path(j$dest,'model.out'))==r$output_sha256);return(r)}\n if(file.exists(file.path(j$dest,'engine_receipt.json')))return(review(j))")
f=f.replace("prepare<-function(z,type,start='A',member=1L){", "# 缓存仅避免重复读取相同父模型；两套起点分别保存。\ncompiled<-new.env(parent=emptyenv());compile_model<-make_model\ncached_model<-function(si,source_dir,perturb){k<-digest(list(si,hashf(file.path(source_dir,'model.out')),perturb),algo='sha256');if(!exists(k,compiled,inherits=FALSE))assign(k,compile_model(si,source_dir,perturb),compiled);get(k,compiled,inherits=FALSE)}\nprepare<-function(z,type,start='A',member=1L){")
put(R/'code/model_functions.R',f)
q=(D/'code/run_models.R').read_text(encoding='utf-8-sig').replace(D.as_posix(),R.as_posix())
q=q.replace("source('","source('",1)
q=q.replace("if(!f$status%in%c('NOT_STARTED','RESOURCE_DEFERRED'))next", "if(!f$status%in%c('NOT_STARTED','RESOURCE_DEFERRED','RUNNING'))next")
q=q.replace("for(a in seqs){", "for(a in seqs){")
q=q.replace("main()", "main()\nsource(file.path(ROOT,'code/pool.R'),local=TRUE)\nwriteLines('COMPLETE',file.path(ROOT,'runtime/MODELS_TERMINAL'))\ncat('CORRECTED_DYNAMIC_MODELS_NATIVE_TERMINAL\\n')")
put(R/'code/queue.R',q)
pool=(D/'code/pool.R').read_text(encoding='utf-8-sig').replace(D.as_posix(),R.as_posix());put(R/'code/pool.R',pool)
put(R/'code/run_models.R', '''# 单协调器使用已验收80份ADL插补；不改变源目录或其他研究进程。
local({
 ROOT<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_dynamic_mi_models_20261018'
 M<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_dynamic_h42_adl_20261018'
 Sys.setenv(OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1,MKL_NUM_THREADS=1)
 library(jsonlite);library(processx);library(ps)
 stopifnot(fromJSON(file.path(M,'audit/INDEPENDENT_MI.json'))$status=='PASS',!file.exists(file.path(ROOT,'runtime/OWNER.json')))
 host<-fromJSON(file.path(ROOT,'audit/HOST_ADMISSION.json'));stopifnot(isTRUE(host$admitted))
 h<-ps_handle();ps_set_cpu_affinity(h,unlist(host$selected_cores))
 op<-file.path(ROOT,'runtime/OWNER.json');write_json(list(owner=list(pid=Sys.getpid(),created=as.numeric(ps_create_time(h)))),op,auto_unbox=TRUE,digits=16)
 aw<-file.path(ROOT,'runtime/awake_MODELS');a<-process$new('<WINDOWS_USERPROFILE>/AppData/Local/Programs/Python/Python314/python.exe',c('-X','utf8',file.path(ROOT,'code/windows_awake_guard.py'),'--owner-file',op,'--output',aw,'--interval','5'),stdout=file.path(ROOT,'runtime/awake.log'),stderr='2>&1',cleanup=FALSE)
 on.exit({if(dir.exists(aw))writeLines('release',file.path(aw,'stop.request'));a$wait(8000L)},add=TRUE)
 clauder_progress('corrected_dynamic_start','One owned engine; four families; 88 calls and 5400 active engine seconds maximum')
 source(file.path(ROOT,'code/queue.R'),local=TRUE)
})
''')
g=(C/'code/harness.py').read_text(encoding='utf-8-sig').replace('pp-lgcm-charls-integration-calibration-20261018','pp-lgcm-charls-corrected-dynamic-20261018').replace('Actual native terminal and bounded calibration receipts saved','Actual native terminal and complete-family adjudications saved')
put(R/'code/harness.py',g);shutil.copyfile(M/'audit/native/PROOF.json',R/'audit/NATIVE_PROOF.json')
jp(R/'audit/PREPARATION.json',dict(status='PREPARED_NOT_SUBMITTED',source_MI_gate_sha256=h(M/'audit/INDEPENDENT_MI.json'),source_parent_hashes={z:e['source_parent_sha256'] for z,e in entries.items()},code_hashes={p.name:h(p) for p in (R/'code').glob('*') if p.is_file()},new_Mplus_calls=0))
print(json.dumps(dict(prepared=True,root=R.as_posix(),members=80,max_calls=88)))
