"""独立读取实际40份DAT，禁止将MI自身passed旗标当唯一证据。"""
from pathlib import Path
import json,hashlib
import os
for _key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ[_key]='1'
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert (R/'runtime/MODELS_TERMINAL').exists(),'Batch still active; no final input verification'
    entries=read(R/'verification/OBSERVED_ENTRIES.json');admissions=read(R/'audit/MI_ADMISSIONS.json');m=read(R/'contracts/RUN_CONTRACT.json')['m'];result={}
    for z,e in entries.items():
        d=R/'mi'/z;ad=admissions[z]
        if not ad.get('passed'):result[z]={'status':'NOT_ADMITTED','reason':ad.get('status','MIXING_OR_METHOD_GATE')};continue
        assert ad['m']==m==40 and ad['N']==e['N']
        p=Path(e['file']);assert sha(p)==e['sha256'] and sha(Path(e['pilot_input']))==e['pilot_input_sha256']
        assert read(d/'audit/SOURCE.json')['sha256']==e['pilot_input_sha256']
        a=np.loadtxt(p);names=e['columns'];observed=a!=-9999
        assert a.shape==(e['N'],len(names)) and names==ad['columns']
        ref=pd.read_csv(d/'audit/MEMBER_VALIDATION.csv').set_index('member');assert set(ref.index)==set(range(1,m+1))
        pred=pd.read_csv(d/'audit/PREDICTORS_ACTUAL.csv').set_index('variable')
        assert (pred.loc['g',['z0','z2','z_adl']]==1).all() and (pred.loc['adl',['g','z0','zg']]==1).all()
        assert (pred.loc[['g','adl'],'cluster']==-2).all() and pred.loc['g','zg']==0 and pred.loc['adl','z_adl']==0
        ia,ig,iz,izg=[names.index(n) for n in ('c7','g','z0','zg')];unchanged=[i for i in range(len(names)) if i not in (ia,ig,izg)]
        for k in range(1,m+1):
            p=d/'private'/f'MI{k:02d}.dat';assert sha(p)==ref.loc[k,'sha256'];b=np.loadtxt(p)
            assert b.shape==a.shape and np.array_equal(a[observed],b[observed])
            assert np.array_equal(a[:,unchanged],b[:,unchanged])
            assert np.isin(b[:,ia],np.arange(7)).all() and np.isin(b[:,ia],a[observed[:,ia],ia]).all()
            assert np.isin(b[:,ig],[0,1]).all() and np.allclose(b[:,izg],b[:,iz]*b[:,ig],atol=1e-12,rtol=1e-12)
        cc=np.loadtxt(d/'private/CC.dat');mask=observed[:,ia]&observed[:,ig];assert np.array_equal(cc,a[mask])
        result[z]={'status':'PASS','members':m,'N':len(a),'N_CC':int(mask.sum()),'original_cells_preserved':int(observed.sum())*m,'XY_masks_preserved':True,'donor_support':True,'resource_products':True}
    out={'status':'PASS_FOR_ADMITTED_FAMILIES','registered':4,'admitted_and_verified':sum(x['status']=='PASS' for x in result.values()),'scopes':result,'not_MAR_or_congeniality_proof':True}
    (R/'audit/INDEPENDENT_INCOME_INPUTS.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))
if __name__=='__main__':main()
