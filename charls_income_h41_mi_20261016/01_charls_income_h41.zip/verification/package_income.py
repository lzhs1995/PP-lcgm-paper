"""终态后按逐文件白名单打包聚合证据；每个ZIP严格小于25MB。"""
from pathlib import Path
import csv,hashlib,io,json,re,zipfile

R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()

def main():
    assert read(R/'verification/FINISH_STATE.json')['status']=='VERIFIED_SUMMARY_READY_FOR_PUBLICATION'
    assert read(R/'audit/INDEPENDENT_H41_VERIFICATION.json')['status']=='PASS'
    assert read(R/'audit/INDEPENDENT_INCOME_INPUTS.json')['status']=='PASS_FOR_ADMITTED_FAMILIES'
    assert read(R/'audit/CLAUDER_COMPLETION.json')['decision']=='PASS'
    S=R/'public_stage';S.mkdir(exist_ok=True)
    assert not list(S.glob('*.zip')),'Existing release: inspect rather than overwrite'
    selected={};generated={}
    def add(rel,role='aggregate_or_code',required=True):
        p=R/rel
        if not p.exists():
            assert not required,p
            return
        assert p.is_file() and 'private' not in Path(rel).parts
        assert p.name!='data.dat' and p.suffix.lower() not in ('.rds','.dta','.RData'.lower())
        selected[rel]=(p,role)
    for rel in ('summary/REPORT.md','summary/RESULTS_DISCUSSION.md','summary/H41_REGISTERED_12.csv','summary/GROUP_CONTRASTS.csv',
                'summary/SUMMARY_RECEIPT.json','summary/H41_GROUP_DIFFERENCES.pdf',
                'contracts/RUN_CONTRACT.json','audit/MI_ADMISSIONS.json',
                'audit/INDEPENDENT_INCOME_INPUTS.json','audit/INDEPENDENT_H41_VERIFICATION.json',
                'audit/CLAUDER_COMPLETION.json','audit/EXECUTION_CODE_HASHES.json',
                'runtime/PIPELINE_TERMINAL.json','runtime/STEPS.json','runtime/budget_status.json',
                'audit/HOUSEHOLD_SCOPE.json','audit/FINAL_FIGURE_REVIEW.json',
                'verification/FINISH_STATE.json','verification/OBSERVED_ENTRIES.json'):
        add(rel)
    for name in ('launch.R','coordinator.py','engine.py','run_one.R','run_models.R',
                 'pool_h41.R','prepare_scope.R','income_imputers.R','r2e_local.R',
                 'r2e_tools.R','r2e_upstream_math.R','validate_setup.R','prepare_cc.R'):
        add('code/'+name)
    for name in ('verify_income_inputs.py','export_original.R','verify_household_scope.R','raw_parameter_reader.py',
                 'summarize_h41.py','plot_h41.py','finish_when_terminal.py','package_income.py'):
        add('verification/'+name)
    for name in ('SETUP_VALIDATION.json','PERFORMANCE_RESUME.json','RECOVERY_CPU_SNAPSHOT.json',
                 'CPU_SCHEDULING_EVIDENCE.json','WINDOWS_MEMORY_SNAPSHOT_20261016T1844.json',
                 'NATIVE_POLL_RECOVERY_20261016T1854.json','GENDER_BOOTSTRAP_RESOURCE.json',
                 'OWNED_STAGE_SCHEDULING.jsonl','VERIFIER_SCHEDULING_WARNING.json'):
        add('audit/'+name,required=False)
    for p in (R/'audit').glob('VERIFIER_SCHEDULING_20*.json'):
        add(p.relative_to(R).as_posix(),'owned_process_scheduling_evidence')
    for name in ('STOP_RECEIPT.json','REPAIR_RECEIPT.json','SECOND_START_RESOURCE_DEFERRAL.json',
                 'RECOVERY_CPU_SNAPSHOT.json'):
        add('audit/resource_admission_repair/'+name,required=False)
    for name in ('RECOVERY_DIAGNOSIS.json','PREPARED.json'):
        add('audit/gender_cache_recovery/'+name,required=False)
    for name in ('prepare_gender_continuation.py','continue_gender_when_terminal.R'):
        add('verification/'+name)
    for name in ('prepare_gender_bootstrap_recovery.py','resume_gender_bootstrap.R','schedule_owned_verifier.py'):
        add('verification/'+name)
    for name in ('PREPARED.json','PREPARED.before_metadata_correction.json'):
        add('audit/gender_bootstrap_recovery/'+name,required=False)
    for name in ('CALL_RESULTS.json','FAMILY_STATUS.json','FAMILY_OVERVIEW.csv','POOLING_RECEIPT.json',
                 'JOINT_D1.csv','POOLED_PATHS.csv','GROUP_CONTRASTS.csv','CC_MI_COMPARISON.csv'):
        add('results/'+name,required=name in ('CALL_RESULTS.json','FAMILY_STATUS.json','FAMILY_OVERVIEW.csv','POOLING_RECEIPT.json'))
    for z in ('sd','gender','oldest','son'):
        for rel in ('audit/ADMISSION.json','audit/SOURCE.json','audit/IMPUTER_INSTRUMENTATION.json',
                    'audit/CONVERGENCE.csv','audit/PREDICTORS_ACTUAL.csv',
                    'audit/MEMBER_VALIDATION.csv','audit/FIT_LOG.jsonl','audit/LOGGED_EVENTS.csv',
                    'audit/WARNINGS.csv','audit/R_SESSION_INFO.txt','results/MI_SUMMARIES.csv','results/MI_CHAINS.pdf'):
            add(f'mi/{z}/{rel}','aggregate_imputation_diagnostic',required=False)
    for family in read(R/'results/FAMILY_STATUS.json'):
        add(f'results/{family}_START_COMPARISON.json',required=False)
        for name in ('POOLED_PATHS.csv','CLUSTER_DF_SENSITIVITY.csv','GROUP_CONTRASTS.csv','JOINT_D1.csv',
                     'MEMBER_ESTIMATES.csv','MEMBER_COVARIANCES.csv','MEMBER_SOURCES.csv','FIT_BY_MEMBER.csv','RECEIPT.json'):
            add(f'results/{family}/{name}','aggregate_pooled_statistics',required=False)
    for model in read(R/'results/CALL_RESULTS.json'):
        for name in ('model.inp','model.out','job.json','engine_receipt.json','receipt.json','not_run.json',
                     'design_check.json','mplus_execution.log','start_mapping.csv','validation.json',
                     'parameters_high_precision.csv','matrix_values.csv','tech1_parameter_map.csv',
                     'parameter_covariance.csv','key_paths.csv','estimates.dat','tech3.dat'):
            add(f'models/{model}/{name}',
                'saved_parameter_estimates' if name=='estimates.dat' else
                'saved_parameter_covariance' if name=='tech3.dat' else 'aggregate_model_evidence',required=False)
    # 公共复算只豁免被明确扣留的微观data.dat哈希；原始参数、协方差、人数仍全部核验。
    p=R/'verification/verify_h41_results.py';s=p.read_text(encoding='utf-8-sig')
    old="ap.add_argument('--output',type=Path);args=ap.parse_args()"
    assert s.count(old)==1
    s=s.replace(old,"ap.add_argument('--output',type=Path);ap.add_argument('--public',action='store_true');args=ap.parse_args()")
    old="for fn,h in job['hashes'].items():assert hashlib.sha256((d/fn).read_bytes()).hexdigest()==h"
    new="""for fn,h in job['hashes'].items():
   if args.public and fn=='data.dat' and not (d/fn).exists():continue
   assert hashlib.sha256((d/fn).read_bytes()).hexdigest()==h"""
    assert s.count(old)==1;s=s.replace(old,new)
    old="OUT.parent.mkdir(parents=True,exist_ok=True)"
    assert s.count(old)==1;s=s.replace(old,"out['individual_data_hashes_recomputed']=not args.public\n "+old)
    compile(s,'verify_h41_results.py','exec')
    generated['verification/verify_h41_results.py']=(s.encode(),'public_verifier_with_explicit_microdata_boundary',sha(p.read_bytes()))
    # 完整保留未形成推断的家族与底层失败记录，不只显示上层wrapper错误。
    admissions=read(R/'audit/MI_ADMISSIONS.json');incomplete={}
    states=read(R/'runtime/STEPS.json')
    for family,fs in read(R/'results/FAMILY_STATUS.json').items():
        if fs['status']=='FORTY_USABLE_PENDING_POOLING':continue
        scope=family.split('_')[0].lower();p=R/'mi'/scope/'audit/FIT_LOG.jsonl'
        fits=[json.loads(s) for s in p.read_text().splitlines() if s.strip()] if p.exists() else []
        incomplete[family]=dict(family_status=fs,imputation_admission=admissions[scope],
           runner_step=states.get('mi_'+scope),conditional_fit_failures=[x for x in fits if not x.get('valid')],
           logged_conditional_calls=len(fits),complete_family_pooled=False,
           interpretation='No adopted complete-family inference; neither zero effect nor proof of nonidentification')
    generated['summary/INCOMPLETE_SCOPES.json']=(json.dumps(incomplete,indent=2).encode(),'incomplete_family_adjudication',None)
    lines=['# 未形成完整推断的范围','',
           '这些范围保留失败证据，不合并成功子集，不把未取得估计写成零效应。','']
    if not incomplete:lines.append('本批四个收入家族均完整；这仍不代表四项动态调节或完整H4已完成。')
    for family,d in incomplete.items():
        lines.extend([f"## {family}",'',f"家族状态：{d['family_status']['status']}。已记录条件调用：{d['logged_conditional_calls']}。",''])
        for e in d['conditional_fit_failures']:
            lines.append(f"- 第{e.get('iteration')}轮、第{e.get('fit_n')}次条件调用，目标{e.get('target')}，后端{e.get('backend')}：{e.get('error','未通过拟合检查')}；记录耗时{e.get('seconds')}秒。")
        lines.extend(['','下层记录见同包FIT_LOG、WARNINGS和ADMISSION；上层runner状态与源代码同时保留。超时本身不确定其唯一原因，不改写成效应不存在或理论不可识别。',''])
    generated['summary/INCOMPLETE_SCOPES.md']=('\n'.join(lines).encode(),'incomplete_family_explanation',None)
    payload={};manifest=[]
    for name,(p,role) in selected.items():generated[name]=(p.read_bytes(),role,None)
    for name,(raw,role,adapted) in generated.items():
        if name.endswith(('.pdf','.png')):data=raw
        else:
            s=raw.decode('utf-8-sig')
            for prefix in ('<LOCAL_USER_HOME>','<LOCAL_USER_HOME>','C:\\\\Users\\\\LZHS','<LOCAL_USER_HOME>','<LOCAL_USER_HOME>'):
                s=s.replace(prefix,'<LOCAL_USER_HOME>')
            assert not re.search(r'(?i)(?:api[_-]?key|access_token)\s*[:=]\s*["\']?[A-Za-z0-9_-]{20,}',s),name
            if name.endswith('.csv') and Path(name).name!='parameter_covariance.csv':
                headers={h.lower() for h in next(csv.reader(io.StringIO(s)))}
                assert not headers&{'pid','fid','childid','householdid','communityid'},name
            data=s.encode('utf-8')
        payload[name]=data;manifest.append(dict(path=name,bytes=len(data),sha256=sha(data),
                          local_source_sha256=adapted or sha(raw),role=role,public_verifier_adapted=bool(adapted)))
    payload['PAYLOAD_MANIFEST.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
    # 分包按压缩后字节检查；每包包含独立路径，全部解压到同一目录即可复算。
    items=sorted(payload.items());groups=[items]
    while True:
        built=[];large=False
        for group in groups:
            buf=io.BytesIO()
            with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
                for name,data in group:z.writestr(name,data)
            if len(buf.getvalue())>=25_000_000:
                assert len(group)>1,'A single file exceeds package limit'
                mid=len(group)//2;built.extend([group[:mid],group[mid:]]);large=True
            else:built.append(group)
        groups=built
        if not large:break
    packages=[]
    for i,group in enumerate(groups,1):
        zp=S/f'{i:02d}_charls_income_h41.zip'
        with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for name,data in group:z.writestr(name,data)
        assert zp.stat().st_size<25_000_000
        with zipfile.ZipFile(zp) as z:assert z.testzip() is None
        packages.append(dict(file=zp.name,bytes=zp.stat().st_size,sha256=sha(zp.read_bytes()),files=len(group)))
    pm=dict(packages=packages,privacy='Explicit file allowlist; individual DAT/DTA/RDS/MI withheld; parameter DAT files only',
            full_H4_complete=False,dynamic_moderations_complete=False)
    (S/'PACKAGE_MANIFEST.json').write_text(json.dumps(pm,indent=2),encoding='utf-8')
    for name in ('REPORT.md','RESULTS_DISCUSSION.md','H41_REGISTERED_12.csv','GROUP_CONTRASTS.csv','H41_GROUP_DIFFERENCES.pdf',
                 'INCOMPLETE_SCOPES.md','INCOMPLETE_SCOPES.json'):
        (S/name).write_bytes(payload['summary/'+name])
    (S/'README.md').write_text('''# CHARLS 收入 H4.1 完整家族核验

**四项调节完整推断、完整 H4 仍未完成。**

[报告](REPORT.md) · [结果讨论与边界](RESULTS_DISCUSSION.md) · [注册12家族状态](H41_REGISTERED_12.csv) · [组内路径及直接组差](GROUP_CONTRASTS.csv) · [区间图](H41_GROUP_DIFFERENCES.pdf) · [未完成范围及原因](INCOMPLETE_SCOPES.md) · [包清单](PACKAGE_MANIFEST.json)

本批检验观测基期家内差异与家庭收入组的条件关联异质性，不是SX×Z0动态调节或H4.2。只有完整40成员及起点检查通过才合并。不得把未形成可采用估计写成零效应。

将所有ZIP解压到同一目录，先按PAYLOAD_MANIFEST.json核对每项SHA256，再执行：

`python verification/verify_h41_results.py --public --root . --output PUBLIC_RECOMPUTATION.json`

需要numpy、pandas、scipy；不调用Mplus。公共复算核对保存参数、TECH3、样本数与合并计算，不复算被扣留的个体data.dat，也不重新拟合CFPS/CHARLS。本机原观测与插补检查只以聚合回执公开。

组合12项中的教育/城乡8家族复用[先前固定提交](https://github.com/lzhs1995/PP-lcgm-paper/tree/950a01ea8599e0782cc3685563c98265c4fc924f/charls_h41_mi_20261016)，不重复上传完整旧包。本批为新增收入4项及组合敏感性，不把相同资料解释为独立复制。方法仍是FCS工作近似，混合通过不证明MAR或精确相容性。

这是一批实证扩展的报告，不修改已冻结正文/附录，不新增NLM审稿。效率和恢复经验见[mplusautomation-guide PR25](https://github.com/lzhs1995/clauder-rstudio-workbench/pull/25)。
''',encoding='utf-8')
    (R/'audit/PUBLIC_FILE_SELECTION.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    sr=read(R/'summary/SUMMARY_RECEIPT.json')
    (S/'FOR_WEB_REVIEWERS.md').write_text(f'''# 给网页端审阅者的本批说明

**四项调节完整推断、完整 H4 仍未完成。** 本批汇总注册12个CHARLS基期资源异质性家族，其中{sr['pooled']}个有完整条件MI合并，新增收入家族{sr['income_pooled']}/4。状态与缺失行请以 `H41_REGISTERED_12.csv` 为准。

1. 先读 `REPORT.md` 和 `RESULTS_DISCUSSION.md`：其中有实际控制变量、各范围缺失数、插补规则、家族完成状态、联合检验与逐参数结果的区别。
2. `GROUP_CONTRASTS.csv` 给出组0、组1及直接组差；PDF显示组差的逐参数区间。不能仅凭两组星号判断异质性。
3. 所有ZIP都小于25,000,000字节；解压到同一目录后按 `PAYLOAD_MANIFEST.json` 核对。公共复算命令见README，独立读取保存参数及TECH3，不拟合模型、不读取微观数据。
4. 新收入家族每个要求40成员，教育/城乡旧8家族每个20成员；旧结果来自README中的固定提交，不是重新估计，更不是独立样本验证。多重比较固定收入4项和组合12项，不随失败或显著性缩小分母。
5. 收入为家庭净收入分组，与CFPS个人收入不同；X为子女见面频率，与CFPS情感亲近度不同。Z及Z×G还有基期指标直接路径，潜截距系数不能当全部基期关联。
6. FCS为工作近似。原观测保留、混合和模型合法性核验不证明MAR或与潜变量交互精确相容。本批不检验SX×Z动态调节或H4.2，也不恢复已失败CFPS规格。
7. 资源延期、可选缓存损坏、通信错误和统计失败分别保留证据。已完成成员复用，失败成员不替换；没有为了显著性挑选插补或规格。

可复核问题是：公开保存结果与合并数值是否一致、组差方向及不确定性如何解释、缺失与测量限制是否写准确。不要把本批完整条件家族改写为原论文全部H4或动态机制已验证。当前冻结论文没有修改，也没有新NLM轮次。
''',encoding='utf-8')
    print(json.dumps(pm))
if __name__=='__main__':main()
