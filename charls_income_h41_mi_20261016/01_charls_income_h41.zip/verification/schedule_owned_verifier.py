"""只调整本批已核实终态核验器及子进程，不关闭或改变外部任务。"""
from pathlib import Path
import datetime,json,psutil
R=Path(__file__).resolve().parents[1]
def main():
    lock=json.loads((R/'verification/finish.lock').read_text())
    p=psutil.Process(lock['pid'])
    assert abs(p.create_time()-lock['created'])<.01
    assert any('finish_when_terminal.py' in a for a in p.cmdline())
    cpu=psutil.cpu_percent(interval=1,percpu=True);base=p.cpu_affinity()
    available=[i for i in base if cpu[i]<50]
    use=len(available)>=2 and any(cpu[i]>=90 for i in base)
    rows=[]
    if use:
        for q in [p]+p.children(recursive=True):
            born=q.create_time();old=q.cpu_affinity()
            assert abs(psutil.Process(q.pid).create_time()-born)<.01
            q.cpu_affinity(available)
            rows.append(dict(pid=q.pid,created=born,name=q.name(),before=old,after=q.cpu_affinity()))
    out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),host_cpu=cpu,
             own_root_pid=p.pid,applied=use,changes=rows,foreign_processes_modified=False)
    f=R/'audit'/('VERIFIER_SCHEDULING_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S')+'.json')
    f.write_text(json.dumps(out,indent=2));print(json.dumps(out))
if __name__=='__main__':main()
