"""轻量终态接续：只运行结果核验/汇总，不启动或重启统计估计。"""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time
import traceback
import psutil

ROOT = Path(__file__).resolve().parents[1]
STATE = ROOT / 'verification/FINISH_STATE.json'
LOCK = ROOT / 'verification/finish.lock'
FILES = ('verify_income_inputs.py', 'verify_h41_results.py', 'raw_parameter_reader.py',
         'summarize_h41.py', 'plot_h41.py', 'schedule_owned_verifier.py')
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def publish(p, obj):
    tmp = p.with_name(p.name + f'.{os.getpid()}.tmp')
    tmp.write_text(json.dumps(obj, indent=2), encoding='utf-8')
    for k in range(20):
        try: os.replace(tmp, p); return
        except PermissionError:
            if k == 19: raise
            time.sleep(.1)
def main():
    me = psutil.Process()
    if LOCK.exists():
        old = read(LOCK)
        try:
            q = psutil.Process(old['pid'])
            assert abs(q.create_time() - old['created']) > .01, 'Existing finish watcher alive'
        except psutil.NoSuchProcess: pass
        raise RuntimeError('Stale watcher lock requires explicit reconciliation; no duplicate')
    fd = os.open(LOCK, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    os.write(fd, json.dumps(dict(pid=me.pid, created=me.create_time(), utc=utc())).encode())
    os.close(fd)
    from schedule_owned_verifier import main as schedule_owned
    try: schedule_owned()
    except Exception as exc:
        publish(ROOT / 'audit/VERIFIER_SCHEDULING_WARNING.json',
                dict(error=repr(exc),utc=utc(),action='Verification continues without claiming scheduling success'))
    hashes = {name: hashlib.sha256((ROOT / 'verification' / name).read_bytes()).hexdigest()
              for name in FILES}
    publish(ROOT / 'verification/FINISH_CODE_HASHES.json', hashes)
    start = time.monotonic(); active = None
    state = dict(status='WAITING_FOR_PIPELINE_TERMINAL', pid=me.pid, created=me.create_time(),
                 started_utc=utc(), estimation_calls=0, steps=[])
    try:
        while not (ROOT / 'runtime/PIPELINE_TERMINAL.json').exists():
            assert time.monotonic() - start < 90000, 'No terminal within 25-hour watch limit'
            # 只读持久进度，30秒间隔；不发MCP轮询、不读逐人数据。
            try:
                live = read(ROOT / 'runtime/PIPELINE.json')
                state['pipeline_step'] = live.get('step')
                state['pipeline_updated_at'] = live.get('updated_at')
            except (FileNotFoundError, PermissionError, json.JSONDecodeError): pass
            state['updated_at'] = utc(); publish(STATE, state); time.sleep(30)
        terminal = read(ROOT / 'runtime/PIPELINE_TERMINAL.json')
        assert terminal['status'] == 'BATCH_TERMINAL' and terminal.get('results'), terminal
        assert (ROOT / 'runtime/MODELS_TERMINAL').exists()
        state['pipeline_terminal_sha256'] = hashlib.sha256((ROOT / 'runtime/PIPELINE_TERMINAL.json').read_bytes()).hexdigest()
        for name, h in hashes.items():
            assert hashlib.sha256((ROOT / 'verification' / name).read_bytes()).hexdigest() == h
        for script, limit in [('verify_income_inputs.py', 900), ('verify_h41_results.py', 1200),
                              ('summarize_h41.py', 180), ('plot_h41.py', 300)]:
            state.update(status='POSTPROCESSING', step=script, updated_at=utc()); publish(STATE, state)
            t = time.monotonic()
            with (ROOT / 'verification' / (script + '.log')).open('xb') as log:
                active = subprocess.Popen([sys.executable, '-u', '-X', 'utf8',
                                           str(ROOT / 'verification' / script)],
                                          cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
                child = psutil.Process(active.pid); born = child.create_time()
                try: rc = active.wait(timeout=limit)
                except subprocess.TimeoutExpired:
                    if abs(psutil.Process(active.pid).create_time() - born) < .01:
                        active.kill(); active.wait(timeout=20)
                    raise RuntimeError('Postprocessing time limit: ' + script)
            active = None
            state['steps'].append(dict(script=script, exitcode=rc, seconds=time.monotonic()-t))
            assert rc == 0, 'Inspect saved log: ' + script
        state.update(status='VERIFIED_SUMMARY_READY_FOR_PUBLICATION', updated_at=utc(),
                     full_H4_complete=False, dynamic_moderations_complete=False)
        publish(STATE, state)
    except Exception as exc:
        state.update(status='POSTPROCESSING_STOPPED_INSPECT_LOG', error=repr(exc),
                     traceback=traceback.format_exc(), updated_at=utc())
        publish(STATE, state)
        raise
    finally:
        LOCK.unlink(missing_ok=True)
if __name__ == '__main__': main()
