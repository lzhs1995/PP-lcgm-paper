# 独立回读已核验的原始分析入口，仅在隔离verification/private保存校验基线。
local({
 BATCH<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_h41_mi_20261016'
 PILOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_mi_pilot_20261016'
 library(jsonlite);library(digest)
 out<-file.path(BATCH,'verification/private');dir.create(out,recursive=TRUE,showWarnings=FALSE)
 incfile<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_scope_20261016/private/INCOME_SCOPE_INPUTS.rds'
 inc<-readRDS(incfile);contract<-fromJSON(file.path(BATCH,'contracts/RUN_CONTRACT.json'))
 stopifnot(inc$threshold==contract$threshold_CNY,contract$m==40)
 rows<-list()
 for(z in contract$indicators){
  src<-file.path(PILOT,'attempt3/private',paste0(z,'_INPUTS.rds'));a<-readRDS(src);idx<-inc$scope[[z]]
  stopifnot(identical(a$data$g,inc$group[idx]),identical(a$data$adl,inc$core$adl[idx]),!anyNA(a$data$z0))
  b<-a$analysis;stopifnot(identical(as.numeric(b$c7),as.numeric(a$data$adl)),identical(as.numeric(b$z0),as.numeric(a$data$z0)))
  b$g<-inc$group[idx];b$zg<-b$g*b$z0
  f<-file.path(out,paste0(z,'_OBSERVED.dat'));stopifnot(!file.exists(f))
  write.table(b,f,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
  rows[[z]]<-list(N=nrow(b),columns=names(b),file=f,sha256=digest(file=f,algo='sha256'),pilot_input=src,pilot_input_sha256=digest(file=src,algo='sha256'),income_source_sha256=digest(file=incfile,algo='sha256'),threshold=inc$threshold,missing_G=sum(is.na(b$g)),missing_ADL=sum(is.na(b$c7)))
 }
 write_json(rows,file.path(BATCH,'verification/OBSERVED_ENTRIES.json'),auto_unbox=TRUE,pretty=TRUE)
 cat('Four independent observed-entry exports; isolated private paths only; no imputation or Mplus\n')
})
