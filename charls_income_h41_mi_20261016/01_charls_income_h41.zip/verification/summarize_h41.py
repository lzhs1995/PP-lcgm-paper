"""基于已核验完整家族汇总；不执行插补、模型或显著性筛选。"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import math
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parents[1]
OLD = HERE.parent / 'charls_h41_mi_20261016'
SCOPES = ('SD', 'GENDER', 'OLDEST', 'SON')
GROUPS = ('EDU', 'URBAN', 'INC')
READ = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))


def csvrows(path):
    with path.open(encoding='utf-8-sig', newline='') as fh:
        return list(csv.DictReader(fh))


def writecsv(path, rows):
    assert rows
    with path.open('w', encoding='utf-8-sig', newline='') as fh:
        wr = csv.DictWriter(fh, list(rows[0]))
        wr.writeheader()
        wr.writerows(rows)


def holm_fixed(rows, denominator, target):
    # 固定注册检验数；未检验行保持空值，不伪造p=1或零效应。
    valid = sorted((float(r['joint_p']), i) for i, r in enumerate(rows)
                   if r['joint_p'] != '')
    assert len(valid) <= denominator
    last = 0.0
    for rank, (p, i) in enumerate(valid):
        last = min(1.0, max(last, (denominator - rank) * p))
        rows[i][target] = last


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--prior-only', action='store_true',
                    help='仅在独立目录演练旧8家族；收入明确记未读取')
    args = ap.parse_args()
    if not args.prior_only:
        assert (HERE / 'runtime/MODELS_TERMINAL').exists(), 'Active batch'
        iv = READ(HERE / 'audit/INDEPENDENT_H41_VERIFICATION.json')
        dv = READ(HERE / 'audit/INDEPENDENT_INCOME_INPUTS.json')
        assert iv['status'] == 'PASS' and iv['required_members_per_family'] == 40
        assert dv['status'] == 'PASS_FOR_ADMITTED_FAMILIES'
    else:
        iv = READ(HERE / 'verification/REHEARSAL_EXISTING_20.json')
        assert iv['status'] == 'PASS' and len(iv['pooled_families']) == 8
    out = HERE / ('verification/PRIOR_ONLY_REHEARSAL' if args.prior_only else 'summary')
    out.mkdir(exist_ok=True)
    hashes = {}

    def track(p):
        key = f'{p.relative_to(OLD) if p.is_relative_to(OLD) else p.relative_to(HERE)}'
        key = ('prior20/' if p.is_relative_to(OLD) else 'income40/') + key
        hashes[key] = hashlib.sha256(p.read_bytes()).hexdigest()

    rows, contrasts = [], []
    for group in GROUPS:
        root = OLD if group != 'INC' else HERE
        overview = None
        if not (args.prior_only and group == 'INC'):
            p = root / 'results/FAMILY_OVERVIEW.csv'
            track(p)
            overview = {r['family']: r for r in csvrows(p)}
        for scope in SCOPES:
            family = f'{scope}_{group}'
            row = dict(family=family, scope=scope, resource=group,
                       status='NOT_READ_PRIOR_ONLY_REHEARSAL', N='', members='',
                       expected_members=40 if group == 'INC' else 20,
                       joint_p='', holm_p_income4='', bonferroni_p_income4='',
                       holm_p_combined12='', bonferroni_p_combined12='',
                       max_MCSE_over_SE='', group_definition='')
            if overview is not None:
                f = overview[family]
                row.update(status=f['status'], N=f['N'], members=f['members'])
                d = root / 'results' / family
                if 'POOLED' in f['status']:
                    recpath, jtpath = d / 'RECEIPT.json', d / 'JOINT_D1.csv'
                    track(recpath); track(jtpath)
                    rec, jt = READ(recpath), csvrows(jtpath)
                    assert rec['m'] == row['expected_members'] == int(f['members'])
                    assert len(jt) == 1 and jt[0]['family'] == family
                    p = float(jt[0]['p']); assert math.isfinite(p) and 0 <= p <= 1
                    row.update(joint_p=p, max_MCSE_over_SE=rec['MCSE_over_SE_max'],
                               group_definition=rec['group'])
                    row['bonferroni_p_combined12'] = min(1.0, 12 * p)
                    if group == 'INC':
                        assert family in iv['pooled_families']
                        row['bonferroni_p_income4'] = min(1.0, 4 * p)
                    cp = d / 'GROUP_CONTRASTS.csv'; track(cp)
                    for cr in csvrows(cp):
                        assert cr['family'] == family
                        contrasts.append(dict(family=family, resource=group, scope=scope,
                                              N=f['N'], m=rec['m'], **{
                            k: cr[k] for k in ('contrast', 'estimate', 'se', 'lower', 'upper', 'p')}))
            rows.append(row)
    holm_fixed(rows, 12, 'holm_p_combined12')
    income = [r for r in rows if r['resource'] == 'INC']
    holm_fixed(income, 4, 'holm_p_income4')
    if not args.prior_only and (HERE / 'results/JOINT_D1.csv').exists():
        for rr in csvrows(HERE / 'results/JOINT_D1.csv'):
            r = next(x for x in income if x['family'] == rr['family'])
            assert math.isclose(r['holm_p_income4'], float(rr['holm_p_4']), rel_tol=1e-10, abs_tol=1e-12)
    writecsv(out / 'H41_REGISTERED_12.csv', rows)
    writecsv(out / 'GROUP_CONTRASTS.csv', contrasts)
    complete = sum(r['joint_p'] != '' for r in rows)
    n_income = sum(r['joint_p'] != '' for r in income)
    receipt = dict(status='PRIOR_ONLY_REHEARSAL' if args.prior_only else 'VERIFIED_AGGREGATE_SUMMARY',
                   created_utc=datetime.now(timezone.utc).isoformat(), registered=12,
                   pooled=complete, income_registered=4, income_pooled=n_income,
                   dynamic_moderation_complete=False, full_H4_complete=False,
                   source_sha256=hashes)
    (out / 'SUMMARY_RECEIPT.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    fmt = lambda x: '未形成完整推断' if x == '' else f'{float(x):.4g}'
    table = '\n'.join(f"| {r['family']} | {r['members']} | {fmt(r['joint_p'])} | {fmt(r['holm_p_combined12'])} | {r['status']} |" for r in rows)
    scope_table = ''
    if not args.prior_only:
        ep = HERE / 'verification/OBSERVED_ENTRIES.json'; track(ep)
        apath = HERE / 'audit/MI_ADMISSIONS.json'; track(apath)
        entries, admissions = READ(ep), READ(apath)
        hp = HERE / 'audit/HOUSEHOLD_SCOPE.json'; track(hp)
        hh = READ(hp); assert hh['status'] == 'ONE_RESPONDENT_PER_HOUSEHOLD_CONFIRMED'
        assert hh['scopes']['cohort']['N'] == hh['scopes']['cohort']['households'] == 3006
        scope_table = '\n'.join(
            f"| {z.upper()} | {e['N']} | {e['missing_G']} | {e['missing_ADL']} | "
            f"{admissions[z].get('iterations', '未形成完整家族')} | "
            f"{'通过' if admissions[z].get('passed') else '未准入'} |"
            for z, e in entries.items())
        # 新增输入来源同样进入已保存的汇总哈希记录。
        (out / 'SUMMARY_RECEIPT.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    text = f'''# CHARLS 基期观察指标与资源组：H4.1 家族汇总

**四项调节完整推断、完整 H4 仍未完成。**

本文件状态：{receipt['status']}。注册12个家族中，{complete}个有完整条件MI推断；收入家族为{n_income}/4。未形成完整推断的家族不填P值，也不合并成功子集。

| 家族 | 完整成员数 | 两路径D1 P | 固定12项Holm P | 状态 |
|---|---:|---:|---:|---|
{table}

教育、城乡原8家族各20份插补保持原交付不变。收入4家族每个要求40份；收入组按基期全队列可观测家庭净收入的固定中位数8730元划分，负值和零值保留。它是家庭资源操作化，不等同于CFPS个人总收入。

主要收入多重比较固定4项；组合12项是新增敏感性汇总。固定注册分母不因失败或不显著而减少。家族使用高度重合样本，不能视为独立重复；Holm/Bonferroni不要求检验间独立。未检验者保持缺失，不能写成无效应。

组差直接检验gizg、gszg，联合检验为二者D1。GROUP_CONTRASTS.csv完整列出两组路径和直接差值，不能由一组显著另一组不显著推断组差。主路径和组差区间为逐参数区间，未冒充同时置信区间。联合P本身不能判定原假设方向获得支持。

Z0与Z0×G同时预测四增长因子和x1/y1，潜截距路径为模型条件关联，非基期观测分数总关联。SD是绝对离散度；性别、排行差为有方向的差值，不能都解释为非负不和谐。CHARLS测量子女见面频率，不自动等同于CFPS情感亲近度。

FCS是含交互信息的工作近似；混合检查和原观测保留不证明MAR或精确实质模型相容性。本批没有恢复失败CFPS规格，没有检验动态SX×Z交互或H4.2，也没有修改已冻结论文。

## 基期控制变量与缺失处理

冻结队列为2011基期入组的3,006人；本批按各项子女指标可定义性形成范围，人数见下表。五期时间载荷为0、2、4、7、9；X/Y保留2011基期标准化口径及原始缺失掩码，轨迹缺失继续进入FIML，不先补齐每人的全部轨迹。

| 模型列 | 实际定义 |
|---|---|
| c1 | (基期年龄−70)/10 |
| c2 | 女性指示变量 |
| c3 | 初中及以上教育 |
| c4 | 城市居住指示变量 |
| c5 | 有伴侣指示变量 |
| c6 | 有效子女报告数，不冒充完整生育子女总数 |
| c7 | 基期ADL困难数，0—6 |
| c8—c11 | 自评健康第2—5类的四个指示变量，第1类为参照 |

这些是11个模型列，不是11种彼此独立的健康测量。沿用已核验的性别来源恢复和官方ADL定义：原队列1例缺失性别有跨波原始来源一致核查；2例ADL部分题目总分保留原定义及完整性标志，不把部分总分说成六题全答。当前范围的剩余核心控制缺失为ADL。

对官方 `householdID` 的只读回查确认：冻结队列3,006人来自3,006个家庭，各分析范围均每户一人。因此本批不存在同户多位受访者的收入组需要共同插补的问题；不能把这个样本事实外推到其他CHARLS样本。家庭收入仍按家庭变量解释，社区随机截距也不等同于家庭层随机效应。聚合证据见 `audit/HOUSEHOLD_SCOPE.json`。

| 范围 | 人数 | 原收入组缺失 | 原ADL缺失 | 完整迭代轮数 | 插补准入 |
|---|---:|---:|---:|---:|---|
{scope_table}

收入G按固定8730元分界定义，已观测的负收入与零收入归G=0。缺失G用社区随机截距二项logit条件模型插补；ADL用社区随机截距PMM、5个供体。每范围40份、至少10轮，最后五轮G和ADL的PSRF均有限且小于1.1才准入；否则最多20轮。Z×G及Z×ADL被动重算，插补预测矩阵保留相关交互信息。结构上未定义的子女对比不进行插补。

收入与ADL的原观测、供体支持、实际输出DAT、XY缺失掩码及被动乘积，见独立回执 `audit/INDEPENDENT_INCOME_INPUTS.json`。完整案例只是敏感性对照，不替代缺失处理；正式合并保留插补间不确定性。开发版mice与本地TMB后端适配、固定参数协方差及条件随机截距方差的核验，沿用[已发布的方法包](https://github.com/lzhs1995/PP-lcgm-paper/tree/fb3318f930a4ce9d4173d6047d324f160c109cf4/charls_income_method_pilot_20261016)，不表述为未经修改的官方插补器。
'''
    (out / 'REPORT.md').write_text(text, encoding='utf-8')
    print(json.dumps({k: v for k, v in receipt.items() if k != 'source_sha256'}))


if __name__ == '__main__':
    main()
