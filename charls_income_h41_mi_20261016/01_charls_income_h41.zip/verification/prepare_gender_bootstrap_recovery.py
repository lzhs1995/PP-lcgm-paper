"""只修恢复阶段的旧PID心跳与调度继承；不重试真实条件拟合失败的SON。"""
from pathlib import Path
import datetime, hashlib, json, shutil
import psutil

R=Path(__file__).resolve().parents[1]
A=R/'audit/gender_bootstrap_recovery'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2),encoding='utf-8')

def main():
    assert not (R/'runtime/pipeline.lock').exists()
    assert not (R/'runtime/engine.lock').exists()
    assert not (R/'verification/finish.lock').exists()
    terminal=read(R/'runtime/PIPELINE_TERMINAL.json')
    assert terminal['status']=='BATCH_TERMINAL'
    finish=read(R/'verification/FINISH_STATE.json')
    assert finish['status'] in ('VERIFIED_SUMMARY_READY_FOR_PUBLICATION','POSTPROCESSING_STOPPED_INSPECT_LOG')
    states=read(R/'runtime/STEPS.json');prior_worker=states['mi_gender'];old=prior_worker
    assert old['status']=='CONDITIONAL_FIT_TIME_LIMIT' and old['pid']==15584
    try:assert abs(psutil.Process(old['pid']).create_time()-old['created'])>.01
    except psutil.NoSuchProcess:pass
    progress=read(R/'mi/gender/runtime/progress.json')
    assert progress['pid']!=old['pid'] and '17:40:20' in progress['updated_at']
    fits=[json.loads(s) for s in (R/'mi/gender/audit/FIT_LOG.jsonl').read_text().splitlines() if s.strip()]
    assert len(fits)==151 and all(x['valid'] for x in fits) and max(x['fit_n'] for x in fits)==151
    assert not (R/'mi/gender/audit/ADMISSION.json').exists()
    cp=R/'mi/gender/checkpoints/ITER01.rds'
    assert sha(cp)=='f8a94b7955ffb0951ee30ec28c58f6eb6ef470bf6df5a93a6dfe786e3b86b354'
    assert len(list(cp.parent.glob('ITER??.rds')))==1
    son=read(R/'mi/son/audit/ADMISSION.json')
    assert not son['passed']
    A.mkdir(exist_ok=False)
    shutil.copytree(R/'code',A/'code_before')
    for rel in ('runtime/STEPS.json','runtime/PIPELINE_TERMINAL.json','runtime/PIPELINE.json',
                'runtime/coordinator.log','runtime/mi_gender.log','runtime/pool.log',
                'runtime/MODELS_TERMINAL','audit/EXECUTION_CODE_HASHES.json',
                'results/FAMILY_STATUS.json','results/FAMILY_OVERVIEW.csv','results/POOLING_RECEIPT.json',
                'results/JOINT_D1.csv','results/POOLED_PATHS.csv','results/GROUP_CONTRASTS.csv',
                'results/CC_MI_COMPARISON.csv','mi/gender/runtime/progress.json'):
        p=R/rel
        if p.exists():q=A/'previous'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
    # 保全本次中间核验；新家族改变合并范围后再执行最终核验。
    for rel in ('verification/FINISH_STATE.json','verification/FINISH_CODE_HASHES.json',
                'verification/final_followup_verification.log','audit/INDEPENDENT_H41_VERIFICATION.json',
                'audit/INDEPENDENT_INCOME_INPUTS.json'):
        p=R/rel
        if p.exists():q=A/'previous'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
    for p in (R/'verification').glob('*.py.log'):
        q=A/'previous/verification'/p.name;q.parent.mkdir(parents=True,exist_ok=True);shutil.move(p,q)
    if (R/'summary').exists():shutil.copytree(R/'summary',A/'previous/summary')
    p=R/'code/coordinator.py';s=p.read_text(encoding='utf-8')
    old="started=time.monotonic();states=read(ROOT/'runtime/STEPS.json',{});active=None;born=None"
    new=old+";base_affinity=me.cpu_affinity()"
    assert s.count(old)==1;s=s.replace(old,new)
    old="begin=time.monotonic();r=dict(status='RUNNING',started_at=utc());states[key]=r;write(ROOT/'runtime/STEPS.json',states)"
    new="""# 每阶段按当前负载选本任务可用核，重启后不依赖旧协调器的掩码。
        host_cpu=psutil.cpu_percent(interval=1,percpu=True)
        candidates=[i for i in base_affinity if i<len(host_cpu) and host_cpu[i]<50]
        use_idle=len(candidates)>=2 and any(host_cpu[i]>=90 for i in base_affinity)
        selected=candidates if use_idle else base_affinity
        me.cpu_affinity(selected)
        begin=time.monotonic();r=dict(status='RUNNING',started_at=utc());states[key]=r;write(ROOT/'runtime/STEPS.json',states)"""
    assert s.count(old)==1;s=s.replace(old,new)
    old="owner=psutil.Process(active.pid);born=owner.create_time();low_since=None;last_marker=None;marker_since=time.monotonic()"
    new=old+"""
            before=dict(pid=owner.pid,created=born,affinity=owner.cpu_affinity(),priority=owner.nice())
            owner.cpu_affinity(selected)
            if use_idle:owner.nice(psutil.ABOVE_NORMAL_PRIORITY_CLASS)
            with (ROOT/'audit/OWNED_STAGE_SCHEDULING.jsonl').open('a',encoding='utf-8') as f:
                f.write(json.dumps(dict(step=key,utc=utc(),host_cpu=host_cpu,before=before,
                                       after_affinity=owner.cpu_affinity(),after_priority=owner.nice(),
                                       foreign_processes_modified=False))+'\\n')"""
    assert s.count(old)==1;s=s.replace(old,new)
    old="elapsed=time.monotonic()-begin;vm=psutil.virtual_memory();latest=read(progress_path,{}) if progress_path else {}"
    new=old+"""
                # 历史进度不属于新worker；不得拿它启动150秒条件拟合计时器。
                if key.startswith('mi_') and latest.get('pid')!=owner.pid:
                    latest=dict(stage='WORKER_BOOTSTRAP',message='Waiting for first progress from current worker',
                                pid=owner.pid,previous_progress_pid=latest.get('pid'),
                                previous_progress_updated_at=latest.get('updated_at'))"""
    assert s.count(old)==1;s=s.replace(old,new)
    old="reason=None\n                if latest.get('stage')"
    new="reason=None\n                if key.startswith('mi_') and latest.get('stage')=='WORKER_BOOTSTRAP' and elapsed>300:reason='WORKER_BOOTSTRAP_TIME_LIMIT'\n                if latest.get('stage')"
    assert s.count(old)==1;s=s.replace(old,new)
    compile(s,str(p),'exec');p.write_text(s,encoding='utf-8')
    states.pop('mi_gender');states.pop('pool',None);write(R/'runtime/STEPS.json',states)
    families=read(R/'results/FAMILY_STATUS.json');families.pop('GENDER_INC');write(R/'results/FAMILY_STATUS.json',families)
    (R/'runtime/PIPELINE_TERMINAL.json').unlink();(R/'runtime/MODELS_TERMINAL').unlink()
    write(R/'verification/FINISH_STATE.json',dict(status='RECOVERY_RUNNING_NO_PUBLICATION',
          reason='Only gender bootstrap retry; prior complete estimates retained'))
    write(A/'PREPARED.json',dict(status='GENDER_BOOTSTRAP_RECOVERY_PREPARED',
          utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),new_fit_calls_in_failed_bootstrap=0,
          old_worker=prior_worker,old_progress=progress,checkpoint_sha256=sha(cp),
          conditional_fit_limits_changed=False,scientific_specification_changed=False,
          son_timeout_retried=False,coordinator_after_sha256=sha(p)))
    print('GENDER_BOOTSTRAP_RECOVERY_PREPARED; original models and SON failure retained')

if __name__=='__main__':main()
