# 原生ClaudeR待续作业：当前队列终态后才恢复性别差，避免并发计算和手动轮询。
library(jsonlite);library(processx)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_h41_mi_20261016'
begin<-Sys.time()
repeat{
 terminal<-file.path(ROOT,'runtime/PIPELINE_TERMINAL.json')
 if(file.exists(terminal)&&!file.exists(file.path(ROOT,'runtime/pipeline.lock')))break
 stopifnot(as.numeric(difftime(Sys.time(),begin,units='hours'))<20)
 if(exists('clauder_progress',mode='function'))clauder_progress('WAIT_CURRENT_QUEUE','Waiting for current oldest/son scopes; no extra model worker')
 Sys.sleep(30)
}
stopifnot(fromJSON(terminal)$status=='BATCH_TERMINAL')
if(exists('clauder_progress',mode='function'))clauder_progress('GENDER_CACHE_RECOVERY','Prepare targeted resume from complete checkpoint; retain all completed estimates')
p<-process$new('<LOCAL_USER_HOME>/AppData/Local/Programs/Python/Python314/python.exe',
 c('-u','-X','utf8',file.path(ROOT,'verification/prepare_gender_continuation.py')),
 stdout=file.path(ROOT,'verification/gender_continuation_prepare.log'),stderr='2>&1',cleanup=TRUE)
while(p$is_alive())p$wait(1000L)
stopifnot(p$get_exit_status()==0)
invisible(parse(file=file.path(ROOT,'code/income_imputers.R')))
invisible(parse(file=file.path(ROOT,'code/prepare_scope.R')))
source(file.path(ROOT,'code/launch.R'),local=TRUE)
if(exists('clauder_progress',mode='function'))clauder_progress('FINAL_INDEPENDENT_VERIFICATION','All current scopes terminal; verify observed inputs and raw model results before reporting')
p<-process$new('<LOCAL_USER_HOME>/AppData/Local/Programs/Python/Python314/python.exe',
 c('-u','-X','utf8',file.path(ROOT,'verification/finish_when_terminal.py')),
 stdout=file.path(ROOT,'verification/final_followup_verification.log'),stderr='2>&1',cleanup=TRUE)
while(p$is_alive()){
 p$wait(5000L)
 s<-tryCatch(fromJSON(file.path(ROOT,'verification/FINISH_STATE.json')),error=function(e)NULL)
 if(!is.null(s)&&exists('clauder_progress',mode='function'))clauder_progress('FINAL_INDEPENDENT_VERIFICATION',paste(s$status,s$step))
}
stopifnot(p$get_exit_status()==0)
print(fromJSON(file.path(ROOT,'verification/FINISH_STATE.json')))
cat('TARGETED_GENDER_CONTINUATION_TERMINAL\n')
