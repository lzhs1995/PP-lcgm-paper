# 旧原生作业终态后运行：只恢复启动阶段误杀的gender，保留SON真实超时。
library(jsonlite);library(processx)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_h41_mi_20261016'
stopifnot(!file.exists(file.path(ROOT,'runtime/pipeline.lock')),
          !file.exists(file.path(ROOT,'verification/finish.lock')))
if(exists('clauder_progress',mode='function'))clauder_progress('BOOTSTRAP_RECOVERY','Verify zero new fits, original checkpoint, and previous terminal before recovery')
p<-process$new('<LOCAL_USER_HOME>/AppData/Local/Programs/Python/Python314/python.exe',
 c('-u','-X','utf8',file.path(ROOT,'verification/prepare_gender_bootstrap_recovery.py')),
 stdout=file.path(ROOT,'verification/gender_bootstrap_prepare.log'),stderr='2>&1',cleanup=TRUE)
while(p$is_alive())p$wait(1000L)
stopifnot(p$get_exit_status()==0)
source(file.path(ROOT,'code/launch.R'),local=TRUE)
if(exists('clauder_progress',mode='function'))clauder_progress('FINAL_INDEPENDENT_VERIFICATION','Verify final complete families; retain incomplete scopes without pooling')
p<-process$new('<LOCAL_USER_HOME>/AppData/Local/Programs/Python/Python314/python.exe',
 c('-u','-X','utf8',file.path(ROOT,'verification/finish_when_terminal.py')),
 stdout=file.path(ROOT,'verification/final_bootstrap_followup.log'),stderr='2>&1',cleanup=TRUE)
while(p$is_alive()){
 p$wait(5000L)
 s<-tryCatch(fromJSON(file.path(ROOT,'verification/FINISH_STATE.json')),error=function(e)NULL)
 if(!is.null(s)&&exists('clauder_progress',mode='function'))clauder_progress('FINAL_INDEPENDENT_VERIFICATION',paste(s$status,s$step))
}
stopifnot(p$get_exit_status()==0)
print(fromJSON(file.path(ROOT,'verification/FINISH_STATE.json')))
cat('GENDER_BOOTSTRAP_RECOVERY_TERMINAL\n')
