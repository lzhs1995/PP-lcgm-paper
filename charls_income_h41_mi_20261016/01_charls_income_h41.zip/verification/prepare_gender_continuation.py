"""首轮队列真正终态后，仅恢复因可选热启动缓存损坏而中断的性别差范围。"""
from pathlib import Path
import datetime,hashlib,json,shutil
import psutil
R=Path(__file__).resolve().parents[1];A=R/'audit/gender_cache_recovery'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2),encoding='utf-8')
def main():
    assert not (R/'runtime/pipeline.lock').exists()
    initial=read(R/'runtime/PIPELINE_TERMINAL.json')
    assert initial['status']=='BATCH_TERMINAL'
    assert not (A/'PREPARED.json').exists(),'Prepared already; inspect before duplicate recovery'
    diagnosis=read(A/'RECOVERY_DIAGNOSIS.json')
    assert diagnosis['conditional_fit_flags_valid'] and diagnosis['logged_conditional_calls']==151
    cp=R/'mi/gender/checkpoints/ITER01.rds'
    assert sha(cp)==diagnosis['checkpoint']['sha256']
    assert not (R/'mi/gender/audit/ADMISSION.json').exists()
    fs=read(R/'results/FAMILY_STATUS.json');g=fs['GENDER_INC']
    assert g['status']=='IMPUTATION_NOT_ADMITTED' and g['detail']['status']=='RUNNER_FAILED'
    st=read(R/'runtime/STEPS.json');assert st['mi_gender']['status']=='RUNNER_FAILED'
    assert 'Error in readRDS(lastfit) : error reading from connection' in (R/'runtime/mi_gender.log').read_text()
    for key in ('mi_oldest','mi_son'):
        assert st[key]['status']!='RUNNING'
    for child in (R/'runtime/pipeline.lock',R/'runtime/engine.lock'):
        assert not child.exists()
    archive=A/'initial_terminal';archive.mkdir()
    shutil.copytree(R/'code',archive/'code_before')
    # 初始只读接续器已按身份停止，移走其锁并保全原状态；最终由本原生作业接续核验。
    v=R/'verification';lock=v/'finish.lock'
    if lock.exists():
        old=read(lock)
        try:assert abs(psutil.Process(old['pid']).create_time()-old['created'])>.01
        except psutil.NoSuchProcess:pass
        for name in ('finish.lock','FINISH_STATE.json','FINISH_LAUNCH.json','FINISH_CODE_HASHES.json','finish_watcher.log'):
            p=v/name
            if p.exists():target=archive/'verification'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
        lock.unlink()
    for rel in ('runtime/PIPELINE_TERMINAL.json','runtime/MODELS_TERMINAL','runtime/STEPS.json',
                'runtime/coordinator.log','results/FAMILY_STATUS.json','results/FAMILY_OVERVIEW.csv',
                'results/POOLING_RECEIPT.json','results/JOINT_D1.csv','results/POOLED_PATHS.csv',
                'results/GROUP_CONTRASTS.csv','results/CC_MI_COMPARISON.csv','audit/EXECUTION_CODE_HASHES.json'):
        p=R/rel
        if p.exists():target=archive/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
    # 不再每次保存十几MB的拟合环境。保留全部拟合、随机抽样与内存精确缓存。
    p=R/'code/income_imputers.R';s=p.read_text(encoding='utf-8')
    old="saveRDS(fit,file.path(ROOT,'private',paste0(scope,'_g_last_TMB_fit.rds')));last_fit_valid<<-TRUE;fit"
    assert s.count(old)==1;s=s.replace(old,'last_fit_valid<<-TRUE;fit')
    p.write_text(s,encoding='utf-8')
    p=R/'code/prepare_scope.R';s=p.read_text(encoding='utf-8')
    old="""lastfit<-file.path(ROOT,'private',paste0(z,'_g_last_TMB_fit.rds'))
if(file.exists(lastfit)){lf<-readRDS(lastfit);assign(z,list(beta=glmmTMB::fixef(lf)$cond,theta=log(sqrt(as.numeric(glmmTMB::VarCorr(lf)$cond[[1]][1,1])))),envir=fit_env$warm);rm(lf)}"""
    assert s.count(old)==1;s=s.replace(old,'# 热启动只从完整检查点的轻量可选旁文件恢复；缺失/损坏时冷启动，不动MIDS/RNG。')
    old="saveRDS(imp,tmp);stopifnot(file.rename(tmp,path));write_json(list(iteration=imp$iteration,sha256=digest(file=path,algo='sha256'),m=imp$m,source_sha256=h0),paste0(path,'.json'),auto_unbox=TRUE,pretty=TRUE)"
    new=old+"""
 if(exists(z,envir=fit_env$warm,inherits=FALSE))tryCatch({
  wp<-paste0(path,'.warm.rds');wt<-paste0(wp,'.tmp');stopifnot(!file.exists(wp))
  saveRDS(get(z,envir=fit_env$warm),wt);stopifnot(file.rename(wt,wp))
 },error=function(e)cat('OPTIONAL_WARM_CACHE_NOT_SAVED:',conditionMessage(e),'\\n'))"""
    assert s.count(old)==1;s=s.replace(old,new)
    old="imp<-readRDS(cp);stopifnot(imp$m==contract$m,identical(imp$data,d));progress('MI_RESUME',paste('verified iteration',imp$iteration,'same saved RNG'));break"
    new="""imp<-readRDS(cp);stopifnot(imp$m==contract$m,identical(imp$data,d))
  wp<-paste0(cp,'.warm.rds')
  if(file.exists(wp))tryCatch({
   w<-readRDS(wp);stopifnot(is.list(w),is.numeric(w$beta),length(w$beta)>0,all(is.finite(w$beta)),length(w$theta)==1,is.finite(w$theta))
   assign(z,w,envir=fit_env$warm)
  },error=function(e)cat('OPTIONAL_WARM_CACHE_IGNORED:',conditionMessage(e),'\\n'))
  progress('MI_RESUME',paste('verified iteration',imp$iteration,'same saved RNG'));break"""
    assert s.count(old)==1;s=s.replace(old,new);p.write_text(s,encoding='utf-8')
    # 清除已准入记录中沿用初始化状态的陈旧文字；passed和原始准入文件仍是依据。
    p=R/'code/coordinator.py';s=p.read_text(encoding='utf-8')
    old="all_ad[z].update(ad);write(ROOT/'audit/MI_ADMISSIONS.json',all_ad)"
    new="all_ad[z].update(ad);all_ad[z]['status']='ADMITTED' if ad.get('passed') else ad.get('status','IMPUTATION_NOT_ADMITTED');write(ROOT/'audit/MI_ADMISSIONS.json',all_ad)"
    assert s.count(old)==1;s=s.replace(old,new);compile(s,str(p),'exec');p.write_text(s,encoding='utf-8')
    p=R/'code/pool_h41.R';s=p.read_text(encoding='utf-8')
    old='# 从全部20个合法成员和完整TECH3合并；正式组差检验而非比较两组星号。'
    assert s.count(old)==1;s=s.replace(old,'# 从全部40个合法成员和完整TECH3合并；正式组差检验而非比较两组星号。')
    p.write_text(s,encoding='utf-8')
    st.pop('mi_gender');st.pop('models_gender',None);st.pop('pool',None)
    save(R/'runtime/STEPS.json',st)
    fs.pop('GENDER_INC');save(R/'results/FAMILY_STATUS.json',fs)
    # 原终态已存档；仅解除本次有证据的恢复入口，不改变已完成成员文件。
    (R/'runtime/PIPELINE_TERMINAL.json').unlink();(R/'runtime/MODELS_TERMINAL').unlink()
    record=dict(status='TARGETED_GENDER_CONTINUATION_PREPARED',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                checkpoint_sha256=sha(cp),original_terminal=initial,
                completed_mplus_outputs_preserved=True,scientific_specification_changed=False,
                rng_rule_changed=False,optional_cache_only=True,
                code_after={n:sha(R/'code'/n) for n in ('income_imputers.R','prepare_scope.R','coordinator.py','pool_h41.R')})
    save(A/'PREPARED.json',record);print(json.dumps({k:v for k,v in record.items() if k!='original_terminal'}))
if __name__=='__main__':main()
