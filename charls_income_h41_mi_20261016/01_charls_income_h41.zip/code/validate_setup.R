# 不重新拟合：解析全部脚本，并验证修正后的条件方差访问器。
BATCH<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_h41_mi_20261016';PILOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_mi_pilot_20261016'
.libPaths(c(file.path(PILOT,'library'),'<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
library(mice);library(miceadds);library(lme4);library(glmmTMB);library(jsonlite);library(digest)
for(f in list.files(file.path(BATCH,'code'),pattern='\\.R$',full.names=TRUE))parse(f)
ROOT<-file.path(BATCH,'validation');dir.create(file.path(ROOT,'audit'),recursive=TRUE,showWarnings=FALSE)
contract<-fromJSON(file.path(BATCH,'contracts/RUN_CONTRACT.json'),simplifyVector=FALSE);progress<-function(...)NULL
source(file.path(BATCH,'code/income_imputers.R'),local=TRUE)
tt<-readRDS(file.path(PILOT,'private/sd_G_TMB_start.rds'));ll<-readRDS(file.path(PILOT,'private/sd_G_LMER_warm.rds'))
cv<-as.numeric(attr(fit_env$random_tmb(tt,TRUE)[[1]],'postVar'));lv<-as.numeric(attr(lme4::ranef(ll,condVar=TRUE)$cluster,'postVar'))
stopifnot(length(cv)==425,all(is.finite(cv)),all(cv>0),max(abs(cv-lv)/lv)<1e-4)
for(z in c('sd','gender','oldest','son')){
 t<-readRDS(file.path(PILOT,'attempt3/private',paste0(z,'_g_last_TMB_fit.rds')));v<-fit_env$random_tmb(t,TRUE)[[1]];stopifnot(all(is.finite(attr(v,'postVar'))),all(attr(v,'postVar')>0))
}
rec<-list(status='SETUP_AND_CONDITIONAL_VARIANCE_PASS',independent_lme4_max_relative=max(abs(cv-lv)/lv),four_saved_scope_objects_valid=TRUE,GLMM_refits=0,Mplus_calls=0,original_pilot_not_formal_MI=TRUE)
write_json(rec,file.path(BATCH,'audit/SETUP_VALIDATION.json'),auto_unbox=TRUE,pretty=TRUE,digits=16);print(rec)
