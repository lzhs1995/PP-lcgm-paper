# CHARLS观测Z×资源的H4.1，不包含SX×Z或三阶潜交互；完整20成员才可合并。
.libPaths(c('<LOCAL_USER_HOME>/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
library(jsonlite);library(digest);library(processx);library(ps);library(MplusAutomation)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_h41_mi_20261016';Sys.setenv(R2E_ROOT=ROOT)
source(file.path(ROOT,'code/r2e_local.R'),local=TRUE)
contract<-rj(file.path(ROOT,'contracts/RUN_CONTRACT.json'))
admission<-rj(file.path(ROOT,'audit/MI_ADMISSIONS.json'));stopifnot(length(admission)==4)
growth<-function(p)paste0('i',p,' s',p,' | ',p,'1@0 ',p,'2@2 ',p,'3@4 ',p,'4@7 ',p,'5@9;')
base<-c(growth('x'),growth('y'),'iy ON ix (bii);','sy ON ix (bis);','sy ON sx (bss);','sy ON iy (bsyiy);','ix WITH sx;','sx WITH iy;',paste0('x',1:5,' WITH y',1:5,';'),'ix sx iy sy ON c1-c11;','ix sx ON z0;','iy ON z0 (gi0);','sy ON z0 (gs0);','x1 y1 ON z0;','ix sx iy sy ON g;','x1 y1 ON g;')
si<-list(kind='linear',fac=FAC_XY,obs=OBS_XY,fixed_zero=character(),model=c(base,'ix sx ON zg;','iy ON zg (gizg);','sy ON zg (gszg);','x1 y1 ON zg;'),key=rbind(KEY_XY,key_add(c('gi0','gs0','gizg','gszg'),c('IY','SY','IY','SY'),c('Z0','Z0','ZG','ZG'))))
# 线性年度载荷固定；只给目标自由参数映射初值，不继承CFPS的自由载荷槽位。
slots<-function(si){
 a<-list();add<-function(op,lhs,rhs='',init=0){a[[length(a)+1L]]<<-data.frame(op=op,lhs=toupper(lhs),rhs=toupper(rhs),init=init)}
 for(f in FAC_XY)add('MEAN',f)
 for(o in OBS_XY)add('VAR',o,init=.5)
 for(f in FAC_XY)add('VAR',f,init=.1)
 for(k in stmt_pairs(si$model)){t<-strsplit(toupper(k),' ',fixed=TRUE)[[1]];add(t[2],t[1],t[3])}
 x<-do.call(rbind,a);x$key<-paste(x$op,x$lhs,x$rhs,sep=':');stopifnot(!anyDuplicated(x$key));x
}
extract<-function(m){do.call(rbind,lapply(seq_len(nrow(si$key)),function(i){k<-si$key[i,];id<-pnum(m,'BETA',k$row,k$column);if(id==0)id<-pnum(m,'GAMMA',k$row,k$column);stopifnot(id>0);p<-m$par[m$par$parameter==id,];data.frame(k,parameter=id,estimate=p$estimate,se=p$se)}))}
prepare<-function(z,g,k,start='A'){
 tag<-if(k==0)'CC'else sprintf('MI%02d',k);id<-paste('CHARLS',toupper(z),'H41',g,tag,start,sep='_');d<-file.path(ROOT,'models',id);dir.create(d,showWarnings=FALSE)
 if(file.exists(file.path(d,'job.json')))return(rj(file.path(d,'job.json')))
 e<-admission[[z]];dat<-file.path(ROOT,'mi',z,'private',if(k==0)'CC.dat'else sprintf('MI%02d.dat',k))
 nms<-unlist(e$columns);a<-read.table(dat,col.names=nms,na.strings='-9999');gcol<-'g';stopifnot(g=='INC')
 a$zg<-a$z0*a[[gcol]];X<-cbind(1,as.matrix(a[c(paste0('c',1:11),'z0','g','zg')]))
 stopifnot(!anyNA(X),qr(X)$rank==ncol(X),all(a[[gcol]]%in%0:1))
 source_dir<-file.path('<LOCAL_USER_HOME>/pp_lgcm_review/charls_observed_moderation_20261016/models',paste0('CHARLS_',toupper(z),'_E0_A'))
 mm<-make_model(si,source_dir,perturb=start=='B');csv(mm$mapping,file.path(d,'start_mapping.csv'))
 lines<-c(paste0('TITLE: ',id,' observed baseline Z by resource heterogeneity;'),'DATA: FILE=data.dat;','VARIABLE:',wrap90(paste('NAMES=',paste(nms,collapse=' '),';')),'USEVARIABLES=x1-x5 y1-y5 c1-c11 z0 g zg;','MISSING=ALL(-9999);','CLUSTER=cluster;','ANALYSIS: TYPE=COMPLEX; ESTIMATOR=MLR; PROCESSORS=1;','ITERATIONS=2000; COVERAGE=.005;','MODEL:',mm$lines,'OUTPUT: TECH1 TECH3 TECH4 TECH8 SVALUES CINTERVAL;','SAVEDATA: RESULTS=estimates.dat; TECH3=tech3.dat;')
 stopifnot(all(nchar(lines)<=90));writeLines(lines,file.path(d,'model.inp'));stopifnot(file.copy(dat,file.path(d,'data.dat')))
 j<-list(id=id,root=ROOT,dest=d,z=z,group=g,member=k,start=start,N=nrow(a),communities=length(unique(a$cluster)),expected_free=mm$expected_free,category='CHARLS_H41',cap_seconds=120,rscript=file.path(R.home('bin'),'Rscript.exe'),mplus=MPLUS,source_start=source_dir,initialization_only_different_population=TRUE,source_data=dat,hashes=list(model.inp=hashf(file.path(d,'model.inp')),data.dat=hashf(file.path(d,'data.dat'))))
 wj(list(rank=qr(X)$rank,columns=ncol(X),groups=as.list(table(a[[gcol]]))),file.path(d,'design_check.json'));wj(j,file.path(d,'job.json'));j
}
review<-function(j){
 er<-rj(file.path(j$dest,'engine_receipt.json'));if(is.null(er))return(list(id=j$id,status='NOT_RUN_RESOURCE_OR_BUDGET',detail=rj(file.path(j$dest,'not_run.json'))))
 r<-list(id=j$id,z=j$z,group=j$group,member=j$member,start=j$start,N_expected=j$N,status=er$status,seconds=er$seconds,source_dir=j$dest)
 if(er$status=='EXITED')tryCatch({
  n<-MplusAutomation::readModels(file.path(j$dest,'model.out'),what='summaries',quiet=TRUE);m<-read_mplus_raw(j$dest);v<-gate_r2e(m,si)
  r$status<-if(isTRUE(v$passed))'USABLE_SINGLE_DATASET'else'INADMISSIBLE';r$negative<-v$negative;r$N<-n$summaries$Observations;r$fit<-n$summaries;r$LL<-m$extra[['H0 Loglikelihood']];r$parameters<-m$P
  if(any(grepl('FIXED TO AVOID SINGULARITY',m$lines,fixed=TRUE)))r$status<-'AUTOFIX_REJECTED'
  if(r$N!=j$N)r$status<-'SAMPLE_MISMATCH'
  if(m$P!=j$expected_free)r$status<-'PARAMETER_CONTRACT_MISMATCH'
  wj(v,file.path(j$dest,'validation.json'));csv(m$par,file.path(j$dest,'parameters_high_precision.csv'));csv(m$spec,file.path(j$dest,'tech1_parameter_map.csv'));csv(m$values,file.path(j$dest,'matrix_values.csv'));csv(extract(m),file.path(j$dest,'key_paths.csv'));write.table(m$V,file.path(j$dest,'parameter_covariance.csv'),sep=',',row.names=FALSE,col.names=FALSE)
 },error=function(e){r$status<<-'READBACK_OR_ESTIMATION_FAILURE';r$error<<-conditionMessage(e)})
 r$output_sha256<-if(file.exists(file.path(j$dest,'model.out')))hashf(file.path(j$dest,'model.out'))else NULL
 wj(r,file.path(j$dest,'receipt.json'));r
}
run<-function(j){
 if(file.exists(file.path(j$dest,'receipt.json')))return(rj(file.path(j$dest,'receipt.json')))
 progress('H41_model_start',j$id)
 p<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/engine.py'),file.path(j$dest,'job.json')),stdout=file.path(j$dest,'supervisor.log'),stderr='2>&1',cleanup=TRUE)
 last<-0;while(p$is_alive()){p$wait(1000L);if(as.numeric(Sys.time())-last>25){if(exists('clauder_progress',mode='function'))clauder_progress('H41_estimating',j$id);last<-as.numeric(Sys.time())}}
 r<-review(j);progress('H41_model_end',paste(j$id,r$status));r
}

main<-function(){
 args<-commandArgs(TRUE);stopifnot(length(args)==2L,args[1]%in%unlist(contract$indicators),args[2]%in%c('CC','FULL'))
 z<-args[1];g<-'INC';fam<-paste(toupper(z),g,sep='_');mode<-args[2]
 calls<-rj(file.path(ROOT,'results/CALL_RESULTS.json'));if(is.null(calls))calls<-list()
 families<-rj(file.path(ROOT,'results/FAMILY_STATUS.json'));if(is.null(families))families<-list()
 j<-prepare(z,g,0);cc<-run(j);calls[[j$id]]<-cc;wj(calls,file.path(ROOT,'results/CALL_RESULTS.json'))
 if(mode=='CC'){cat('INCOME_CC_TERMINAL',fam,cc$status,'\n');return(invisible(NULL))}
 if(!isTRUE(admission[[z]]$passed)){families[[fam]]<-list(status='IMPUTATION_NOT_ADMITTED',members=0,N=admission[[z]]$N);wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'));return(invisible(NULL))}
 members<-list();state<-'RUNNING';t0<-Sys.time()
 for(k in seq_len(contract$m)){
  if(as.numeric(difftime(Sys.time(),t0,units='secs'))>contract$wall_seconds-120){state<-'WALL_LIMIT';break}
  j<-prepare(z,g,k);r<-run(j);calls[[j$id]]<-r;wj(calls,file.path(ROOT,'results/CALL_RESULTS.json'))
  if(r$status=='NOT_RUN_RESOURCE_OR_BUDGET'){
   state<-if(identical(r$detail$status,'RESOURCE_HOLD'))'RESOURCE_DEFERRED'else'BUDGET_NOT_RUN'
   break
  }
  members[[as.character(k)]]<-r
  families[[fam]]<-list(status='RUNNING',members=length(members),CC=cc$status,N=admission[[z]]$N);wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'))
  if(r$status!='USABLE_SINGLE_DATASET'){state<-'INCOMPLETE_STOPPED';break}
  if(k==1L){
   jb<-prepare(z,g,k,'B');rb<-run(jb);calls[[jb$id]]<-rb;wj(calls,file.path(ROOT,'results/CALL_RESULTS.json'))
   if(rb$status=='NOT_RUN_RESOURCE_OR_BUDGET'){
    state<-if(identical(rb$detail$status,'RESOURCE_HOLD'))'RESOURCE_DEFERRED'else'BUDGET_NOT_RUN'
    break
   }
   co<-if(rb$status=='USABLE_SINGLE_DATASET')compare_numeric(list(key=read.csv(file.path(j$dest,'key_paths.csv')),receipt=r),list(key=read.csv(file.path(jb$dest,'key_paths.csv')),receipt=rb),'start',list(start_LL=.01,start_path_abs=.001,start_path_se=.05,integration_path_se=.05,se_rel=.05))else list(passed=FALSE,reason=rb$status)
   wj(co,file.path(ROOT,'results',paste0(fam,'_START_COMPARISON.json')))
   if(!isTRUE(co$passed)){state<-'START_CHECK_FAILED';break}
  }
 }
 if(length(members)==contract$m&&all(vapply(members,function(x)x$status=='USABLE_SINGLE_DATASET',TRUE)))state<-'FORTY_USABLE_PENDING_POOLING'
 families[[fam]]<-list(status=state,members=length(members),CC=cc$status,N=admission[[z]]$N,full_H4=FALSE)
 wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'));progress('INCOME_FAMILY_TERMINAL',paste(fam,state));cat('INCOME_FAMILY_TERMINAL\n')
}
if(!identical(Sys.getenv('H41_READ_ONLY'),'1'))main()
