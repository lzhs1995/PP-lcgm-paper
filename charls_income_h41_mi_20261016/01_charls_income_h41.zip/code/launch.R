# ClaudeR真实异步入口；计算委托给有日志、有PID身份与预算的单worker协调器。
library(processx);library(jsonlite)
BATCH<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_h41_mi_20261016'
stopifnot(!file.exists(file.path(BATCH,'runtime/pipeline.lock')),!file.exists(file.path(BATCH,'runtime/PIPELINE_TERMINAL.json')))
p<-process$new('<LOCAL_USER_HOME>/AppData/Local/Programs/Python/Python314/python.exe',c('-X','utf8',file.path(BATCH,'code/coordinator.py')),stdout=file.path(BATCH,'runtime/coordinator.log'),stderr='2>&1',cleanup=TRUE)
last<-''
while(p$is_alive()){
 p$wait(5000L)
 x<-tryCatch(fromJSON(file.path(BATCH,'runtime/PIPELINE.json'),simplifyVector=FALSE),error=function(e)NULL)
 if(!is.null(x)){
  msg<-paste(x$step,x$status,if(!is.null(x$latest))x$latest$message else '',sprintf('elapsed %.0fs; available %.2fGiB',if(is.null(x$elapsed_seconds))0 else x$elapsed_seconds,x$available_GiB))
  if(exists('clauder_progress',mode='function'))clauder_progress(paste0('income_',x$step),msg)
  key<-paste(x$step,x$status);if(key!=last){cat(msg,'\n');flush.console();last<-key}
 }
}
stopifnot(p$get_exit_status()==0);rec<-fromJSON(file.path(BATCH,'runtime/PIPELINE_TERMINAL.json'));print(rec)
if(exists('clauder_progress',mode='function'))clauder_progress('INCOME_BATCH_TERMINAL','Inspect full-family results; full H4 remains unfinished')
