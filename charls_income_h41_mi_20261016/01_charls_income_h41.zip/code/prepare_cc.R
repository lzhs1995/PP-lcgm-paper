# 先用已观测完整案例检查收入规格，生成的占位信息不授权MI推断。
BATCH<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_h41_mi_20261016'
PILOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_mi_pilot_20261016'
library(jsonlite);library(digest)
path<-file.path(BATCH,'audit/MI_ADMISSIONS.json');if(file.exists(path))stop('CC preparation already done; reuse')
ad<-list()
for(z in c('sd','gender','oldest','son')){
 R<-file.path(BATCH,'mi',z);for(n in c('private','audit','runtime','results','checkpoints'))dir.create(file.path(R,n),recursive=TRUE,showWarnings=FALSE)
 a<-readRDS(file.path(PILOT,'attempt3/private',paste0(z,'_INPUTS.rds')));b<-a$analysis;b$g<-a$data$g;b$zg<-a$data$zg
 cc<-b[!is.na(b$g)&!is.na(b$c7),];stopifnot(!anyNA(cc[c(paste0('c',1:11),'g','zg')]))
 write.table(cc,file.path(R,'private/CC.dat'),row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
 ad[[z]]<-list(scope=z,passed=FALSE,status='NOT_YET_IMPUTED',N=nrow(b),N_CC=nrow(cc),columns=names(b),communities=length(unique(b$cluster)))
}
write_json(ad,path,auto_unbox=TRUE,pretty=TRUE);cat('Four CC data prepared; no MI admitted\n')
