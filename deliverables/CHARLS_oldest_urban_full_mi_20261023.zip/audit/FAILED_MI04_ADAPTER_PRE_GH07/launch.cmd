@echo off
"C:/Users/LZHS/AppData/Local/Programs/Python/Python314/python.exe" -X utf8 "C:/Users/LZHS/pp_lgcm_review/charls_latent_h42_oldest_urban_full_20261023/code/adapter.py" "%~dp0job.json" "%~1"
exit /b %ERRORLEVEL%
