"""先验证已知二元组的解析重参数化；不改变数据或目标路径。"""
from pathlib import Path
import csv,datetime,hashlib,json,shutil
R=Path(__file__).resolve().parents[1];P=R.parent/'cfps_mean_h41_20261017'
for n in ('contracts','audit','runtime','models','results','references','reports'):(R/n).mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['engine.py','run_one.R','windows_awake_guard.py','mplus_queue.py','process_ownership.py']:
 src=P/'code'/name;dst=R/'code'/name;assert not dst.exists();shutil.copyfile(src,dst)
guard=(R.parent/'cfps_yshape_parent_20261017/code/guard.py').read_text(encoding='utf-8').replace('pp-lgcm-cfps-yshape-parent-20261017','pp-lgcm-binary-h41-calibration-20261017').replace('cfps_h42_unrun_sd_20261017','cfps_mean_h41_20261017')
(R/'code/guard.py').write_text(guard,encoding='utf-8')
contract=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 scope='Binary observed G exact conditional Gaussian reparameterization via KNOWNCLASS; first reproduce existing SW parent with all group differences except four structural intercepts constrained equal. No hypothesis inference before equivalence gate.',
 preserved='Same SW data, missing masks, fid clusters, controls except G absorbed into four class-specific structural intercepts; shared measurement, PSI, THETA, other regressions. Three target regressions may vary only in later admitted H4.1.',
 knownclass='Both classes fully observed; not latent-class discovery. Fix class logit at0; likelihood may include known constant -N*log(2), checked rather than presumed.',
 max_calls=5,total_engine_seconds=600,category_seconds={'CALIBRATION':600},per_call_seconds=120,
 repair='At most one syntax-only repair in fresh directory, counts toward same budget. Numerical/model failure does not trigger third starts or variance fixing.',
 admission='First H0 equivalence to saved SW; all128 parameters and transformed cluster-robust TECH3; independent moments/conditional likelihood. Later nonzero-interaction synthetic pair only if H0 passes. No automatic CFPS H4 family under this calibration contract.',
 equivalence=dict(parameter_absolute_floor=.001,parameter_SE_fraction=.05,SE_relative=.05,conditional_LL_absolute=.02),
 resource_admission_revision=dict(owned_engine_slots=1,max_external_mplus_at_admission=2,minimum_available_gib=1,minimum_commit_available_gib=2,max_host_cpu_percent=85,resource_wait_seconds=120,foreign_processes_never_modified=True),
 primary_sources=['https://www.statmodel.com/HTML_UG/chapter17V8.htm','https://www.statmodel.com/HTML_UG/chapter15v8.htm','https://www.statmodel.com/HTML_UG/chapter16V8.htm'])
assert not (R/'contracts/RUN_CONTRACT.json').exists()
(R/'contracts/RUN_CONTRACT.json').write_text(json.dumps(contract,indent=2),encoding='utf-8')
source=P/'models/CFPS_MEAN_EDU_H41_MI01_A/start_mapping.csv'
rows=list(csv.DictReader(source.open(encoding='utf-8-sig')))
rows=[r for r in rows if r['rhs'] not in ('IXG','SXG')];assert len(rows)==128
for i,r in enumerate(rows):r['label']=f'p{i+1:03d}'
d=R/'models/CFPS_EDU_KNOWN_H0_MI01_A';d.mkdir(exist_ok=False)
shutil.copyfile(P/'private/MI01.dat',d/'data.dat')
def stmt(r,value=None,label=None):
 v=float(r['value']) if value is None else value;lab=r['label'] if label is None else label
 lhs=r['lhs'].lower();rhs=r['rhs'].lower();x=f'{v:.12g}'
 if r['op']=='MEAN':return f'[{lhs}*{x}] ({lab});'
 if r['op']=='VAR':return f'{lhs}*{x} ({lab});'
 return f'{lhs} {r["op"]} {rhs}*{x} ({lab});'
common=[r for r in rows if r['op']!='MEAN' and not(r['op']=='ON' and r['rhs']=='C2')]
means=[r for r in rows if r['op']=='MEAN'];effects={r['lhs']:float(r['value']) for r in rows if r['op']=='ON' and r['rhs']=='C2'}
growth=['ix sx | x1@0 x2*.4 x3*.6 x4*.8 x5@1;','iy sy | y1@0 y2@.4 y3@.6 y4@.8 y5@1;']
lines=['TITLE: CFPS EDU exact binary knownclass H0 calibration;','DATA: FILE="data.dat";','VARIABLE:',
 'NAMES=fid x1-x5 y1-y5 c1-c24 ginc;','USEVARIABLES=x1-x5 y1-y5 c1 c3-c24;',
 'MISSING=.; CLUSTER=fid; CLASSES=cg(2); KNOWNCLASS=cg(c2=0 c2=1);',
 'ANALYSIS: TYPE=COMPLEX MIXTURE; ESTIMATOR=MLR; STARTS=0;',
 'PROCESSORS=1; COVERAGE=.005; ITERATIONS=2000; MITERATIONS=2000;',
 'MODEL:','%OVERALL%',*growth,'[cg#1@0];','[x1-x5@0 y1-y5@0];',*[stmt(r) for r in common]]
mapping=[]
for cls in (0,1):
 lines += [f'%cg#{cls+1}%','[x1-x5@0 y1-y5@0];']
 lines += [stmt(r) for r in common]
 for r in means:
  lab=r['lhs'].lower()+str(cls);v=float(r['value'])+cls*effects[r['lhs']]
  lines.append(stmt(r,v,lab));mapping.append(dict(class_value=cls,op='MEAN',lhs=r['lhs'],rhs='',label=lab,value=v))
for r in common:mapping.append({k:r[k] for k in ['op','lhs','rhs','label','value']})
lines+=['OUTPUT: TECH1 TECH3 TECH4 TECH8 CINTERVAL SVALUES;','SAVEDATA: RESULTS=estimates.dat; TECH3=tech3.dat;']
assert max(map(len,lines))<=90
(d/'model.inp').write_text('\n'.join(lines)+'\n',encoding='ascii')
(d/'parameter_binding.json').write_text(json.dumps(dict(original_slots=rows,knownclass_slots=mapping,expected_parameters=128),indent=2),encoding='utf-8')
job=dict(id=d.name,root=str(R),dest=str(d),category='CALIBRATION',cap_seconds=120,
 mplus='<LOCAL_USER>/Downloads/Mplus/mplus9/ducument/Mplus.exe',hashes={n:sha(d/n) for n in ['model.inp','data.dat']})
(d/'job.json').write_text(json.dumps(job,indent=2),encoding='utf-8')
src=R.parent/'round2C_20261007/models/SW_MI01/attempt01'
rf=R/'references/SW_MI01';rf.mkdir(exist_ok=False)
for n in ['model.inp','model.out','parameters_high_precision.csv','parameter_covariance.csv','estimates.dat','tech3.dat','receipt.json']:
 if (src/n).exists():shutil.copyfile(src/n,rf/n)
(R/'audit/INPUT_PREPARED.json').write_text(json.dumps(dict(status='H0_INPUT_PREPARED',source_mapping_sha256=sha(source),data_sha256=sha(d/'data.dat'),contract_sha256=sha(R/'contracts/RUN_CONTRACT.json'),expected_parameters=128),indent=2),encoding='utf-8')
print(json.dumps(dict(status='H0_INPUT_PREPARED',input_sha256=sha(d/'model.inp'))))
