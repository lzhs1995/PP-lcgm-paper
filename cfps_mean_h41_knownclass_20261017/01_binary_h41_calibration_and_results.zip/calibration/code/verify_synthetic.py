"""比较非零交互的39参数、完整稳健协方差、条件似然。"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import json
import numpy as np
import pandas as pd
from verify_h0 import matrices,pid
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def main():
 known=R/'models/SYNTHETIC_KNOWN_H41_A';direct=R/'models/SYNTHETIC_XWITH_H41_A'
 kt,km,kq,ks,KV,kl=matrices(known);dt,dm,dq,ds,DV,dl=matrices(direct)
 assert len(kq)==len(dq)==39 and len(km)==2 and len(dm)==1
 J=np.zeros((39,39));labels=[]
 for n in range(1,40):
  cells=[r for r in dm[1] if r[3]==n];assert cells
  mat,r,c,_=cells[0];labels.append(f'{mat}:{r}:{c}')
  if mat in ('BETA','GAMMA') and c=='C2':
   J[n-1,pid(km[2],'ALPHA','1',r)]=1;J[n-1,pid(km[1],'ALPHA','1',r)]=-1
  elif mat in ('BETA','GAMMA') and c in ('IXG','SXG'):
   base='IX' if c=='IXG' else 'SX';J[n-1,pid(km[2],'BETA',r,base)]=1;J[n-1,pid(km[1],'BETA',r,base)]=-1
  else:
   j=pid(km[1],mat,r,c);J[n-1,j]=1
   if mat!='ALPHA':
    if mat in ('BETA','GAMMA') and (r,c) in {('IY','IX'),('SY','IX'),('SY','SX')}:
     assert j!=pid(km[2],mat,r,c),(mat,r,c)
    else:assert j==pid(km[2],mat,r,c),(mat,r,c)
 assert np.linalg.matrix_rank(J)==39
 q=J@kq;V=J@KV@J.T;se=np.sqrt(V.diagonal());diff=np.abs(q-dq)
 covariance_difference=np.max(np.abs(V-DV)/np.outer(ds,ds));sdiff=np.abs(se-ds)/ds
 counts=read(R/'audit/SYNTHETIC_DESIGN.json');n=counts['N'];conditional=kl+n*np.log(2)
 checks=dict(normal_known='THE MODEL ESTIMATION TERMINATED NORMALLY' in kt,normal_XWITH='THE MODEL ESTIMATION TERMINATED NORMALLY' in dt,
  all_parameters=np.all(diff<=np.maximum(.001,.05*ds)),all_SE=np.all(sdiff<=.05),full_vcov=covariance_difference<.05,
  likelihood=abs(conditional-dl)<.02,no_autofix=all('FIXED TO AVOID SINGULARITY' not in text for text in (kt,dt)),
  positive_known_vcov=np.linalg.eigvalsh(KV/np.outer(ks,ks)).min()>1e-10,positive_XWITH_vcov=np.linalg.eigvalsh(DV/np.outer(ds,ds)).min()>1e-10)
 checks={k:bool(v) for k,v in checks.items()}
 tab=pd.DataFrame(dict(parameter=np.arange(1,40),label=labels,XWITH_estimate=dq,known_transformed_estimate=q,XWITH_SE=ds,known_transformed_SE=se,difference_over_SE=diff/ds))
 tab.to_csv(R/'results/SYN_ALL_PARAMETER_COMPARISON.csv',index=False)
 delta=tab[tab.label.str.contains('IXG|SXG')].to_dict('records');assert len(delta)==3
 res=dict(status='PASS' if all(checks.values()) else 'FAIL',checks=checks,N=n,P=39,
  max_parameter_difference_over_SE=float(np.max(diff/ds)),max_SE_relative_difference=float(sdiff.max()),
  max_vcov_difference_over_SE_product=float(covariance_difference),knownclass_conditional_LL=conditional,XWITH_LL=dl,
  interaction_parameters=delta,known_seconds=read(known/'engine_receipt.json')['seconds'],XWITH_seconds=read(direct/'engine_receipt.json')['seconds'],
  limitation='Synthetic numerical calibration, not a CFPS hypothesis test or general runtime benchmark')
 (R/'audit/SYN_EQUIVALENCE.json').write_text(json.dumps(res,indent=2),encoding='utf-8');print(json.dumps(res))
if __name__=='__main__':main()
