# 仅运行已冻结的一个父模型等价校准；无自动追加研究家族。
ROOT<-'<LOCAL_USER>/pp_lgcm_review/cfps_binary_h41_calibration_20261017'
library(jsonlite);library(processx);library(ps)
.libPaths(c('<LOCAL_USER>/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
PY<-'<LOCAL_USER>/AppData/Local/Programs/Python/Python314/python.exe'
rj<-function(p)if(file.exists(p))fromJSON(p,simplifyVector=FALSE)else NULL
wj<-function(x,p)write_json(x,p,auto_unbox=TRUE,pretty=TRUE,digits=NA)
main<-function(){
 own<-list(pid=Sys.getpid(),created=as.numeric(ps::ps_create_time(ps::ps_handle())))
 wj(list(owner=own),file.path(ROOT,'runtime/OWNER.json'))
 awake<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/windows_awake_guard.py'),'--owner-file',file.path(ROOT,'runtime/OWNER.json'),'--output',file.path(ROOT,'runtime/awake'),'--interval','5'),stdout=file.path(ROOT,'runtime/awake.log'),stderr='2>&1',cleanup=FALSE)
 on.exit({writeLines('release',file.path(ROOT,'runtime/awake/stop.request'));awake$wait(8000L)},add=TRUE)
 active<-FALSE
 for(i in 1:40){a<-rj(file.path(ROOT,'runtime/awake/identity.json'));h<-rj(file.path(ROOT,'runtime/awake/heartbeat.json'));if(!is.null(a)&&!is.null(h)&&a$owner$pid==own$pid&&abs(a$owner$created-own$created)<.01&&awake$is_alive()){active<-TRUE;break};if(!awake$is_alive())stop('awake startup failed');Sys.sleep(.5)}
 stopifnot(active)
 d<-file.path(ROOT,'models/CFPS_EDU_KNOWN_H0_MI01_A');j<-rj(file.path(d,'job.json'))
 j$rscript<-file.path(R.home('bin'),'Rscript.exe');wj(j,file.path(d,'job.json'))
 if(exists('clauder_progress',mode='function'))clauder_progress('knownclass_H0','Starting exact binary parent calibration')
 p<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/engine.py'),file.path(d,'job.json')),stdout=file.path(d,'supervisor.log'),stderr='2>&1',cleanup=FALSE)
 last<-0
 while(p$is_alive()){
  p$wait(1000L)
  if(as.numeric(Sys.time())-last>25){h<-rj(file.path(ROOT,'runtime/progress.json'));msg<-paste(j$id,h$stage,if(!is.null(h$elapsed_seconds))round(h$elapsed_seconds,1)else'');cat(msg,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress('knownclass_H0',msg);last<-as.numeric(Sys.time())}
 }
 er<-rj(file.path(d,'engine_receipt.json'));nr<-rj(file.path(d,'not_run.json'))
 rr<-list(status=if(!is.null(er))er$status else if(!is.null(nr))nr$status else 'NO_ENGINE_RECEIPT',engine=er)
 if(!is.null(er)&&er$status=='EXITED'){
  txt<-readLines(file.path(d,'model.out'),warn=FALSE)
  rr$normal<-any(grepl('THE MODEL ESTIMATION TERMINATED NORMALLY',txt,fixed=TRUE))
  rr$input_error<-any(grepl('*** ERROR',txt,fixed=TRUE))
  if(rr$normal){library(MplusAutomation);m<-readModels(file.path(d,'model.out'),what='all',quiet=TRUE);saveRDS(m,file.path(d,'readback.rds'))}
 }
 wj(rr,file.path(d,'receipt.json'));wj(list(status='H0_CALIBRATION_ENGINE_TERMINAL',result=rr,scientific_equivalence_not_yet_established=TRUE),file.path(ROOT,'audit/BATCH_TERMINAL.json'))
 cat('KNOWNCLASS_H0_NATIVE_TERMINAL\n')
}
main()
