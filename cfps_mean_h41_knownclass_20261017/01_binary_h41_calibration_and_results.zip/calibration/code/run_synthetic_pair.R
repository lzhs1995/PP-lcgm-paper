# 校准非零三路径交互；两个模型用同一合成数据，不构成论文实证。
ROOT<-'<LOCAL_USER>/pp_lgcm_review/cfps_binary_h41_calibration_20261017'
library(jsonlite);library(processx);library(ps)
PY<-'<LOCAL_USER>/AppData/Local/Programs/Python/Python314/python.exe'
rj<-function(p)if(file.exists(p))fromJSON(p,simplifyVector=FALSE)else NULL
wj<-function(x,p)write_json(x,p,auto_unbox=TRUE,pretty=TRUE,digits=NA)
main<-function(){
 stopifnot(rj(file.path(ROOT,'audit/H0_EQUIVALENCE.json'))$status=='PASS')
 own<-list(pid=Sys.getpid(),created=as.numeric(ps::ps_create_time(ps::ps_handle())))
 wj(list(owner=own),file.path(ROOT,'runtime/SYN_OWNER.json'))
 awake<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/windows_awake_guard.py'),'--owner-file',file.path(ROOT,'runtime/SYN_OWNER.json'),'--output',file.path(ROOT,'runtime/syn_awake'),'--interval','5'),stdout=file.path(ROOT,'runtime/syn_awake.log'),stderr='2>&1',cleanup=FALSE)
 on.exit({writeLines('release',file.path(ROOT,'runtime/syn_awake/stop.request'));awake$wait(8000L)},add=TRUE)
 active<-FALSE
 for(i in 1:40){a<-rj(file.path(ROOT,'runtime/syn_awake/identity.json'));h<-rj(file.path(ROOT,'runtime/syn_awake/heartbeat.json'));if(!is.null(a)&&!is.null(h)&&a$owner$pid==own$pid&&abs(a$owner$created-own$created)<.01&&awake$is_alive()){active<-TRUE;break};if(!awake$is_alive())stop('awake startup failed');Sys.sleep(.5)}
 stopifnot(active);res<-list()
 for(kind in c('KNOWN','XWITH')){
  if(kind=='XWITH'){
   pre<-processx::run(PY,c('-X','utf8',file.path(ROOT,'code/synthetic_pair.py'),'xwith'),error_on_status=FALSE,timeout=120000)
   writeLines(c(pre$stdout,pre$stderr),file.path(ROOT,'audit/SYN_XWITH_PREPARE.log'))
   if(pre$status!=0){res$XWITH<-list(status='PREPARATION_FAILED');break}
  }
  id<-paste0('SYNTHETIC_',kind,'_H41_A');d<-file.path(ROOT,'models',id);j<-rj(file.path(d,'job.json'))
  j$rscript<-file.path(R.home('bin'),'Rscript.exe');wj(j,file.path(d,'job.json'))
  p<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/engine.py'),file.path(d,'job.json')),stdout=file.path(d,'supervisor.log'),stderr='2>&1',cleanup=FALSE)
  last<-0
  while(p$is_alive()){
   p$wait(1000L)
   if(as.numeric(Sys.time())-last>25){h<-rj(file.path(ROOT,'runtime/progress.json'));msg<-paste(id,h$stage,if(!is.null(h$elapsed_seconds))round(h$elapsed_seconds,1)else'');cat(msg,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress('synthetic_calibration',msg);last<-as.numeric(Sys.time())}
  }
  er<-rj(file.path(d,'engine_receipt.json'));nr<-rj(file.path(d,'not_run.json'))
  rr<-list(status=if(!is.null(er))er$status else if(!is.null(nr))nr$status else 'NO_ENGINE_RECEIPT',engine=er)
  if(file.exists(file.path(d,'model.out'))){txt<-readLines(file.path(d,'model.out'),warn=FALSE);rr$normal<-any(grepl('THE MODEL ESTIMATION TERMINATED NORMALLY',txt,fixed=TRUE));rr$input_error<-any(grepl('*** ERROR',txt,fixed=TRUE))}
  wj(rr,file.path(d,'receipt.json'));res[[kind]]<-rr
  if(!isTRUE(rr$normal))break
 }
 wj(list(status='SYNTHETIC_CALIBRATION_ENGINE_TERMINAL',results=res,formal_H4=FALSE),file.path(ROOT,'audit/SYN_BATCH_TERMINAL.json'))
 cat('SYNTHETIC_CALIBRATION_NATIVE_TERMINAL\n')
}
main()
