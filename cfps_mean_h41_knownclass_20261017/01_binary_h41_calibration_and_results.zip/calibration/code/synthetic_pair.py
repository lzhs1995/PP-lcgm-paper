"""非零交互校准：先已知组解析拟合，再用其终值初始化同目标XWITH。"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import csv,hashlib,json,shutil,sys
import numpy as np
from verify_h0 import matrices,pid
R=Path(__file__).resolve().parents[1];P=R.parent/'cfps_mean_h41_20261017'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
fac=['IX','SX','IY','SY'];obs=[f'{p}{i}' for p in ['X','Y'] for i in range(1,6)]
targets={('IY','IX'):'dii',('SY','IX'):'dis',('SY','SX'):'dss'}
def stmt(r,value=None,label=None):
 v=float(r['value']) if value is None else value;lab=r['label'] if label is None else label
 lhs=r['lhs'].lower();rhs=r['rhs'].lower();x=f'{v:.12g}'
 if r['op']=='MEAN':return f'[{lhs}*{x}] ({lab});'
 if r['op']=='VAR':return f'{lhs}*{x} ({lab});'
 return f'{lhs} {r["op"]} {rhs}*{x} ({lab});'
growth=['ix sx | x1@0 x2*.4 x3*.6 x4*.8 x5@1;','iy sy | y1@0 y2@.4 y3@.6 y4@.8 y5@1;']
def common_header(id):return ['TITLE: '+id+';','DATA: FILE="data.dat";','VARIABLE: NAMES=fid x1-x5 y1-y5 c1-c24 ginc;','MISSING=.; CLUSTER=fid;']
def output():return ['OUTPUT: TECH1 TECH3 TECH8 CINTERVAL SVALUES;','SAVEDATA: RESULTS=estimates.dat; TECH3=tech3.dat;']
def job(d):
 assert max(map(len,(d/'model.inp').read_text().splitlines()))<=90
 j=dict(id=d.name,root=str(R),dest=str(d),category='CALIBRATION',cap_seconds=120,mplus='<LOCAL_USER>/Downloads/Mplus/mplus9/ducument/Mplus.exe',hashes={n:sha(d/n) for n in ['model.inp','data.dat']})
 (d/'job.json').write_text(json.dumps(j,indent=2),encoding='utf-8')
def prepare():
 assert read(R/'audit/H0_EQUIVALENCE.json')['status']=='PASS'
 rng=np.random.default_rng(26101751);n=400;g=np.tile([0.,1.],n//2);fid=np.repeat(np.arange(1,n//2+1),2)
 B=np.zeros((4,4));B[2,0]=-.3;B[3,0]=-.2;B[3,1]=-.25;B[3,2]=.1
 alpha=np.array([.1,.2,-.1,.15]);gm=np.array([.2,.15,-.15,.1]);delta={'dii':.35,'dis':-.3,'dss':.45}
 PSI=np.diag([.8,.5,.7,.5]);PSI[0,1]=PSI[1,0]=.05;PSI[1,2]=PSI[2,1]=.05
 noise=rng.multivariate_normal(np.zeros(4),PSI*.85,n)+np.repeat(rng.multivariate_normal(np.zeros(4),PSI*.15,n//2),2,axis=0)
 latent=np.zeros((n,4))
 for i in range(n):
  bi=B.copy()
  for (a,b),lab in targets.items():bi[fac.index(a),fac.index(b)]+=delta[lab]*g[i]
  latent[i]=np.linalg.solve(np.eye(4)-bi,alpha+gm*g[i]+noise[i])
 L=np.zeros((10,4));L[:5,0]=1;L[5:,2]=1;L[:5,1]=[0,.4,.6,.8,1];L[5:,3]=[0,.4,.6,.8,1]
 TH=np.eye(10)*.4
 for i in range(5):TH[i,i+5]=TH[i+5,i]=.03
 y=latent@L.T+rng.multivariate_normal(np.zeros(10),TH,n)
 missing=rng.random((n,10))<.08;missing[:,0]=False;missing[:,5]=False;y[missing]=np.nan
 dat=np.zeros((n,36));dat[:,0]=fid;dat[:,1:11]=y;dat[:,12]=g
 rows=list(csv.DictReader((P/'models/CFPS_MEAN_EDU_H41_MI01_A/start_mapping.csv').open(encoding='utf-8-sig')))
 rows=[r for r in rows if r['rhs'] not in ('IXG','SXG') and not(r['op']=='ON' and r['rhs'].startswith('C') and r['rhs']!='C2')]
 assert len(rows)==36
 for i,r in enumerate(rows):
  r['label']=f'p{i+1:03d}';op=r['op'];a=r['lhs'];b=r['rhs']
  if op=='BY':v=L[obs.index(b),fac.index(a)]
  elif op=='MEAN':v=alpha[fac.index(a)]
  elif op=='VAR':v=PSI[fac.index(a),fac.index(a)] if a in fac else TH[obs.index(a),obs.index(a)]
  elif op=='WITH':v=PSI[fac.index(a),fac.index(b)] if a in fac else TH[obs.index(a),obs.index(b)]
  elif op=='ON':v=gm[fac.index(a)] if b=='C2' else B[fac.index(a),fac.index(b)]
  else:raise ValueError(op)
  r['value']=float(v)
 d=R/'models/SYNTHETIC_KNOWN_H41_A';d.mkdir(exist_ok=False)
 np.savetxt(d/'data.dat',dat,fmt='%.12g');txt=(d/'data.dat').read_text().replace('nan','.');(d/'data.dat').write_text(txt,encoding='ascii')
 common=[r for r in rows if r['op']!='MEAN' and not(r['op']=='ON' and r['rhs']=='C2')]
 means=[r for r in rows if r['op']=='MEAN']
 lines=common_header(d.name)+['USEVARIABLES=x1-x5 y1-y5;','CLASSES=cg(2); KNOWNCLASS=cg(c2=0 c2=1);',
 'ANALYSIS: TYPE=COMPLEX MIXTURE; ESTIMATOR=MLR; STARTS=0;',
 'PROCESSORS=1; ITERATIONS=2000; MITERATIONS=2000; COVERAGE=.005;',
 'MODEL:','%OVERALL%',*growth,'[cg#1@0];','[x1-x5@0 y1-y5@0];',*[stmt(r) for r in common]]
 for cls in (0,1):
  lines += [f'%cg#{cls+1}%','[x1-x5@0 y1-y5@0];']
  for r in common:
   lab=targets.get((r['lhs'],r['rhs'])) if r['op']=='ON' else None
   lines.append(stmt(r,r['value']+cls*delta[lab],r['label']+str(cls)) if lab else stmt(r))
  for r in means:lines.append(stmt(r,r['value']+cls*gm[fac.index(r['lhs'])],r['lhs'].lower()+str(cls)))
 lines+=output();(d/'model.inp').write_text('\n'.join(lines)+'\n',encoding='ascii');job(d)
 (R/'audit/SYNTHETIC_DESIGN.json').write_text(json.dumps(dict(seed=26101751,N=n,households=n//2,group_mixed_in_each_household=True,delta=delta,rows=rows,expected_free=39,data_sha256=sha(d/'data.dat'),source='Entirely simulated, no CFPS microdata'),indent=2),encoding='utf-8')
 print('SYNTHETIC_KNOWN_INPUT_PREPARED')
def prepare_xwith():
 design=read(R/'audit/SYNTHETIC_DESIGN.json');source=R/'models/SYNTHETIC_KNOWN_H41_A'
 txt,mp,q,se,V,ll=matrices(source)
 assert 'THE MODEL ESTIMATION TERMINATED NORMALLY' in txt and len(q)==39 and np.linalg.eigvalsh(V/np.outer(se,se)).min()>1e-10
 for c in (1,2):
  for f in fac:assert q[pid(mp[c],'PSI',f,f)]>0
 rows=design['rows']
 for r in rows:
  op=r['op'];a=r['lhs'];b=r['rhs']
  if op=='MEAN':v=q[pid(mp[1],'ALPHA','1',a)]
  elif op=='BY':v=q[pid(mp[1],'LAMBDA',b,a)]
  elif op=='VAR':v=q[pid(mp[1],'PSI' if a in fac else 'THETA',a,a)]
  elif op=='WITH':v=q[pid(mp[1],'PSI' if a in fac else 'THETA',a,b)]
  elif op=='ON':v=q[pid(mp[2],'ALPHA','1',a)]-q[pid(mp[1],'ALPHA','1',a)] if b=='C2' else q[pid(mp[1],'BETA',a,b)]
  r['value']=float(v)
 delta={lab:float(q[pid(mp[2],'BETA',a,b)]-q[pid(mp[1],'BETA',a,b)]) for (a,b),lab in targets.items()}
 d=R/'models/SYNTHETIC_XWITH_H41_A';d.mkdir(exist_ok=False);shutil.copyfile(source/'data.dat',d/'data.dat')
 lines=common_header(d.name)+['USEVARIABLES=x1-x5 y1-y5 c2;',
  'ANALYSIS: TYPE=COMPLEX RANDOM; ESTIMATOR=MLR; PROCESSORS=1;',
  'ALGORITHM=INTEGRATION; INTEGRATION=20; ITERATIONS=2000;',
  'MITERATIONS=4000; COVERAGE=.005; MCSEED=26101751;',
  'MODEL:',*growth,'ixg | ix XWITH c2;','sxg | sx XWITH c2;',*[stmt(r) for r in rows]]
 for (a,b),lab in targets.items():lines.append(f'{a.lower()} ON {"sxg" if b=="SX" else "ixg"}*{delta[lab]:.12g} ({lab});')
 lines+=output();(d/'model.inp').write_text('\n'.join(lines)+'\n',encoding='ascii');job(d)
 print('SYNTHETIC_XWITH_INPUT_PREPARED')
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]=='xwith':prepare_xwith()
