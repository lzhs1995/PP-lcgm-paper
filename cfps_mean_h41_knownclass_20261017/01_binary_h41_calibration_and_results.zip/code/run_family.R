# 解析已知组模型：同一估计目标、十份实际MI、逐家族停止规则。
ROOT<-'<LOCAL_USER>/pp_lgcm_review/cfps_mean_h41_knownclass_20261017'
library(jsonlite);library(processx);library(ps)
PY<-'<LOCAL_USER>/AppData/Local/Programs/Python/Python314/python.exe'
rj<-function(p)if(file.exists(p))fromJSON(p,simplifyVector=FALSE)else NULL
wj<-function(x,p)write_json(x,p,auto_unbox=TRUE,pretty=TRUE,digits=NA)
progress<-function(stage,message){cat(format(Sys.time(),tz='UTC',usetz=TRUE),stage,message,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(stage,message)}
python<-function(args,log){p<-processx::run(PY,c('-X','utf8',file.path(ROOT,'code/models.py'),args),error_on_status=FALSE,timeout=120000);writeLines(c(p$stdout,p$stderr),log);if(p$status!=0)stop('Python stage failed: ',log);p}
run_one<-function(g,k,start){
 id<-sprintf('CFPS_MEAN_%s_MI%02d_%s',g,k,start);d<-file.path(ROOT,'models',id)
 progress('prepare',id);python(c('prepare',g,as.character(k),start),file.path(ROOT,'audit',paste0(id,'_prepare.log')))
 j<-rj(file.path(d,'job.json'));j$rscript<-file.path(R.home('bin'),'Rscript.exe');wj(j,file.path(d,'job.json'))
 p<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/engine.py'),file.path(d,'job.json')),stdout=file.path(d,'supervisor.log'),stderr='2>&1',cleanup=FALSE)
 last<-0
 while(p$is_alive()){
  p$wait(1000L)
  if(as.numeric(Sys.time())-last>25){h<-rj(file.path(ROOT,'runtime/progress.json'));progress('estimating',paste(id,h$stage,if(!is.null(h$elapsed_seconds))round(h$elapsed_seconds,1)else''));last<-as.numeric(Sys.time())}
 }
 if(!file.exists(file.path(d,'engine_receipt.json'))){rr<-list(id=id,dest=d,group=g,member=k,start=start,status='NO_ENGINE_RECEIPT',not_run=rj(file.path(d,'not_run.json')));wj(rr,file.path(d,'receipt.json'));return(rr)}
 progress('validate',id);python(c('normalize',d),file.path(d,'readback.log'));r<-rj(file.path(d,'receipt.json'));progress('adjudicated',paste(id,r$status));r
}
main<-function(){
 started_at<-Sys.time()
 stopifnot(!file.exists(file.path(ROOT,'audit/BATCH_TERMINAL.json')))
 own<-list(pid=Sys.getpid(),created=as.numeric(ps::ps_create_time(ps::ps_handle())))
 wj(list(owner=own),file.path(ROOT,'runtime/OWNER.json'))
 awake<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/windows_awake_guard.py'),'--owner-file',file.path(ROOT,'runtime/OWNER.json'),'--output',file.path(ROOT,'runtime/awake'),'--interval','5'),stdout=file.path(ROOT,'runtime/awake.log'),stderr='2>&1',cleanup=FALSE)
 on.exit({writeLines('release',file.path(ROOT,'runtime/awake/stop.request'));awake$wait(8000L)},add=TRUE)
 active<-FALSE
 for(i in 1:40){a<-rj(file.path(ROOT,'runtime/awake/identity.json'));h<-rj(file.path(ROOT,'runtime/awake/heartbeat.json'));if(!is.null(a)&&!is.null(h)&&a$owner$pid==own$pid&&abs(a$owner$created-own$created)<.01&&awake$is_alive()){active<-TRUE;break};if(!awake$is_alive())stop('awake startup failed');Sys.sleep(.5)}
 stopifnot(active);families<-list();attempts<-list()
 save_attempt<-function(rr){attempts[[rr$id]]<<-rr;wj(attempts,file.path(ROOT,'results/ATTEMPTS.json'))}
 for(g in c('EDU','URBAN','INC')){
  fam<-list(group=g,status='STARTING',complete_MI=FALSE,usable_members=0,planned_members=10)
  a<-run_one(g,1,'A');save_attempt(a)
  if(a$status!='USABLE'){fam$status<-'FIRST_MEMBER_FAILED';fam$reason<-a$status;families[[g]]<-fam;wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'));next}
  b<-run_one(g,1,'B');save_attempt(b)
  if(b$status!='USABLE'){fam$status<-'SECOND_START_FAILED';fam$reason<-b$status;families[[g]]<-fam;wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'));next}
  cf<-file.path(ROOT,'results',paste0(g,'_START_AGREEMENT.json'))
  python(c('agree',a$dest,b$dest,cf),file.path(ROOT,'audit',paste0(g,'_agreement.log')))
  if(!isTRUE(rj(cf)$passed)){fam$status<-'START_DISAGREEMENT';families[[g]]<-fam;wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'));next}
  fam$usable_members<-1;members<-list(a);fam$status<-'EXTENDING_MI'
  for(k in 2:10){
   rr<-run_one(g,k,'A');save_attempt(rr)
   if(rr$status!='USABLE'){fam$status<-'MI_FAMILY_INCOMPLETE';fam$reason<-rr$status;break}
   members[[k]]<-rr;fam$usable_members<-k;families[[g]]<-fam;wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'))
  }
  fam$complete_MI<-fam$usable_members==10L;if(fam$complete_MI)fam$status<-'COMPLETE_CONDITIONAL_WORKING_MI'
  fam$member_paths<-vapply(members,function(x)x$dest,'');families[[g]]<-fam;wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'))
 }
 progress('pooling','Only complete ten-member families')
 source(file.path(ROOT,'code/pool_mean.R'),local=TRUE)
 writeLines(capture.output(sessionInfo()),file.path(ROOT,'audit/R_SESSION_INFO.txt'))
 wj(list(status='KNOWNCLASS_MEAN_H41_BATCH_ADJUDICATED',groups=families,budget=rj(file.path(ROOT,'runtime/budget_status.json')),coordinator_wall_seconds=as.numeric(difftime(Sys.time(),started_at,units='secs')),original_four_moderation_complete=FALSE,full_original_H4_complete=FALSE),file.path(ROOT,'audit/BATCH_TERMINAL.json'))
 progress('KNOWNCLASS_MEAN_NATIVE_TERMINAL','Three families adjudicated with calibrated equivalent computation')
 cat('KNOWNCLASS_MEAN_NATIVE_TERMINAL\n')
}
main()
