"""仅在两项实际等价校准PASS后，冻结同目标解析执行合同。"""
from pathlib import Path
import datetime,hashlib,json,shutil
R=Path(__file__).resolve().parents[1];C=R.parent/'cfps_binary_h41_calibration_20261017';P=R.parent/'cfps_mean_h41_20261017'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ('contracts','audit','runtime','models','results','reports'):(R/n).mkdir(exist_ok=True)
proof={}
for n in ['H0_EQUIVALENCE.json','SYN_EQUIVALENCE.json']:
 p=C/'audit'/n;j=read(p);assert j['status']=='PASS';proof[n]=dict(source=str(p),sha256=sha(p),result=j)
for n in ['engine.py','run_one.R','windows_awake_guard.py','mplus_queue.py','process_ownership.py','r2e_local.R','r2e_tools.R','r2e_upstream_math.R']:
 dst=R/'code'/n;assert not dst.exists();shutil.copyfile(P/'code'/n,dst)
shutil.copyfile(C/'code/verify_h0.py',R/'code/calibrated_reader.py')
guard=(C/'code/guard.py').read_text(encoding='utf-8').replace('pp-lgcm-binary-h41-calibration-20261017','pp-lgcm-mean-h41-knownclass-20261017')
(R/'code/guard.py').write_text(guard,encoding='utf-8')
for n in ['mean_tools.R','pool_mean.R']:
 s=(P/'code'/n).read_text(encoding='utf-8').replace('cfps_mean_h41_20261017','cfps_mean_h41_knownclass_20261017');(R/'code'/n).write_text(s,encoding='utf-8')
contract=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 scope='Same CFPS mean-resource IX*G->IY, IX*G->SY, SX*G->SY as prior bounded XWITH attempt; analytically equivalent observed-binary KNOWNCLASS implementation after real H0 and nonzero synthetic calibrations.',
 no_changed_estimand='Not latent-class discovery, no relaxed measurement/residual equality, no variance fixing, no new covariates, no new imputations.',
 groups={'EDU':'c2','URBAN':'c3','INC':'ginc:positive personal income'},
 max_calls=33,total_engine_seconds=1800,category_seconds={g:600 for g in ['EDU','URBAN','INC']},per_call_seconds=120,
 admission='First MI01 legal, second distinct start legal and all-parameter/SE agreement; then remaining actual MI02-10. Any failed member stops that family. No unchanged retry; syntax-only recovery would require separately recorded budget use.',
 numerical_agreement=dict(parameter_absolute_floor=.001,parameter_SE_fraction=.05,SE_relative=.05,conditional_LL_absolute=.02),
 starts='A legal own-member parent plus new interaction0.1; B nonvariance free starts +/-0.02 and new interactions -0.1. Shared variances unchanged at start. No third start.',
 inference='Complete ten only; full transformed TECH3; pooled joint D1 of dii/dis/dss; Holm across planned3; group contrasts include cross-covariance. Conditional working MI, not exact latent substantive-model MI.',
 resource_admission_revision=dict(owned_engine_slots=1,max_external_mplus_at_admission=2,minimum_available_gib=1,minimum_commit_available_gib=2,max_host_cpu_percent=85,resource_wait_seconds=120,foreign_processes_never_modified=True),
 calibration_proofs=proof,original_four_moderation_complete=False,full_original_H4_complete=False)
assert not (R/'contracts/RUN_CONTRACT.json').exists()
(R/'contracts/RUN_CONTRACT.json').write_text(json.dumps(contract,indent=2),encoding='utf-8')
print(json.dumps(dict(status='CALIBRATED_ANALYTIC_BATCH_FROZEN',sha256=sha(R/'contracts/RUN_CONTRACT.json'))))
