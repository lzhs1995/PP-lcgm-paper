"""复用当前同一原生会话的真实smoke证据；不伪造新连接证明。"""
from pathlib import Path
import contextlib,datetime,hashlib,io,json,sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,'<LOCAL_USER>/.codex/skills/clauder-rstudio-workbench')
from clauder_workbench.cli import main
mode=sys.argv[1];key='pp-lgcm-mean-h41-knownclass-20261017'
if mode=='pre-submit':
 source=R.parent/'cfps_mean_h41_20261017/audit/NATIVE_PROOF.json';proof=json.loads(source.read_text())
 assert proof['decision']=='PASS' and proof['transport_class']=='NATIVE_MCP_OK' and str(proof['pid'])=='11644'
 age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(proof['timestamp_utc'].replace('Z','+00:00'))).total_seconds();assert age<3600
 (R/'audit/NATIVE_PROOF_REUSED.json').write_text(json.dumps(dict(source=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),evidence_id=proof['evidence_id'],age_seconds=age,same_agent_and_session=True),indent=2),encoding='utf-8')
args=['async-guard',mode,'--task-key',key]
if mode in ('pre-submit','register-job'):args+=['--session-name','default','--io-mode','durable_files']
if len(sys.argv)>2:args+=['--job-id',sys.argv[2]]
if mode=='complete':args+=['--reason','actual_terminal_saved']
b=io.StringIO()
with contextlib.redirect_stdout(b):rc=main(args)
j=json.loads(b.getvalue());(R/'audit'/('GUARD_'+mode+'.json')).write_text(b.getvalue(),encoding='utf-8');assert rc==0 and j['decision']=='PASS',j
print(json.dumps(dict(decision=j['decision'],evidence_id=j['evidence_id'],mode=mode)))
