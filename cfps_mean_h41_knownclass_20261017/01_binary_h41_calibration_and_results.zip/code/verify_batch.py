"""仅回读：校准、原始参数/TECH3、R打印读回及完整家族状态；不调用Mplus。"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import hashlib,json,re,sys
import numpy as np
import pandas as pd
from calibrated_reader import matrices,pid
R=Path(__file__).resolve().parents[1]
C=R/'calibration' if (R/'calibration').exists() else R.parent/'cfps_binary_h41_calibration_20261017'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
public='--public' in sys.argv
def printed_check(d,mp,q,se):
 p=pd.read_csv(d/'mplusautomation_printed_parameters.csv',dtype={'LatentClass':str});n=0
 for cl,entries in mp.items():
  for mat,a,b,j in entries:
   if j==0:continue
   if mat=='LAMBDA':heads=[b+'.|',b+'.BY'];param=a
   elif mat=='ALPHA':heads=['Intercepts','Means'];param=b
   elif mat in ('BETA','GAMMA'):heads=[a+'.ON'];param=b
   elif mat in ('THETA','PSI') and a==b:heads=['Residual.Variances','Variances'];param=a
   elif mat in ('THETA','PSI'):
    s=p[(p.LatentClass==str(cl))&(((p.paramHeader==a+'.WITH')&(p.param==b))|((p.paramHeader==b+'.WITH')&(p.param==a)))];assert len(s)==1,(mat,a,b,cl)
    assert abs(float(s.est.iloc[0])-q[j-1])<=.000501 and abs(float(s.se.iloc[0])-se[j-1])<=.000501;n+=1;continue
   else:raise ValueError((mat,a,b))
   s=p[(p.LatentClass==str(cl))&p.paramHeader.isin(heads)&(p.param==param)];assert len(s)==1,(mat,a,b,cl)
   assert abs(float(s.est.iloc[0])-q[j-1])<=.000501 and abs(float(s.se.iloc[0])-se[j-1])<=.000501;n+=1
 return n
records=[]
for d in sorted((R/'models').iterdir()):
 if not d.is_dir():continue
 rr=read(d/'receipt.json');job=read(d/'job.json');er=read(d/'engine_receipt.json')
 if not public:
  for n,h in job['hashes'].items():assert sha(d/n)==h
  assert sha(d/'model.out')==rr['output_sha256']==er['output_sha256']
 txt,mp,q,se,V,ll=matrices(d);slots=read(d/'normalized_slots.json');n=len(q);J=np.zeros((n,n))
 assert len(slots)==n==job['expected_free'] and len(mp)==2
 for i,s in enumerate(slots):
  op=s['op'];a=s['lhs'];b=s['rhs']
  if op=='ON' and b==job['g']:
   J[i,pid(mp[2],'ALPHA','1',a)]=1;J[i,pid(mp[1],'ALPHA','1',a)]=-1
  elif op=='ON' and b in ('IXG','SXG'):
   J[i,pid(mp[2],'BETA',a,b[:2])]=1;J[i,pid(mp[1],'BETA',a,b[:2])]=-1
  else:
   if op=='BY':m,r,c='LAMBDA',b,a
   elif op=='MEAN':m,r,c='ALPHA','1',a
   elif op in ('VAR','WITH'):m,r,c=('PSI' if a in ('IX','SX','IY','SY') else 'THETA'),a,(a if op=='VAR' else b)
   else:m,r,c='BETA',a,b
   j=pid(mp[1],m,r,c);J[i,j]=1
   if op!='MEAN':
    is_target=op=='ON' and (a,b) in {('IY','IX'),('SY','IX'),('SY','SX')}
    assert (j!=pid(mp[2],m,r,c))==is_target
 assert np.linalg.matrix_rank(J)==n
 nq=J@q;NV=J@V@J.T;par=pd.read_csv(d/'parameters_high_precision.csv')
 assert np.array_equal(J,np.loadtxt(d/'parameter_transform.csv',delimiter=','))
 assert np.allclose(nq,par.estimate,atol=1e-12,rtol=1e-12)
 assert np.allclose(np.sqrt(NV.diagonal()),par.se,atol=1e-12,rtol=1e-12)
 assert np.allclose(NV,np.loadtxt(d/'parameter_covariance.csv',delimiter=','),atol=1e-12,rtol=1e-12)
 printed=printed_check(d,mp,q,se)
 sy=pid(mp[1],'PSI','SY','SY');assert sy==pid(mp[2],'PSI','SY','SY')
 assert q[sy]<0 and rr['status']=='INADMISSIBLE' and rr['negative']==['SY']
 assert 'THE MODEL ESTIMATION TERMINATED NORMALLY' in txt and 'FIXED TO AVOID SINGULARITY' not in txt
 assert er['status']=='EXITED' and er['seconds']<=job['cap_seconds']
 assert not re.search(r'\b(?:ix|sx|iy|sy)\s*@\s*0\s*;', (d/'model.inp').read_text(),re.I)
 records.append(dict(id=d.name,parameters=n,printed_free_rows=printed,status=rr['status'],SY=float(q[sy]),SY_SE=float(se[sy]),engine_seconds=er['seconds'],peak_tree_MiB=er['peak_tree_rss']/2**20))
assert len(records)==3
fs=read(R/'results/FAMILY_STATUS.json');assert len(fs)==3 and all(not f['complete_MI'] for f in fs.values())
assert read(R/'results/POOLING_RECEIPT.json')['complete']==0
assert read(R/'audit/GUARD_complete.json')['decision']=='PASS' and read(R/'runtime/awake/completion.json')['released']
# 父模型校准从原始输出重建完整参数变换，不依赖历史PASS标记。
h=C/'models/CFPS_EDU_KNOWN_H0_MI01_A';o=C/'references/SW_MI01'
_,hm,hq,hs,HV,hl=matrices(h);_,om,oq,osd,OV,ol=matrices(o)
ref=pd.read_csv(o/'parameters_high_precision.csv').sort_values('parameter');HJ=np.zeros((128,128))
assert len(hq)==len(oq)==128
for i,r in enumerate(ref.itertuples()):
 m,a,b=r.matrix.upper(),r.row,r.column
 if m in ('BETA','GAMMA') and b=='C2':HJ[i,pid(hm[2],'ALPHA','1',a)]=1;HJ[i,pid(hm[1],'ALPHA','1',a)]=-1
 else:HJ[i,pid(hm[1],m,a,b)]=1
assert np.array_equal(HJ,np.loadtxt(C/'results/H0_PARAMETER_TRANSFORMATION.csv',delimiter=','))
cv=HJ@HV@HJ.T;cq=HJ@hq;cs=np.sqrt(cv.diagonal());hr=read(C/'audit/H0_EQUIVALENCE.json')
hstats=[np.max(np.abs(cq-oq)/osd),np.max(np.abs(cs-osd)/osd),np.max(np.abs(cv-OV)/np.outer(osd,osd))]
for key,v in zip(['max_parameter_difference_over_SE','max_SE_relative_difference','max_vcov_difference_over_SE_product'],hstats):assert np.isclose(hr[key],v,atol=1e-10,rtol=1e-8)
assert max(hstats)<.05 and abs(hl+3274*np.log(2)-ol)<.02
# 非零交互校准：相同条件模型的39个参数和完整稳健协方差。
sys.path.insert(0,str(C/'code'))
import verify_synthetic
verify_synthetic.main()
sr=read(C/'audit/SYN_EQUIVALENCE.json');assert sr['status']=='PASS'
cal_seconds=sum(read(d/'engine_receipt.json')['seconds'] for d in (C/'models').iterdir() if d.is_dir())
if not public:
 inv=read(R.parent/'cfps_mean_h41_20261017/audit/SOURCE_INVENTORY.json')
 for member in inv['members']:
  assert sha(Path(member['data']))==member['data_sha256']
  for n,hsh in member['parent_hashes'].items():assert sha(Path(member['source_parent'])/n)==hsh
result=dict(status='PASS',public_mode=public,attempts=records,actual_CFPS_calls=3,calibration_calls=3,CFPS_engine_seconds=sum(r['engine_seconds'] for r in records),calibration_engine_seconds=cal_seconds,total_engine_seconds=sum(r['engine_seconds'] for r in records)+cal_seconds,complete_new_families=0,original_four_complete=False,full_H4_complete=False,H0_parameter_count=128,synthetic_parameter_count=39,scope='Raw saved parameters, full covariance, printed R readback and receipts; public replay does not recompute individual-data likelihood or refit models')
(R/'audit/INDEPENDENT_KNOWNCLASS.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
