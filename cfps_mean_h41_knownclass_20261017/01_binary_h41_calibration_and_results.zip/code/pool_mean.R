# 只合并完整十份合法家族；保留未形成推断的家族，不平均P值。
local({
 ROOT<-'<LOCAL_USER>/pp_lgcm_review/cfps_mean_h41_knownclass_20261017'
 fs<-jsonlite::fromJSON(file.path(ROOT,'results/FAMILY_STATUS.json'),simplifyVector=FALSE)
 stopifnot(length(fs)==3L)
 if(!any(vapply(fs,function(x)isTRUE(x$complete_MI),logical(1)))){
  jsonlite::write_json(list(status='MEAN_H41_POOLING_ADJUDICATED',registered=3,complete=0,failed_groups=names(fs),full_original_H4_complete=FALSE,conditional_on_existing_working_MI=TRUE),file.path(ROOT,'results/POOLING_RECEIPT.json'),auto_unbox=TRUE,pretty=TRUE)
  cat('MEAN_H41_POOLING_DONE complete=0 of3; no coefficient test performed\n')
 }else{
source('<LOCAL_USER>/pp_lgcm_review/cfps_mean_h41_knownclass_20261017/code/mean_tools.R',local=TRUE)
library(mitml)
fs<-rj(file.path(ROOT,'results/FAMILY_STATUS.json'));stopifnot(length(fs)==3L)
joint<-list();paths<-list();contrasts<-list();labs<-c('bii','bis','bss','bsyiy','dii','dis','dss')
for(g in names(fs)){
 f<-fs[[g]]
 if(!isTRUE(f$complete_MI))next
 dirs<-unlist(f$member_paths);stopifnot(length(dirs)==10L)
 Q<-matrix(NA_real_,10,7,dimnames=list(NULL,labs));U<-list()
 for(k in 1:10){
  d<-dirs[k];rr<-rj(file.path(d,'receipt.json'));stopifnot(rr$status=='USABLE',rr$member==k,rr$output_sha256==hashf(file.path(d,'model.out')))
  p<-read.csv(file.path(d,'key_paths.csv'));p<-p[match(labs,p$label),]
  V<-as.matrix(read.csv(file.path(d,'parameter_covariance.csv'),header=FALSE))
  Q[k,]<-p$estimate;U[[k]]<-V[p$parameter,p$parameter];dimnames(U[[k]])<-list(labs,labs)
 }
 po<-rubin_pool(Q,U);paths[[g]]<-data.frame(group=g,label=labs,po$table,row.names=NULL)
 d1<-mitml::testConstraints(qhat=lapply(1:10,function(k)setNames(Q[k,],labs)),uhat=U,constraints=c('dii','dis','dss'),method='D1')
 joint[[g]]<-data.frame(group=g,F=d1$test[1,1],df1=d1$test[1,2],df2=d1$test[1,3],p=d1$test[1,4],RIV=d1$test[1,5])
 cs<-list(IY_IX_G0=c(bii=1),IY_IX_G1=c(bii=1,dii=1),IY_IX_group_difference=c(dii=1),
  SY_IX_G0=c(bis=1),SY_IX_G1=c(bis=1,dis=1),SY_IX_group_difference=c(dis=1),
  SY_SX_G0=c(bss=1),SY_SX_G1=c(bss=1,dss=1),SY_SX_group_difference=c(dss=1))
 contrasts[[g]]<-do.call(rbind,lapply(names(cs),function(n){a<-setNames(rep(0,7),labs);a[names(cs[[n]])]<-cs[[n]];data.frame(group=g,contrast=n,pool_contrast(Q,U,a),row.names=NULL)}))
 d<-file.path(ROOT,'results',g);dir.create(d,showWarnings=FALSE)
 csv(data.frame(member=1:10,Q),file.path(d,'MEMBER_ESTIMATES.csv'))
 csv(do.call(rbind,lapply(1:10,function(k)data.frame(member=k,expand.grid(row=labs,column=labs,stringsAsFactors=FALSE),covariance=as.vector(U[[k]])))),file.path(d,'MEMBER_COVARIANCES.csv'))
}
if(length(joint)){
 j<-do.call(rbind,joint);j$holm_planned3<-p.adjust(j$p,'holm',n=3)
 csv(j,file.path(ROOT,'results/JOINT_D1.csv'));csv(do.call(rbind,paths),file.path(ROOT,'results/POOLED_PATHS.csv'));csv(do.call(rbind,contrasts),file.path(ROOT,'results/GROUP_CONTRASTS.csv'))
}
wj(list(status='MEAN_H41_POOLING_ADJUDICATED',registered=3,complete=length(joint),failed_groups=setdiff(names(fs),names(joint)),
 full_original_H4_complete=FALSE,conditional_on_existing_working_MI=TRUE),file.path(ROOT,'results/POOLING_RECEIPT.json'))
cat('MEAN_H41_POOLING_DONE complete=',length(joint),'of3\n')
 }
})
