# 本批只有总体亲近度×资源组；不沿用忽略IXG的旧条件几何检查。
ROOT <- '<LOCAL_USER>/pp_lgcm_review/cfps_mean_h41_knownclass_20261017'
.libPaths(c('<LOCAL_USER>/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
Sys.setenv(R2E_ROOT=ROOT)
source(file.path(ROOT,'code/r2e_local.R'),local=TRUE)
MEAN_NAMES<-c('fid',paste0('x',1:5),paste0('y',1:5),paste0('c',1:24),'ginc')
mean_spec<-function(group,interaction=TRUE){
 g<-R2E_G[[group]];stopifnot(!is.null(g))
 lines<-sw_lines()
 if(!g$in_controls)lines<-c(lines,paste('ix sx iy sy ON',g$col,';'))
 key<-KEY_XY
 if(interaction){
  lines<-c(lines,paste('ixg | ix XWITH',g$col,';'),paste('sxg | sx XWITH',g$col,';'),
   'iy ON ixg (dii);','sy ON ixg (dis);','sy ON sxg (dss);')
  key<-rbind(key,key_add(c('dii','dis','dss'),c('IY','SY','SY'),c('IXG','IXG','SXG')))
 }
 list(kind=if(interaction)'mean_resource' else 'linear',model=lines,fac=FAC_XY,obs=OBS_XY,
  use=c('x1-x5','y1-y5','c1-c24',if(!g$in_controls)'ginc'),fixed_zero=character(),key=key,group=group)
}
base_geometry<-geometry_r2e
geometry_r2e<-function(m,si,zpoints=c(-1,0,1)){
 if(si$kind!='mean_resource')return(base_geometry(m,si,zpoints))
 fac<-si$fac;obs<-si$obs
 B<-outer(fac,fac,Vectorize(function(r,c)mval(m,'BETA',r,c)));dimnames(B)<-list(fac,fac)
 P<-outer(fac,fac,Vectorize(function(r,c)mval(m,'PSI',r,c)));dimnames(P)<-list(fac,fac)
 meas<-canonical_measurement(m,fac,obs);TH<-meas$THETA;L<-meas$LAMBDA
 checks<-list(PSI=mcheck(P,4L),THETA=mcheck(TH));mats<-list(B=B,PSI=P,THETA=TH,LAMBDA=L)
 for(g in 0:1){
  BC<-B
  BC['IY','IX']<-BC['IY','IX']+g*mval(m,'BETA','IY','IXG')
  BC['SY','IX']<-BC['SY','IX']+g*mval(m,'BETA','SY','IXG')
  BC['SY','SX']<-BC['SY','SX']+g*mval(m,'BETA','SY','SXG')
  A<-solve(diag(4)-BC);G<-A%*%P%*%t(A);S<-L%*%G%*%t(L)+TH
  checks[[paste0('G',g)]]<-mcheck(G,4L);checks[[paste0('SIGMA',g)]]<-mcheck(S)
  mats[[paste0('B',g)]]<-BC;mats[[paste0('G',g)]]<-G;mats[[paste0('SIGMA',g)]]<-S
 }
 list(checks=checks,matrices=mats,passed=all(vapply(checks,function(x)isTRUE(x$positive_definite)&&isTRUE(x$rank_ok),logical(1))),promoted=meas$promoted)
}
mean_mapping<-function(si,parent,start='A'){
 mm<-make_model(si,parent,perturb=start=='B')
 # 新交互起点仅改变初值，不固定参数。
 j<-which(mm$mapping$rhs%in%c('IXG','SXG'))
 if(length(j)){
  mm$mapping$value[j]<-if(start=='A').1 else -.1
  mm$mapping$action[j]<-paste0('new_interaction_start_',start)
  n<-length(si$model)
  for(i in j)mm$lines[n+i]<-paste(tolower(mm$mapping$lhs[i]),'ON',paste0(tolower(mm$mapping$rhs[i]),'*',mm$mapping$value[i],';'))
 }
 mm
}
mean_input<-function(id,si,mm){
 an<-analysis_r2e(if(si$kind=='linear')'linear' else 'lms_observed',points=20,processors=1)
 output<-if(si$kind=='linear')'TECH1 TECH3 TECH4 SAMPSTAT RESIDUAL CINTERVAL SVALUES;' else 'TECH1 TECH3 TECH8 CINTERVAL SVALUES;'
 s<-c('TITLE:',id,'DATA:','FILE="data.dat";','VARIABLE:',wrap90(paste0('NAMES=',paste(MEAN_NAMES,collapse=' '),';')),
 'MISSING=.;',wrap90(paste0('CLUSTER=fid; USEVARIABLES=',paste(si$use,collapse=' '),';')),
 'ANALYSIS:',an,'MODEL:',unlist(lapply(mm$lines,wrap90)),'OUTPUT:',output,'SAVEDATA:','TECH3=tech3.dat; RESULTS=estimates.dat;')
 stopifnot(all(nchar(s)<=90));s
}
