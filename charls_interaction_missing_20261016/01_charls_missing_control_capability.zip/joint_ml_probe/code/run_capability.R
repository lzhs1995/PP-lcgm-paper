# 仅执行本批合成接口，保留错误；两个接口都不能直接宣称真实MI可用。
library(jsonlite);library(processx);library(ps)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_interaction_missing_20261016/joint_ml_probe'
PY<-'<LOCAL_USER_HOME>/AppData/Local/Programs/Python/Python314/python.exe'
jobs<-fromJSON(file.path(ROOT,'contracts/SYNTHETIC_JOBS.json'),simplifyVector=FALSE)
wj<-function(x,p)write_json(x,file.path(ROOT,p),auto_unbox=TRUE,pretty=TRUE,na='null',null='null')
main<-function(){
 owner<-ps_handle();stopfile<-file.path(ROOT,'runtime/BATCH_TERMINAL')
 guard<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/coordinator_awake.py'),'--owner-pid',Sys.getpid(),'--owner-created',as.numeric(ps_create_time(owner)),'--receipt',file.path(ROOT,'runtime/BATCH_AWAKE.json'),'--max-seconds','1800','--stop-file',stopfile),stdout=file.path(ROOT,'runtime/awake.log'),stderr='2>&1',cleanup=FALSE)
 on.exit(writeLines('Synthetic coordinator terminal',stopfile),add=TRUE)
 wj(list(pid=Sys.getpid(),created=as.numeric(ps_create_time(owner))),'runtime/coordinator.json')
 result<-list()
 for(j in jobs){
  if(file.exists(file.path(j$dest,'engine_receipt.json')))stop('Receipt exists; reconcile, never rerun')
  clauder_progress('synthetic_interface',j$id)
  p<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/engine.py'),file.path(j$dest,'job.json')),stdout=file.path(j$dest,'supervisor.log'),stderr='2>&1',cleanup=TRUE)
  last<-0;while(p$is_alive()){p$wait(1000L);if(as.numeric(Sys.time())-last>25){clauder_progress('synthetic_interface_running',j$id);last<-as.numeric(Sys.time())}}
  rec<-file.path(j$dest,'engine_receipt.json');o<-file.path(j$dest,'model.out')
  result[[j$id]]<-list(engine=if(file.exists(rec))fromJSON(rec)else NULL,output_exists=file.exists(o),imputation_files=basename(list.files(j$dest,pattern='^imp[0-9]+\\.dat$')))
  wj(result,'results/CAPABILITY_CALLS.json')
 }
 clauder_progress('CAPABILITY_TERMINAL','Three joint-ML checks adjudicated; inspect exact errors and imputation output');cat('CAPABILITY_TERMINAL\n')
}
main()
