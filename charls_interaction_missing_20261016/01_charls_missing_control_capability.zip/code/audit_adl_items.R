# 回查正式ADL计数的组成及跳转；只报告，不覆盖历史控制/插补。
library(haven);library(jsonlite);library(digest)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_interaction_missing_20261016'
RAW<-'<LOCAL_USER_HOME>/Desktop/20230505 毕业论文/开题报告/开题报告/CHARLS'
core<-readRDS('<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015/private/charls_core_mi_inputs.rds')
roster<-readRDS('<LOCAL_USER_HOME>/pp_lgcm_review/charls_roster_moderation_20261015/private/CONSTRUCTED_BASELINE_CONTRASTS.rds')
hp<-file.path(RAW,'charls11_20_harmonized/data_Harmonized/H_CHARLS_D_Data.dta')
rp<-file.path(RAW,'CHARLS2011/Data/health_status_and_functioning.dta')
dp<-file.path(RAW,'charls11_20_harmonized/data_Harmonized/H_CHARLS_D_do_file.do')
items<-c('r1dressa','r1batha','r1eata','r1beda','r1toilta','r1urina')
h<-read_dta(hp,col_select=all_of(c('ID','r1agey','r1adlab_c','r1adlabm_c',items)));h<-h[match(core$raw$pid,h$ID),]
needed<-c('ID','householdID',paste0('db',sprintf('%03d',c(1,4:15))))
r<-read_dta(rp,col_select=all_of(needed));key<-paste0(r$householdID,'0',substr(r$ID,nchar(r$ID)-1,nchar(r$ID)));j<-match(core$raw$pid,key)
stopifnot(!anyNA(h$ID),!anyNA(j),!anyDuplicated(key));r<-r[j,]
a<-as.data.frame(lapply(h[items],as.numeric));valid<-!is.na(as.matrix(a));n<-rowSums(valid);sum_observed<-rowSums(a,na.rm=TRUE);sum_observed[n==0]<-NA
stopifnot(identical(is.na(sum_observed),is.na(core$raw$adl_difficulties)),all(sum_observed[!is.na(sum_observed)]==core$raw$adl_difficulties[!is.na(sum_observed)]),all(6-n==as.numeric(h$r1adlabm_c)))
rawitems<-as.data.frame(lapply(r[paste0('db',sprintf('%03d',10:15))],as.numeric))
skipvars<-as.data.frame(lapply(r[paste0('db',sprintf('%03d',c(1,4:9)))],as.numeric))
skip<-rowSums(skipvars==1,na.rm=TRUE)==7L
recode<-as.matrix(rawitems);recode[]<-NA
for(k in 1:6){v<-rawitems[[k]];recode[v%in%1,k]<-0;recode[v%in%2:4,k]<-1;recode[is.na(v)&skip,k]<-0}
same<-is.na(recode)==is.na(as.matrix(a));neq<-which(!same|(!is.na(recode)&!is.na(as.matrix(a))&recode!=as.matrix(a)),arr.ind=TRUE)
csv<-function(x,p)write.csv(x,file.path(ROOT,p),row.names=FALSE,na='')
scopes<-list(cohort=rep(TRUE,nrow(a)))
for(z in c('sd','gender','oldest','son'))scopes[[z]]<-roster$all_listed[[paste0(z,'_status')]]=='DEFINED' & roster$legacy_keys_compatible
tab<-do.call(rbind,lapply(names(scopes),function(z){idx<-scopes[[z]];data.frame(scope=z,N=sum(idx),all_six_items_observed=sum(n[idx]==6),partial_items=sum(n[idx]>0&n[idx]<6),all_items_missing=sum(n[idx]==0),harmonized_total_observed=sum(!is.na(h$r1adlab_c[idx])),raw_complete_recoverable_total=sum(n[idx]==0 & rowSums(!is.na(recode[idx,,drop=FALSE]))==6))}))
csv(tab,'results/ADL_ITEM_COMPLETENESS.csv')
freq<-as.data.frame(table(observed_items=n),stringsAsFactors=FALSE);csv(freq,'results/ADL_ITEM_COUNT_DISTRIBUTION.csv')
saveRDS(list(harmonized=h,raw=r,raw_reconstruction=recode,scopes=scopes),file.path(ROOT,'private/adl_item_audit.rds'))
write_json(list(status='AUDITED_NOT_REPLACED',harmonized_sum_reproduced=TRUE,raw_item_disagreements=nrow(neq),raw_comparison_scope='2011 db010-db015; direct1=>0,2:4=>1; skip if db001/db004-db009 all1; no age-under50 override silently applied',partial_total_rule='Official rowtotal of observed 0/1 items if at least one item observed; not necessarily six-item complete',source_hashes=list(harmonized=digest(file=hp,algo='sha256'),raw=digest(file=rp,algo='sha256'),do_file=digest(file=dp,algo='sha256')),source_lines='H_CHARLS_D_do_file.do 4478-4581 item coding,4712-4719 total'),file.path(ROOT,'audit/ADL_ITEM_AUDIT.json'),pretty=TRUE,auto_unbox=TRUE)
cat('ADL_AUDIT\n');print(tab);cat('raw item disagreements',nrow(neq),'\n')
