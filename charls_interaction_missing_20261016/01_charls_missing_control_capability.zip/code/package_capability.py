"""逐项选择聚合证据；不公开真实或合成个人行，不按CSV行数判隐私。"""
from pathlib import Path
import csv,hashlib,io,json,re,zipfile,shutil
R=Path(__file__).resolve().parents[1];S=R/'public_stage';S.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda x:hashlib.sha256(x).hexdigest()
for p in ('audit/CLAUDER_COMPLETION.json','audit/INDEPENDENT_CAPABILITY_VERIFICATION.json','audit/TERMINAL_CHECK.json'):
 q=read(R/p);assert q.get('decision',q.get('status'))=='PASS'
fixed='''reports/REPORT.md
reports/FOR_WEB_REVIEWERS.md
reports/BATCH_RECEIPT.json
contracts/MISSING_CONTROL_ENTRIES.json
results/MISSING_CONTROL_SCOPE.csv
results/ADL_ITEM_COMPLETENESS.csv
results/ADL_ITEM_COUNT_DISTRIBUTION.csv
results/ALL_CAPABILITY_ADJUDICATIONS.json
results/MC_SEED_COMPARISON.json
results/SYNTHETIC_PARAMETERS.csv
audit/SOURCE_HASHES.csv
audit/ADL_ITEM_AUDIT.json
audit/INPUT_INTEGRITY.csv
audit/ENGINE_RESOURCES.csv
audit/TERMINAL_CHECK.json
audit/INDEPENDENT_CAPABILITY_VERIFICATION.json
audit/CLAUDER_COMPLETION.json
runtime/native_capability_terminal.json
runtime/native_submit.json
joint_ml_probe/results/COMPLETE_DATA_PATH_EQUIVALENCE.csv
joint_ml_probe/results/COMPLETE_DATA_PATH_EQUIVALENCE.json
joint_ml_probe/runtime/native_submit.json
joint_ml_probe/runtime/native_terminal_observation.json
joint_mc_probe/runtime/native_submit.json
joint_mc_probe/runtime/native_terminal.json
code/prepare_missing_and_synthetic.R
code/audit_adl_items.R
code/prepare_joint_ml_probe.R
code/prepare_mc_probe.py
code/check_joint_complete.R
code/adjudicate_capability.R
code/verify_capability.py
code/finalize_capability.py
code/package_capability.py
code/verify_public_bundle.py'''.splitlines()
files={x:'aggregate_report_or_code' for x in fixed}
for sub in ('','joint_ml_probe/','joint_mc_probe/'):
 for p in ('contracts/RUN_CONTRACT.json','contracts/SYNTHETIC_JOBS.json','results/CAPABILITY_CALLS.json','runtime/BATCH_AWAKE.json','runtime/budget_status.json','code/run_capability.R','code/run_one.R','code/engine.py','code/coordinator_awake.py'):
  files[sub+p]='aggregate_runtime_or_code'
 for d in (R/sub/'models').iterdir():
  for n in ('model.inp','model.out','job.json','engine_receipt.json','adjudication.json','mplus_execution.log','parameters_high_precision.csv','parameter_covariance.csv','tech1_parameter_map.csv','readback.json','estimates.dat','tech3.dat'):
   p=d/n
   if p.exists() and p.stat().st_size:
    files[p.relative_to(R).as_posix()]='model_parameters' if n=='estimates.dat' else 'parameter_covariance' if n=='tech3.dat' else 'synthetic_model_evidence'
payload={};manifest=[]
for name,role in files.items():
 p=R/name;assert p.is_file(),name
 assert 'private' not in p.relative_to(R).parts and p.name!='data.dat' and p.suffix.lower() not in ('.rds','.dta')
 raw=p.read_bytes();text=raw.decode('utf-8-sig')
 for prefix in ('<LOCAL_USER_HOME>','<LOCAL_USER_HOME>','C:\\\\Users\\\\LZHS','<LOCAL_USER_HOME>','<LOCAL_USER_HOME>'):text=text.replace(prefix,'<LOCAL_USER_HOME>')
 assert not re.search(r'(?i)(?:api[_-]?key|access_token)\s*[:=]\s*["\']?[A-Za-z0-9_-]{20,}',text),name
 if p.suffix=='.csv' and p.name!='parameter_covariance.csv':
  header=next(csv.reader(io.StringIO(text)));assert not {x.lower() for x in header}&{'pid','fid','childid','householdid','communityid'},name
 data=text.encode('utf-8');payload[name]=data
 manifest.append({'path':name,'bytes':len(data),'sha256':sha(data),'local_source_sha256':sha(raw),'paths_redacted':data!=raw,'role':role})
payload['PAYLOAD_MANIFEST.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
zpath=S/'01_charls_missing_control_capability.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,data in payload.items():z.writestr(name,data)
assert zpath.stat().st_size<25_000_000
with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
pm={'packages':[{'file':zpath.name,'bytes':zpath.stat().st_size,'sha256':sha(zpath.read_bytes()),'files':len(payload)}],'privacy':'Explicit per-file statistical roles. No participant DAT/DTA/RDS/MI/IDs. estimates.dat and tech3.dat contain model parameters only. Local user paths redacted.'}
(S/'PACKAGE_MANIFEST.json').write_text(json.dumps(pm,ensure_ascii=False,indent=2),encoding='utf-8')
for n in ('REPORT.md','FOR_WEB_REVIEWERS.md','BATCH_RECEIPT.json'):(S/n).write_bytes(payload['reports/'+n])
for n in ('MISSING_CONTROL_SCOPE.csv','ADL_ITEM_COMPLETENESS.csv'):(S/n).write_bytes(payload['results/'+n])
(S/'README.md').write_text('''# CHARLS基期控制缺失：来源与接口核验

**四项调节完整推断、完整 H4 仍未完成。**

[本批报告](REPORT.md) · [网页端说明](FOR_WEB_REVIEWERS.md) · [实际回执](BATCH_RECEIPT.json) · [ADL条目完整性](ADL_ITEM_COMPLETENESS.csv)

基期ADL来源已核清；七次合成调用保留正常、未收敛、不支持及超时结果。没有新增真实样本估计、插补或旧CFPS重跑。H4.1继续沿用3/12个完整条件家族。

解压后运行`python code/verify_public_bundle.py`核对清单哈希；`python code/verify_capability.py`独立复算保存参数与完整数据路径对照，需numpy/pandas，不调用Mplus。单包小于25MB；无个人数据或MI；DAT白名单仅为模型参数和协方差。经验见[mplusautomation-guide PR25](https://github.com/lzhs1995/clauder-rstudio-workbench/pull/25)。
''',encoding='utf-8')
(R/'audit/PUBLIC_FILE_SELECTION.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(pm,ensure_ascii=False))
