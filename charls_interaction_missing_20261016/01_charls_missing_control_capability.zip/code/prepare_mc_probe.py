"""合成数据接口修正：保留统计模型，仅按Mplus明确报错改积分方式。"""
from pathlib import Path
import json, shutil, hashlib
from datetime import datetime, timezone
base=Path('<LOCAL_USER_HOME>/pp_lgcm_review/charls_interaction_missing_20261016/joint_ml_probe')
root=base.parent/'joint_mc_probe'
for d in ('code','contracts','models','results','runtime','audit'):(root/d).mkdir(parents=True,exist_ok=True)
contract=dict(created_utc=datetime.now(timezone.utc).isoformat(),scope='Only correct the explicit Monte Carlo integration requirement; same synthetic missing-ADL likelihood; two fixed seeds',total_engine_seconds=480,category_seconds={'SYNTHETIC':480},max_calls=2,wall_seconds=1800,per_call_cap=240,processor=1,engine_slots=1,real_data_calls=0,points=5000,seeds=[26101611,26101612],comparison={'paths':['IY:IX','SY:IX','SY:SX','SY:IY','SY:SXZ','SY:ADL'],'estimate_difference_reference_SE':0.1,'SE_relative':0.05},failure_action='retain outcomes; no automatic point or iteration escalation',preregistration_claim=False)
(root/'contracts/RUN_CONTRACT.json').write_text(json.dumps(contract,indent=2),encoding='utf-8')
for name in ('engine.py','coordinator_awake.py','run_one.R'):shutil.copyfile(base/'code'/name,root/'code'/name)
runner=(base/'code/run_capability.R').read_text(encoding='utf-8').replace(base.as_posix(),root.as_posix()).replace('Three joint-ML checks adjudicated','Two fixed-seed Monte Carlo interface checks adjudicated')
(root/'code/run_capability.R').write_text(runner,encoding='utf-8')
src=base/'models/SYNTHETIC_JOINT_MISSING';jobs={}
for k,seed in enumerate(contract['seeds'],1):
 ident=f'SYNTHETIC_JOINT_MISSING_MC{k}';d=root/'models'/ident;d.mkdir(exist_ok=True)
 if (d/'engine_receipt.json').exists():raise RuntimeError('Existing result; do not rerun')
 inp=(src/'model.inp').read_text().replace('SYNTHETIC_JOINT_MISSING',ident).replace('INTEGRATION=30;',f'INTEGRATION=MONTECARLO(5000); MCSEED={seed};')
 (d/'model.inp').write_text(inp,encoding='utf-8');shutil.copyfile(src/'data.dat',d/'data.dat')
 job=json.loads((src/'job.json').read_text());job.update(id=ident,root=root.as_posix(),dest=d.as_posix(),cap_seconds=240)
 job['hashes']={n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in ('model.inp','data.dat')}
 (d/'job.json').write_text(json.dumps(job,indent=2),encoding='utf-8');jobs[ident]=job
(root/'contracts/SYNTHETIC_JOBS.json').write_text(json.dumps(jobs,indent=2),encoding='utf-8')
print('PREPARED',root,'calls',len(jobs),'real-data calls 0')
