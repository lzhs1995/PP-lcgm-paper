"""仅从保存参数与TECH1/TECH3独立复算，不拟合个人数据。"""
from pathlib import Path
import hashlib,json,re
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def tech1(text):
 text=text.split('PARAMETER SPECIFICATION',1)[1].split('STARTING VALUES',1)[0]
 lines=text.splitlines();result=[];i=0;mats={'NU','LAMBDA','THETA','ALPHA','BETA','PSI','GAMMA','TAU','KAPPA'}
 while i<len(lines)-2:
  mat=lines[i].strip()
  if mat not in mats or not re.fullmatch(r'[_ ]+',lines[i+2]) or not lines[i+2].strip():i+=1;continue
  cols=lines[i+1].split();i+=3
  while i<len(lines) and lines[i].strip() and lines[i].strip() not in mats:
   tk=lines[i].split()
   if mat in {'NU','ALPHA','TAU','KAPPA'} and re.match(r'^[-+\d]',tk[0]):row='1';vals=tk
   else:row=tk[0];vals=tk[1:]
   for col,value in zip(cols,vals):result.append((mat,row,col,int(value)))
   i+=1
 return result
def main():
 results=read(R/'results/ALL_CAPABILITY_ADJUDICATIONS.json');details={};parsed={}
 for root in (R,R/'joint_ml_probe',R/'joint_mc_probe'):
  for d in (root/'models').iterdir():
   if not (d/'adjudication.json').exists():continue
   q=results[d.name];o=(d/'model.out').read_bytes()
   # Public paths are redacted; only the local raw file is expected to retain raw hash.
   if b'<LOCAL_USER_HOME>' not in o:assert hashlib.sha256(o).hexdigest()==q['output_sha256']
   if not (d/'parameters_high_precision.csv').exists():details[d.name]={'status':q['status'],'parameters_read':0};continue
   mp=tech1(o.decode('latin1'));n=max(x[3] for x in mp)
   v=np.fromstring((d/'estimates.dat').read_text(),sep=' ');t=np.fromstring((d/'tech3.dat').read_text(),sep=' ')
   assert len(t)==n*(n+1)//2 and len(v)>=2*n
   V=np.zeros((n,n));V[np.tril_indices(n)]=t;V=V+V.T-np.diag(V.diagonal())
   assert np.allclose(np.sqrt(V.diagonal()),v[n:2*n],rtol=1e-6,atol=1e-8)
   p=pd.read_csv(d/'parameters_high_precision.csv').sort_values('parameter')
   assert len(p)==n and np.allclose(p.estimate,v[:n],atol=1e-12) and np.allclose(p.se,v[n:2*n],atol=1e-12)
   assert np.allclose(pd.read_csv(d/'parameter_covariance.csv',header=None),V,rtol=1e-12,atol=1e-12)
   for row in p.itertuples():assert (row.matrix.upper(),row.row,row.column,row.parameter) in mp
   paths={a+':'+b:(v[k-1],v[n+k-1]) for mat,a,b,k in mp if mat in {'BETA','GAMMA'} and k>0}
   parsed[d.name]=paths;details[d.name]={'status':'RAW_PARAMETERS_MATCH_R','parameters_read':n}
 eq=pd.read_csv(R/'joint_ml_probe/results/COMPLETE_DATA_PATH_EQUIVALENCE.csv')
 a=parsed['SYNTHETIC_CONDITIONAL_COMPLETE'];b=parsed['SYNTHETIC_JOINT_COMPLETE']
 for t in eq.itertuples():
  x,s=a[t.key];y,u=b[t.key]
  assert np.allclose([t.conditional_est,t.joint_est,t.conditional_se,t.joint_se,t.diff_over_se,t.se_relative],[x,y,s,u,abs(x-y)/s,abs(s-u)/s],rtol=1e-7,atol=1e-12)
 result={'status':'PASS','models':details,'complete_data_paths_independently_compared':len(eq),'max_difference_in_SE':float(eq.diff_over_se.max()),'real_data_fit_claim':False,'full_MI_claim':False}
 (R/'audit/INDEPENDENT_CAPABILITY_VERIFICATION.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
if __name__=='__main__':main()
