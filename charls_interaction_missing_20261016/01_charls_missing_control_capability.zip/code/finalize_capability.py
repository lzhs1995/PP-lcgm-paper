"""本批终态、原始输入完整性与缺失处理决策；不调用估计器。"""
from pathlib import Path
from datetime import datetime,timezone
import csv,hashlib,json,sqlite3
import psutil
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
assert read(R/'audit/INDEPENDENT_CAPABILITY_VERIFICATION.json')['status']=='PASS'
calls=read(R/'results/ALL_CAPABILITY_ADJUDICATIONS.json');checks=[];owned=set();resources=[];budgets=[]
for root in (R,R/'joint_ml_probe',R/'joint_mc_probe'):
 assert (root/'runtime/BATCH_TERMINAL').exists()
 assert read(root/'runtime/BATCH_AWAKE.json')['status']=='RELEASED'
 assert not (root/'runtime/engine.lock').exists()
 con=sqlite3.connect(f'file:{(root/"runtime/budget.sqlite").as_posix()}?mode=ro',uri=True)
 assert con.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
 assert con.execute('SELECT count(*) FROM calls WHERE seconds IS NULL').fetchone()[0]==0;con.close()
 contract=read(root/'contracts/RUN_CONTRACT.json');budget=read(root/'runtime/budget_status.json')
 assert len(budget['rows'])<=contract['max_calls']
 budgets.append({'batch':root.name,'nominal_cap':contract['total_engine_seconds'],'observed_seconds':budget['engine_seconds'],'overshoot_seconds':max(0,budget['engine_seconds']-contract['total_engine_seconds'])})
 for d in (root/'models').iterdir():
  j=read(d/'job.json');e=read(d/'engine_receipt.json')
  for name,h in j['hashes'].items():assert sha(d/name)==h;checks.append({'model':d.name,'file':name,'sha256':h,'status':'PASS'})
  assert sha(d/'model.out')==e['output_sha256']==calls[d.name]['output_sha256']
  if (d/'resources.jsonl').exists():
   for line in (d/'resources.jsonl').read_text().splitlines():
    for p in json.loads(line)['processes']:
     if p['name'].lower()=='mplus.exe':owned.add((p['pid'],p['created']))
  resources.append({'model':d.name,'engine_status':e['status'],'adjudication':calls[d.name]['status'],'seconds':e['seconds'],'peak_tree_RSS_MiB':e['peak_tree_rss']/2**20,'sampled_tree_CPU_seconds':e['sampled_tree_cpu_seconds']})
for pid,born in owned:
 try:assert abs(psutil.Process(pid).create_time()-born)>.01,('Owned engine still active',pid)
 except psutil.NoSuchProcess:pass
for x in csv.DictReader((R/'audit/SOURCE_HASHES.csv').open(encoding='utf-8-sig')):assert sha(Path(x['path']))==x['sha256']
for x in read(R/'contracts/MISSING_CONTROL_ENTRIES.json').values():assert sha(Path(x['data_file']))==x['data_sha256']
for filename,rows in [('INPUT_INTEGRITY.csv',checks),('ENGINE_RESOURCES.csv',resources)]:
 with (R/'audit'/filename).open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
terminal={'status':'PASS','utc':datetime.now(timezone.utc).isoformat(),'owned_engine_identities':len(owned),'owned_engines_remaining':0,'all_three_awake_guards':'RELEASED','queue_integrity':'ok','input_checks':len(checks),'source_hashes_rechecked':True,'budgets':budgets,'note':'Timeout accounting includes polling/termination overhead; observed overshoot reported, never hidden by changing contract'}
write(R/'audit/TERMINAL_CHECK.json',terminal)
receipt={'status':'MISSING_CONTROL_AUDIT_AND_BOUNDED_CAPABILITY_COMPLETE','synthetic_calls':len(calls),'real_data_calls':0,'new_MI':0,'engine_launcher_seconds':sum(x['seconds'] for x in resources),'CFPS_H41_complete_conditional_families':3,'CFPS_H41_registered_families':12,'original_four_moderations_complete':False,'full_H4_complete':False,'new_CFPS_calls':0,'unchanged_failed_specs_repeated':0,'new_NLM':0,'closed_manuscript_changed':False,'MI_generated':0,'joint_missing_real_data_admitted':False,'limits':'Capabilities and missing-control definition only, not complete inference'}
write(R/'reports/BATCH_RECEIPT.json',receipt)
rows='\n'.join(f"| {x['model']} | {x['adjudication']} | {x['seconds']:.3f} |" for x in resources)
scope=list(csv.DictReader((R/'results/ADL_ITEM_COMPLETENESS.csv').open(encoding='utf-8-sig')))
srows='\n'.join(f"| {x['scope']} | {x['N']} | {x['all_six_items_observed']} | {x['partial_items']} | {x['all_items_missing']} |" for x in scope)
eq=read(R/'joint_ml_probe/results/COMPLETE_DATA_PATH_EQUIVALENCE.json')
report=f'''# CHARLS调节模型：基期ADL缺失定义与有上限的接口核验

**四项调节完整推断、完整 H4 仍未完成。**

本批接续已发表的四个CHARLS完整案例小试，不覆盖旧数据、MI或论文。新增真实CFPS/CHARLS估计均为0；新增插补为0。实际完成的是原始ADL来源审计、可恢复范围确认，以及七次合成接口调用。H4.1沿用三个十份条件家族；其余九个登记家族未形成完整推断，不原样重跑。

## 基期控制和原始条目

现有核心调整集为年龄、性别、教育、城乡、伴侣、子女数、ADL和自评健康分类。合法跨期性别来源恢复已在前批记录，原始缺失标记保留。四个已核实名册范围余下普通控制缺失仅ADL，分别18、15、18、18人；其他缺失来自结构性未定义或来源歧义，不混在ADL处理中。

原始2011 db010—db015经直接回答编码与合法跳转规则，逐项复现harmonized ADL，差异0。官方r1adlab_c是有至少一项时的可用条目总和，并不要求六项全观测。原3006人有2个部分条目总分、20个全缺失；没有可以从同年原始回答直接补回的全缺失总分。

| 范围 | N | 六项完整 | 部分条目 | 全缺失 |
|---|---:|---:|---:|---:|
{srows}

因此此前“核心控制完整案例”是harmonized控制变量非缺失，不等于六项ADL都完整。部分总分是官方定义，不直接裁定为编码错误。现有结果保留该定义；任何六项完整或题目级插补方案须另行声明改变，不静默重算。全缺失不得填0，结构性无儿子等也不得填补。

## 实测接口结果

| 合成调用 | 裁定 | 引擎及启动器秒数 |
|---|---|---:|
{rows}

单层Bayes接受观测ADL作为数值控制与SX×Z交互，但短链未收敛、无可用插补。两层版明确不支持PREDICTOR=OBSERVED；这不等于Mplus普遍不支持两层Bayes交互。删除此选项会改变类别变量用作预测量的含义，不能当成无损修复。

直接联合MLR保留社区稳健SE和原结构。完整数据下，加入ADL类别分布后，共同结构路径最大差异{eq['max_estimate_difference_in_SE']:.9g}个参照SE；这支持完整数据下观测预测含义一致，但不证明有缺失时全部推断正确，也不验证MAR。合成样本仅40个社区，稳健参数协方差的秩受社区数限制，不能机械要求超过39维的全参数稳健协方差满秩。

带缺失的联合ML模型明确要求Monte Carlo积分，故追加的是两个有具体错误依据、不同固定种子的合成调用，不是重跑原失败规格。固定5000点、每次240秒；结果和超时保留，无自动加点、延时或扩展真实数据。总实际引擎/启动器{receipt['engine_launcher_seconds']:.3f}秒。超时终止的轮询与清理开销在TERMINAL_CHECK中按实报告；没有事后扩大合同。

## 缺失处理方案与可执行边界

1. 继续保留已核实子女名册、结构性定义、原X/Y缺失掩码、固定尺度、官方ADL及其部分条目标记。
2. 现有四项完整案例结果仅用于其条件样本；不凭缺失比例小宣称无选择偏误，不称为完整MI。
3. 现有核心20份与资源40份加法MI仅对应既有加法模型；不能直接挪用成已证明相容的潜交互MI。三个CFPS H4.1完整条件家族也保留既有插补相容性限制。
4. 本次接口没有产生可直接投入真实资料的缺失控制推断。联合ML路线保留为方法候选，若将来继续须先有新的低成本算法依据和独立预算，不默认重复本次超时调用。
5. 本批可以关闭“控制缺失在哪里、原始来源能否恢复、现成接口是否已可用”三个问题；不能关闭四项调节或完整H4。下一步研究应在明确的估计对象下选择缺失处理，而不是继续堆积同一失败规格。

## 可复核证据与工具经验

输入、原始输出、TECH1、高精度参数、TECH3、两种独立回读、原始ADL聚合核验和运行合同随包。真实个人data.dat、RDS、IDs和MI不公开。所有合成失败输出均保留。发布代码按文件角色白名单选择，不因CSV较短就默认安全。

RStudio通过ClaudeR default@8787异步运行，三批均有原job_id、进度和终态。独占引擎、PID创建时间、超时父链、临时Windows空闲保护均有回执。小内存占用但CPU持续增长是计算负担证据，不应为此关闭无关应用。方法接口先用小合成样本核验，避免向数千人×多份插补推广一个尚不可用的组合。

依据：[Mplus PREDICTOR选项](https://www.statmodel.com/HTML_UG/chapter16V8.htm)、[数据插补](https://www.statmodel.com/HTML_UG/chapter11V8.htm)、[版本历史](https://www.statmodel.com/verhistory.shtml)。具体不支持组合以随包Mplus9原始错误为证，不把软件接口限制外推成统计不可能。

既有结果固定提交：四项完整案例04e97911e2008343aacc7ccc1c38e4c84cffbbc8；名册671d844575c04492be29a2e05c434c876a41ca41；资源MI与H4.1剩余分支437518be9ba2c55313ad91ff2fd079eec73df0d1。本批不修改收尾稿，不新增NLM或原稿定稿声明。
'''
(R/'reports/REPORT.md').write_text(report,encoding='utf-8')
(R/'reports/FOR_WEB_REVIEWERS.md').write_text('''# 给网页端审阅者

请先读REPORT与BATCH_RECEIPT。本包只回答CHARLS调节所需的控制缺失来源与方法接口；不是完整调节结果包。CFPS H4.1仍3/12个完整条件家族，四项调节与完整H4未完成。

关键新证据是：官方ADL可能来自部分条目；全缺失无法从同年原始数据恢复；两层Bayes不接受PREDICTOR=OBSERVED；联合ML完整数据路径含义可核对，但有缺失的Monte Carlo配置未取得可采用完整证据。请不要要求原样重复已失败CFPS、将加法MI直接称为交互相容、或因缺失比例小而忽略推断边界。

公开包仅有代码、聚合结果和合成/参数证据。可解压执行code/verify_public_bundle.py和code/verify_capability.py，不调用Mplus、不需要个人数据。超时日志不是软件正常收敛，也不是无效应证明。
''',encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
