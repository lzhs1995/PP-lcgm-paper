"""核验公开包逐文件哈希、统计参数文件角色和批次边界。"""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[1]
rows=json.loads((R/'PAYLOAD_MANIFEST.json').read_text(encoding='utf-8-sig'))
for r in rows:
 p=R/r['path'];assert p.is_file() and len(p.read_bytes())==r['bytes']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
 assert p.name!='data.dat' and p.suffix.lower() not in {'.rds','.dta'}
 if p.suffix=='.dat':assert p.name in {'estimates.dat','tech3.dat'} and r['role'] in {'model_parameters','parameter_covariance'}
b=json.loads((R/'reports/BATCH_RECEIPT.json').read_text(encoding='utf-8-sig'))
assert b['new_CFPS_calls']==0 and b['real_data_calls']==0 and b['new_MI']==0 and b['MI_generated']==0
assert not b['original_four_moderations_complete'] and not b['full_H4_complete']
print(json.dumps({'status':'PASS','payload_files':len(rows),'synthetic_calls':b['synthetic_calls'],'real_data_calls':0,'full_moderation_MI':False,'full_H4':False}))
