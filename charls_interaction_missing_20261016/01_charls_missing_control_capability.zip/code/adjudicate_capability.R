# 汇总真实接口结果，不把退出码0当成可用估计；只读取、不重新拟合。
library(jsonlite);library(digest)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_interaction_missing_20261016'
source('<LOCAL_USER_HOME>/pp_lgcm_review/charls_observed_moderation_20261016/code/r2e_tools.R',local=TRUE)
roots<-c(ROOT,file.path(ROOT,'joint_ml_probe'),file.path(ROOT,'joint_mc_probe'))
all<-list();pars<-list()
for(root in roots){
 stopifnot(file.exists(file.path(root,'runtime/BATCH_TERMINAL')))
 calls<-fromJSON(file.path(root,'results/CAPABILITY_CALLS.json'),simplifyVector=FALSE)
 for(id in names(calls)){
  d<-file.path(root,'models',id);e<-calls[[id]]$engine
  L<-if(file.exists(file.path(d,'model.out')))readLines(file.path(d,'model.out'),warn=FALSE)else character()
  f<-gsub('[[:space:]]+',' ',paste(L,collapse=' '))
  status<-if(e$status!='EXITED')e$status else 'UNADJUDICATED'
  if(grepl('PREDICTOR=OBSERVED setting is not available with TYPE=TWOLEVEL',f,fixed=TRUE))status<-'UNSUPPORTED_OBSERVED_PREDICTOR_TWOLEVEL'
  if(grepl('THIS MODEL CAN BE DONE ONLY WITH MONTECARLO INTEGRATION',f,fixed=TRUE))status<-'REQUIRES_MONTECARLO_INTEGRATION'
  if(grepl('SINGLE_ORDINAL',id))status<-'BAYES_SHORT_CHAIN_NOT_CONVERGED_NO_MI'
  q<-list(id=id,status=status,engine_status=e$status,seconds=e$seconds,output_sha256=if(length(L))digest(file=file.path(d,'model.out'),algo='sha256')else NULL,real_data=FALSE)
  if(file.exists(file.path(d,'estimates.dat'))&&file.exists(file.path(d,'tech3.dat'))&&file.info(file.path(d,'estimates.dat'))$size>0&&file.info(file.path(d,'tech3.dat'))$size>0){
   tryCatch({
    m<-read_mplus_raw(d);fl<-out_flags(m$lines)
    geom<-geometry_r2e(m,list(kind='lms_observed',fac=FAC_XY,obs=OBS_XY,fixed_zero=character()),c(-3,0,3))
    neg<-free_negative(m)
    v<-m$V/outer(sqrt(diag(m$V)),sqrt(diag(m$V)));ev<-eigen(v,symmetric=TRUE,only.values=TRUE)$values
    # 合成样本只有40个社区；稳健协方差的满秩不可能超过39，不能误判为模型未识别。
    q$validation<-list(normal=fl$normal,fatal=fl$fatal,warnings=fl$warnings,negative=neg,geometry=geom$checks,geometry_passed=geom$passed,se_tech3_max_diff=m$se_tech3_max_diff,parameter_count=m$P,communities=40,robust_covariance_rank=sum(ev>1e-7),robust_covariance_min_eigen=min(ev),rank_note='40 clusters: robust score covariance rank at most 39; synthetic capability check, not full real-data inference')
    q$status<-if(fl$normal&&!fl$fatal&&!length(neg)&&geom$passed&&m$se_tech3_max_diff<1e-5)'SYNTHETIC_FUNCTIONAL_FIT'else'SYNTHETIC_UNACCEPTABLE_ESTIMATE'
    write.csv(m$par,file.path(d,'parameters_high_precision.csv'),row.names=FALSE)
    write.csv(m$spec,file.path(d,'tech1_parameter_map.csv'),row.names=FALSE)
    write.table(m$V,file.path(d,'parameter_covariance.csv'),sep=',',row.names=FALSE,col.names=FALSE)
    p<-m$par;p$key<-paste(p$row,p$column,sep=':');p$model<-id;pars[[id]]<-p
   },error=function(err){q$status<<-'READBACK_FAILURE';q$error<<-conditionMessage(err)})
  }
  write_json(q,file.path(d,'adjudication.json'),auto_unbox=TRUE,pretty=TRUE,digits=16,na='null');all[[id]]<-q
 }
}
mcids<-paste0('SYNTHETIC_JOINT_MISSING_MC',1:2)
cmp<-list(status='NOT_AVAILABLE',reason='Two usable synthetic missing-control fits required',real_data_admitted=FALSE)
if(all(vapply(mcids,function(id)identical(all[[id]]$status,'SYNTHETIC_FUNCTIONAL_FIT'),TRUE))){
 key<-c('IY:IX','SY:IX','SY:SX','SY:IY','SY:SXZ','SY:ADL');a<-pars[[mcids[1]]];b<-pars[[mcids[2]]]
 a<-a[match(key,a$key),];b<-b[match(key,b$key),];stopifnot(!anyNA(a$key),!anyNA(b$key))
 t<-data.frame(key=key,estimate_a=a$estimate,estimate_b=b$estimate,se_a=a$se,se_b=b$se,diff_over_SE=abs(a$estimate-b$estimate)/a$se,SE_relative=abs(a$se-b$se)/a$se)
 ok<-all(t$diff_over_SE<=.1)&all(t$SE_relative<=.05)
 cmp<-list(status=if(ok)'PASS_FROZEN_SEED_COMPARISON'else'FAILED_FROZEN_SEED_COMPARISON',maximum_difference_SE=max(t$diff_over_SE),maximum_SE_relative=max(t$SE_relative),real_data_admitted=FALSE,note='Even a passing synthetic check is not a real-data result')
 write.csv(t,file.path(ROOT,'results/MC_SEED_COMPARISON.csv'),row.names=FALSE)
}
write_json(cmp,file.path(ROOT,'results/MC_SEED_COMPARISON.json'),auto_unbox=TRUE,pretty=TRUE,digits=16)
write_json(all,file.path(ROOT,'results/ALL_CAPABILITY_ADJUDICATIONS.json'),auto_unbox=TRUE,pretty=TRUE,digits=16,na='null')
if(length(pars))write.csv(do.call(rbind,pars),file.path(ROOT,'results/SYNTHETIC_PARAMETERS.csv'),row.names=FALSE)
print(data.frame(model=names(all),status=vapply(all,function(x)x$status,'')));print(cmp)
