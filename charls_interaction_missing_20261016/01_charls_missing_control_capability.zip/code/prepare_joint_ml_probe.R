# 新方法接口合同：联合ADL类别分布＋原潜交互；检验完整资料时条件模型的路径恒等性。
library(jsonlite);library(digest)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_interaction_missing_20261016/joint_ml_probe'
truth<-readRDS('<LOCAL_USER_HOME>/pp_lgcm_review/charls_interaction_missing_20261016/private/synthetic_truth.rds')
model<-c('ix sx | x1@0 x2@2 x3@4 x4@7 x5@9;','iy sy | y1@0 y2@2 y3@4 y4@7 y5@9;',
 'ix sx iy sy ON z c1 adl;','iy ON ix (bii);','sy ON ix (bis);','sy ON sx (bss);','sy ON iy (bsyiy);',
 'ix WITH sx;','sx WITH iy;',paste0('x',1:5,' WITH y',1:5,';'),'sxz | sx XWITH z;','sy ON sxz (dc);')
jobs<-list()
for(type in c('CONDITIONAL_COMPLETE','JOINT_COMPLETE','JOINT_MISSING')){
 id<-paste0('SYNTHETIC_',type);d<-file.path(ROOT,'models',id);dir.create(d,showWarnings=FALSE)
 a<-if(type=='JOINT_MISSING')truth$observed else truth$full
 write.table(a,file.path(d,'data.dat'),row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
 lines<-c(paste0('TITLE: ',id,' interface and observed ADL parameter identity;'),'DATA: FILE=data.dat;',
 'VARIABLE: NAMES=rid cluster z c1 adl x1-x5 y1-y5;','USEVARIABLES=z c1 adl x1-x5 y1-y5;',
 if(type!='CONDITIONAL_COMPLETE')'CATEGORICAL=adl;','CLUSTER=cluster; IDVARIABLE=rid; MISSING=ALL(-9999);',
 'ANALYSIS: TYPE=COMPLEX RANDOM; ESTIMATOR=MLR; PROCESSORS=1;',
 'ALGORITHM=INTEGRATION; INTEGRATION=30;','ITERATIONS=2000; MITERATIONS=2000;',
 'LOGCRITERION=.000001; RLOGCRITERION=.000000001; MCONVERGENCE=.000001;',
 'MODEL:',model,if(type!='CONDITIONAL_COMPLETE')'adl ON z c1;',
 'OUTPUT: TECH1 TECH3 TECH4 TECH8 SVALUES CINTERVAL;',
 'SAVEDATA: RESULTS=estimates.dat; TECH3=tech3.dat;')
 stopifnot(all(nchar(lines)<=90));writeLines(lines,file.path(d,'model.inp'))
 j<-list(id=id,root=ROOT,dest=d,category='SYNTHETIC',cap_seconds=180,rscript=file.path(R.home('bin'),'Rscript.exe'),mplus='<LOCAL_USER_HOME>/Downloads/Mplus/mplus9/ducument/Mplus.exe',hashes=list(model.inp=digest(file=file.path(d,'model.inp'),algo='sha256'),data.dat=digest(file=file.path(d,'data.dat'),algo='sha256')))
 write_json(j,file.path(d,'job.json'),pretty=TRUE,auto_unbox=TRUE,digits=16);jobs[[type]]<-j
}
write_json(jobs,file.path(ROOT,'contracts/SYNTHETIC_JOBS.json'),pretty=TRUE,auto_unbox=TRUE,digits=16)
cat('JOINT_ML_PROBE_PREPARED\n')
