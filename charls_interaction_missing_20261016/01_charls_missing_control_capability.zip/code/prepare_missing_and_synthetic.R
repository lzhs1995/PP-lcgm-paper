# 为缺失处理准备只读来源审计和合成接口；不改旧MI，不填补结构性差异。
library(jsonlite);library(digest);library(haven)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_interaction_missing_20261016'
OLD<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_observed_moderation_20261016'
ROSTER<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_roster_moderation_20261015'
CORE<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015'
wj<-function(x,p)write_json(x,file.path(ROOT,p),pretty=TRUE,auto_unbox=TRUE,digits=16,na='null',null='null')
csv<-function(x,p)write.csv(x,file.path(ROOT,p),row.names=FALSE,na='')
src<-c(roster=file.path(ROSTER,'private/CONSTRUCTED_BASELINE_CONTRASTS.rds'),core=file.path(CORE,'private/charls_core_mi_inputs.rds'))
hash<-vapply(src,function(p)digest(file=p,algo='sha256'),'');r<-readRDS(src['roster']);c<-readRDS(src['core'])
entries<-fromJSON(file.path(OLD,'contracts/DATA_ENTRIES.json'),simplifyVector=FALSE)
vars<-c('age','female','edu','urban','partner','nchild','adl','health2','health3','health4','health5')
base<-data.frame(cluster=c$data$cluster,c$raw[c(paste0('x',1:5),paste0('y',1:5))],c$data[vars]);names(base)[12:22]<-paste0('c',1:11)
scopes<-list();info<-list()
for(z in names(entries)){
 idx<-r$all_listed[[paste0(z,'_status')]]=='DEFINED' & r$legacy_keys_compatible
 a<-base[idx,];a$z0<-(r$all_listed[[paste0(z,'_absolute')]][idx]-entries[[z]]$z_mean)/entries[[z]]$z_sd
 stopifnot(all(complete.cases(a[setdiff(names(a),c('c7',paste0('x',1:5),paste0('y',1:5)))])))
 out<-file.path(ROOT,'private',paste0('CHARLS_',toupper(z),'_MISSING_CONTROL.dat'))
 write.table(a,out,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
 old<-read.table(entries[[z]]$data_file);cc_idx<-r$core_complete_case[idx]
 stopifnot(isTRUE(all.equal(unname(as.matrix(a[cc_idx,])),unname(as.matrix(replace(old,old==-9999,NA))),tolerance=1e-10)))
 info[[z]]<-list(N=nrow(a),missing_ADL=sum(is.na(a$c7)),documented_sex_recovery=sum(is.na(c$raw$female[idx])),original_complete_case=sum(cc_idx),columns=names(a),data_file=out,data_sha256=digest(file=out,algo='sha256'),z_scaling='previous complete-case scale retained for direct comparison',complete_case_identity=TRUE)
 scopes[[z]]<-data.frame(indicator=z,N=nrow(a),missing_ADL=sum(is.na(a$c7)),sex_source_recovered=sum(is.na(c$raw$female[idx])),original_complete_case=sum(cc_idx))
}
csv(do.call(rbind,scopes),'results/MISSING_CONTROL_SCOPE.csv');wj(info,'contracts/MISSING_CONTROL_ENTRIES.json')
csv(data.frame(source=names(src),path=unname(src),sha256=hash),'audit/SOURCE_HASHES.csv')

# 独立合成样本，已知类别控制在真实生成式中按0--6观测值起作用。
set.seed(26101617);n<-400L;g<-rep(1:40,each=10);z<-rnorm(n);c1<-rnorm(n);u<-rnorm(40,sd=.4)
adl<-as.numeric(cut(.3*z+.2*c1+u[g]+rnorm(n),breaks=c(-Inf,-1.5,-1,-.5,0,.5,1,Inf),labels=FALSE))-1
ix<-.2*c1+.1*adl+rnorm(n,sd=.7);sx<-.03*c1+.02*adl+rnorm(n,sd=.18)
iy<--.3*ix+.2*adl+.1*c1+rnorm(n,sd=.6)
sy<--.15*sx+.04*adl+.2*sx*z+rnorm(n,sd=.16)
t<-c(0,2,4,7,9);x<-outer(ix,rep(1,5))+outer(sx,t)+matrix(rnorm(n*5,sd=.5),n)
y<-outer(iy,rep(1,5))+outer(sy,t)+matrix(rnorm(n*5,sd=.6),n)
full<-data.frame(rid=1:n,cluster=g,z=z,c1=c1,adl=adl,x,y);names(full)[6:15]<-c(paste0('x',1:5),paste0('y',1:5))
mask<-sample(1:n,40);dat<-full;dat$adl[mask]<-NA
for(v in c(paste0('x',2:5),paste0('y',2:5)))dat[sample(1:n,30),v]<-NA
saveRDS(list(full=full,observed=dat,missing_adl=mask),file.path(ROOT,'private/synthetic_truth.rds'))
jobs<-list()
for(type in c('SINGLE','TWOLEVEL')){
 id<-paste0('SYNTHETIC_',type,'_ORDINAL_CONTROL');d<-file.path(ROOT,'models',id);dir.create(d,showWarnings=FALSE)
 write.table(dat,file.path(d,'data.dat'),row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
 model<-c('ix sx | x1@0 x2@2 x3@4 x4@7 x5@9;','iy sy | y1@0 y2@2 y3@4 y4@7 y5@9;',
  'ix sx iy sy ON z c1 adl;','iy ON ix;','sy ON ix sx iy;','ix WITH sx;','sx WITH iy;',
  paste0('x',1:5,' WITH y',1:5,';'),'sxz | sx XWITH z;','sy ON sxz (dc);','adl ON z c1;')
 if(type=='TWOLEVEL')model<-c('%WITHIN%',model,'%BETWEEN%','adl;')
 lines<-c(paste0('TITLE: ',id,' function test only;'),'DATA: FILE=data.dat;',
  'VARIABLE: NAMES=rid cluster z c1 adl x1-x5 y1-y5;','USEVARIABLES=z c1 adl x1-x5 y1-y5;','CATEGORICAL=adl;','IDVARIABLE=rid; MISSING=ALL(-9999);',
  if(type=='TWOLEVEL')c('CLUSTER=cluster;','WITHIN=z c1 x1-x5 y1-y5;'),
  'DATA IMPUTATION: IMPUTE=adl(c); NDATASETS=3; SAVE=imp*.dat; THIN=10;',
  paste0('ANALYSIS: TYPE=',if(type=='TWOLEVEL')'TWOLEVEL RANDOM'else'RANDOM',';'),
  'ESTIMATOR=BAYES; PROCESSORS=1; CHAINS=2;','PREDICTOR=OBSERVED; ALGORITHM=GIBBS(RW);',
  'BITERATIONS=200(100); BSEED=26101617;','MODEL:',model,'OUTPUT: TECH1 TECH8;')
 stopifnot(all(nchar(lines)<=90));writeLines(lines,file.path(d,'model.inp'))
 j<-list(id=id,root=ROOT,dest=d,category='SYNTHETIC',cap_seconds=180,rscript=file.path(R.home('bin'),'Rscript.exe'),mplus='<LOCAL_USER_HOME>/Downloads/Mplus/mplus9/ducument/Mplus.exe',hashes=list(model.inp=digest(file=file.path(d,'model.inp'),algo='sha256'),data.dat=digest(file=file.path(d,'data.dat'),algo='sha256')))
 write_json(j,file.path(d,'job.json'),pretty=TRUE,auto_unbox=TRUE,digits=16);jobs[[type]]<-j
}
wj(jobs,'contracts/SYNTHETIC_JOBS.json');stopifnot(identical(hash,vapply(src,function(p)digest(file=p,algo='sha256'),'')))
cat('PREPARED: private missing-control entries and two synthetic jobs; no Mplus called\n')
