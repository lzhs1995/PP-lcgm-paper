# 不重新估计；直接读取保存参数，核对观测ADL数值预测的路径恒等性。
library(jsonlite)
source('<LOCAL_USER_HOME>/pp_lgcm_review/charls_observed_moderation_20261016/code/r2e_upstream_math.R',local=TRUE)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_interaction_missing_20261016/joint_ml_probe'
read<-function(id){
 d<-file.path(ROOT,'models',id);m<-read_mplus_raw(d)
 write.csv(m$par,file.path(d,'parameters_high_precision.csv'),row.names=FALSE)
 write.csv(m$spec,file.path(d,'tech1_parameter_map.csv'),row.names=FALSE)
 write.table(m$V,file.path(d,'parameter_covariance.csv'),sep=',',row.names=FALSE,col.names=FALSE)
 write_json(list(flags=out_flags(m$lines),se_tech3_max_diff=m$se_tech3_max_diff),file.path(d,'readback.json'),pretty=TRUE,auto_unbox=TRUE)
 p<-m$par;p$key<-paste(p$row,p$column,sep=':');p
}
a<-read('SYNTHETIC_CONDITIONAL_COMPLETE');b<-read('SYNTHETIC_JOINT_COMPLETE')
# GAMMA与BETA的分区可能改变；有方向的结构回归按行/列语义对应。
a<-subset(a,matrix %in% c('gamma','beta'));b<-subset(b,matrix %in% c('gamma','beta'))
j<-match(a$key,b$key);stopifnot(!anyNA(j),!anyDuplicated(a$key),!anyDuplicated(b$key));b<-b[j,]
tab<-data.frame(key=a$key,conditional_est=a$estimate,joint_est=b$estimate,conditional_se=a$se,joint_se=b$se)
tab$diff_over_se<-abs(tab$conditional_est-tab$joint_est)/tab$conditional_se
tab$se_relative<-abs(tab$conditional_se-tab$joint_se)/tab$conditional_se
write.csv(tab,file.path(ROOT,'results/COMPLETE_DATA_PATH_EQUIVALENCE.csv'),row.names=FALSE)
write_json(list(max_estimate_difference_in_SE=max(tab$diff_over_se),max_SE_relative_difference=max(tab$se_relative),note='Descriptive numerical comparison, not a post hoc gate or global-optimum proof'),file.path(ROOT,'results/COMPLETE_DATA_PATH_EQUIVALENCE.json'),pretty=TRUE,auto_unbox=TRUE,digits=16)
print(tab[tab$key %in% c('SY:SXZ','SY:SX','IY:IX','SY:ADL'),]);cat('max coefficient difference in SE=',max(tab$diff_over_se),'\n')
