"""仅核验本批已完成家族和真实输出；不将工作MI误称为完整H4。"""
from pathlib import Path
import json,sys,io,contextlib,datetime,psutil
R=Path(__file__).resolve().parents[1];read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sys.path.insert(0,'<LOCAL_USER>/.codex/skills/clauder-rstudio-workbench')
from clauder_workbench.cli import main
v=read(R/'audit/INDEPENDENT_H41_VERIFICATION.json');mi=read(R/'audit/INDEPENDENT_MI.json');pool=read(R/'results/POOLING_RECEIPT.json')
assert v['status']==mi['status']=='PASS' and v['registered_families']==8 and pool['registered']==8
assert not (R/'runtime/engine.lock').exists()
for name in ('models','postprocess'):assert read(R/'audit'/('GUARD_'+name+'_complete.json'))['decision']=='PASS'
o=read(R/'runtime/models_coordinator.json')['owner']
try:assert abs(psutil.Process(o['pid']).create_time()-o['created'])>.01
except psutil.NoSuchProcess:pass
assert read(R/'runtime/awake_MODELS/completion.json')['released']
rec=dict(status='CORRECTED_BASELINE_EDUCATION_URBAN_ADJUDICATED',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pooling=pool,independent=v,MI=mi,original_four_complete=False,full_H4_complete=False,owned_model_process_active=False)
(R/'audit/ACCEPTED_BATCH.json').write_text(json.dumps(rec,indent=2),encoding='utf-8')
b=io.StringIO()
with contextlib.redirect_stdout(b):rc=main(['completion-check','--mode','formal','--require-file','terminal::'+str(R/'audit/ACCEPTED_BATCH.json')+',max_age_h=24','--require-file','validation::'+str(R/'audit/INDEPENDENT_H41_VERIFICATION.json')+',max_age_h=24'])
(R/'audit/COMPLETION_CHECK.json').write_text(b.getvalue(),encoding='utf-8');j=json.loads(b.getvalue());assert rc==0 and j['decision']=='PASS'
print(json.dumps(dict(status='PASS',calls=v['calls'],engine_seconds=v['engine_seconds'],complete_families=pool['pooled'],full_H4_complete=False)),flush=True)
