"""独立读取原始TECH1/参数/TECH3并重算Rubin、D1和组差。无微观拟合。"""
import os
for _key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[_key]='1'
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
from scipy.stats import t as student_t,f as f_dist
from raw_parameter_reader import raw_model
R=Path(__file__).resolve().parents[1];read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
labs=['bii','bis','bss','bsyiy','gi0','gs0','gizg','gszg']
def main():
 calls=read(R/'results/CALL_RESULTS.json');families=read(R/'results/FAMILY_STATUS.json');parsed={};models={};pooled={}
 for name,c in calls.items():
  d=R/'models'/name
  if not (d/'engine_receipt.json').exists():
   assert c['status']=='NOT_RUN_RESOURCE_OR_BUDGET';models[name]={'status':c['status'],'estimated':False};continue
  if (d/'model.out').exists():assert hashlib.sha256((d/'model.out').read_bytes()).hexdigest()==c['output_sha256']
  else:assert c['status']!='USABLE_SINGLE_DATASET'
  if c['status']!='USABLE_SINGLE_DATASET':models[name]={'status':c['status']};continue
  out,mapping,q,se,v,key,ll=raw_model(d)
  assert 'THE MODEL ESTIMATION TERMINATED NORMALLY' in out and 'FIXED TO AVOID SINGULARITY' not in out
  assert not any(q[k-1]<0 for mat,a,b,k in mapping if mat in ('PSI','THETA') and a==b and k>0)
  assert np.linalg.eigvalsh(v/np.outer(np.sqrt(v.diagonal()),np.sqrt(v.diagonal()))).min()>0
  labels=labs[:6] if c.get('parent',False) else labs
  key=key.set_index('label').loc[labels];ix=key.parameter.to_numpy(dtype=int)-1
  parsed[name]=(q[ix],v[np.ix_(ix,ix)],se[ix],ll)
  models[name]={'status':'PASS','free_parameters':len(q),'key_paths':len(ix)}
 for fam,f in families.items():
  z,g=fam.split('_');a=parsed.get(f'CHARLS_{z}_H41_{g}_MI01_A');b=parsed.get(f'CHARLS_{z}_H41_{g}_MI01_B')
  if a is not None and b is not None:
   ok=abs(a[3]-b[3])<=.01 and np.all(abs(a[0]-b[0])<=np.maximum(.001,.05*b[2])) and np.all(abs(a[2]-b[2])/b[2]<=.05)
   assert bool(ok)==read(R/'results'/f'{fam}_START_COMPARISON.json')['passed']
  if f['status']!='TWENTY_USABLE_PENDING_POOLING':continue
  d=R/'results'/fam;xs=[parsed[f'CHARLS_{z}_H41_{g}_MI{k:02d}_A'] for k in range(1,21)]
  Q=np.array([x[0] for x in xs]);U=np.array([x[1] for x in xs]);m=len(Q);W=U.mean(0);B=np.cov(Q,rowvar=False,ddof=1);T=W+(1+1/m)*B;e=Q.mean(0)
  def scalar(a,dfcom=np.inf):
   est=float(a@e);se=float(np.sqrt(a@T@a));r=(1+1/m)*(a@B@a)/(a@W@a);lam=(1+1/m)*(a@B@a)/(a@T@a)
   df=(m-1)*(1+1/r)**2 if r>0 else np.inf
   if np.isfinite(dfcom):df=1/(1/df+1/((dfcom+1)/(dfcom+3)*dfcom*(1-lam)))
   return [est,se,df,est-student_t.ppf(.975,df)*se,est+student_t.ppf(.975,df)*se,2*student_t.sf(abs(est/se),df),lam,np.sqrt(a@B@a/m)/se]
  fields=['estimate','se','df','lower','upper','p','lambda','MCSE_over_SE']
  ref=pd.read_csv(d/'POOLED_PATHS.csv').set_index('label').loc[labs];calc=np.array([scalar(a) for a in np.eye(8)])
  assert np.allclose(calc,ref[fields],rtol=1e-8,atol=1e-10)
  dfcom=read(d/'RECEIPT.json')['communities']-1
  finite=pd.read_csv(d/'CLUSTER_DF_SENSITIVITY.csv').set_index('label').loc[labs]
  assert np.allclose([scalar(a,dfcom) for a in np.eye(8)],finite[fields],rtol=1e-8,atol=1e-10)
  ix=[6,7];w=W[np.ix_(ix,ix)];b=B[np.ix_(ix,ix)];q=e[ix];k=2;r=(1+1/m)*np.trace(b@np.linalg.inv(w))/k
  F=q@np.linalg.solve((1+r)*w,q)/k;nu=4+(k*(m-1)-4)*(1+(1-2/(k*(m-1)))/r)**2;p=f_dist.sf(F,k,nu)
  j=pd.read_csv(d/'JOINT_D1.csv').iloc[0];assert np.allclose([F,nu,p,r],[j.F,j.df2,j.p,j.RIV],rtol=2e-6,atol=1e-8)
  cs={'IY_Z_G0':{'gi0':1},'IY_Z_G1':{'gi0':1,'gizg':1},'IY_group_difference':{'gizg':1},'SY_Z_G0':{'gs0':1},'SY_Z_G1':{'gs0':1,'gszg':1},'SY_group_difference':{'gszg':1}}
  cr=pd.read_csv(d/'GROUP_CONTRASTS.csv').set_index('contrast')
  for n,co in cs.items():assert np.allclose(scalar(np.array([co.get(l,0) for l in labs])),cr.loc[n,fields].to_numpy(dtype=float),rtol=1e-8,atol=1e-10)
  pooled[fam]={'status':'PASS','members':m,'joint_p':float(p),'max_MCSE_over_SE':float(calc[:,-1].max()),'contrasts':6}
 if pooled:
  joint=pd.read_csv(R/'results/JOINT_D1.csv').set_index('family');names=list(pooled);pvals=np.array([pooled[n]['joint_p'] for n in names]);order=np.argsort(pvals);adjusted=np.empty(len(pvals));adjusted[order]=np.minimum(1,np.maximum.accumulate(pvals[order]*(12-np.arange(len(pvals)))))
  assert np.allclose(joint.loc[names,'holm_p_planned12'],adjusted,rtol=1e-7,atol=1e-10)
  assert np.allclose(joint.loc[names,'bonferroni_p_planned12'],np.minimum(1,12*pvals),rtol=1e-7,atol=1e-10)
 contract=read(R/'contracts/RUN_CONTRACT.json');engine=[read(R/'models'/n/'engine_receipt.json') for n in calls if (R/'models'/n/'engine_receipt.json').exists()]
 assert len(engine)<=contract['max_mplus_calls'] and sum(e['seconds'] for e in engine)<=contract['total_engine_seconds']+5
 out={'status':'PASS','models':models,'pooled_families':pooled,'registered_families':len(families),'calls':len(engine),'engine_seconds':sum(e['seconds'] for e in engine),'planned_multiplicity':12,'full_H4_claim':False,'scope':'Raw saved parameter identity and arithmetic, not proof of MAR or FCS compatibility'}
 (R/'audit/INDEPENDENT_H41_VERIFICATION.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({'status':'PASS','models':len(models),'pooled_families':pooled}))
if __name__=='__main__':main()
