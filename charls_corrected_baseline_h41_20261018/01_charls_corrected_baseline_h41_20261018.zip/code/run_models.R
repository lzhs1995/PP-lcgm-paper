# 修正来源后的基期Z×资源H4.1；单槽、新父模型、完整20份才合并。
local({
 .libPaths(c('<LOCAL_USER>/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
 library(jsonlite);library(digest);library(processx);library(ps);library(MplusAutomation)
 ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_baseline_h41_20261018';Sys.setenv(R2E_ROOT=ROOT,OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1,MKL_NUM_THREADS=1)
 source(file.path(ROOT,'code/r2e_local.R'),local=TRUE)
 contract<-rj(file.path(ROOT,'contracts/RUN_CONTRACT.json'));admission<-rj(file.path(ROOT,'audit/MI_ADMISSIONS.json'))
 stopifnot(length(admission)==4L,rj(file.path(ROOT,'audit/INDEPENDENT_MI.json'))$status=='PASS')
 growth<-function(p)paste0('i',p,' s',p,' | ',p,'1@0 ',p,'2@2 ',p,'3@4 ',p,'4@7 ',p,'5@9;')
 base<-c(growth('x'),growth('y'),'iy ON ix (bii);','sy ON ix (bis);','sy ON sx (bss);','sy ON iy (bsyiy);','ix WITH sx;','sx WITH iy;',paste0('x',1:5,' WITH y',1:5,';'),'ix sx iy sy ON c1-c11;','ix sx ON z0;','iy ON z0 (gi0);','sy ON z0 (gs0);','x1 y1 ON z0;')
 spec_for<-function(parent=FALSE){
  m<-base;k<-rbind(KEY_XY,key_add(c('gi0','gs0'),c('IY','SY'),c('Z0','Z0')))
  if(!parent){m<-c(m,'ix sx ON zg;','iy ON zg (gizg);','sy ON zg (gszg);','x1 y1 ON zg;');k<-rbind(k,key_add(c('gizg','gszg'),c('IY','SY'),c('ZG','ZG')))}
  list(kind='linear',fac=FAC_XY,obs=OBS_XY,fixed_zero=character(),model=m,key=k)
 }
 slots<-function(si){
  a<-list();add<-function(op,lhs,rhs='',init=0){a[[length(a)+1L]]<<-data.frame(op=op,lhs=toupper(lhs),rhs=toupper(rhs),init=init)}
  for(f in FAC_XY)add('MEAN',f)
  for(o in OBS_XY)add('VAR',o,init=.5)
  for(f in FAC_XY)add('VAR',f,init=.1)
  for(k in stmt_pairs(si$model)){t<-strsplit(toupper(k),' ',fixed=TRUE)[[1]];add(t[2],t[1],t[3])}
  x<-do.call(rbind,a);x$key<-paste(x$op,x$lhs,x$rhs,sep=':');stopifnot(!anyDuplicated(x$key));x
 }
 # 仅缓存同一语法、同一起点源哈希与扰动的确定性编译结果；DAT与随机插补不缓存。
 compile_model<-make_model;compiled<-new.env(parent=emptyenv())
 cached_model<-function(si,source_dir,perturb){
  h<-digest(list(si,hashf(file.path(source_dir,'model.out')),perturb),algo='sha256')
  if(!exists(h,compiled,inherits=FALSE))assign(h,compile_model(si,source_dir,perturb),compiled)
  get(h,compiled,inherits=FALSE)
 }
 extract<-function(m,si){do.call(rbind,lapply(seq_len(nrow(si$key)),function(i){k<-si$key[i,];id<-pnum(m,'BETA',k$row,k$column);if(id==0)id<-pnum(m,'GAMMA',k$row,k$column);stopifnot(id>0);p<-m$par[m$par$parameter==id,];data.frame(k,parameter=id,estimate=p$estimate,se=p$se)}))}
 prepare<-function(z,g,k,start='A'){
  parent<-g=='PARENT';si<-spec_for(parent);tag<-if(k==0)'CC'else sprintf('MI%02d',k);id<-paste('CHARLS',toupper(z),'H41',g,tag,start,sep='_');d<-file.path(ROOT,'models',id);dir.create(d,recursive=TRUE,showWarnings=FALSE)
  if(file.exists(file.path(d,'job.json')))return(rj(file.path(d,'job.json')))
  e<-admission[[z]];dat<-file.path(ROOT,'mi',z,'private',if(k==0)'CC.dat'else sprintf('MI%02d.dat',k))
  nms<-unlist(e$columns);a<-read.table(dat,col.names=nms,na.strings='-9999');gcol<-if(g=='EDU')'c3'else'c4';covs<-c(paste0('c',1:11),'z0')
  if(!parent){a$zg<-a$z0*a[[gcol]];covs<-c(covs,'zg');stopifnot(all(a[[gcol]]%in%0:1))}
  X<-cbind(1,as.matrix(a[covs]));stopifnot(!anyNA(X),qr(X)$rank==ncol(X))
  source_dir<-if(parent)file.path('<LOCAL_USER>/pp_lgcm_review/charls_observed_moderation_20261016/models',paste0('CHARLS_',toupper(z),'_E0_A'))else file.path(ROOT,'models',paste0('CHARLS_',toupper(z),'_H41_PARENT_MI01_A'))
  if(!parent)stopifnot(rj(file.path(source_dir,'receipt.json'))$status=='USABLE_SINGLE_DATASET')
  mm<-cached_model(si,source_dir,start=='B');csv(mm$mapping,file.path(d,'start_mapping.csv'))
  lines<-c(paste0('TITLE: ',id,' corrected source baseline Z resource heterogeneity;'),'DATA: FILE=data.dat;','VARIABLE:',wrap90(paste('NAMES=',paste(nms,collapse=' '),';')),paste0('USEVARIABLES=x1-x5 y1-y5 c1-c11 z0',if(parent)''else' zg',';'),'MISSING=ALL(-9999);','CLUSTER=cluster;',if(!parent)paste0('DEFINE: zg=z0*',gcol,';'),'ANALYSIS: TYPE=COMPLEX; ESTIMATOR=MLR; PROCESSORS=1;','ITERATIONS=2000; COVERAGE=.005;','MODEL:',mm$lines,'OUTPUT: TECH1 TECH3 TECH4 TECH8 SVALUES CINTERVAL;','SAVEDATA: RESULTS=estimates.dat; TECH3=tech3.dat;')
  stopifnot(all(nchar(lines)<=90));writeLines(lines,file.path(d,'model.inp'));stopifnot(file.copy(dat,file.path(d,'data.dat')))
  j<-list(id=id,root=ROOT,dest=d,z=z,group=g,parent=parent,member=k,start=start,N=nrow(a),communities=length(unique(a$cluster)),expected_free=mm$expected_free,category='CHARLS_CORRECTED_H41',cap_seconds=contract$per_model_seconds,rscript=file.path(R.home('bin'),'Rscript.exe'),mplus=MPLUS,source_start=source_dir,source_start_output_sha256=hashf(file.path(source_dir,'model.out')),historical_parent_for_initialization_only=parent,source_data=dat,hashes=list(model.inp=hashf(file.path(d,'model.inp')),data.dat=hashf(file.path(d,'data.dat'))))
  wj(list(rank=qr(X)$rank,columns=ncol(X)),file.path(d,'design_check.json'));wj(j,file.path(d,'job.json'));j
 }
 review<-function(j){
  er<-rj(file.path(j$dest,'engine_receipt.json'));if(is.null(er))return(list(id=j$id,status='NOT_RUN_RESOURCE_OR_BUDGET',detail=rj(file.path(j$dest,'not_run.json'))))
  r<-list(id=j$id,z=j$z,group=j$group,parent=j$parent,member=j$member,start=j$start,N_expected=j$N,status=er$status,seconds=er$seconds,source_dir=j$dest)
  if(er$status=='EXITED')tryCatch({
   si<-spec_for(isTRUE(j$parent));n<-MplusAutomation::readModels(file.path(j$dest,'model.out'),what='summaries',quiet=TRUE);m<-read_mplus_raw(j$dest);v<-gate_r2e(m,si)
   r$status<-if(isTRUE(v$passed))'USABLE_SINGLE_DATASET'else'INADMISSIBLE';r$negative<-v$negative;r$N<-n$summaries$Observations;r$fit<-n$summaries;r$LL<-m$extra[['H0 Loglikelihood']];r$parameters<-m$P
   if(any(grepl('FIXED TO AVOID SINGULARITY',m$lines,fixed=TRUE)))r$status<-'AUTOFIX_REJECTED'
   if(r$N!=j$N)r$status<-'SAMPLE_MISMATCH'
   if(m$P!=j$expected_free)r$status<-'PARAMETER_CONTRACT_MISMATCH'
   wj(v,file.path(j$dest,'validation.json'));csv(m$par,file.path(j$dest,'parameters_high_precision.csv'));csv(m$spec,file.path(j$dest,'tech1_parameter_map.csv'));csv(m$values,file.path(j$dest,'matrix_values.csv'));csv(extract(m,si),file.path(j$dest,'key_paths.csv'));write.table(m$V,file.path(j$dest,'parameter_covariance.csv'),sep=',',row.names=FALSE,col.names=FALSE)
  },error=function(e){r$status<<-'READBACK_OR_ESTIMATION_FAILURE';r$error<<-conditionMessage(e)})
  r$output_sha256<-if(file.exists(file.path(j$dest,'model.out')))hashf(file.path(j$dest,'model.out'))else NULL
  wj(r,file.path(j$dest,'receipt.json'));r
 }
 run<-function(j){
  for(n in names(j$hashes))stopifnot(hashf(file.path(j$dest,n))==j$hashes[[n]])
  if(file.exists(file.path(j$dest,'receipt.json'))){r<-rj(file.path(j$dest,'receipt.json'));if(!is.null(r$output_sha256))stopifnot(hashf(file.path(j$dest,'model.out'))==r$output_sha256);return(r)}
  if(file.exists(file.path(j$dest,'engine_receipt.json')))return(review(j))
  progress('H41_model_start',j$id)
  p<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/model_engine.py'),file.path(j$dest,'job.json')),stdout=file.path(j$dest,'supervisor.log'),stderr='2>&1',cleanup=TRUE)
  last<-0;while(p$is_alive()){p$wait(1000L);if(as.numeric(Sys.time())-last>25){clauder_progress('H41_estimating',j$id);last<-as.numeric(Sys.time())}}
  r<-review(j);progress('H41_model_end',paste(j$id,r$status));r
 }
 main<-function(){
  stopfile<-file.path(ROOT,'runtime/MODELS_TERMINAL');ownerfile<-file.path(ROOT,'runtime/models_coordinator.json');t0<-Sys.time()
  stopifnot(!file.exists(stopfile),!file.exists(ownerfile));h<-ps_handle();ps_set_cpu_affinity(h,0:7)
  wj(list(owner=list(pid=Sys.getpid(),created=as.numeric(ps_create_time(h)))),ownerfile)
  aw<-file.path(ROOT,'runtime/awake_MODELS');a<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/windows_awake_guard.py'),'--owner-file',ownerfile,'--output',aw,'--interval','5'),stdout=file.path(ROOT,'runtime/awake_MODELS.log'),stderr='2>&1',cleanup=FALSE)
  on.exit({if(dir.exists(aw))writeLines('release',file.path(aw,'stop.request'));a$wait(8000L)},add=TRUE)
  calls<-list();families<-list()
  savecalls<-function(){wj(calls,file.path(ROOT,'results/CALL_RESULTS.json'));wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'))}
  for(z in unlist(contract$indicators)){
   stopifnot(admission[[z]]$status=='ADMITTED_WORKING_MI')
   pj<-prepare(z,'PARENT',1);pr<-run(pj);calls[[pj$id]]<-pr;savecalls()
   for(g in unlist(contract$groups)){
    fam<-paste(toupper(z),g,sep='_');state<-'RUNNING';members<-list();cc<-list(status='NOT_RUN')
    if(pr$status!='USABLE_SINGLE_DATASET'){families[[fam]]<-list(status='PARENT_NOT_ADMITTED',members=0,N=admission[[z]]$N,parent=pr$status,full_H4=FALSE);savecalls();next}
    if(as.numeric(difftime(Sys.time(),t0,units='secs'))>contract$wall_seconds-120){families[[fam]]<-list(status='WALL_LIMIT_NOT_RUN',members=0,N=admission[[z]]$N);savecalls();next}
    j<-prepare(z,g,0);cc<-run(j);calls[[j$id]]<-cc;savecalls()
    for(k in 1:20){
     if(as.numeric(difftime(Sys.time(),t0,units='secs'))>contract$wall_seconds-120){state<-'WALL_LIMIT';break}
     j<-prepare(z,g,k);r<-run(j);calls[[j$id]]<-r;members[[as.character(k)]]<-r
     families[[fam]]<-list(status='RUNNING',members=length(members),CC=cc$status,N=admission[[z]]$N,full_H4=FALSE);savecalls()
     if(r$status!='USABLE_SINGLE_DATASET'){state<-'INCOMPLETE_STOPPED';break}
     if(k==1){
      jb<-prepare(z,g,k,'B');rb<-run(jb);calls[[jb$id]]<-rb;savecalls()
      co<-if(rb$status=='USABLE_SINGLE_DATASET')compare_numeric(list(key=read.csv(file.path(j$dest,'key_paths.csv')),receipt=r),list(key=read.csv(file.path(jb$dest,'key_paths.csv')),receipt=rb),'start',list(start_LL=.01,start_path_abs=.001,start_path_se=.05,integration_path_se=.05,se_rel=.05))else list(passed=FALSE,reason=rb$status)
      wj(co,file.path(ROOT,'results',paste0(fam,'_START_COMPARISON.json')))
      if(!isTRUE(co$passed)){state<-'START_CHECK_FAILED';break}
     }
    }
    if(length(members)==20L&&all(vapply(members,function(x)x$status=='USABLE_SINGLE_DATASET',TRUE)))state<-'TWENTY_USABLE_PENDING_POOLING'
    families[[fam]]<-list(status=state,members=length(members),CC=cc$status,N=admission[[z]]$N,full_H4=FALSE);savecalls()
   }
  }
  writeLines('All eight registered families adjudicated; read FAMILY_STATUS',stopfile)
  progress('CORRECTED_BASELINE_H41_MODELS_TERMINAL','Eight education/urban families adjudicated; income separate; no full-H4 claim')
 }
 if(!identical(Sys.getenv('H41_READ_ONLY'),'1'))main()
})
