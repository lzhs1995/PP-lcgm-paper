# 从冻结入口和MIDS独立重建导出值，四个范围、80个实际DAT全部核对。
local({
 R <- '<LOCAL_USER>/pp_lgcm_review/charls_corrected_baseline_h41_20261018'
 .libPaths(c('<LOCAL_USER>/pp_lgcm_review/charls_income_mi_pilot_20261016/library',.libPaths()))
 library(mice);library(jsonlite);library(digest)
 entries <- fromJSON(file.path(R,'contracts/SOURCE_ENTRIES.json'),simplifyVector=FALSE)
 checks <- list(); scopes <- list()
 sources <- fromJSON(file.path(R,'audit/SOURCE_HASHES.json'),simplifyVector=FALSE)
 for(p in names(sources))stopifnot(digest(file=p,algo='sha256')==sources[[p]])
 for(z in names(entries)){
  e <- entries[[z]]; stopifnot(digest(file=e$file,algo='sha256')==e$sha256)
  src <- readRDS(e$file); root <- file.path(R,'mi',z)
  imp <- readRDS(file.path(root,'private/MIDS.rds'));ad <- fromJSON(file.path(root,'audit/MI_ADMISSION.json'))
  stopifnot(ad$status=='ADMITTED_WORKING_MI',imp$m==20L,imp$iteration==1L,ad$fresh_draws==20L)
  obs <- !is.na(src$data$adl)
  for(n in names(src$data))stopifnot(identical(imp$data[[n]],src$data[[n]]))
  for(k in 1:20){
   v <- complete(imp,k); stopifnot(!anyNA(v),identical(v$adl[obs],src$data$adl[obs]),all(v$adl[!obs]%in%src$data$adl[obs]))
   for(n in setdiff(names(v),'adl'))stopifnot(identical(v[[n]],imp$data[[n]]))
   for(g in c('edu','urban')){
    stopifnot(isTRUE(all.equal(v[[paste0('zg_',g)]],v$z0*v[[g]],tolerance=1e-12)))
    for(n in grep('^(obs_|missing_)',names(src$data),value=TRUE))stopifnot(isTRUE(all.equal(v[[paste0(g,'_',n)]],v[[g]]*v[[n]],tolerance=1e-12)))
   }
   expected <- src$analysis;expected$c7 <- v$adl;p <- file.path(root,'private',sprintf('MI%02d.dat',k))
   got <- as.matrix(read.table(p,na.strings='-9999'));want <- as.matrix(expected)
   stopifnot(identical(dim(got),dim(want)),identical(unname(is.na(got)),unname(is.na(want))))
   delta <- max(abs(got-want),na.rm=TRUE);stopifnot(delta<1e-10)
   checks[[length(checks)+1L]] <- data.frame(scope=z,member=k,N=nrow(got),communities=length(unique(got[,1])),maximum_export_difference=delta,observed_and_XY_masks_preserved=TRUE,source_sha256=e$sha256,sha256=digest(file=p,algo='sha256'))
  }
  cc <- as.matrix(read.table(file.path(root,'private/CC.dat'),na.strings='-9999'));want <- as.matrix(src$analysis[src$original_complete_case,])
  stopifnot(identical(dim(cc),dim(want)),identical(unname(is.na(cc)),unname(is.na(want))),max(abs(cc-want),na.rm=TRUE)<1e-10)
  stopifnot(setequal(unname(unlist(src$source_hashes)),unname(unlist(sources))))
  scopes[[z]] <- list(status='PASS',N=nrow(want),MI_N=nrow(src$analysis),missing_ADL=sum(!obs),m=20,source_sha256=e$sha256)
  if(exists('clauder_progress',mode='function'))clauder_progress('baseline_MI_verify',paste(z,'20 members verified'))
 }
 tab <- do.call(rbind,checks);stopifnot(nrow(tab)==80L)
 write.csv(tab,file.path(R,'audit/INDEPENDENT_MI_MEMBERS.csv'),row.names=FALSE)
 write_json(list(status='PASS',scopes=scopes,member_files=80,maximum_export_difference=max(tab$maximum_export_difference),income_FCS_included=FALSE,old_completed_MI_reused=FALSE,not_proof_of_MAR_or_exact_latent_compatibility=TRUE),file.path(R,'audit/INDEPENDENT_MI.json'),auto_unbox=TRUE,pretty=TRUE,digits=16)
 cat('BASELINE_Z_ADL_MI_INDEPENDENT_PASS\n')
})
