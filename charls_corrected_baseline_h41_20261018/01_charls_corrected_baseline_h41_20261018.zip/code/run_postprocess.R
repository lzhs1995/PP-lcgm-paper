# 仅在本批8个家族均已裁定后合并；不足20份或失败的家族保持未完成。
local({
 R<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_baseline_h41_20261018'
 Sys.setenv(OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1,MKL_NUM_THREADS=1)
 stopifnot(file.exists(file.path(R,'runtime/MODELS_TERMINAL')))
 f<-jsonlite::fromJSON(file.path(R,'results/FAMILY_STATUS.json'),simplifyVector=FALSE)
 stopifnot(length(f)==8L,all(vapply(f,function(x)x$status!='RUNNING',TRUE)))
 clauder_progress('baseline_H41_pool','Pool complete20 families with full covariance; retain stopped families')
 source(file.path(R,'code/pool_h41.R'),local=TRUE)
 clauder_progress('baseline_H41_verify','Independent saved parameters, TECH3, group contrasts, D1 and planned12 multiplicity')
 out<-file.path(R,'audit/INDEPENDENT_H41_REPLAY.log');err<-file.path(R,'audit/INDEPENDENT_H41_REPLAY.stderr')
 p<-processx::process$new('<LOCAL_USER>/AppData/Local/Programs/Python/Python314/python.exe',c('-u','-X','utf8',file.path(R,'code/verify_h41_results.py')),stdout=out,stderr=err,cleanup=TRUE)
 started<-Sys.time();last<-Sys.time()
 while(p$is_alive()){
  p$wait(1000L)
  if(as.numeric(difftime(Sys.time(),last,units='secs'))>30){clauder_progress('baseline_H41_verify','Verifier active; reading saved files only, no new models');last<-Sys.time()}
  if(as.numeric(difftime(Sys.time(),started,units='secs'))>1200){p$kill_tree();stop('Independent verifier runtime limit; preserve model outputs and logs')}
 }
 stopifnot(p$get_exit_status()==0,jsonlite::fromJSON(file.path(R,'audit/INDEPENDENT_H41_VERIFICATION.json'))$status=='PASS')
 clauder_progress('CORRECTED_BASELINE_H41_POSTPROCESS_DONE','Eight registered education/urban families adjudicated and available complete families verified; income separate')
 cat('CORRECTED_BASELINE_H41_POSTPROCESS_DONE\n')
})
