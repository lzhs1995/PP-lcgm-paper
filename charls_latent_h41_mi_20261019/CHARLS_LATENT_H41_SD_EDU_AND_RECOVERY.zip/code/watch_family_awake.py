"""单家族只读监控；清醒预算与墙钟均保留，睡眠不耗尽监控租期。"""
from pathlib import Path
import ctypes,datetime,json,time,psutil,sys
from active_clock import BudgetClock
sys.path.insert(0,'C:/Users/LZHS/Desktop/cnm/tasks/01_R_analysis/work/ch4_archived_replay_20261016')
from windows_process_terminal import process_state
R=Path(__file__).resolve().parents[1]
family,tag=sys.argv[1:3]
assert family in ('sd_EDU','sd_URBAN','gender_EDU','gender_URBAN')
assert tag.replace('_','').isalnum()
class Mem(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(k,ctypes.c_ulonglong) for k in ['total','avail','commit_limit','commit_avail','virt','virt_avail','extended']]
clock=BudgetClock();worker=None;seen=False;reason=None
(R/'audit'/f'{tag}_MONITOR_OWNER.json').write_text(json.dumps(dict(pid=psutil.Process().pid,created_exact=format(psutil.Process().create_time(),'.17g'),script=__file__,family=family,tag=tag),indent=2))
with (R/'audit'/f'{tag}_RESOURCE.jsonl').open('x') as out:
 while True:
  timing=clock.sample()
  if timing['active_seconds']>=5400 or timing['wall_seconds']>=86400:
   reason='MONITOR_LEASE_EXPIRED_NOT_MODEL_FAILURE';break
  m=Mem();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
  lock=R/'runtime'/f'{family}_RESERVED.json'
  if worker is None and lock.exists():worker=json.loads(lock.read_text())
  engines=[];state=None
  if worker:
   state=process_state(worker['pid'],float(worker.get('created_exact',worker['created'])))['state']
   if state=='active':
    seen=True
    try:
     for p in psutil.Process(worker['pid']).children(recursive=True):
      try:
       if p.name().lower()=='mplus.exe':
        v=p.memory_info();engines.append(dict(pid=p.pid,created=p.create_time(),rss=v.rss,private=v.private,peak_wset=v.peak_wset,peak_pagefile=v.peak_pagefile,cpu=sum(p.cpu_times()[:2])))
      except psutil.Error:pass
    except psutil.Error:pass
  progress=None;p=R/'runtime'/f'{family}_PROGRESS.json'
  if p.exists():
   try:progress=json.loads(p.read_text())
   except (ValueError,OSError):progress={'read_retry_needed':True}
  out.write(json.dumps(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),available=m.avail,commit_available=m.commit_avail,worker=worker,worker_state=state,engines=engines,progress=progress,timing=timing))+'\n');out.flush()
  if state in ('absent','exited','reused'):
   reason='OWNED_WORKER_TERMINAL_OR_IDENTITY_UNRESOLVED';break
  time.sleep(5)
(R/'audit'/f'{tag}_MONITOR_TERMINAL.json').write_text(json.dumps(dict(reason=reason,worker=worker,timing=clock.sample(),model_mutations=0),indent=2))
print('FAMILY_SENTINEL_TERMINAL',family,reason,flush=True)
