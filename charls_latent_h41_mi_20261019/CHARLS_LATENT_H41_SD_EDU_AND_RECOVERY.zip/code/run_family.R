# 一个原生ClaudeR后台任务执行一个完整MI家族；失败/资源暂停均保全退出。
# 调用方在局部环境提供FAMILY，例如 sd_EDU；不修改前台工作区。
local({
 ROOT<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_h41_mi_20261019'
 PY<-'C:/Users/LZHS/AppData/Local/Programs/Python/Python314/python.exe'
 stopifnot(exists('FAMILY',inherits=TRUE));fam<-get('FAMILY',inherits=TRUE)
 parts<-strsplit(fam,'_',fixed=TRUE)[[1]];stopifnot(length(parts)==2L);z<-parts[1];g<-parts[2]
 Sys.setenv(OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1,MKL_NUM_THREADS=1)
 .libPaths(c('C:/Users/LZHS/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
 library(jsonlite);library(MplusAutomation);library(processx);library(ps);library(digest)
 ps_set_cpu_affinity(ps_handle(),8:11)
 rj<-function(p)fromJSON(p,simplifyVector=FALSE);wj<-function(x,p)write_json(x,p,auto_unbox=TRUE,pretty=TRUE,digits=NA,null='null')
 progress<-function(stage,message){cat(format(Sys.time(),tz='UTC'),stage,message,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(stage,message);wj(list(stage=stage,message=message,at=format(Sys.time(),tz='UTC')),file.path(ROOT,'runtime',paste0(fam,'_PROGRESS.json')))}
 source(file.path(ROOT,'code/model_service_client.R'),local=TRUE)
 main<-function(){
  on.exit(helper_close(),add=TRUE)
  lock<-file.path(ROOT,'runtime',paste0(fam,'_RESERVED.json'));stopifnot(!file.exists(lock))
  created<-as.numeric(ps_create_time(ps_handle()))
  wj(list(pid=Sys.getpid(),created=created,created_exact=sprintf('%.17g',created),family=fam,package_version=as.character(getNamespaceVersion('MplusAutomation'))),lock)
  admission<-rj(file.path(ROOT,'mi',z,'audit/MI_ADMISSION.json'));stopifnot(admission$status=='ADMITTED_WORKING_MI',g%in%unlist(admission$eligible_groups))
  dest<-file.path(ROOT,'results',fam);dir.create(dest,showWarnings=FALSE);calls<-list()
  run<-function(k,st){
   id<-sprintf('CHARLS_%s_LATENT_H41_%s_MI%02d_%s',toupper(z),g,k,st);d<-file.path(ROOT,'models',id)
   if(file.exists(file.path(d,'receipt.json'))){
    old<-rj(file.path(d,'receipt.json'));jj<-rj(file.path(d,'job.json'))
    stopifnot(old$status=='USABLE',old$output_sha256==digest(file=file.path(d,'model.out'),algo='sha256'))
    for(n in names(jj$hashes))stopifnot(digest(file=file.path(d,n),algo='sha256')==jj$hashes[[n]])
    calls[[id]]<<-old;progress('LATENT_H41_MI_REUSED',id);return(old)
   }
   stopifnot(!file.exists(file.path(d,'engine_receipt.json')))
   if(!file.exists(file.path(d,'job.json')))helper_call('models.py',c('prepare',z,g,as.character(k),st),file.path(ROOT,'runtime',paste0(id,'_prepare.log')))
   j<-rj(file.path(d,'job.json'));for(n in names(j$hashes))stopifnot(digest(file=file.path(d,n),algo='sha256')==j$hashes[[n]])
   helper_close();helper_state$p<-NULL;gc(FALSE)
   cmd<-file.path(d,'launch.cmd');writeLines(c('@echo off',paste0('"',PY,'" -X utf8 "',ROOT,'/code/adapter.py" "%~dp0job.json" "%~1"'),'exit /b %ERRORLEVEL%'),cmd)
   progress('LATENT_H41_MI_ESTIMATING',id);warnings<-character();error<-NULL
   withCallingHandlers(tryCatch(MplusAutomation::runModels(file.path(d,'model.inp'),recursive=FALSE,showOutput=TRUE,replaceOutfile='never',Mplus_command=cmd,killOnFail=FALSE,logFile=file.path(d,'MplusAutomation.log')),error=function(e)error<<-conditionMessage(e)),warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')})
   wj(list(warnings=warnings,error=error),file.path(d,'R_WRAPPER_RETURN.json'));stopifnot(file.exists(file.path(d,'engine_receipt.json')))
   helper_call('models.py',c('normalize',d),file.path(ROOT,'runtime',paste0(id,'_normalize.log')))
   rec<-rj(file.path(d,'receipt.json'));calls[[id]]<<-rec;wj(calls,file.path(dest,'CALL_RESULTS.json'));progress('LATENT_H41_MI_MEMBER_TERMINAL',paste(id,rec$status));rec
  }
  state<-'RUNNING';a<-run(1L,'A')
  if(a$status!='USABLE'){state<-paste0('MI01_A_',a$status)}else{
   b<-run(1L,'B')
   if(b$status!='USABLE'){state<-paste0('MI01_B_',b$status)}else{
    cmp<-file.path(ROOT,'results',paste0(fam,'_MI01_START_COMPARISON.json'))
    if(!file.exists(cmp))helper_call('models.py',c('agree',a$dest,b$dest,cmp),file.path(ROOT,'runtime',paste0(fam,'_MI01_agree.log')))
    if(!isTRUE(rj(cmp)$passed)){state<-'MI01_START_CHECK_FAILED'}else{
     state<-'TWENTY_USABLE_PENDING_POOLING'
     for(k in 2:20){rec<-run(k,'A');if(rec$status!='USABLE'){state<-paste0('MI',sprintf('%02d',k),'_',rec$status);break}}
    }
   }
  }
  usable<-sum(vapply(calls,function(x)x$status=='USABLE'&&x$start=='A',TRUE))
  wj(list(status=state,family=fam,usable_members=usable,expected_members=20,actual_engine_calls=sum(vapply(calls,function(x)x$engine$actual_engine_calls,numeric(1))),N=admission$N,communities=admission$communities,complete_inference=FALSE,original_four_complete=FALSE,full_H4_complete=FALSE),file.path(dest,'FAMILY_STATUS.json'))
  progress('LATENT_H41_MI_FAMILY_TERMINAL',paste(fam,state,'usable',usable,'of20'));cat('LATENT_H41_MI_FAMILY_DONE\n')
 }
 main()
})
