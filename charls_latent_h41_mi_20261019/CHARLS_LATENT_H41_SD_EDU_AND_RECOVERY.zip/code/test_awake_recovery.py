"""真实Windows子进程正常/超时分支，加本次真实睡眠事件回放；不启动Mplus。"""
from pathlib import Path
from datetime import datetime,timezone
import json,sys,subprocess,hashlib
from bounded_child_awake import run_child
from active_clock import power_sleep_events
R=Path(__file__).resolve().parents[1];out=R/'audit/awake_recovery_tests';out.mkdir(exist_ok=False)
normal=run_child([sys.executable,'-c','print("NORMAL_CHILD")'],out/'normal',8)
timeout=run_child([sys.executable,'-c','import time;time.sleep(5)'],out/'timeout',.4)
assert normal['state']=='EXITED' and normal['exitcode']==0 and normal['active_seconds']<8
assert timeout['state']=='TIMEOUT' and timeout['process_exited'] and .35<timeout['active_seconds']<3
start=datetime(2026,10,19,15,15,27,tzinfo=timezone.utc);end=datetime(2026,10,19,15,49,19,tzinfo=timezone.utc)
events=power_sleep_events(start,end);overlap=sum(x['overlap_seconds'] for x in events)
assert overlap>1900 and (end-start).total_seconds()-overlap<60
result=dict(status='PASS',normal=normal,timeout=timeout,actual_sleep_gap=dict(start=start.isoformat(),end=end.isoformat(),wall_seconds=(end-start).total_seconds(),excluded_seconds=overlap,remaining_non_sleep_seconds=(end-start).total_seconds()-overlap,events=events),new_Mplus_calls=0)
(R/'audit/AWAKE_RECOVERY_TESTS.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
