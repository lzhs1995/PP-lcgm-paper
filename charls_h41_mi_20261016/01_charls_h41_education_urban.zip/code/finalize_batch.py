"""按实际终态编制CHARLS H4.1报告；不执行估计或改变失败状态。"""
from pathlib import Path
from datetime import datetime,timezone
import csv,hashlib,json,sqlite3
import pandas as pd
import psutil
R=Path(__file__).resolve().parents[1];read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
assert read(R/'audit/INDEPENDENT_H41_VERIFICATION.json')['status']=='PASS'
assert read(R/'audit/INDEPENDENT_MI_INPUTS.json')['status']=='PASS'
calls=read(R/'results/CALL_RESULTS.json');families=read(R/'results/FAMILY_STATUS.json');mi=read(R/'audit/MI_ADMISSIONS.json')
assert len(families)==8 and (R/'runtime/MODELS_TERMINAL').exists()
assert all(f['status']!='RUNNING' for f in families.values())
for name in ('MI_AWAKE.json','MODELS_AWAKE.json'):assert read(R/'runtime'/name)['status']=='RELEASED'
con=sqlite3.connect(f'file:{(R/"runtime/budget.sqlite").as_posix()}?mode=ro',uri=True);assert con.execute('PRAGMA integrity_check').fetchone()[0]=='ok';assert con.execute('SELECT count(*) FROM calls WHERE seconds IS NULL').fetchone()[0]==0;con.close()
owned=set();resource=[];inputs=[]
for name,r in calls.items():
 d=R/'models'/name;j=read(d/'job.json')
 if not (d/'engine_receipt.json').exists():
  assert r['status']=='NOT_RUN_RESOURCE_OR_BUDGET';continue
 e=read(d/'engine_receipt.json')
 for file,h in j['hashes'].items():assert sha(d/file)==h;inputs.append({'model':name,'file':file,'sha256':h,'status':'PASS'})
 assert sha(Path(j['source_data']))==j['hashes']['data.dat'];assert sha(d/'model.out')==r['output_sha256']==e['output_sha256']
 for line in (d/'resources.jsonl').read_text().splitlines():
  for p in json.loads(line)['processes']:
   if p['name'].lower()=='mplus.exe':owned.add((p['pid'],p['created']))
 resource.append({'model':name,'status':r['status'],'seconds':e['seconds'],'peak_tree_RSS_MiB':e['peak_tree_rss']/2**20,'sampled_tree_CPU_seconds':e['sampled_tree_cpu_seconds']})
for pid,born in owned:
 try:assert abs(psutil.Process(pid).create_time()-born)>.01,('Owned Mplus still alive',pid)
 except psutil.NoSuchProcess:pass
for x in csv.DictReader((R/'audit/SOURCE_HASHES.csv').open(encoding='utf-8-sig')):assert sha(Path(x['path']))==x['sha256']
assert not (R/'runtime/engine.lock').exists()
pd.DataFrame(inputs).to_csv(R/'audit/INPUT_INTEGRITY.csv',index=False);pd.DataFrame(resource).to_csv(R/'results/ENGINE_RESOURCES.csv',index=False)
contract=read(R/'contracts/RUN_CONTRACT.json');budget=read(R/'runtime/budget_status.json');assert len(calls)<=contract['max_calls']
model_wall_seconds=(R/'runtime/MODELS_TERMINAL').stat().st_mtime-read(R/'runtime/models_coordinator.json')['created']
assert model_wall_seconds>0
write(R/'audit/TERMINAL_CHECK.json',{'status':'PASS','utc':datetime.now(timezone.utc).isoformat(),'owned_engines_sampled':len(owned),'owned_engines_remaining':0,'awake_guards':'RELEASED','queue_integrity':'ok','source_hashes_unchanged':True,'input_hashes_checked':len(inputs),'engine_seconds':budget['engine_seconds'],'nominal_engine_cap':contract['total_engine_seconds'],'overshoot_seconds':max(0,budget['engine_seconds']-contract['total_engine_seconds'])})
pooled=read(R/'results/POOLING_RECEIPT.json');overview=pd.read_csv(R/'results/FAMILY_OVERVIEW.csv')
joint=pd.read_csv(R/'results/JOINT_D1.csv') if (R/'results/JOINT_D1.csv').exists() else pd.DataFrame()
receipt={'status':'CHARLS_H41_REGISTERED_FAMILIES_ADJUDICATED','registered_families':8,'complete_pooled_families':pooled['pooled'],'model_calls':len(resource),'attempts_including_not_run':len(calls),'engine_launcher_seconds':budget['engine_seconds'],'new_MI_scopes':4,'new_MI_members_per_scope':20,'MI_fresh_draw_calls':sum(x['fresh_draws'] for x in mi.values()),'deterministic_fit_cache_misses':sum(x['fit_cache_misses'] for x in mi.values()),'deterministic_fit_cache_hits':sum(x['fit_cache_hits'] for x in mi.values()),'original_CFPS_H41_complete_families':3,'original_CFPS_H41_registered_families':12,'original_four_moderations_complete':False,'full_H4_complete':False,'new_CFPS_calls':0,'closed_manuscript_changed':False,'new_NLM':0,'compatibility':contract['compatibility']}
receipt['coordinator_process_wall_seconds']=model_wall_seconds
receipt['timing_scope']='Engine/launcher sum excludes preparation/readback; coordinator wall includes them and process initialization, excludes earlier MI and later pooling'
write(R/'reports/BATCH_RECEIPT.json',receipt)
rows='\n'.join(f'| {t.family} | {t.N} | {t.members} | {t.status} |' for t in overview.itertuples())
jrows='\n'.join(f'| {t.family} | {t.F:.5f} | {t.p:.6g} | {t.bonferroni_p_8:.6g} |' for t in joint.itertuples()) if not joint.empty else '| 无完整家族 | — | — | — |'
paths=pd.read_csv(R/'results/POOLED_PATHS.csv') if (R/'results/POOLED_PATHS.csv').exists() else pd.DataFrame()
effect_rows=[]
for fam in joint.family if not joint.empty else []:
 p=paths.loc[paths.family==fam].set_index('label');cells=[]
 for lab in ('gizg','gszg'):
  t=p.loc[lab];cells.append(f'{t.estimate:.4f} [{t.lower:.4f}, {t.upper:.4f}]')
 effect_rows.append('| '+fam+' | '+' | '.join(cells)+' |')
effect_table='\n'.join(effect_rows) if effect_rows else '| 无完整家族 | — | — |'
raw_rejections=int((joint.p<.05).sum()) if not joint.empty else 0
adjusted_rejections=int((joint.bonferroni_p_8<.05).sum()) if not joint.empty else 0
mrows='\n'.join(f"| {z} | {v['N']} | {v['missing_ADL']} | {v['psrf']:.5f} | {v['warnings']} |" for z,v in mi.items())
report=f'''# CHARLS H4.1：基期家内差异关联的教育／城乡异质性

**四项调节完整推断、完整 H4 仍未完成。**

本批从此前已核实名册与合法父模型继续，执行新的CHARLS H4.1家族。它检验观测基期差异Z0与教育／城乡的乘积，不是SX×Z0动态调节，也不是H4.2三阶交互。CFPS仍为3/12个完整条件家族，其余九个原失败规格未重跑；本批CHARLS结果不冒充CFPS完成。

对照20260214原稿，假设4.1a/4.1b是社会经济资源较好者受家内关系差异影响较弱/较强的竞争假设，涉及学历、城乡和收入。原稿结果同时讨论初始水平和变化关联。本批仅覆盖其中“观测基期差异×教育/城乡”的条件路径，未覆盖收入、差异轨迹变化或原CFPS全部直接关联；故即使8/8完成，也只是这八个CHARLS工作模型家族完成。具体来源和口径见`ORIGINAL_H4_SCOPE.md`。

## 实际家族完成情况

| 家族 | N | 实际MI成员 | 状态 |
|---|---:|---:|---|
{rows}

已合并{pooled['pooled']}/8个教育／城乡家族；只有实际20/20成员全部合法、首成员第二起点通过者才合并。完整案例和第二起点不算MI成员。首个不可采用成员停止该家族，保留输出，其他家族独立执行。成员全部合法不等于原研究所有假设完成。

两条组差路径gizg、gszg直接联合D1检验如下；不能用“一组显著另一组不显著”代替组差。

| 家族 | D1 F | 原始P | 固定八项Bonferroni P |
|---|---:|---:|---:|
{jrows}

| 家族 | 潜截距路径组差gizg [95%区间] | 变化路径组差gszg [95%区间] |
|---|---:|---:|
{effect_table}

在实际完整的{pooled['pooled']}个家族中，原始联合D1有{raw_rejections}项P<.05，按预定八项Bonferroni校正后有{adjusted_rejections}项P<.05。这是本批工作模型下的检验结果；区间包含零不能证明资源组差不存在，亦不能据此判定原稿全部H4.1a/H4.1b。完整组内条件效应见GROUP_CONTRASTS.csv。

每条系数、六个组内/组差对比、有限MI自由度区间、社区数减一的自由度敏感性、完整案例对照和逐份拟合均随包。只有八项全部形成检验才给完整Holm；不平均P值或拟合指标。图为逐项95%条件MI区间，不是同时置信带或因果效应。

联合D1只回答两条条件路径是否存在资源组差，不直接判定“影响更强/更弱”。方向须结合两组的系数、编码方向和区间分别解释；尤其带符号的性别/排行差不能与非负SD混作同一种不和谐程度。不得仅依据交互正负或某组星号接受H4.1a/H4.1b。

## 插补与模型含义

四个分析范围来自此前子女名册审计，分别保留定义明确的SD、儿子−女儿、最年长子女−其他、长子−全部其他差异。结构性无定义、出生年并列和来源不一致不作为普通缺失填补。X为子女见面频率1—9编码均值，不能等同CFPS情感亲近度；Y为CESD10。使用原队列基期标准化和0、2、4、7、9时间载荷。

上述原队列标准化指X/Y轨迹。Z0另沿用各差异指标前批完整案例范围的均值和标准差，以便和完整案例比较；没有在每份MI或资源组内重新标准化。四个Z指标的参考范围各不相同，不能把不同家族的系数差异直接当作同一尺度上的优劣排序。

具体Z参照值保存在REUSED_Z_SCALING.json。按0、2、4、7、9的年份载荷，潜截距组差以基期Y标准差/该Z参照标准差计，变化路径组差以基期Y标准差/年/该Z参照标准差计。

每个范围重新生成20份ADL插补：社区随机截距PMM、5供体、20轮、独立范围种子，显式保留z0、z0×教育、z0×城乡。不是直接挪用旧加法MI。原观测、供体支持及X/Y原缺失模式独立回读通过；未来未观测X/Y仍由FIML处理。

轨迹辅助预测沿用已登记的核心方案：观测标准化X/Y进入插补模型，未观测位置用零占位并附显式缺失指示。零只用于辅助预测设计，未写回为观测结局；这也不等同对完整联合轨迹分布作了严格相容的联合插补。

| 范围 | N | ADL缺失 | 最终PSRF | 警告/消息数 |
|---|---:|---:|---:|---:|
{mrows}

这是包含目标交互信息的FCS工作近似，不能声称已证明与联合潜增长模型严格相容或MAR成立；尤其不能推广为SX×Z0潜交互MI。健康条目和官方ADL来源定义沿用：官方可用条目总分中有部分条目记录，非缺失控制不等于六项ADL都完整。合法跨期性别来源恢复沿用，完整案例仍按原基期缺失标记，因此MI与完整案例差异不能单独归因于插补算法。

模型保留11个核心控制、社区聚类稳健SE、同期跨过程残差相关及全部低阶项；Z0×G预测四个增长因子，并允许x1、y1对Z0与Z0×G的直接路径。这使潜截距组差明确为给定基期指标直接路径后的条件关系，不是Z0与实测基期抑郁的总关联。教育G1为初中及以上，城乡G1为城市。本批不含收入资源调节。

## 效率、边界和下一步

实际{len(resource)}次MplusAutomation调用，引擎/启动器合计{budget['engine_seconds']:.3f}秒，模型协调器进程墙钟{model_wall_seconds:.3f}秒（含输入准备、读回和进程初始化）。另有先前四范围插补和后续合并时间，不混作整项任务端到端耗时。1600次插补均重新抽取参数、条件随机效应与PMM供体，只缓存四次确定性拟合。缓存函数与此前已验证版本哈希一致，每次参数齐全入键；没有把一次填充值复制成20份。

启动时Windows可用约2.46GiB，使用一个引擎、每引擎一个处理器；协调器有PID创建时间、临时空闲保护、逐模型进度和预算。原数据与已收尾稿不动。没有为不显著或非法解增加规格、修改约束或替换MI成员。

运行中对未领取的排行差/长子差家族提前准备了88份输入，约58秒完成，缓存4次确定性起点计算、复用84次；没有调用Mplus或复制随机插补值，也没有改变原协调器。输入准备回执明确标记“未估计”，后续仍逐模型核验。不能将预备数量计入有效估计数。

H4.1基期关联异质性与动态调节是不同目标。本批完整条件家族可用于对应的CHARLS工作模型报告；不关闭原CFPS四项调节、完整H4或尚未执行的收入/动态资源分支。后续只在明确的科学规格和缺失假设下推进新分支，不原样重复失败CFPS或上一批超时的联合MC输入。

前批证据：[名册及完整案例小试](https://github.com/lzhs1995/PP-lcgm-paper/tree/04e97911e2008343aacc7ccc1c38e4c84cffbbc8/charls_observed_moderation_20261016)、[ADL来源及接口限制](https://github.com/lzhs1995/PP-lcgm-paper/tree/d67b7066f05e2709d08bdf38d3bd8449d2d9898a/charls_interaction_missing_20261016)。公开包只含代码与聚合证据，真实个人DAT、DTA、RDS和MI不公开。
'''
(R/'reports/REPORT.md').write_text(report,encoding='utf-8')
(R/'reports/FOR_WEB_REVIEWERS.md').write_text('''# 网页端阅读说明

先读REPORT和BATCH_RECEIPT，再读POOLED_PATHS、GROUP_CONTRASTS、JOINT_D1及各家族逐份证据。不要把CHARLS教育/城乡H4.1条件推断改称CFPS四项动态调节或完整H4。

本批新插补显式包含观测Z与两个资源乘积，但保留FCS工作近似/MAR边界，未声称严格潜交互相容。潜截距路径还条件于x1/y1的直接Z和ZG路径。只合并完整20份，不平均P，也不靠组内星号判组差。全部失败和实际运行记录保留。

公开包核验器可直接读取保存参数与TECH3重算，不拟合微观数据。本人级DAT/MI/RDS未发布；estimates.dat和tech3.dat仅含模型参数及协方差。
''',encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
