"""独立回读20份实际DAT，核对源观测、原缺失掩码、供体及交互预测列。"""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
entries=read(R.parent/'charls_interaction_missing_20261016/contracts/MISSING_CONTROL_ENTRIES.json')
admissions=read(R/'audit/MI_ADMISSIONS.json');result={}
for z,e in entries.items():
 p=Path(e['data_file']);assert hashlib.sha256(p.read_bytes()).hexdigest()==e['data_sha256']
 a=np.loadtxt(p);col=e['columns'].index('c7');observed=a!=-9999
 assert a.shape==(e['N'],len(e['columns']))
 ref=pd.read_csv(R/'mi'/z/'audit/MEMBER_VALIDATION.csv');assert len(ref)==20
 pred=pd.read_csv(R/'mi'/z/'audit/PREDICTORS_ACTUAL.csv').set_index('variable')
 assert (pred.loc['adl',['z0','zg_edu','zg_urban']]==1).all() and pred.loc['adl','cluster']==-2
 for k in range(1,21):
  p=R/'mi'/z/'private'/f'MI{k:02d}.dat';b=np.loadtxt(p)
  assert hashlib.sha256(p.read_bytes()).hexdigest()==ref.set_index('member').loc[k,'sha256']
  assert b.shape==a.shape and np.array_equal(b[observed],a[observed])
  other=list(range(a.shape[1]));other.remove(col)
  assert np.array_equal(b[:,other],a[:,other])
  assert np.isin(b[:,col],a[observed[:,col],col]).all() and np.isin(b[:,col],np.arange(7)).all()
 result[z]={'status':'PASS','members':20,'N':len(a),'missing_ADL':int((~observed[:,col]).sum()),'explicit_products_preserved':True,'all_observed_cells_preserved':True,'XY_and_all_other_columns_unchanged':True,'donor_support':True,'imputation_admitted':admissions[z]['passed']}
out={'status':'PASS','scope':'Independent actual-DAT and predictor checks; not MAR or substantive compatibility proof','scopes':result}
(R/'audit/INDEPENDENT_MI_INPUTS.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))
