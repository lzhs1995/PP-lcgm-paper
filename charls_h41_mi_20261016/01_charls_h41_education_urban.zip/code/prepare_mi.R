# 每个已核实名册范围独立生成20份ADL插补；Z及资源乘积均已观测，不从旧加法MI挪用。
.libPaths(c('<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
library(mice);library(miceadds);library(jsonlite);library(digest);library(lme4)
BATCH<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_h41_mi_20261016'
contract<-fromJSON(file.path(BATCH,'contracts/RUN_CONTRACT.json'),simplifyVector=FALSE)
src<-c(core='<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015/private/charls_core_mi_inputs.rds',roster='<LOCAL_USER_HOME>/pp_lgcm_review/charls_roster_moderation_20261015/private/CONSTRUCTED_BASELINE_CONTRASTS.rds')
hash0<-vapply(src,function(f)digest(file=f,algo='sha256'),'');core<-readRDS(src['core']);roster<-readRDS(src['roster'])
entries<-fromJSON('<LOCAL_USER_HOME>/pp_lgcm_review/charls_interaction_missing_20261016/contracts/MISSING_CONTROL_ENTRIES.json',simplifyVector=FALSE)
write.csv(data.frame(source=names(src),path=unname(src),sha256=hash0),file.path(BATCH,'audit/SOURCE_HASHES.csv'),row.names=FALSE)
progress<-function(s,m){write_json(list(stage=s,message=m,updated_at=format(Sys.time(),tz='UTC',usetz=TRUE)),file.path(BATCH,'runtime/mi_progress.json'),auto_unbox=TRUE,pretty=TRUE);cat(s,m,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(s,m)}
prepare_scope<-function(z){
 ROOT<-file.path(BATCH,'mi',z);for(d in c('private','audit','runtime','results'))dir.create(file.path(ROOT,d),recursive=TRUE,showWarnings=FALSE)
 out<-file.path(ROOT,'audit/ADMISSION.json')
 if(file.exists(out))return(fromJSON(out,simplifyVector=FALSE))
 idx<-roster$all_listed[[paste0(z,'_status')]]=='DEFINED' & roster$legacy_keys_compatible
 e<-entries[[z]];stopifnot(identical(digest(file=e$data_file,algo='sha256'),e$data_sha256))
 a<-read.table(e$data_file,col.names=unlist(e$columns),na.strings='-9999');cc<-core$data[idx,]
 stopifnot(nrow(cc)==e$N,identical(as.numeric(cc$adl),as.numeric(a$c7)),sum(is.na(cc$adl))==e$missing_ADL)
 cc$z0<-a$z0;cc$zg_edu<-cc$z0*cc$edu;cc$zg_urban<-cc$z0*cc$urban
 method<-make.method(cc);method[]<-'';method['adl']<-'2l.pmm.cached'
 pm<-matrix(0,ncol(cc),ncol(cc),dimnames=list(names(cc),names(cc)));pm['adl',setdiff(names(cc),c('adl','cluster'))]<-1;pm['adl','cluster']<--2
 saveRDS(list(data=cc,analysis=a,original_cc=roster$core_complete_case[idx],methods=method,predictors=pm,source_hashes=hash0),file.path(ROOT,'private/INPUTS.rds'))
 source(file.path(BATCH,'code/mi_exact_fit_cache.R'),local=TRUE)
 warnings<-list();iteration<-0L
 catch<-function(expr)withCallingHandlers(expr,warning=function(w){warnings[[length(warnings)+1L]]<<-data.frame(iteration=iteration,type='warning',message=conditionMessage(w));invokeRestart('muffleWarning')},message=function(w){warnings[[length(warnings)+1L]]<<-data.frame(iteration=iteration,type='message',message=conditionMessage(w));invokeRestart('muffleMessage')})
 cp<-file.path(ROOT,'private/MIDS.rds')
 if(file.exists(cp)){imp<-readRDS(cp);stopifnot(identical(imp$data,cc))}else{
  progress('H41_MI_initialize',paste(z,'20 fresh chains; explicit observed Z and resource products'))
  iteration<-1L;imp<-catch(mice(cc,m=20,maxit=1,method=method,predictorMatrix=pm,seed=contract$mi_seeds[[z]],donors=5,printFlag=FALSE,remove.collinear=TRUE));saveRDS(imp,cp)
 }
 while(imp$iteration<20){iteration<-imp$iteration+1L;progress('H41_MI_iteration',paste(z,iteration,'of20'));imp<-catch(mice.mids(imp,maxit=1,donors=5,printFlag=FALSE));saveRDS(imp,cp)}
 conv<-mice::convergence(imp);last<-tail(subset(conv,vrb=='adl'),1)
 write.csv(conv,file.path(ROOT,'audit/CONVERGENCE.csv'),row.names=FALSE)
 write.csv(data.frame(variable=rownames(imp$predictorMatrix),imp$predictorMatrix,check.names=FALSE),file.path(ROOT,'audit/PREDICTORS_ACTUAL.csv'),row.names=FALSE)
 if(!is.null(imp$loggedEvents))write.csv(imp$loggedEvents,file.path(ROOT,'audit/LOGGED_EVENTS.csv'),row.names=FALSE)
 if(length(warnings))write.csv(do.call(rbind,warnings),file.path(ROOT,'audit/WARNINGS.csv'),row.names=FALSE)
 fit<-readRDS(file.path(ROOT,'private/MI_ADL_CONDITIONAL_LMER.rds'))
 passed<-is.null(fit@optinfo$conv$lme4$messages)&&fit@optinfo$conv$opt==0&&is.finite(last$psrf)&&last$psrf<1.1&&all(imp$predictorMatrix['adl',c('z0','zg_edu','zg_urban')]==1)&&imp$predictorMatrix['adl','cluster']==-2
 vals<-list();members<-list();summ<-list()
 for(k in 1:20){
  v<-complete(imp,k);stopifnot(all(v$adl%in%0:6));mask<-!is.na(cc$adl);stopifnot(identical(v$adl[mask],cc$adl[mask]),all(v$adl[!mask]%in%cc$adl[mask]))
  b<-a;b$c7<-v$adl;stopifnot(identical(b[setdiff(names(b),'c7')],a[setdiff(names(a),'c7')]))
  path<-file.path(ROOT,'private',sprintf('MI%02d.dat',k));write.table(b,path,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999');vals[[k]]<-b
  members[[k]]<-data.frame(member=k,N=nrow(b),observed_preserved=TRUE,XY_masks_preserved=TRUE,support_and_donor_valid=TRUE,sha256=digest(file=path,algo='sha256'))
  summ[[k]]<-data.frame(scope=z,member=k,imputed_ADL_mean=mean(v$adl[!mask]),overall_ADL_mean=mean(v$adl))
 }
 saveRDS(vals,file.path(ROOT,'private/COMPLETED.rds'));write.csv(do.call(rbind,members),file.path(ROOT,'audit/MEMBER_VALIDATION.csv'),row.names=FALSE);write.csv(do.call(rbind,summ),file.path(ROOT,'results/MI_SUMMARIES.csv'),row.names=FALSE)
 b<-a[roster$core_complete_case[idx],];stopifnot(!anyNA(b[paste0('c',1:11)]));write.table(b,file.path(ROOT,'private/CC.dat'),row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
 pdf(file.path(ROOT,'results/MI_CHAINS.pdf'),width=9,height=5);print(plot(imp,'adl'));dev.off()
 rec<-list(scope=z,passed=passed,m=20,iterations=imp$iteration,N=nrow(a),N_CC=nrow(b),communities=length(unique(a$cluster)),missing_ADL=sum(is.na(a$c7)),psrf=last$psrf,autocorrelation=last$ac,warnings=length(warnings),lmer_converged=is.null(fit@optinfo$conv$lme4$messages)&&fit@optinfo$conv$opt==0,random_intercept_boundary=isSingular(fit),products_retained=all(imp$predictorMatrix['adl',c('z0','zg_edu','zg_urban')]==1),fresh_draws=cache_env$hits+cache_env$misses,fit_cache_hits=cache_env$hits,fit_cache_misses=cache_env$misses,columns=names(a),source_data_sha256=e$data_sha256,compatibility=contract$compatibility)
 write_json(rec,out,auto_unbox=TRUE,pretty=TRUE,digits=16,na='null');progress('H41_MI_scope_done',paste(z,'admitted',passed));rec
}
admission<-list()
for(z in unlist(contract$indicators))admission[[z]]<-prepare_scope(z)
stopifnot(identical(hash0,vapply(src,function(f)digest(file=f,algo='sha256'),'')))
write_json(admission,file.path(BATCH,'audit/MI_ADMISSIONS.json'),auto_unbox=TRUE,pretty=TRUE,digits=16,na='null')
writeLines(capture.output(sessionInfo()),file.path(BATCH,'audit/R_SESSION_INFO.txt'))
progress('H41_MI_TERMINAL','Four distinct scope MI families audited; no scientific equivalence claim')
