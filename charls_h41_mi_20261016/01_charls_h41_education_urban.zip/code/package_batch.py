"""仅在终态/统计复算/原生链证据通过后发布白名单，真实MI和个人DAT永不入包。"""
from pathlib import Path
import csv,hashlib,io,json,re,zipfile
R=Path(__file__).resolve().parents[1];S=R/'public_stage';S.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda x:hashlib.sha256(x).hexdigest()
for name in ('audit/INDEPENDENT_H41_VERIFICATION.json','audit/INDEPENDENT_MI_INPUTS.json','audit/TERMINAL_CHECK.json','audit/CLAUDER_COMPLETION.json'):
 x=read(R/name);assert x.get('status',x.get('decision'))=='PASS'
files={}
def add(p,role='aggregate_report_or_code'):
 p=Path(p);assert p.is_file(),p;files[p.relative_to(R).as_posix()]=role
for name in ('reports/REPORT.md','reports/FOR_WEB_REVIEWERS.md','reports/BATCH_RECEIPT.json','contracts/RUN_CONTRACT.json','audit/MI_ADMISSIONS.json','audit/INDEPENDENT_MI_INPUTS.json','audit/INDEPENDENT_H41_VERIFICATION.json','audit/TERMINAL_CHECK.json','audit/CLAUDER_COMPLETION.json','audit/SOURCE_HASHES.csv','audit/INPUT_INTEGRITY.csv','audit/R_SESSION_INFO.txt','runtime/mi_native_submit.json','runtime/mi_native_terminal.json','runtime/models_native_submit.json','runtime/models_native_terminal.json','runtime/MI_AWAKE.json','runtime/MODELS_AWAKE.json','runtime/budget_status.json','runtime/POSTPROCESS_TERMINAL.json'):
 add(R/name)
add(R/'reports/ORIGINAL_H4_SCOPE.md')
add(R/'audit/REUSED_Z_SCALING.json')
for name in ('code/plot_h41_results.R','audit/H41_PLOT_RECEIPT.json'):add(R/name)
for name in ('code/plot_mi_diagnostics.R','results/MI_DIAGNOSTICS.pdf','audit/MI_PLOT_RECEIPT.json'):add(R/name)
for name in ('code/prepare_future_inputs.R','audit/FUTURE_INPUT_PREPARATION.json','audit/INPUT_PREPARATION_PROFILE.json','runtime/future_inputs_native_submit.json','runtime/future_inputs_native_terminal.json'):add(R/name)
for name in ('initialize_batch.py','prepare_mi.R','run_mi.R','run_models.R','pool_h41.R','verify_mi_inputs.py','verify_h41_results.py','raw_parameter_reader.py','completion_watch.py','finalize_batch.py','package_batch.py','verify_public_bundle.py','engine.py','run_one.R','coordinator_awake.py','r2e_local.R','r2e_tools.R','r2e_upstream_math.R','mi_exact_fit_cache.R'):add(R/'code'/name)
for name in ('CALL_RESULTS.json','FAMILY_STATUS.json','FAMILY_OVERVIEW.csv','POOLING_RECEIPT.json','JOINT_D1.csv','POOLED_PATHS.csv','GROUP_CONTRASTS.csv','CC_MI_COMPARISON.csv','ENGINE_RESOURCES.csv','RESOURCE_GROUP_DIFFERENCES.pdf'):
 if (R/'results'/name).exists():add(R/'results'/name)
for z in ('sd','gender','oldest','son'):
 for rel in ('audit/ADMISSION.json','audit/CONVERGENCE.csv','audit/PREDICTORS_ACTUAL.csv','audit/MEMBER_VALIDATION.csv','audit/MI_FIT_CACHE_FIRST.json','audit/LOGGED_EVENTS.csv','audit/WARNINGS.csv','results/MI_SUMMARIES.csv','results/MI_CHAINS.pdf'):
  p=R/'mi'/z/rel
  if p.exists():add(p,'aggregate_imputation_diagnostic')
for fam in read(R/'results/FAMILY_STATUS.json'):
 p=R/'results'/f'{fam}_START_COMPARISON.json'
 if p.exists():add(p)
 d=R/'results'/fam
 for n in ('POOLED_PATHS.csv','CLUSTER_DF_SENSITIVITY.csv','GROUP_CONTRASTS.csv','JOINT_D1.csv','MEMBER_ESTIMATES.csv','MEMBER_COVARIANCES.csv','MEMBER_SOURCES.csv','FIT_BY_MEMBER.csv','RECEIPT.json'):
  if (d/n).exists():add(d/n,'aggregate_pooled_statistics')
for name in read(R/'results/CALL_RESULTS.json'):
 d=R/'models'/name
 for n in ('model.inp','model.out','job.json','engine_receipt.json','receipt.json','not_run.json','design_check.json','mplus_execution.log','start_mapping.csv','validation.json','parameters_high_precision.csv','matrix_values.csv','tech1_parameter_map.csv','parameter_covariance.csv','key_paths.csv','estimates.dat','tech3.dat'):
  p=d/n
  if p.exists() and p.stat().st_size:add(p,'model_parameters' if n=='estimates.dat' else 'parameter_covariance' if n=='tech3.dat' else 'aggregate_model_evidence')
payload={};manifest=[]
for name,role in files.items():
 p=R/name;assert 'private' not in p.relative_to(R).parts and p.name!='data.dat' and p.suffix.lower() not in {'.rds','.dta'}
 raw=p.read_bytes()
 if p.suffix in {'.pdf','.png'}:data=raw
 else:
  s=raw.decode('utf-8-sig')
  for prefix in ('<LOCAL_USER_HOME>','<LOCAL_USER_HOME>','C:\\\\Users\\\\LZHS','<LOCAL_USER_HOME>','<LOCAL_USER_HOME>'):s=s.replace(prefix,'<LOCAL_USER_HOME>')
  assert not re.search(r'(?i)(?:api[_-]?key|access_token)\s*[:=]\s*["\']?[A-Za-z0-9_-]{20,}',s),name
  if p.suffix=='.csv' and p.name!='parameter_covariance.csv':assert not {h.lower() for h in next(csv.reader(io.StringIO(s)))}&{'pid','fid','childid','householdid','communityid'},name
  data=s.encode('utf-8')
 payload[name]=data;manifest.append({'path':name,'bytes':len(data),'sha256':sha(data),'local_source_sha256':sha(raw),'paths_redacted':data!=raw,'role':role})
payload['PAYLOAD_MANIFEST.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
zpath=S/'01_charls_h41_education_urban.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,b in payload.items():z.writestr(name,b)
assert zpath.stat().st_size<25_000_000,'Split into multiple <=25MB packs before upload'
with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
pm={'packages':[{'file':zpath.name,'bytes':zpath.stat().st_size,'sha256':sha(zpath.read_bytes()),'files':len(payload)}],'privacy':'Explicit per-file statistical role allowlist; no individual DAT/DTA/RDS/MI; local paths redacted; parameter DATs only'}
(S/'PACKAGE_MANIFEST.json').write_text(json.dumps(pm,ensure_ascii=False,indent=2),encoding='utf-8')
for n in ('REPORT.md','FOR_WEB_REVIEWERS.md','BATCH_RECEIPT.json','ORIGINAL_H4_SCOPE.md'):(S/n).write_bytes(payload['reports/'+n])
for n in ('FAMILY_OVERVIEW.csv','JOINT_D1.csv','POOLED_PATHS.csv','GROUP_CONTRASTS.csv','RESOURCE_GROUP_DIFFERENCES.pdf'):
 if 'results/'+n in payload:(S/n).write_bytes(payload['results/'+n])
(S/'README.md').write_text('''# CHARLS H4.1：教育与城乡

**四项调节完整推断、完整 H4 仍未完成。**

[报告](REPORT.md) · [网页端说明](FOR_WEB_REVIEWERS.md) · [实际回执](BATCH_RECEIPT.json) · [家族状态](FAMILY_OVERVIEW.csv) · [直接联合组差检验](JOINT_D1.csv)

本批为四个基期家内差异 × 教育／城乡的CHARLS H4.1。新插补包含观测资源乘积，但保留FCS工作近似边界；不是CFPS或潜变量动态交互的完整推断。

解压后运行`python code/verify_public_bundle.py`核验哈希，再运行`python code/verify_h41_results.py`独立复算原始保存参数/TECH3与合并。需要numpy/pandas/scipy，不调用Mplus。包内不含个人数据和实际MI。指南经验见[mplusautomation-guide PR25](https://github.com/lzhs1995/clauder-rstudio-workbench/pull/25)。
''',encoding='utf-8')
(R/'audit/PUBLIC_FILE_SELECTION.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(pm,ensure_ascii=False))
