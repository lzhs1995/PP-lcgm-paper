"""低开销托管：核实协调器终态后合并与独立复算；不重启或重估任何模型。"""
from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess,sys,time
import psutil
R=Path(__file__).resolve().parents[1]
def read(p):
 try:return json.loads(p.read_text(encoding='utf-8-sig'))
 except (FileNotFoundError,json.JSONDecodeError):return None
def save(p,x):
 t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
 for k in range(12):
  try:os.replace(t,p);return
  except PermissionError:
   if k==11:raise
   time.sleep(.2)
def alive(owner):
 try:p=psutil.Process(owner['pid']);return p.is_running() and abs(p.create_time()-owner['created'])<.01
 except psutil.NoSuchProcess:return False
def main():
 owner=read(R/'runtime/models_coordinator.json');assert owner
 me=psutil.Process();save(R/'runtime/completion_watch_owner.json',{'pid':me.pid,'created':me.create_time(),'model_owner':owner})
 start=time.monotonic()
 while time.monotonic()-start<9000:
  fs=read(R/'results/FAMILY_STATUS.json') or {};calls=read(R/'results/CALL_RESULTS.json') or {};live=alive(owner)
  status={'utc':datetime.now(timezone.utc).isoformat(),'coordinator_alive_verified':live,'calls_recorded':len(calls),'usable_calls':sum(x['status']=='USABLE_SINGLE_DATASET' for x in calls.values()),'complete_families':sum(x['status']=='TWENTY_USABLE_PENDING_POOLING' for x in fs.values()),'family_status':fs,'latest_progress':read(R/'runtime/progress.json'),'watcher_elapsed_seconds':time.monotonic()-start}
  save(R/'runtime/WATCH_STATUS.json',status)
  if live:time.sleep(20);continue
  if not (R/'runtime/MODELS_TERMINAL').exists() or len(fs)!=8 or any(x['status']=='RUNNING' for x in fs.values()):
   save(R/'runtime/POSTPROCESS_TERMINAL.json',{'status':'COORDINATOR_FAILED_INCOMPLETE','action':'No automatic resubmission; inspect native job and retained receipts','state':status});return 2
  for _ in range(15):
   if all((read(R/'runtime'/p) or {}).get('status')=='RELEASED' for p in ('MI_AWAKE.json','MODELS_AWAKE.json')):break
   time.sleep(1)
  job=read(next((R/'models').glob('*/job.json')))
  commands=[[job['rscript'],'--vanilla',str(R/'code/pool_h41.R')],[sys.executable,'-X','utf8',str(R/'code/verify_h41_results.py')],[sys.executable,'-X','utf8',str(R/'code/finalize_batch.py')]]
  for k,cmd in enumerate(commands,1):
   save(R/'runtime/POSTPROCESS_PROGRESS.json',{'stage':k,'program':Path(cmd[-1]).name,'utc':datetime.now(timezone.utc).isoformat()})
   with (R/'runtime'/f'postprocess_{k}.log').open('wb') as log:q=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT,timeout=300)
   if q.returncode:
    save(R/'runtime/POSTPROCESS_TERMINAL.json',{'status':'POSTPROCESS_FAILED','stage':k,'exitcode':q.returncode,'action':'Repair readback/postprocess only; do not refit valid estimates'});return q.returncode
  save(R/'runtime/POSTPROCESS_TERMINAL.json',{'status':'POOLED_INDEPENDENTLY_VERIFIED_REPORT_READY','utc':datetime.now(timezone.utc).isoformat(),'new_estimates_by_watcher':0,'public_upload_done':False});return 0
 save(R/'runtime/POSTPROCESS_TERMINAL.json',{'status':'WATCH_LIMIT','action':'Does not kill or restart model owner'});return 3
if __name__=='__main__':
 try:sys.exit(main())
 except Exception as e:
  save(R/'runtime/POSTPROCESS_TERMINAL.json',{'status':'WATCH_ERROR','error':repr(e)});raise
