"""核验逐文件统计角色与载荷哈希；不把本批完成冒充全部H4完成。"""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[1]
rows=json.loads((R/'PAYLOAD_MANIFEST.json').read_text(encoding='utf-8-sig'))
for r in rows:
 p=R/r['path'];b=p.read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
 assert 'private' not in p.relative_to(R).parts and p.name!='data.dat' and p.suffix.lower() not in {'.rds','.dta'}
 if p.suffix=='.dat':assert p.name in {'estimates.dat','tech3.dat'} and r['role'] in {'model_parameters','parameter_covariance'}
b=json.loads((R/'reports/BATCH_RECEIPT.json').read_text(encoding='utf-8-sig'))
assert b['new_CFPS_calls']==0 and b['new_MI_scopes']==4 and b['new_MI_members_per_scope']==20
assert not b['original_four_moderations_complete'] and not b['full_H4_complete']
print(json.dumps({'status':'PASS','payload_files':len(rows),'model_calls':b['model_calls'],'complete_pooled_families':b['complete_pooled_families'],'full_H4':False}))
