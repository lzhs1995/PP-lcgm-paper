# 协调器全程可观测并受临时空闲保护；仅本批PID创建时间归属。
library(processx);library(ps);library(jsonlite)
BATCH<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_h41_mi_20261016'
main<-function(){
 owner<-ps_handle();stopfile<-file.path(BATCH,'runtime/MI_TERMINAL')
 stopifnot(!file.exists(stopfile),!file.exists(file.path(BATCH,'runtime/mi_coordinator.json')))
 write_json(list(pid=Sys.getpid(),created=as.numeric(ps_create_time(owner))),file.path(BATCH,'runtime/mi_coordinator.json'),auto_unbox=TRUE)
 guard<-process$new('<LOCAL_USER_HOME>/AppData/Local/Programs/Python/Python314/python.exe',c('-X','utf8',file.path(BATCH,'code/coordinator_awake.py'),'--owner-pid',Sys.getpid(),'--owner-created',as.numeric(ps_create_time(owner)),'--receipt',file.path(BATCH,'runtime/MI_AWAKE.json'),'--max-seconds','3600','--stop-file',stopfile),stdout=file.path(BATCH,'runtime/mi_awake.log'),stderr='2>&1',cleanup=FALSE)
 on.exit(writeLines('MI coordinator terminal; inspect MI_ADMISSIONS',stopfile),add=TRUE)
 source(file.path(BATCH,'code/prepare_mi.R'),local=TRUE)
 cat('H41_MI_TERMINAL\n')
}
main()
