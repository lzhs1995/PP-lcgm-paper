"""新CHARLS H4.1合同；复用历史估计作起点，绝不改原始目录。"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil
R=Path(__file__).resolve().parents[1]
old=R.parent/'charls_observed_moderation_20261016'
for d in ('code','contracts','private','models','results','reports','audit','runtime'):(R/d).mkdir(parents=True,exist_ok=True)
if (R/'contracts/RUN_CONTRACT.json').exists():raise RuntimeError('Contract exists: reconcile, do not overwrite')
for n in ('engine.py','run_one.R','coordinator_awake.py','r2e_upstream_math.R','r2e_tools.R','r2e_local.R'):shutil.copyfile(old/'code'/n,R/'code'/n)
cache=R.parent/'charls_adjusted_h41_20261015/code/mi_exact_fit_cache.R'
shutil.copyfile(cache,R/'code/mi_exact_fit_cache.R')
c=dict(created_utc=datetime.now(timezone.utc).isoformat(),scope='CHARLS baseline observed Z0 by observed education/urban resource heterogeneity; not SX*Z0 dynamics or full H4',max_calls=176,total_engine_seconds=5400,category_seconds={'CHARLS_H41':5400},wall_seconds=7200,per_call_seconds=120,processor=1,engine_slots=1,indicators=['sd','gender','oldest','son'],groups={'EDU':'c3: junior high or above versus below','URBAN':'c4: urban versus rural'},m=20,maxit=20,mi_seeds={'sd':26101631,'gender':26101632,'oldest':26101633,'son':26101634},imputation='Fresh per-scope community random-intercept PMM5 ADL; include exact observed z0, z0*education, z0*urban predictors; preserve original outcomes and official partial-item ADL definition',compatibility='Interaction-aware FCS working approximation; not proof of exact substantive-model compatibility or MAR; not latent-interaction MI',model='Parent linear-time PP-LGCM plus z0*G -> four growth factors and x1/y1; retain all lower-order paths, core controls, community robust SE, same-wave residual associations',family_sequence=['CC sensitivity','MI01','separately perturbed MI01 start','MI02 through MI20 if legal'],pooling='Complete20 only; full TECH3 Rubin; direct two-path D1 group difference; frozen8-family multiplicity; never average P',numerical_check={'LL_abs':.01,'path_abs_floor':.001,'path_SE_fraction':.05,'SE_relative':.05},stops=['no unchanged failed CFPS','no variance fixed for success','no replacing failed members','no automatic imputation or estimator escalation','no p-value gating'],source_public_commits=['04e97911e2008343aacc7ccc1c38e4c84cffbbc8','d67b7066f05e2709d08bdf38d3bd8449d2d9898a'],cache_source_sha256=hashlib.sha256(cache.read_bytes()).hexdigest(),closed_manuscript_changed=False,preregistration_claim=False)
(R/'contracts/RUN_CONTRACT.json').write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding='utf-8')
print('FROZEN 8 families, 20 MI each, one engine, no latent interaction integration')
