# 只读取已完成的插补对象，绘制聚合链诊断；不插补、不估计模型。
library(jsonlite)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_h41_mi_20261016'
pdf(file.path(ROOT,'results/MI_DIAGNOSTICS.pdf'),width=9,height=4.2)
records<-list()
for(z in c('sd','gender','oldest','son')){
 imp<-readRDS(file.path(ROOT,'mi',z,'private/MIDS.rds'))
 a<-jsonlite::fromJSON(file.path(ROOT,'mi',z,'audit/ADMISSION.json'))
 mu<-imp$chainMean['adl',,,drop=TRUE];ss<-sqrt(imp$chainVar['adl',,,drop=TRUE]);stopifnot(identical(dim(mu),c(20L,20L)),identical(dim(ss),dim(mu)),all(is.finite(mu)),all(is.finite(ss)))
 par(mfrow=c(1,2),mar=c(4,4,3,1),oma=c(1.5,0,1,0))
 for(typ in c('Mean','SD')){
  y<-if(typ=='Mean')mu else ss
  matplot(seq_len(nrow(y)),y,type='l',lty=1,col=adjustcolor(hcl.colors(20,'Dark3'),alpha.f=.75),xlab='Iteration',ylab=paste('Imputed ADL',typ),main=paste(toupper(z),'-',typ),xaxt='n');axis(1,at=c(1,5,10,15,20))
 }
 mtext(sprintf('20 chains; %d missing ADL; final PSRF = %.4f. Descriptive diagnostics, not proof of MAR or model compatibility.',a$missing_ADL,a$psrf),outer=TRUE,side=1,line=0,cex=.75)
 records[[z]]<-list(iterations=nrow(mu),chains=ncol(mu),missing_ADL=a$missing_ADL,psrf=a$psrf,plots_finite=TRUE)
}
dev.off()
jsonlite::write_json(list(status='PLOTTED_FROM_RETAINED_MIDS',new_imputations=0,new_model_calls=0,scopes=records),file.path(ROOT,'audit/MI_PLOT_RECEIPT.json'),auto_unbox=TRUE,pretty=TRUE)
cat('MI_DIAGNOSTIC_PLOTS_COMPLETE 4 pages; no estimates\n')
