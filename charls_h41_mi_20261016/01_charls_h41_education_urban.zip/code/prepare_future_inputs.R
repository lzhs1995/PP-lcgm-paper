# 只为尚未领取的家族预备输入，不启动协调器、不调用Mplus、不复用随机插补值。
Sys.setenv(H41_READ_ONLY='1')
source('<LOCAL_USER_HOME>/pp_lgcm_review/charls_h41_mi_20261016/code/run_models.R',local=TRUE)
t0<-Sys.time();state<-rj(file.path(ROOT,'results/FAMILY_STATUS.json'))
stopifnot(!any(grepl('^(OLDEST|SON)_',names(state))),!file.exists(file.path(ROOT,'runtime/MODELS_TERMINAL')))
original_make_model<-make_model;cached_models<-new.env(parent=emptyenv());hits<-0L;misses<-0L
make_model<-function(si,source_dir=NULL,perturb=FALSE){
 key<-digest::digest(list(si=si,source_output_sha256=hashf(file.path(source_dir,'model.out')),perturb=perturb),algo='sha256')
 if(exists(key,envir=cached_models,inherits=FALSE)){hits<<-hits+1L;return(get(key,envir=cached_models))}
 ans<-original_make_model(si,source_dir,perturb);assign(key,ans,envir=cached_models);misses<<-misses+1L;ans
}
records<-list()
for(z in c('oldest','son'))for(g in c('EDU','URBAN')){
 for(k in 0:20){
  id<-paste('CHARLS',toupper(z),'H41',g,if(k==0)'CC'else sprintf('MI%02d',k),'A',sep='_')
  stopifnot(!dir.exists(file.path(ROOT,'models',id)))
  j<-prepare(z,g,k);stopifnot(!file.exists(file.path(j$dest,'engine_receipt.json')),identical(hashf(j$source_data),j$hashes$data.dat))
  records[[id]]<-list(id=id,status='INPUT_ONLY_NOT_ESTIMATED',input_sha256=j$hashes$model.inp,data_sha256=j$hashes$data.dat)
 }
 id<-paste('CHARLS',toupper(z),'H41',g,'MI01_B',sep='_');stopifnot(!dir.exists(file.path(ROOT,'models',id)))
 j<-prepare(z,g,1,'B');records[[id]]<-list(id=id,status='INPUT_ONLY_NOT_ESTIMATED',input_sha256=j$hashes$model.inp,data_sha256=j$hashes$data.dat)
 if(exists('clauder_progress',mode='function'))clauder_progress('future_input_preparation',paste(z,g,'input only; no engine'))
}
stopifnot(length(records)==88L,misses==4L,hits==84L)
wj(list(status='PREPARED_NOT_ESTIMATED',prepared=length(records),deterministic_start_cache_misses=misses,deterministic_start_cache_hits=hits,seconds=as.numeric(difftime(Sys.time(),t0,units='secs')),new_estimates=0,changes_to_model_or_data=FALSE,records=records),file.path(ROOT,'audit/FUTURE_INPUT_PREPARATION.json'))
cat('FUTURE_INPUT_PREPARATION_TERMINAL 88 inputs, zero engine calls\n')
