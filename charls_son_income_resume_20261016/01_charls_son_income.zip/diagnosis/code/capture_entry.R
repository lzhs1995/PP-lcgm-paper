# 使用同版MICE真实采样器组装输入；两种插补方法仅返回原值，不拟合、不抽样、不保留假MIDS。
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_son_income_diagnosis_20261016'
OLD<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_h41_mi_20261016'
.libPaths(c('<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_mi_pilot_20261016/library','<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
library(mice);library(jsonlite);library(digest);library(lme4)
progress<-function(s){write_json(list(stage=s,pid=Sys.getpid(),updated_at=format(Sys.time(),tz='UTC',usetz=TRUE)),file.path(ROOT,'runtime/progress.json'),auto_unbox=TRUE);cat(s,'\n');flush.console()}
cp<-file.path(OLD,'mi/son/checkpoints/ITER05.rds');h0<-digest(file=cp,algo='sha256');stopifnot(h0=='1723166859def4d35e8afe6e153019117858a57e9aca4cb4a869777505849d69')
imp<-readRDS(cp);stopifnot(imp$iteration==5,imp$m==40)
ce<-new.env(parent=asNamespace('mice'));ce$n<-0L;ce$entries<-list()
ce$capture_fit<-function(...){
 args<-list(...);n<<-n+1L
 entries[[n]]<<-list(formula=deparse(args[[1]]),data=args$data,
   hash=digest::digest(list(formula=deparse(args[[1]]),data=args$data,family='binomial_logit',profile=FALSE),algo='sha256'))
 stop('CAPTURE_ONLY_NO_FIT')
}
environment(ce$capture_fit)<-ce
bin<-mice::mice.impute.2l.bin;replaced<-0L
swap<-function(x){if(is.call(x)&&identical(x[[1]],call('::',as.name('lme4'),as.name('glmer')))){x[[1]]<-as.name('capture_fit');replaced<<-replaced+1L;return(x)};if(is.call(x)||is.expression(x))for(i in seq_along(x))if(!identical(x[[i]],quote(expr=)))x[[i]]<-swap(x[[i]]);x}
body(bin)<-swap(body(bin));stopifnot(replaced==1L);environment(bin)<-ce
mice.impute.2l.bin.logged<-function(...)suppressWarnings(bin(...,random.effects='laplace'))
mice.impute.2l.pmm.logged<-function(y,ry,x,type,wy=NULL,...)y[if(is.null(wy))!ry else wy]
progress('CAPTURE_EXACT_CONDITIONAL_INPUTS')
probe<-suppressWarnings(mice.mids(imp,maxit=1,printFlag=FALSE))
stopifnot(ce$n==40L)
for(k in 1:40)stopifnot(identical(complete(imp,k),complete(probe,k)))
hist<-lapply(readLines(file.path(OLD,'mi/son/audit/FIT_LOG.jsonl')),fromJSON)
checks<-lapply(1:5,function(k){old<-hist[[400+2*k-1]];e<-ce$entries[[k]];stopifnot(old$fit_n==400+2*k-1,old$valid,identical(old$data_spec_hash,e$hash));list(chain=k,historical_call=old$fit_n,matched=TRUE,hash=e$hash)})
target<-ce$entries[[6]];warm<-readRDS(file.path(ROOT,'private/LAST_VALID_INPUT.rds'))$warm
target$warm<-warm;target$historical_call<-411L;target$chain<-6L
saveRDS(target,file.path(ROOT,'private/FAILED_CONDITIONAL_ENTRY.rds'))
form<-as.formula(paste(target$formula,collapse=' '));X<-model.matrix(lme4::nobars(form),target$data)
rec<-list(status='EXACT_ENTRY_RECONSTRUCTED_WITH_KNOWN_CALL_CROSSCHECK',checkpoint_sha256=h0,
 target_call=411,iteration=6,chain=6,target_data_spec_hash=target$hash,known_entry_checks=checks,
 N_observed=nrow(target$data),fixed_parameters=ncol(X),rank=qr(X)$rank,kappa=kappa(X),
 capture_calls=40,fitting_calls=0,stochastic_imputations=0,all_completed_chain_values_unchanged=TRUE,
 condition='MICE iterates chains independently; G is first visited variable; iteration5 values are preserved by capture-only functions')
write_json(rec,file.path(ROOT,'audit/FAILED_INPUT_IDENTITY.json'),auto_unbox=TRUE,pretty=TRUE,digits=16)
stopifnot(digest(file=cp,algo='sha256')==h0)
progress('EXACT_INPUT_CAPTURE_COMPLETE');print(rec[c('status','target_call','target_data_spec_hash','rank','kappa','fitting_calls')])
