# 同一失败入口、同一目标/默认优化器/120秒上限；仅原热起点与冷起点两次诊断，不进入MI合并。
args<-commandArgs(TRUE);stopifnot(length(args)==1,args%in%c('warm','cold'));which<-args[1]
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_son_income_diagnosis_20261016'
.libPaths(c('<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_mi_pilot_20261016/library',.libPaths()))
library(glmmTMB);library(jsonlite);library(digest)
entry<-readRDS(file.path(ROOT,'private/FAILED_CONDITIONAL_ENTRY.rds'))
form<-as.formula(paste(entry$formula,collapse=' '));start<-if(which=='warm')entry$warm else NULL
stage<-'INITIALIZED';t0<-Sys.time();cpu0<-proc.time();warning_text<-character()
mark<-function(s){stage<<-s;write_json(list(stage=paste(which,s),pid=Sys.getpid(),elapsed=as.numeric(difftime(Sys.time(),t0,units='secs')),cpu=as.numeric(sum((proc.time()-cpu0)[1:2])),updated_at=format(Sys.time(),tz='UTC',usetz=TRUE)),file.path(ROOT,'runtime/progress.json'),auto_unbox=TRUE);cat(which,s,'\n');flush.console()}
out<-tryCatch({
 setTimeLimit(elapsed=120,transient=TRUE)
 mark('GLMM_TMB_BEGIN')
 fit<-withCallingHandlers(glmmTMB(form,data=entry$data,family=binomial(),start=start,
       control=glmmTMBControl(parallel=1,profile=FALSE,rank_check='stop',optCtrl=list(iter.max=1000,eval.max=1000))),warning=function(w){warning_text<<-c(warning_text,conditionMessage(w));invokeRestart('muffleWarning')})
 mark('GLMM_TMB_RETURNED')
 V<-as.matrix(vcov(fit)$cond);eig<-eigen((V+t(V))/2,symmetric=TRUE,only.values=TRUE)$values
 beta<-fixef(fit)$cond;psi<-as.numeric(VarCorr(fit)$cond[[1]][1,1]);b<-ranef(fit,condVar=FALSE)$cond[[1]]
 mf<-model.frame(fit);X<-model.matrix(fit,component='cond');pr<-plogis(as.numeric(X%*%beta)+b[match(as.character(mf$cluster),rownames(b)),1])
 pv<-1/(tapply(pr*(1-pr),mf$cluster,sum)+1/psi)
 valid<-fit$fit$convergence==0&&isTRUE(fit$sdr$pdHess)&&all(is.finite(eig))&&min(eig)>0&&is.finite(psi)&&psi>0&&all(is.finite(pv))&&all(pv>0)
 mark('NUMERICAL_CHECKS_COMPLETE');setTimeLimit(cpu=Inf,elapsed=Inf,transient=FALSE)
 write.csv(data.frame(parameter=names(beta),estimate=as.numeric(beta),se=sqrt(diag(V))),file.path(ROOT,'results',paste0(which,'_parameters.csv')),row.names=FALSE)
 write.table(V,file.path(ROOT,'results',paste0(which,'_covariance.csv')),row.names=FALSE,col.names=FALSE,sep=',')
 list(status=if(valid)'VALID_CONDITIONAL_DIAGNOSTIC' else 'INVALID_CONDITIONAL_DIAGNOSTIC',valid=valid,mode=which,
      input_hash=entry$hash,logLik=as.numeric(logLik(fit)),iterations=fit$fit$iterations,evaluations=as.list(fit$fit$evaluations),
      optimizer_code=fit$fit$convergence,pdHess=fit$sdr$pdHess,max_gradient=max(abs(fit$sdr$gradient.fixed)),
      psi=psi,min_vcov_eigenvalue=min(eig),min_conditional_random_variance=min(pv),warnings=warning_text)
},error=function(e){setTimeLimit(cpu=Inf,elapsed=Inf,transient=FALSE);list(status='FAILED_CONDITIONAL_DIAGNOSTIC',valid=FALSE,mode=which,input_hash=entry$hash,error=conditionMessage(e),failed_stage=stage,warnings=warning_text)})
out$seconds<-as.numeric(difftime(Sys.time(),t0,units='secs'));out$cpu_seconds<-as.numeric(sum((proc.time()-cpu0)[1:2]));out$adopted_as_MI<-FALSE
write_json(out,file.path(ROOT,'audit',paste0('FIT_',toupper(which),'.json')),auto_unbox=TRUE,pretty=TRUE,digits=16)
mark('DIAGNOSTIC_TERMINAL');print(out)
