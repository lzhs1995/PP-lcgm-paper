"""从经过验证的完整检查点创建独立续算；旧失败批次及原始目录只读。"""
from pathlib import Path
import hashlib,json,shutil,datetime
D=Path(__file__).resolve().parents[1];O=D.parent/'charls_income_h41_mi_20261016';R=D.parent/'charls_son_income_resume_20261016'
assert not R.exists(),'Existing continuation needs reconciliation, not overwrite'
identity=json.loads((D/'audit/FAILED_INPUT_IDENTITY.json').read_text());diag=json.loads((D/'audit/PROBES_TERMINAL.json').read_text())
assert all(c['matched'] for c in identity['known_entry_checks']) and all(x['valid'] for x in diag['fits'].values())
for d in ('code','contracts','audit','runtime','models','results','reports','verification','mi/son/checkpoints','mi/son/private','mi/son/audit','mi/son/results','mi/son/runtime'):(R/d).mkdir(parents=True,exist_ok=True)
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def w(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
oldroot=str(O).replace('\\','/');newroot=str(R).replace('\\','/')
for name in ('prepare_scope.R','income_imputers.R','run_models.R','run_one.R','pool_h41.R','r2e_local.R','r2e_tools.R','r2e_upstream_math.R','engine.py'):
    txt=(O/'code'/name).read_text(encoding='utf-8').replace(oldroot,newroot)
    if name=='run_models.R':
        txt=txt.replace('length(admission)==4','length(admission)==1')
        txt=txt.replace("j<-prepare(z,g,0);cc<-run(j);calls[[j$id]]<-cc;wj(calls,file.path(ROOT,'results/CALL_RESULTS.json'))", "cc<-rj(file.path(ROOT,'audit/REUSED_CC_RECEIPT.json'));stopifnot(cc$status=='USABLE_SINGLE_DATASET')")
    if name=='pool_h41.R':
        txt=txt.replace('length(families)==4L','length(families)==1L')
        txt=txt.replace("d<-file.path(ROOT,'models',paste0('CHARLS_',toupper(z),'_H41_',g,'_CC_A'))", "d<-file.path('"+oldroot+"','models',paste0('CHARLS_',toupper(z),'_H41_',g,'_CC_A'))")
        txt=txt.replace("j$holm_p_4<-p.adjust(j$p,'holm',n=4)","j$holm_p_4<-NA_real_ # combine with three already published families before multiplicity inference")
        txt=txt.replace("status='FOUR_INCOME_FAMILIES_ADJUDICATED',registered=4", "status='SON_CONTINUATION_ADJUDICATED',registered=1")
    if name=='income_imputers.R':
        txt=txt.replace("cache_hit<-exists(key,envir=cache,inherits=FALSE)", "cache_hit<-exists(key,envir=cache,inherits=FALSE);cpu0<-proc.time();record(list(event='BEGIN',fit_n=fit_n,iteration=iteration,target='g',data_spec_hash=key,utc=format(Sys.time(),tz='UTC',usetz=TRUE)))")
        # BEGIN 证据独立于正式成功/失败台账，避免改变已有验收器计数。
        txt=txt.replace("record(list(event='BEGIN',", "cat(jsonlite::toJSON(list(event='BEGIN',")
        txt=txt.replace("utc=format(Sys.time(),tz='UTC',usetz=TRUE)))", "utc=format(Sys.time(),tz='UTC',usetz=TRUE)),auto_unbox=TRUE),'\\n',file=file.path(ROOT,'audit/FIT_BEGIN.jsonl'),append=TRUE)")
        txt=txt.replace("backend='glmmTMB_default_Laplace',seconds=", "backend='glmmTMB_default_Laplace',cpu_seconds=as.numeric(sum((proc.time()-cpu0)[1:2])),seconds=")
        txt=txt.replace("backend='glmmTMB_default_Laplace',error=", "backend='glmmTMB_default_Laplace',data_spec_hash=key,cpu_seconds=as.numeric(sum((proc.time()-cpu0)[1:2])),error=")
    (R/'code'/name).write_text(txt,encoding='utf-8')
cp=O/'mi/son/checkpoints/ITER05.rds';assert h(cp)==identity['checkpoint_sha256']
for suffix in ('','.json'):shutil.copyfile(Path(str(cp)+suffix),R/'mi/son/checkpoints'/('ITER05.rds'+suffix))
lines=(O/'mi/son/audit/FIT_LOG.jsonl').read_text().splitlines();valid=lines[:400]
assert all(json.loads(x)['valid'] and json.loads(x)['iteration']<=5 for x in valid)
(R/'mi/son/audit/FIT_LOG.jsonl').write_text('\n'.join(valid)+'\n',encoding='utf-8')
c=json.loads((O/'contracts/RUN_CONTRACT.json').read_text());c.update(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),indicators=['son'],max_calls=41,total_engine_seconds=1800,category_seconds={'CHARLS_H41':1800},wall_seconds=7200)
c['resume_contract']={'source_batch':oldroot,'checkpoint':str(cp),'checkpoint_sha256':h(cp),'completed_iterations_reused':5,'historical_calls_reused':400,'incomplete_iteration_calls_401_411':'preserved in original batch; not complete state, no member dropped','first_recovery_fit':'cold start, optional warm sidecar absent; same saved MIDS and RNG','diagnostic_input_hash':identity['target_data_spec_hash'],'valid_diagnostic_seconds':{k:v['seconds'] for k,v in diag['fits'].items()},'old_timeout_cause':'not uniquely identifiable; exact same failed input now legally fits from warm and cold starts','new_Mplus_call_limit':41,'CC_reused_not_refit':True,'owned_worker_limit':1,'no_automatic_fit_retry':True}
w(R/'contracts/RUN_CONTRACT.json',c)
cc=O/'models/CHARLS_SON_H41_INC_CC_A/receipt.json';ccj=json.loads(cc.read_text());assert ccj['status']=='USABLE_SINGLE_DATASET';assert h(cc.parent/'model.out')==ccj['output_sha256'];w(R/'audit/REUSED_CC_RECEIPT.json',ccj)
refs=[cp,Path(str(cp)+'.json'),O/'mi/son/audit/FIT_LOG.jsonl',O/'mi/son/audit/ADMISSION.json',O/'code/income_imputers.R',cc,cc.parent/'model.out',D/'audit/PROBES_TERMINAL.json',D/'audit/FAILED_INPUT_IDENTITY.json']
w(R/'audit/REUSED_SOURCE_MANIFEST.json',[{'path':str(p),'sha256':h(p),'bytes':p.stat().st_size} for p in refs])
w(R/'audit/RECOVERY_INITIALIZATION.json',{'status':'PREPARED_NOT_RUN','source_checkpoint_unchanged':h(cp)==h(R/'mi/son/checkpoints/ITER05.rds'),'private_files_stay_local':True,'old_failure_preserved':True,'minimum_iterations':10,'maximum_iterations':20,'members':40,'scientific_model_unchanged':True})
print(str(R))
