"""只对已验证的失败入口做两次诊断；每个阶段独立资源准入和进程守护。"""
from pathlib import Path
import ctypes,datetime,hashlib,json,os,subprocess,time,psutil
R=Path(__file__).resolve().parents[1]
RS='<LOCAL_USER_HOME>/Downloads/RStudio/R_ducument/R-4.5.2/bin/x64/Rscript.exe'
for d in ('results','runtime','audit'):(R/d).mkdir(exist_ok=True)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def put(name,x):
    p=R/name;t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,indent=2),encoding='utf-8');os.replace(t,p)
def progress(s,**kw):put('runtime/probe_state.json',dict(stage=s,updated_at=utc(),**kw))
class MEM(ctypes.Structure):
    _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ('total','available','page_total','page_available','virtual_total','virtual_available','extended')]
def admission():
    until=time.monotonic()+600
    while True:
        m=MEM();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
        cpu=psutil.cpu_percent(interval=1,percpu=True)
        rec=dict(available_GiB=m.available/2**30,commit_free_GiB=m.page_available/2**30,cpu=sum(cpu)/len(cpu),per_core=cpu)
        if rec['available_GiB']>=1 and rec['commit_free_GiB']>=2 and rec['cpu']<85:return rec
        progress('RESOURCE_WAIT',resources=rec)
        if time.monotonic()>until:raise TimeoutError('Resource admission expired; no fit submitted')
        time.sleep(10)
def stage(name,args,fit=False):
    resources=admission();p0=R/'runtime/progress.json'
    env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    start=time.monotonic();fit_clock=None;last_stage='BOOTSTRAP';rc=None;reason=None
    with (R/'runtime'/f'{name}.log').open('xb') as log:
        child=subprocess.Popen([RS,*args],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
        p=psutil.Process(child.pid);born=p.create_time();allowed=p.cpu_affinity()
        idle=[i for i in allowed if resources['per_core'][i]<50]
        if len(idle)>=2 and any(resources['per_core'][i]>=90 for i in allowed):p.cpu_affinity(idle)
        p.nice(psutil.ABOVE_NORMAL_PRIORITY_CLASS)
        while child.poll() is None:
            try:
                s=json.loads(p0.read_text());
                if s.get('pid')==child.pid:
                    last_stage=s['stage']
                    if fit and 'GLMM_TMB_BEGIN' in last_stage and fit_clock is None:fit_clock=time.monotonic()
            except (OSError,ValueError):pass
            try:cpu_sec=sum(p.cpu_times()[:2])
            except psutil.Error:cpu_sec=None
            elapsed=time.monotonic()-start
            progress(name,pid=child.pid,created=born,elapsed=elapsed,cpu_seconds=cpu_sec,worker_stage=last_stage,resources=resources)
            if (fit_clock is not None and time.monotonic()-fit_clock>150) or (fit_clock is None and elapsed>240):
                reason='FIT_STAGE_150S' if fit_clock else 'BOOTSTRAP_OR_CAPTURE_240S'
                if p.is_running() and abs(p.create_time()-born)<.01:child.kill();child.wait(20)
                rc=124;break
            time.sleep(2)
        if rc is None:rc=child.returncode
    rec=dict(stage=name,exitcode=rc,seconds=time.monotonic()-start,pid=child.pid,created=born,terminal_stage=last_stage,watchdog=reason,resources=resources,utc=utc())
    put(f'audit/{name}_TERMINAL.json',rec)
    if fit and not (R/'audit'/f'FIT_{name.upper()}.json').exists():put(f'audit/FIT_{name.upper()}.json',dict(status='PROCESS_FAILED_DIAGNOSTIC',valid=False,reason=reason,exitcode=rc,adopted_as_MI=False))
    return rec
terminal=dict(status='FAILED',new_Mplus_calls=0,diagnostic_fits_attempted=0)
try:
    assert not (R/'audit/PROBES_TERMINAL.json').exists(),'Do not repeat terminal diagnosis'
    frozen={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [R/'DIAGNOSTIC_CONTRACT.md',R/'code/capture_entry.R',R/'code/fit_entry.R',Path(__file__)]}
    put('audit/DIAGNOSTIC_FROZEN_HASHES.json',frozen)
    rec=stage('capture',[str(R/'code/capture_entry.R')]);assert rec['exitcode']==0,rec
    identity=json.loads((R/'audit/FAILED_INPUT_IDENTITY.json').read_text());assert len(identity['known_entry_checks'])==5
    for mode in ('warm','cold'):
        terminal['diagnostic_fits_attempted']+=1
        stage(mode,[str(R/'code/fit_entry.R'),mode],True)
    terminal.update(status='DIAGNOSIS_TERMINAL',fits={m:json.loads((R/f'audit/FIT_{m.upper()}.json').read_text()) for m in ('warm','cold')})
except Exception as e:terminal['error']=repr(e)
terminal['utc']=utc();put('audit/PROBES_TERMINAL.json',terminal);progress(terminal['status']);print(json.dumps(terminal),flush=True)
raise SystemExit(0 if terminal['status']=='DIAGNOSIS_TERMINAL' else 1)
