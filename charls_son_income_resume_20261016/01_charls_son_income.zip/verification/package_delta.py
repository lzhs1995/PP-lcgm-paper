"""只发布本批新增模型证据与12家族汇总；微观数据永不进入白名单。"""
from pathlib import Path
import csv,hashlib,io,json,re,zipfile
R=Path(__file__).resolve().parents[1];D=R.parent/'charls_son_income_diagnosis_20261016'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def main():
    assert read(R/'audit/CLAUDER_COMPLETION.json')['decision']=='PASS'
    assert read(R/'audit/INDEPENDENT_H41_VERIFICATION.json')['status']=='PASS'
    assert read(R/'audit/INDEPENDENT_INCOME_INPUTS.json')['status']=='PASS_FOR_ADMITTED_FAMILIES'
    assert read(R/'audit/FINAL_FIGURE_REVIEW.json')['status']=='PASS'
    S=R/'public_stage';S.mkdir(exist_ok=True);assert not list(S.glob('*.zip'))
    selected={}
    def add(rel,p=None,required=True):
        p=p or R/rel
        if not p.exists():assert not required,p;return
        assert 'private' not in Path(rel).parts and p.is_file()
        assert p.suffix.lower() not in ('.rds','.dta','.rdata')
        if p.suffix.lower()=='.dat':assert p.name in ('estimates.dat','tech3.dat')
        selected[rel]=p
    for n in ('REPORT.md','RESULTS_DISCUSSION.md','H41_REGISTERED_12.csv','GROUP_CONTRASTS.csv','SUMMARY_RECEIPT.json','H41_GROUP_DIFFERENCES.pdf'):add('summary/'+n)
    for n in ('RUN_CONTRACT.json','RESUME_RATIONALE.md'):add('contracts/'+n)
    for n in ('INDEPENDENT_H41_VERIFICATION.json','INDEPENDENT_INCOME_INPUTS.json','CLAUDER_COMPLETION.json','REUSED_SOURCE_MANIFEST.json','REUSED_CC_RECEIPT.json','RECOVERY_INITIALIZATION.json','FROZEN_CODE.json','MI_ADMISSIONS.json','TERMINAL.json','FINAL_FIGURE_REVIEW.json','SOURCE_PRESERVATION.json'):add('audit/'+n)
    for n in ('DIAGNOSTIC_COMPARISON.json','PRIOR_PARTIAL_ITERATION.json'):add('audit/'+n)
    for n in ('WRAPPER_ERROR_ADJUDICATION.json','NATIVE_PIPELINE_WRAPPER_ERROR.json','NATIVE_FINAL_READBACK.json'):add('audit/'+n)
    for n in ('POST_RUN_FORMATTER_FIX.json','FORMATTER_FIX_NATIVE_CHECK.json','executed_code/launch.R'):add('audit/'+n)
    add('verification/native_final_readback.R')
    for n in ('budget_status.json','PIPELINE.json'):add('runtime/'+n)
    for n in ('prepare_scope.R','income_imputers.R','run_models.R','run_one.R','pool_h41.R','r2e_local.R','r2e_tools.R','r2e_upstream_math.R','engine.py','coordinator.py','launch.R'):add('code/'+n)
    for n in ('raw_parameter_reader.py','verify_h41_results.py','verify_income_inputs.py','OBSERVED_ENTRIES.json','summarize.py','plot_h41.py','package_delta.py'):add('verification/'+n)
    for n in ('ADMISSION.json','SOURCE.json','IMPUTER_INSTRUMENTATION.json','CONVERGENCE.csv','PREDICTORS_ACTUAL.csv','MEMBER_VALIDATION.csv','FIT_LOG.jsonl','FIT_BEGIN.jsonl','LOGGED_EVENTS.csv','WARNINGS.csv','R_SESSION_INFO.txt'):add('mi/son/audit/'+n,required=False)
    for n in ('MI_SUMMARIES.csv','MI_CHAINS.pdf'):add('mi/son/results/'+n)
    for n in ('CALL_RESULTS.json','FAMILY_STATUS.json','FAMILY_OVERVIEW.csv','POOLING_RECEIPT.json','SON_INC_START_COMPARISON.json','JOINT_D1.csv','POOLED_PATHS.csv','GROUP_CONTRASTS.csv','CC_MI_COMPARISON.csv'):add('results/'+n)
    for n in ('POOLED_PATHS.csv','CLUSTER_DF_SENSITIVITY.csv','GROUP_CONTRASTS.csv','JOINT_D1.csv','MEMBER_ESTIMATES.csv','MEMBER_COVARIANCES.csv','MEMBER_SOURCES.csv','FIT_BY_MEMBER.csv','RECEIPT.json'):add('results/SON_INC/'+n)
    for name in read(R/'results/CALL_RESULTS.json'):
        for n in ('model.inp','model.out','job.json','engine_receipt.json','receipt.json','design_check.json','mplus_execution.log','start_mapping.csv','validation.json','parameters_high_precision.csv','matrix_values.csv','tech1_parameter_map.csv','parameter_covariance.csv','key_paths.csv','estimates.dat','tech3.dat'):add(f'models/{name}/{n}',required=True)
    for n in ('DIAGNOSTIC_CONTRACT.md','audit/FAILED_INPUT_IDENTITY.json','audit/PROBES_TERMINAL.json','audit/FIT_WARM.json','audit/FIT_COLD.json','code/capture_entry.R','code/fit_entry.R','code/probe_runner.py','code/prepare_resume.py','results/warm_parameters.csv','results/cold_parameters.csv','results/warm_covariance.csv','results/cold_covariance.csv'):add('diagnosis/'+n,D/n)
    payload={};manifest=[]
    for name,p in selected.items():
        raw=p.read_bytes()
        if p.suffix.lower() in ('.pdf','.png'):data=raw
        else:
            text=raw.decode('utf-8-sig')
            for prefix in ('<LOCAL_USER_HOME>','<LOCAL_USER_HOME>','C:\\\\Users\\\\LZHS','<LOCAL_USER_HOME>','<LOCAL_USER_HOME>'):text=text.replace(prefix,'<LOCAL_USER_HOME>')
            assert not re.search(r'(?i)(?:api[_-]?key|access_token)\s*[:=]\s*["\x27]?[A-Za-z0-9_-]{20,}',text),name
            if p.suffix=='.csv' and p.name not in ('parameter_covariance.csv','warm_covariance.csv','cold_covariance.csv'):
                head={x.lower() for x in next(csv.reader(io.StringIO(text)))};assert not head&{'pid','fid','childid','householdid','communityid'},name
            data=text.encode('utf-8')
        payload[name]=data;manifest.append(dict(path=name,bytes=len(data),sha256=sha(data),local_source_sha256=sha(raw),role='explicit_aggregate_code_parameter_allowlist'))
    payload['PAYLOAD_MANIFEST.json']=json.dumps(manifest,indent=2).encode();groups=[sorted(payload.items())]
    while True:
        revised=[];split=False
        for items in groups:
            b=io.BytesIO()
            with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
                for n,data in items:z.writestr(n,data)
            if len(b.getvalue())>=25_000_000:
                assert len(items)>1;mid=len(items)//2;revised.extend([items[:mid],items[mid:]]);split=True
            else:revised.append(items)
        groups=revised
        if not split:break
    packs=[]
    for i,items in enumerate(groups,1):
        p=S/f'{i:02d}_charls_son_income.zip'
        with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for n,data in items:z.writestr(n,data)
        assert p.stat().st_size<25_000_000
        with zipfile.ZipFile(p) as z:assert z.testzip() is None
        packs.append(dict(file=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes()),files=len(items)))
    pm=dict(packages=packs,privacy='Individual DAT/DTA/RDS and MIDS withheld; estimates.dat and tech3.dat contain aggregate parameters only',dynamic_moderations_complete=False,full_H4_complete=False)
    (S/'PACKAGE_MANIFEST.json').write_text(json.dumps(pm,indent=2),encoding='utf-8')
    for n in ('REPORT.md','RESULTS_DISCUSSION.md','H41_REGISTERED_12.csv','GROUP_CONTRASTS.csv','H41_GROUP_DIFFERENCES.pdf'):(S/n).write_bytes(payload['summary/'+n])
    text='''# CHARLS SON×收入续算交付

**四项调节完整推断、完整 H4 仍未完成。**

[报告](REPORT.md) · [结果讨论](RESULTS_DISCUSSION.md) · [12家族表](H41_REGISTERED_12.csv) · [组内路径及直接组差](GROUP_CONTRASTS.csv) · [区间图](H41_GROUP_DIFFERENCES.pdf) · [包清单](PACKAGE_MANIFEST.json)

本批只新增SON收入完整40份家族及首成员第二起点；旧SON完整案例和其他11家族均复用。旧超时保留，诊断与独立续算证据在包内，未修改原数据或冻结论文，未重跑失败CFPS规格。

所有ZIP小于25,000,000字节。合并解压后按PAYLOAD_MANIFEST.json逐项检查SHA-256，执行：

`python verification/verify_h41_results.py --public --root . --output PUBLIC_RECOMPUTATION.json`

需要numpy、pandas、scipy；直接复算保存参数、TECH3及完整40份合并，不重新拟合，不读取未公开微观数据。其余11家族汇总沿用下列固定提交，不重复上传原模型包：

- [教育/城乡8家族](https://github.com/lzhs1995/PP-lcgm-paper/tree/950a01ea8599e0782cc3685563c98265c4fc924f/charls_h41_mi_20261016)
- [收入3家族及旧SON失败](https://github.com/lzhs1995/PP-lcgm-paper/tree/d43c9cca8d77f077e824ff09ebfc36d5b0324b26/charls_income_h41_mi_20261016)

本批H4.1为基期Z₀×资源组条件异质性，不能代替SX×Z₀动态调节或H4.2三重交互。CHARLS测量见面频率和家庭净收入，与CFPS情感亲近度/个人收入不同。FCS仍为工作近似；区间为逐参数区间；先看联合检验和固定多重比较，不挑选有星号结果。
'''
    (S/'README.md').write_text(text,encoding='utf-8')
    (S/'FOR_WEB_REVIEWERS.md').write_text('# 给网页端审阅者\n\n请先读REPORT和RESULTS_DISCUSSION，再查看12家族及72项条件对比。重点复核SON恢复是否保留旧失败、40份MI及TECH3合并是否一致、固定4/12项联合检验和测量限制是否正确。旧11家族直接复用固定提交。不得把本批条件H4.1完成改写为四项动态调节或完整H4完成。无微观数据，不需要重拟合或新NLM轮次。\n\n'+text,encoding='utf-8')
    (R/'audit/PUBLIC_FILE_SELECTION.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');print(json.dumps(pm))
if __name__=='__main__':main()
