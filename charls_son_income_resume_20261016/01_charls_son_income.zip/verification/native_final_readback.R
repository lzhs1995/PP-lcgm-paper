# 仅核验已保存终态；原858adefa进度格式错误保留，不重估或重启协调器。
library(jsonlite);library(digest)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_son_income_resume_20261016'
elapsed_label<-function(x)if(is.numeric(x)&&length(x)==1L&&is.finite(x))as.character(round(x))else'not_applicable'
stopifnot(elapsed_label(NULL)=='not_applicable',elapsed_label(NA_real_)=='not_applicable',elapsed_label(1.6)=='2')
clauder_progress('SON_FINAL_READBACK','Validate durable terminal and all40 saved receipts; no estimation')
t<-fromJSON(file.path(ROOT,'audit/TERMINAL.json'));stopifnot(t$status=='SON_CONTINUATION_TERMINAL',t$pooling$pooled==1L)
f<-fromJSON(file.path(ROOT,'results/FAMILY_STATUS.json'));stopifnot(f$SON_INC$status=='FORTY_USABLE_PENDING_POOLING',f$SON_INC$members==40L)
for(k in 1:40){d<-file.path(ROOT,'models',sprintf('CHARLS_SON_H41_INC_MI%02d_A',k));r<-fromJSON(file.path(d,'receipt.json'));stopifnot(r$status=='USABLE_SINGLE_DATASET',r$N==2387L,digest(file=file.path(d,'model.out'),algo='sha256')==r$output_sha256)}
p<-read.csv(file.path(ROOT,'results/SON_INC/POOLED_PATHS.csv'));stopifnot(nrow(p)==8L,all(is.finite(p$estimate)),all(is.finite(p$se)),all(p$se>0))
rec<-list(status='FINAL_READBACK_PASS',members=40L,pooled_paths=nrow(p),new_estimation_calls=0L,old_wrapper_error_preserved=TRUE,nullable_progress_formatter_checked=TRUE,full_H4_complete=FALSE)
write_json(rec,file.path(ROOT,'audit/NATIVE_FINAL_READBACK.json'),auto_unbox=TRUE,pretty=TRUE)
clauder_progress('SON_FINAL_READBACK_COMPLETE','All40 saved outputs and pooled paths verified; wrapper error separated from analysis')
print(rec);cat('SON_FINAL_READBACK_NATIVE_TERMINAL\n')
