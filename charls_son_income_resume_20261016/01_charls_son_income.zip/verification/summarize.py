"""新SON与已发布11家族的增量汇总；完整保留旧记录和固定检验数。"""
from pathlib import Path
import csv,hashlib,json,datetime
R=Path(__file__).resolve().parents[1];O=R.parent/'charls_income_h41_mi_20261016';D=R.parent/'charls_son_income_diagnosis_20261016'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def rows(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(p,a):
    with p.open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,list(a[0]));w.writeheader();w.writerows(a)
def holm(a,col,n):
    last=0
    for rank,r in enumerate(sorted([x for x in a if x['joint_p']!=''],key=lambda x:float(x['joint_p']))):
        last=min(1,max(last,(n-rank)*float(r['joint_p'])));r[col]=last
def main():
    iv=read(R/'audit/INDEPENDENT_H41_VERIFICATION.json');dv=read(R/'audit/INDEPENDENT_INCOME_INPUTS.json')
    assert iv['status']=='PASS' and dv['status']=='PASS_FOR_ADMITTED_FAMILIES'
    assert read(O/'audit/INDEPENDENT_H41_VERIFICATION.json')['status']=='PASS'
    published={x['path']:x for x in read(O/'audit/PUBLIC_FILE_SELECTION.json')}
    for n in ('summary/H41_REGISTERED_12.csv','summary/GROUP_CONTRASTS.csv','audit/INDEPENDENT_H41_VERIFICATION.json'):
        assert hashlib.sha256((O/n).read_bytes()).hexdigest()==published[n]['local_source_sha256'],n
    out=R/'summary';out.mkdir(exist_ok=True)
    a=rows(O/'summary/H41_REGISTERED_12.csv');cs=rows(O/'summary/GROUP_CONTRASTS.csv');f=rows(R/'results/FAMILY_OVERVIEW.csv')[0]
    r=next(x for x in a if x['family']=='SON_INC');r.update(status=f['status'],N=f['N'],members=f['members'])
    if 'POOLED' in f['status']:
        assert 'SON_INC' in iv['pooled_families'];d=R/'results/SON_INC';rec=read(d/'RECEIPT.json');j=rows(d/'JOINT_D1.csv')[0]
        r.update(joint_p=j['p'],max_MCSE_over_SE=rec['MCSE_over_SE_max'],group_definition=rec['group'])
        p=float(j['p']);r.update(bonferroni_p_income4=min(1,4*p),bonferroni_p_combined12=min(1,12*p))
        cs += [dict(family='SON_INC',resource='INC',scope='SON',N=f['N'],m=40,**{k:x[k] for k in ('contrast','estimate','se','lower','upper','p')}) for x in rows(d/'GROUP_CONTRASTS.csv')]
    holm(a,'holm_p_combined12',12);holm([x for x in a if x['resource']=='INC'],'holm_p_income4',4)
    write(out/'H41_REGISTERED_12.csv',a);write(out/'GROUP_CONTRASTS.csv',cs)
    complete=sum(x['joint_p']!='' for x in a);ad=read(R/'audit/MI_ADMISSIONS.json')['son'];budget=read(R/'runtime/budget_status.json')
    sources=[O/'summary/H41_REGISTERED_12.csv',O/'summary/GROUP_CONTRASTS.csv',O/'audit/INDEPENDENT_H41_VERIFICATION.json',R/'audit/INDEPENDENT_H41_VERIFICATION.json',R/'audit/INDEPENDENT_INCOME_INPUTS.json',R/'results/FAMILY_OVERVIEW.csv']
    if 'POOLED' in f['status']:sources += list((R/'results/SON_INC').glob('*.csv'))+[R/'results/SON_INC/RECEIPT.json']
    sr=dict(status='VERIFIED_AGGREGATE_SUMMARY',registered=12,pooled=complete,income_registered=4,income_pooled=complete-8,dynamic_moderation_complete=False,full_H4_complete=False,source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    (out/'SUMMARY_RECEIPT.json').write_text(json.dumps(sr,indent=2),encoding='utf-8')
    fmt=lambda x:'未形成完整推断' if x=='' else f'{float(x):.6g}'
    table='\n'.join(f"| {x['family']} | {x['N']} | {x['members']} | {fmt(x['joint_p'])} | {fmt(x['holm_p_combined12'])} |" for x in a)
    report=f'''# CHARLS SON×收入续算与 H4.1 完整家族汇总

**四项调节完整推断、完整 H4 仍未完成。**

本次仅续算SON收入，其他11个已完成家族及SON完整案例均复用，失败CFPS规格未原样重跑。CHARLS基期Z₀×资源组条件H4.1现有{complete}/12个完整家族；这不是四项SX×Z₀动态调节，也不是H4.2。

## 本次实际执行

旧失败411保留。使用同版MICE采样器捕获入口，前五个入口哈希与历史401/403/405/407/409逐一匹配；目标411的61列固定设计满秩。两个受限诊断均合法（热起点5.120秒、冷起点7.227秒），但原记录不足以唯一判断旧超时原因。

从完整ITER05的40链状态及RNG续算，不挑选成员；旧第6轮未完成记录仍在原批次。新批使用后来已执行验证的轻量可选暖启动缓存，避免每个条件调用保存完整TMB对象。最终完整迭代{ad.get('iterations')}轮，收入缺失568、ADL缺失18，N=2387。40份原观测值、原XY缺失掩码、ADL供体范围和被动乘积均独立核对。

本批实际Mplus调用{len(budget['rows'])}次，含首成员第二起点；引擎及启动器总墙钟{budget['engine_seconds']:.2f}秒，不包含FCS、资源等待和后处理。完整40份才合并，第二起点不算MI成员。数值独立复算直接读原始保存参数及TECH3，非仅依赖既有passed旗标。

## 家族联合检验

| 家族 | N | MI成员 | 两路径D1 P | 固定12项Holm P |
|---|---:|---:|---:|---:|
{table}

收入主要多重比较固定4项，组合12项为敏感性汇总；完整值见CSV。共同队列重叠，不是独立重复。逐路径95%区间不是同时区间，不能用局部星号替代预设联合检验；联合P也不自动证明原假设方向。

## 基期控制和缺失处理

11个控制列为(age−70)/10、女性、初中及以上、城市、有伴侣、有效子女报告数、ADL0—6以及健康第2—5类指示变量（第1类参照）。它们的来源和实际入口沿用已公开的前批核验。有效子女数不冒充完整生育总数；2例部分ADL题目总分的来源边界仍保留。

冻结队列3006人，经官方householdID核对为3006户；本次SON范围2387人每户一人。家庭收入仍为家庭资源，不能把社区随机截距当家庭共享值约束，也不能外推其他样本每户一人。

G=1表示家庭净收入高于固定8730元中位数，负值和零值保留为G=0，缺失不编码为0。缺失G使用社区随机截距二项FCS，ADL用二层PMM5；ZG、Z×ADL被动重算，结构上无定义的子女对比不插补。至少10轮、最多20轮，最后五轮G/ADL PSRF均有限且<1.1；不根据P值调整轮数。该实现是明确记录的TMB适配及FCS工作近似，不证明MAR或精确潜变量交互相容性。

五期年度载荷0、2、4、7、9，基期标准化，XY缺失继续用FIML。X是子女见面频率，非CFPS情感亲近度；SD为绝对离散度，性别/排行为有向差，不能一律解释为非负不和谐。Z₀、G和ZG另有x1/y1直接路径，因此潜截距路径不是与实际基期抑郁分数的总关联。

## 任务边界

CFPS条件H4.1仍3/12，四项完整动态调节及完整H4仍未完成；本批没有重开已失败规格、恢复旧阈值结论、修改冻结论文或新增NLM审稿。下一阶段需另行完善动态SX×Z₀模型的缺失处理与完整家族，H4.2直接检验SX×Z₀×G及全部低阶项，不能拿本批基期Z₀×G替代。

前11家族证据来自固定提交d43c9cca8d77f077e824ff09ebfc36d5b0324b26及950a01ea8599e0782cc3685563c98265c4fc924f。本批发布新增证据和完整12项汇总，不重复上传旧模型包；微观数据和MIDS始终留在本机。
'''
    (out/'REPORT.md').write_text(report,encoding='utf-8')
    # 结果方向以实际计算写入，不预填“显著/不显著”。
    relevant=[x for x in a if x['joint_p']!=''];under=[x['family'] for x in relevant if float(x['joint_p'])<.05]
    corrected=[x['family'] for x in relevant if float(x['holm_p_combined12'])<.05]
    son=[x for x in cs if x['family']=='SON_INC']
    tab='\n'.join(f"| {x['contrast']} | {float(x['estimate']):.6f} | [{float(x['lower']):.6f}, {float(x['upper']):.6f}] | {float(x['p']):.6g} |" for x in son)
    (out/'RESULTS_DISCUSSION.md').write_text(f'''# 结果解释

**四项调节完整推断、完整 H4 仍未完成。**

本批SON收入联合P={fmt(r['joint_p'])}；收入4项Holm P={fmt(r['holm_p_income4'])}；组合12项Holm P={fmt(r['holm_p_combined12'])}。完整12项中，未校正联合P<.05的家族为{under or '无'}，固定12项Holm后为{corrected or '无'}。这些检验不能证明效应不存在，也不能替代方向与精度判断。

| SON收入条件路径/直接组差 | 估计 | 逐参数95%区间 | P |
|---|---:|---:|---:|
{tab}

组差直接来自ZG系数，G1斜率包含Z和ZG两参数协方差，不能只比较组内星号。旧SD潜截距组差与OLDEST变化组差的名义区间仍完整保留在72行汇总中；不会因为它们局部显著而取代家族联合检验。模型与量尺边界见REPORT。

本批消除了SON收入的完整插补家族缺口，不等于原机制研究全部完成。现阶段未建立完整动态调节或H4.2结论；缺失处理诊断通过也不证明相容性或MAR。
''',encoding='utf-8')
    print(json.dumps({'pooled':complete,'new_family':r},ensure_ascii=False))
if __name__=='__main__':main()
