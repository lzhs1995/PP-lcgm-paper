"""仅绘制完整家族的真实组差及逐项区间；缺失家族明确标注。"""
from pathlib import Path
import argparse
import csv
import json
import os
for name in ('OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS'):
    os.environ[name] = '1'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--summary', type=Path, default=Path(__file__).resolve().parents[1] / 'summary')
    args = ap.parse_args(); root = args.summary
    receipt = json.loads((root / 'SUMMARY_RECEIPT.json').read_text())
    assert receipt['status'] in ('VERIFIED_AGGREGATE_SUMMARY', 'PRIOR_ONLY_REHEARSAL')
    def read(name):
        with (root / name).open(encoding='utf-8-sig', newline='') as f:
            return list(csv.DictReader(f))
    families = read('H41_REGISTERED_12.csv')
    contrasts = {(r['family'], r['contrast']): r for r in read('GROUP_CONTRASTS.csv')}
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10})
    fig, axes = plt.subplots(1, 2, figsize=(12, 8), sharey=True)
    colors = {'EDU': '#2563a6', 'URBAN': '#327b54', 'INC': '#a65324'}
    for ax, target, title in zip(axes, ('IY_group_difference', 'SY_group_difference'),
                               ('Latent intercept association: G1 minus G0',
                                'Annual change association: G1 minus G0')):
        ax.axvline(0, color='0.5', linewidth=1, linestyle='--')
        for i, fam in enumerate(families):
            y = len(families) - 1 - i
            row = contrasts.get((fam['family'], target))
            if row is None:
                ax.text(.98, y, 'No complete pooled inference', transform=ax.get_yaxis_transform(),
                        ha='right', va='center', fontsize=8, color='0.4')
                continue
            est, lo, hi = (float(row[k]) for k in ('estimate', 'lower', 'upper'))
            ax.errorbar(est, y, xerr=[[est-lo], [hi-est]], fmt='o', capsize=3,
                        color=colors[fam['resource']], markersize=5)
        ax.set_title(title, fontsize=11)
        ax.set_xlabel('Difference in conditional coefficient')
        ax.set_yticks(range(len(families)), [r['family'] for r in reversed(families)])
        ax.set_ylim(-.65, len(families)-.35)
        ax.grid(axis='y', alpha=.15)
        ax.spines[['top', 'right']].set_visible(False)
    note = ('Pointwise 95% conditional MI intervals; overlapping cohorts, not independent replications.\n'
            'X: child-contact frequency; Z: baseline SD or signed contrast. Each Z uses its own frozen reference SD.\n'
            'Intercept paths are conditional on x1/y1 direct paths. Full dynamic moderation and H4 remain incomplete.')
    if receipt['status'] == 'PRIOR_ONLY_REHEARSAL':
        note += '\nREHEARSAL: income data intentionally not read; no final income result is implied.'
    fig.suptitle('CHARLS H4.1: direct tests of resource-group differences', fontsize=14)
    fig.text(.03, .025, note, fontsize=9, va='bottom')
    fig.tight_layout(rect=(0, .15, 1, .94))
    fig.savefig(root / 'H41_GROUP_DIFFERENCES.pdf')
    fig.savefig(root / 'H41_GROUP_DIFFERENCES.png', dpi=160)
    plt.close(fig)
    print(str(root / 'H41_GROUP_DIFFERENCES.pdf'))

if __name__ == '__main__':
    main()
