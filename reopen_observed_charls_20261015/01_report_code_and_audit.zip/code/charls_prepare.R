# 新的连续PP-LGCM入口：只读取历史子女长表及原始CESD题目，不使用旧类别/插补。
library(haven);library(dplyr);library(jsonlite);library(digest)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/reopen_observed_charls_20261015'
BASE<-'<LOCAL_USER_HOME>/Desktop/开题报告/0_data_clo'
RAW<-'<LOCAL_USER_HOME>/Desktop/20230505 毕业论文/开题报告/开题报告/CHARLS'
yrs<-c(2011,2013,2015,2018,2020)
wj<-function(x,p)write_json(x,p,pretty=TRUE,auto_unbox=TRUE,na='null',null='null',digits=16)
csv<-function(x,p)write.csv(x,p,row.names=FALSE,na='')
hashes<-list();labels<-list();wave_audit<-list();waves<-list();cesds<-list()
record<-function(p){hashes[[length(hashes)+1L]]<<-data.frame(file=p,sha256=digest(file=p,algo='sha256'))}
read_source<-function(p,...){record(p);read_dta(p,...)}
update<-function(stage,msg){cat(stage,msg,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(stage,msg)}
for(k in seq_along(yrs)){
 y<-yrs[k];update('charls_measurement',as.character(y));base<-file.path(RAW,paste0('CHARLS',y),'Data')
 l<-read_source(file.path(BASE,paste0('contact_',y,'_long.dta')))
 stopifnot(!anyDuplicated(paste(l$pid,l$ID_c2gc,sep=':')))
 fam<-read_source(list.files(base,pattern='^family_information.dta$',ignore.case=TRUE,full.names=TRUE),n_max=0)
 locvar<-grep('^cb053_1_?$',names(fam),value=TRUE)
 if(length(locvar))labels[[paste0(y,'_residence')]]<-as.list(attr(fam[[locvar[1]]],'labels'))
 # 跨波居住类别不同；只承认明确同住，邻院/邻楼不能填最高频率。
 meet<-ifelse(l$cd003_ %in% 1:9,10-as.numeric(l$cd003_),NA_real_)
 cores<-if(y==2011) l$cb053_ %in% 1 else if(y<2020) l$cb053_ %in% 1:2 else l$cd003_w4_ %in% 12
 meet[is.na(meet)&cores]<-9
 sex<-as.numeric(l$cb049_);sex[!sex %in% 1:2]<-NA
 birth<-as.numeric(l$cb051_1_);birth[birth<1800|birth>y]<-NA
 pid<-as.character(l$pid);fid<-as.character(l$fid)
 if(y==2011){stopifnot(all(nchar(pid)==11),all(nchar(fid)==9));pid<-paste0(fid,'0',substr(pid,nchar(pid)-1,nchar(pid)));fid<-paste0(fid,'0')}
 d<-data.frame(pid=pid,fid=fid,age=as.numeric(l$age),meet=meet,sex=sex,birth=birth)
 wave_audit[[k]]<-data.frame(year=y,source_children=nrow(l),source_parents=length(unique(pid)),old_contact_valid=sum(!is.na(l$contact1)),new_contact_valid=sum(!is.na(meet)),old_filled_now_missing=sum(!is.na(l$contact1)&is.na(meet)),changed_nonmissing=sum(abs(as.numeric(l$contact1)-meet)>1e-8,na.rm=TRUE),cores_filled=sum(is.na(l$cd003_)&cores))
 # 指标只对有有效频率的已报告子女定义；不把未报告子女当零。
 gap<-function(v,g){if(anyNA(g)||!any(g)||all(g))return(NA_real_);mean(v[g])-mean(v[!g])}
 rankgap<-function(v,b,s=NULL){if(anyNA(b)||(!is.null(s)&&anyNA(s)))return(NA_real_);eligible<-if(is.null(s))rep(TRUE,length(b)) else s==1;if(!any(eligible))return(NA_real_);g<-eligible&b==min(b[eligible]);if(sum(g)!=1L)return(NA_real_);gap(v,g)}
 d<-d[!is.na(d$meet),]
 a<-d %>% group_by(pid) %>% summarise(fid=first(fid),age=first(age),n=n(),x=if(n()>=2)mean(meet) else NA_real_,sd=if(n()>=2)sd(meet) else NA_real_,gender=gap(meet,sex==1),oldest=rankgap(meet,birth),son=rankgap(meet,birth,sex),.groups='drop')
 stopifnot(!anyDuplicated(a$pid));names(a)[!names(a)%in%'pid']<-paste0(names(a)[!names(a)%in%'pid'],k);waves[[k]]<-a
 # 五波均从十题原始回答重算；2018题目在Cognition，2020题号移动7位。
 hp<-list.files(base,pattern=if(y==2018)'^cognition.dta$' else '^health_status_and_functioning.dta$',ignore.case=TRUE,full.names=TRUE)
 items<-paste0('dc',sprintf('%03d',if(y==2020)16:25 else 9:18))
 h<-read_source(hp,col_select=all_of(c('ID','householdID',items)))
 labels[[paste0(y,'_CESD')]]<-setNames(lapply(h[items],function(v)list(question=attr(v,'label'),codes=as.list(attr(v,'labels')))),items)
 mat<-as.matrix(as.data.frame(lapply(h[items],as.numeric)));mat[!mat%in%1:4]<-NA_real_
 good<-rowSums(!is.na(mat))==10L
 scored<-mat-1;scored[,c(5,8)]<-4-mat[,c(5,8)]
 total<-rowSums(scored);total[!good]<-NA_real_
 stopifnot(all(is.na(total)|total>=0&total<=30))
 pid<-as.character(h$ID);if(y==2011)pid<-paste0(as.character(h$householdID),'0',substr(pid,nchar(pid)-1,nchar(pid)))
 stopifnot(!anyDuplicated(pid));z<-data.frame(pid=pid,total=total);names(z)[2]<-paste0('y',k);cesds[[k]]<-z
 wave_audit[[k]]$health_rows<-nrow(h);wave_audit[[k]]$complete10<-sum(good)
 # 仅本地保存逐人分数及完整作答标志；不进入发布白名单。
 saveRDS(data.frame(pid=pid,complete10=good,total=total),file.path(ROOT,'private',paste0('cesd_',y,'.rds')))
}
d<-waves[[1]]
for(k in 2:5)d<-left_join(d,waves[[k]],by='pid')
for(k in 1:5)d<-left_join(d,cesds[[k]],by='pid')
keep_age<-!is.na(d$age1)&d$age1>=60
keep_base<-keep_age&d$n1>=2&!is.na(d$x1)&!is.na(d$y1)
keep<-keep_base&rowSums(!is.na(d[paste0('x',2:5)]))>=1&rowSums(!is.na(d[paste0('y',2:5)]))>=1
flow<-data.frame(stage=c('Baseline_reported_children','Baseline_age60plus','Baseline_two_children_and_XY','Plus_X_and_Y_followup'),N=c(nrow(d),sum(keep_age),sum(keep_base),sum(keep)))
d<-d[keep,];stopifnot(nrow(d)>100,!anyNA(d$fid1),!anyDuplicated(d$pid))
# 与旧已发布处理链只比较，不以旧值强制覆盖新值。
old<-read_source(file.path(BASE,'depression_contact_2011_20_unbal.dta'))
j<-match(d$pid,as.character(old$pid));comparison<-do.call(rbind,lapply(1:5,function(k){a<-d[[paste0('y',k)]];b<-as.numeric(old[[paste0('r',k,'cesd10')]])[j];data.frame(year=yrs[k],both=sum(!is.na(a)&!is.na(b)),unequal=sum(abs(a-b)>1e-7,na.rm=TRUE),new_missing_old_valid=sum(is.na(a)&!is.na(b)),new_valid_old_missing=sum(!is.na(a)&is.na(b)))}))
scales<-data.frame(process=c('X_contact_mean','Y_CESD10'),mean=c(mean(d$x1),mean(d$y1)),sd=c(sd(d$x1),sd(d$y1)))
out<-data.frame(fid=match(d$fid1,unique(d$fid1)))
for(k in 1:5)out[[paste0('x',k)]]<-(d[[paste0('x',k)]]-scales$mean[1])/scales$sd[1]
for(k in 1:5)out[[paste0('y',k)]]<-(d[[paste0('y',k)]]-scales$mean[2])/scales$sd[2]
for(v in c('sd','gender','oldest','son'))out[[paste0('z_',v)]]<-d[[paste0(v,1)]]
saveRDS(d,file.path(ROOT,'private/charls_cohort.rds'));saveRDS(out,file.path(ROOT,'private/charls_mplus_frame.rds'))
write.table(out,file.path(ROOT,'private/charls_continuous.dat'),row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
desc<-do.call(rbind,lapply(1:5,function(k)data.frame(year=yrs[k],nX=sum(!is.na(d[[paste0('x',k)]])),nY=sum(!is.na(d[[paste0('y',k)]])),nXY=sum(!is.na(d[[paste0('x',k)]])&!is.na(d[[paste0('y',k)]])),meanX=mean(d[[paste0('x',k)]],na.rm=TRUE),sdX=sd(d[[paste0('x',k)]],na.rm=TRUE),meanY=mean(d[[paste0('y',k)]],na.rm=TRUE),sdY=sd(d[[paste0('y',k)]],na.rm=TRUE))))
csv(flow,file.path(ROOT,'results/CHARLS_SAMPLE_FLOW.csv'));csv(desc,file.path(ROOT,'results/CHARLS_DESCRIPTIVES.csv'));csv(scales,file.path(ROOT,'results/CHARLS_BASELINE_SCALING.csv'))
csv(do.call(rbind,wave_audit),file.path(ROOT,'audit/CHARLS_MEASUREMENT_AUDIT.csv'));csv(comparison,file.path(ROOT,'audit/CHARLS_CESD_LEGACY_COMPARISON.csv'));csv(do.call(rbind,hashes),file.path(ROOT,'audit/CHARLS_SOURCE_HASHES.csv'));wj(labels,file.path(ROOT,'audit/CHARLS_RAW_LABELS.json'))
wj(list(status='PREPARED_FOR_UNADJUSTED_PILOTS',N=nrow(d),families=length(unique(d$fid1)),years=yrs,time=c(0,2,4,7,9),names=names(out),source_scope='Existing child-long records after historic valid-contact selection; not a new unrestricted household-roster reconstruction',ties='No arbitrary birth-rank tie break: ambiguous rank gap missing',CESD='10 valid items; negative items value-1; hopeful/happy 4-value',contact='Ordinal frequency score 1-9, adjacent residence not sufficient for daily; baseline scaling fixed over waves',full_MI=FALSE),file.path(ROOT,'results/CHARLS_DATA_RECEIPT.json'))
update('charls_data_ready',paste(nrow(d),'people; no model launched by preparation script'))
