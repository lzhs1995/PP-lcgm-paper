"""独立Python从Stata列重算，输出汇总核验；不发布ID或逐人记录。"""
from pathlib import Path
import pandas as pd, numpy as np, hashlib,json
root=Path('<LOCAL_USER_HOME>/pp_lgcm_review/reopen_observed_charls_20261015')
base=Path('<LOCAL_USER_HOME>/Desktop/开题报告/0_data_clo')
raw=Path('<LOCAL_USER_HOME>/Desktop/20230505 毕业论文/开题报告/开题报告/CHARLS')
target=pd.read_csv(root/'private/charls_score_check.csv',dtype={'pid':str}).set_index('pid')
rows=[]
for k,year in enumerate([2011,2013,2015,2018,2020],1):
    folder=raw/f'CHARLS{year}'/'Data'
    hp=next(x for x in folder.iterdir() if x.name.lower()==('cognition.dta' if year==2018 else 'health_status_and_functioning.dta'))
    items=[f'dc{i:03d}' for i in (range(16,26) if year==2020 else range(9,19))]
    h=pd.read_stata(hp,columns=['ID','householdID']+items,convert_categoricals=False)
    pid=h.ID.astype(str)
    if year==2011:pid=h.householdID.astype(str)+'0'+pid.str[-2:]
    a=h[items].where(h[items].isin([1,2,3,4]));a=a-1
    a[items[4]]=3-a[items[4]];a[items[7]]=3-a[items[7]]
    score=a.sum(axis=1,min_count=10);score.index=pid
    match=score.reindex(target.index)
    expected=target[f'y{k}']; cesd_bad=~((match.isna()&expected.isna())|np.isclose(match,expected,equal_nan=True))
    cols=['pid','fid','cd003_']+(['cd003_w4_'] if year==2020 else ['cb053_'])
    l=pd.read_stata(base/f'contact_{year}_long.dta',columns=cols,convert_categoricals=False)
    pid=l.pid.astype(str)
    if year==2011:pid=l.fid.astype(str)+'0'+pid.str[-2:]
    # Stata float列由pandas保持float32；先转double，避免分组均值/SD的单精度舍入。
    freq=10-l.cd003_.astype('float64').where(l.cd003_.isin(range(1,10)))
    cores=l.cd003_w4_.eq(12) if year==2020 else l.cb053_.isin([1] if year==2011 else [1,2])
    freq=freq.mask(freq.isna()&cores,9)
    z=pd.DataFrame({'pid':pid,'freq':freq}).groupby('pid').freq.agg(['count','mean','std'])
    z.loc[z['count']<2,['mean','std']]=np.nan
    z=z.reindex(target.index)
    xbad=~np.isclose(z['mean'],target[f'x{k}'],equal_nan=True,atol=1e-12,rtol=1e-12)
    sbad=~np.isclose(z['std'],target[f'sd{k}'],equal_nan=True,atol=1e-12,rtol=1e-12)
    rows.append({'year':year,'N_checked':len(target),'CESD_differences':int(cesd_bad.sum()),'Xmean_differences':int(xbad.sum()),'Xsd_differences':int(sbad.sum())})
ok=all(all(r[n]==0 for n in ['CESD_differences','Xmean_differences','Xsd_differences']) for r in rows)
hashes=pd.read_csv(root/'audit/CHARLS_SOURCE_HASHES.csv');hashok=all(hashlib.sha256(Path(r.file).read_bytes()).hexdigest()==r.sha256 for r in hashes.itertuples())
res={'status':'PASS' if ok and hashok else 'FAIL','implementation':'Independent pandas Stata read and arithmetic; compared with native R cohort','comparisons':rows,'source_hashes_unchanged':hashok,'rows_private':True}
(root/'audit/CHARLS_INDEPENDENT_VALIDATION.json').write_text(json.dumps(res,indent=2),encoding='utf-8');print(json.dumps(res))
assert ok and hashok
