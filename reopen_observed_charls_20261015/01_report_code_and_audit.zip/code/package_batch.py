"""逐文件公开选择；真实微观数据/MI/得分不进入ZIP或Git。"""
from pathlib import Path
import json,csv,hashlib,zipfile,io,re,shutil,datetime
root=Path('<LOCAL_USER_HOME>/pp_lgcm_review/reopen_observed_charls_20261015')
stage=root/'public_stage';stage.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
selected={}
for n in ['reports/REPORT.md','reports/FOR_WEB_REVIEWERS.md','reports/BATCH_RECEIPT.json',
 'contracts/RUN_CONTRACT.json','contracts/INFERENCE_BOUNDARIES.md','contracts/H4_REGISTER.csv',
 'results/CALLS.csv','results/PILOT_PATHS.csv','results/CFPS_PILOTS.json','results/CHARLS_PILOTS.json',
 'results/FOUR_MODERATION_REGISTER.json','results/CHARLS_DATA_RECEIPT.json','results/CHARLS_SAMPLE_FLOW.csv',
 'results/CHARLS_DESCRIPTIVES.csv','results/CHARLS_BASELINE_SCALING.csv',
 'results/CHARLS_DESCRIPTIVE_TRAJECTORIES.pdf','results/CHARLS_DESCRIPTIVE_TRAJECTORIES.png',
 'audit/CFPS_REUSED_HISTORY.json','audit/CHARLS_MEASUREMENT_AUDIT.csv','audit/CHARLS_CESD_LEGACY_COMPARISON.csv',
 'audit/CHARLS_SOURCE_HASHES.csv','audit/CHARLS_INDEPENDENT_VALIDATION.json',
 'audit/CHARLS_INDEPENDENT_VALIDATION_float32_failure.json','audit/FINAL_READBACK.json','audit/splice_check_regression.json',
 'audit/R_SESSION_INFO.txt',
 'code/pilot.R','code/charls_prepare.R','code/charls_pilot.R','code/charls_syntax_recovery.R',
 'code/charls_verify_and_plot.R','code/verify_charls.py','code/run_one.R','code/engine.py',
 'code/r2e_local.R','code/r2e_tools.R','code/r2e_upstream_math.R','code/register_remaining.py','code/finish_batch.py','code/package_batch.py']:
 selected[n]='report_or_aggregate_or_code'
ids=[r['id'] for r in csv.DictReader((root/'results/CALLS.csv').open(encoding='utf-8'))]
for name in ids:
 for fn in ['model.inp','model.out','engine_receipt.json','receipt.json','validation.json','parameters_high_precision.csv','key_paths.csv','matrix_values.csv','tech1_parameter_map.csv','parameter_covariance.csv','estimates.dat','tech3.dat','failure_classification.json']:
  n=f'models/{name}/{fn}'
  if (root/n).exists():selected[n]='aggregate_model_output' if fn!='model.inp' else 'model_syntax'
# estimates.dat/tech3.dat为保存的参数/协方差，不是SAVEDATA逐人得分；数据文件名唯一data.dat且不在白名单。
payload={};manifest=[]
for n,role in selected.items():
 p=root/n;assert p.is_file();assert not n.startswith('private/') and p.name not in ['data.dat','job.json'] and p.suffix!='.rds'
 b=p.read_bytes();before=sha(b);transformed=False
 if p.suffix.lower() not in ['.pdf','.png']:
  txt=b.decode('utf-8-sig',errors='strict')
  for prefix in ['<LOCAL_USER_HOME>','<LOCAL_USER_HOME>','C:\\\\Users\\\\LZHS','<LOCAL_USER_HOME>','<LOCAL_USER_HOME>']:
   if prefix in txt:txt=txt.replace(prefix,'<LOCAL_USER_HOME>');transformed=True
  b=txt.encode('utf-8')
  assert not re.search(r'(?i)(?:api[_-]?key|access_token)\s*[:=]\s*["\']?[A-Za-z0-9_-]{20,}',txt)
  if p.suffix=='.csv' and p.name not in ['parameter_covariance.csv']:
   fields=next(csv.reader(io.StringIO(txt)),[])
   assert not set(x.lower() for x in fields)&{'pid','fid','householdid','pair_pid','communityid'},(n,fields)
   if 'id' in fields:
    # 唯一例外为已核验的模型调用ID；不是逐人ID的通用豁免。
    assert n=='results/CALLS.csv'
    assert {r['id'] for r in csv.DictReader(io.StringIO(txt))}==set(ids)
 payload[n]=b;manifest.append({'path':n,'role':role,'bytes':len(b),'sha256':sha(b),'local_source_sha256':before,'local_paths_redacted':transformed})
payload['PAYLOAD_MANIFEST.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8')
packages=[]
for category,filename in [('report','01_report_code_and_audit.zip'),('models','02_model_evidence.zip')]:
 chosen=[n for n in payload if n.startswith('models/')==(category=='models')]
 p=stage/filename
 with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n in chosen:z.writestr(n,payload[n])
 assert p.stat().st_size<=25_000_000
 with zipfile.ZipFile(p) as z:assert z.testzip() is None
 packages.append({'file':filename,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'files':len(chosen)})
for name in ['REPORT.md','FOR_WEB_REVIEWERS.md','BATCH_RECEIPT.json']: (stage/name).write_bytes(payload['reports/'+name])
(stage/'PACKAGE_MANIFEST.json').write_text(json.dumps({'packages':packages,'payload_files':len(payload),'privacy':'Explicit reviewed file selection; no participant DAT/RDS/scores/identifiers; estimates.dat and tech3.dat contain aggregate parameters/covariance only','payload_manifest':'Inside 01_report_code_and_audit.zip; excludes its own hash','source_hashes':'Local source hash vs redacted public payload hash explicitly separated'},ensure_ascii=False,indent=2),encoding='utf-8')
(root/'audit/PUBLIC_FILE_SELECTION.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
(stage/'README.md').write_text('''# PP-LGCM：2026-10-15有限研究重启

入口：[报告](REPORT.md) · [网页评议说明](FOR_WEB_REVIEWERS.md) · [批次回执](BATCH_RECEIPT.json) · [包清单](PACKAGE_MANIFEST.json)

8次调用，约19.2分钟（含启动）。CHARLS三个未调整连续增长模型合法；CFPS自由SD交互仍负残差；H4.1一份合法，H4.2到限停止。四项调节/完整H4仍未完成。

包01含报告、代码、审计与汇总图；包02含模型语法、原始输出、参数和协方差。每包小于25MB。没有微观数据或真实MI对象，云端可复核保存结果但不能据此重拟合。

此前范围收缩稿保持。技能经验已提交至 [guide分支](https://github.com/lzhs1995/clauder-rstudio-workbench/tree/61a36a89fff9c811432296369ac52a9fae00b933/skills/mplusautomation-guide)。本批文档不是新稿件，无新NLM循环。
''',encoding='utf-8')
print(json.dumps({'packages':packages,'payload_files':len(payload),'selected':len(selected)},ensure_ascii=False))
