# 一次明确语法修复，使用独立目录并计入RECOVERY，不修改模型科学结构。
Sys.setenv(PP_PREPARE_ONLY='1')
source('<LOCAL_USER_HOME>/pp_lgcm_review/reopen_observed_charls_20261015/code/charls_pilot.R',local=TRUE)
Sys.unsetenv('PP_PREPARE_ONLY')
old<-file.path(ROOT,'models/CHARLS_PP_LINEAR_UNADJUSTED');d<-paste0(old,'_syntax_fix')
dir.create(d,showWarnings=FALSE);j<-rj(file.path(old,'job.json'))
lines<-readLines(file.path(old,'model.inp'));needle<-'sy ON ix (bis) sx (bss) iy (bsyiy);';stopifnot(sum(lines==needle)==1L)
i<-match(needle,lines);new<-append(lines[-i],c('sy ON ix (bis);','sy ON sx (bss);','sy ON iy (bsyiy);'),after=i-1L)
stopifnot(identical(new[-seq.int(i,i+2L)],lines[-i]))
# 逐语句核对三条路径与原合同一致；唯一变更是拆开带标签的回归语句。
stopifnot(all(c('sy ON ix (bis);','sy ON sx (bss);','sy ON iy (bsyiy);')%in%new))
writeLines(new,file.path(d,'model.inp'));stopifnot(file.copy(file.path(old,'data.dat'),file.path(d,'data.dat')))
j$id<-basename(d);j$dest<-d;j$category<-'RECOVERY';j$cap_seconds<-300;j$hashes<-list(model.inp=hashf(file.path(d,'model.inp')),data.dat=hashf(file.path(d,'data.dat')))
wj(j,file.path(d,'job.json'));wj(list(status='INPUT_SYNTAX_ERROR',cause='Mplus permits one parenthesized parameter label at statement end; split three labelled ON paths',replacement=j$id,changes_data=FALSE,changes_statistical_paths=FALSE),file.path(old,'failure_classification.json'))
progress('syntax_recovery_start',j$id)
p<-processx::process$new(PY,c('-X','utf8',file.path(ROOT,'code/engine.py'),file.path(d,'job.json')),stdout=file.path(d,'supervisor.log'),stderr='2>&1',cleanup=TRUE)
while(p$is_alive()){p$wait(1000L);if(exists('clauder_progress',mode='function'))clauder_progress('syntax_recovery',j$id)}
res<-check(j);a<-rj(file.path(ROOT,'results/CHARLS_PILOTS.json'));a$PP_syntax_fix<-res;wj(a,file.path(ROOT,'results/CHARLS_PILOTS.json'))
progress('CHARLS_RECOVERY_TERMINAL',res$status);cat('CHARLS_RECOVERY_TERMINAL\n')
