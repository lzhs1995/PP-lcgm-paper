library(jsonlite)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/reopen_observed_charls_20261015'
d<-readRDS(file.path(ROOT,'private/charls_cohort.rds'))
write.csv(d[c('pid',paste0('x',1:5),paste0('y',1:5),paste0('sd',1:5))],file.path(ROOT,'private/charls_score_check.csv'),row.names=FALSE,na='')
a<-read.csv(file.path(ROOT,'results/CHARLS_DESCRIPTIVES.csv'))
draw<-function(){par(mfrow=c(1,2),mar=c(4,4,3,1));plot(a$year,a$meanX,type='b',pch=19,xlim=c(2010.5,2020.5),ylim=c(min(a$meanX)-.04,max(a$meanX)+.07),xlab='Year',ylab='Mean frequency score (1-9)',main='Reported child contact');text(a$year,a$meanX,labels=paste0('n=',a$nX),pos=3,cex=.7);plot(a$year,a$meanY,type='b',pch=19,xlim=c(2010.5,2020.5),ylim=c(min(a$meanY)-.15,max(a$meanY)+.3),xlab='Year',ylab='Mean CESD-10 (0-30)',main='Depressive symptoms');text(a$year,a$meanY,labels=paste0('n=',a$nY),pos=3,cex=.7);mtext('Observed wave-specific means; changing response composition; not model predictions',outer=TRUE,line=-1,cex=.7)}
png(file.path(ROOT,'results/CHARLS_DESCRIPTIVE_TRAJECTORIES.png'),width=1300,height=600,res=120);draw();dev.off()
pdf(file.path(ROOT,'results/CHARLS_DESCRIPTIVE_TRAJECTORIES.pdf'),width=11,height=5);draw();dev.off()
cat('CHARLS aggregate plot and private validation input saved\n')
