# CHARLS首次连续增长小试；与CFPS共用预算及单槽，不占用其他会话。
library(jsonlite);library(digest);library(processx);library(MplusAutomation)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/reopen_observed_charls_20261015';Sys.setenv(R2E_ROOT=ROOT)
source(file.path(ROOT,'code/r2e_local.R'),local=TRUE)
growth<-function(p)paste0('i',p,' s',p,' | ',p,'1@0 ',p,'2@2 ',p,'3@4 ',p,'4@7 ',p,'5@9;')
specs<-list(X=list(fac=c('IX','SX'),obs=paste0('X',1:5),model=c(growth('x'),'ix WITH sx;')),
 Y=list(fac=c('IY','SY'),obs=paste0('Y',1:5),model=c(growth('y'),'iy WITH sy;')),
 PP=list(fac=FAC_XY,obs=OBS_XY,model=c(growth('x'),growth('y'),'iy ON ix (bii);','sy ON ix (bis);','sy ON sx (bss);','sy ON iy (bsyiy);','ix WITH sx;','sx WITH iy;',paste0('x',1:5,' WITH y',1:5,';'))))
prep<-function(sp){
 d<-file.path(ROOT,'models',paste0('CHARLS_',sp,'_LINEAR_UNADJUSTED'));dir.create(d,showWarnings=FALSE)
 if(file.exists(file.path(d,'job.json')))return(rj(file.path(d,'job.json')))
 si<-specs[[sp]];nn<-rj(file.path(ROOT,'results/CHARLS_DATA_RECEIPT.json'))$names
 lines<-c(paste0('TITLE: CHARLS ',sp,' continuous PP-LGCM pilot;'),'DATA: FILE=data.dat;','VARIABLE:',wrap90(paste('NAMES=',paste(nn,collapse=' '),';')),paste0('USEVARIABLES=',paste(tolower(si$obs),collapse=' '),';'),'MISSING=ALL(-9999);','CLUSTER=fid;','ANALYSIS: TYPE=COMPLEX; ESTIMATOR=MLR; PROCESSORS=1;','ITERATIONS=2000; COVERAGE=.005;','MODEL:',si$model,'OUTPUT: TECH1 TECH3 TECH4 TECH8 SVALUES CINTERVAL;','SAVEDATA: RESULTS=estimates.dat; TECH3=tech3.dat;')
 stopifnot(all(nchar(lines)<=90));writeLines(lines,file.path(d,'model.inp'))
 stopifnot(file.copy(file.path(ROOT,'private/charls_continuous.dat'),file.path(d,'data.dat')))
 j<-list(id=basename(d),root=ROOT,dest=d,spec=sp,category='CHARLS',cap_seconds=600,rscript=file.path(R.home('bin'),'Rscript.exe'),mplus=MPLUS,hashes=list(model.inp=hashf(file.path(d,'model.inp')),data.dat=hashf(file.path(d,'data.dat'))));wj(j,file.path(d,'job.json'));j
}
check<-function(j){
 er<-rj(file.path(j$dest,'engine_receipt.json'));if(is.null(er))return(list(id=j$id,status='NOT_RUN_RESOURCE_OR_BUDGET'))
 res<-list(id=j$id,spec=j$spec,engine_status=er$status,status=er$status,seconds=er$seconds,full_MI=FALSE,adjustment='none')
 if(er$status=='EXITED')tryCatch({
  n<-MplusAutomation::readModels(file.path(j$dest,'model.out'),what='all',quiet=TRUE);saveRDS(n,file.path(j$dest,'mplusautomation_readback.rds'))
  m<-read_mplus_raw(j$dest);si<-specs[[j$spec]];si$kind<-'linear';si$fixed_zero<-character()
  gt<-gate_r2e(m,si);res$status<-if(isTRUE(gt$passed))'USABLE_SINGLE_DATASET' else 'INADMISSIBLE';res$negative<-gt$negative
  if(any(grepl('FIXED TO AVOID SINGULARITY',m$lines,fixed=TRUE)))res$status<-'AUTOFIX_REJECTED'
  res$fit<-n$summaries;res$N<-n$summaries$Observations
  wj(gt,file.path(j$dest,'validation.json'));csv(m$par,file.path(j$dest,'parameters_high_precision.csv'));csv(m$values,file.path(j$dest,'matrix_values.csv'));csv(m$spec,file.path(j$dest,'tech1_parameter_map.csv'));write.table(m$V,file.path(j$dest,'parameter_covariance.csv'),sep=',',row.names=FALSE,col.names=FALSE)
  if(j$spec=='PP')csv(key_paths_r2e(m,KEY_XY),file.path(j$dest,'key_paths.csv'))
 },error=function(e){res$status<<-'READBACK_OR_ESTIMATION_FAILURE';res$error<<-conditionMessage(e)})
 res$output_sha256<-if(file.exists(file.path(j$dest,'model.out')))hashf(file.path(j$dest,'model.out')) else NULL
 wj(res,file.path(j$dest,'receipt.json'));res
}
charls_main<-function(){
jobs<-lapply(names(specs),prep);names(jobs)<-names(specs);wj(jobs,file.path(ROOT,'contracts/CHARLS_PILOT_JOBS.json'))
t0<-Sys.time()
repeat{
 cf<-rj(file.path(ROOT,'results/CFPS_PILOTS.json'))
 if(length(cf)==4L&&!file.exists(file.path(ROOT,'runtime/engine.lock')))break
 if(as.numeric(difftime(Sys.time(),t0,units='secs'))>1000)stop('CFPS coordinator not terminal; no conflicting engine launched')
 if(exists('clauder_progress',mode='function'))clauder_progress('waiting_engine_slot','CHARLS prepared; CFPS pilot owns single engine slot')
 Sys.sleep(20)
}
results<-list()
for(sp in names(jobs)){
 j<-jobs[[sp]]
 if(sp=='PP'&&!all(vapply(results,function(x)identical(x$status,'USABLE_SINGLE_DATASET'),logical(1)))){
  results[[sp]]<-list(id=j$id,status='DEFERRED_INVALID_UNIVARIATE_PARENT');wj(results,file.path(ROOT,'results/CHARLS_PILOTS.json'));next
 }
 if(file.exists(file.path(j$dest,'receipt.json'))){results[[sp]]<-rj(file.path(j$dest,'receipt.json'));next}
 progress('charls_estimate_start',j$id)
 p<-processx::process$new(PY,c('-X','utf8',file.path(ROOT,'code/engine.py'),file.path(j$dest,'job.json')),stdout=file.path(j$dest,'supervisor.log'),stderr='2>&1',cleanup=TRUE)
 last<-0
 while(p$is_alive()){
  p$wait(1000L)
  if(as.numeric(Sys.time())-last>25){h<-rj(file.path(ROOT,'runtime/progress.json'));if(exists('clauder_progress',mode='function'))clauder_progress(if(is.null(h$stage))'starting' else h$stage,paste(j$id,h$elapsed_seconds));last<-as.numeric(Sys.time())}
 }
 results[[sp]]<-check(j);wj(results,file.path(ROOT,'results/CHARLS_PILOTS.json'));progress('charls_estimate_end',paste(j$id,results[[sp]]$status))
}
progress('CHARLS_PILOT_TERMINAL','Prespecified linear pilots adjudicated; no class queue or MI started');cat('CHARLS_PILOT_TERMINAL\n')
}
if(!identical(Sys.getenv('PP_PREPARE_ONLY'),'1'))charls_main()
