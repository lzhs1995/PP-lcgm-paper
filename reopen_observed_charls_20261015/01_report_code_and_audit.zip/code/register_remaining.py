"""只读复用历史输出，登记四调节与H4待办；不启动Mplus。"""
from pathlib import Path
import json,csv,hashlib
root=Path('<LOCAL_USER_HOME>/pp_lgcm_review/reopen_observed_charls_20261015')
old=Path('<LOCAL_USER_HOME>/pp_lgcm_review/round2E_20261010/models')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for d in sorted(old.iterdir()):
    f=d/'receipt.json'
    if not d.name.startswith('CFPS_') or not f.exists():continue
    a=json.loads(f.read_text());rows.append({'id':d.name,'status':a['status'],'receipt_sha256':sha(f),'output_sha256':sha(d/'model.out') if (d/'model.out').exists() else None,'negative':a.get('negative'),'seconds':a.get('seconds')})
(root/'audit/CFPS_REUSED_HISTORY.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
zpath=Path('<LOCAL_USER_HOME>/pp_lgcm_review/round2D_20261008/audit/Z_CONTRACT.json');z=json.loads(zpath.read_text())
branches=[]
for b in ['SD','SEXGAP','OLDEST','SONGAP']:
    base=[r for r in rows if r['id'].startswith('CFPS_'+b+'_E0_')]
    inter=[r for r in rows if r['id'].startswith('CFPS_'+b+'_E1_')]
    branches.append({'branch':b,'Z0':'observed 2012, not latent IZ','orientation':z['z'][b]['orientation'],'N':z['samples'][b+'_Z0']['N'],'control_term':z['samples'][b+'_Z0']['ctrl_term'],'historical_E0_usable':sum(r['status']=='USABLE' for r in base),'historical_E1_usable':sum(r['status']=='USABLE' for r in inter),'complete_moderation_MI':False,'current_action':'Read new derivative pilot receipts; do not extend invalid model' if b=='SD' else 'Retain historical failures; unchanged specification not resubmitted'})
(root/'results/FOUR_MODERATION_REGISTER.json').write_text(json.dumps(branches,ensure_ascii=False,indent=2),encoding='utf-8')
hc=[]
for h in ['H4.1','H4.2']:
 for b in ['SD','SEXGAP','OLDEST','SONGAP']:
  for g in ['EDU','URBAN','INC']:
   hc.append({'family':h,'Z':b,'G':g,'G_one_means':z['g'][g]['one_means'],'target':'IY ON Z0*G; SY ON Z0*G' if h=='H4.1' else 'SY ON SX*Z0*G with all lower-order terms','pilot_this_batch':b=='SD' and g=='EDU','formal_MI':'NOT_COMPLETED','gate':'Legal estimate and complete registered MI family; not main interaction significance','multiplicity':'12 specification-level tests per H4 family; H4.1 uses joint 2-path Wald as primary, path intervals secondary; Holm across 12','inference':'Pool coefficients and full covariance, never average p-values; group difference tested directly'})
with (root/'contracts/H4_REGISTER.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=hc[0]);w.writeheader();w.writerows(hc)
(root/'contracts/INFERENCE_BOUNDARIES.md').write_text('''# 新批次推断边界

旧范围收缩稿及 SCOPED_CLOSEOUT_COMPLETE 保持；本批是作者另行批准的研究重启。
四项调节指 SX×观测2012 Z0→SY。SD、性别差、长幼差、长子差分别保留来源、定向、结构性缺失及各自样本；不把潜截距、观测起点和因子得分当等价模型。

首批只做有限可行性试验。H4.1/H4.2 各12个规格先登记，正式全量MI不在本批自动执行范围。H4.1 两条异质性路径的联合Wald为规格层主检验；H4.2直接检验三重交互，报告两组条件效应及其差。不同家庭作Holm校正，未运行项目保留未检验状态，不缩小分母选显著项。H4.2b不能凭一组显著另一组不显著来判定。

单份合法、十份合法、MI合并、科学采用、论文修订是不同状态。所有失败成员保留；不删除失败插补、不给负方差兜底、不平均p值、不将不同起点拼成MI。完整十份成功后才可作相应条件MI推断，仍需解释量尺、估计精度与模型限制。

本批SD导数试验在自由SY的E1上运行，非上轮可选的SY@0 E1B试验。保持30点积分，唯一数值变动为MCONVERGENCE=1e-5。两来源仍非法即关闭该小试，不在剩余额度内搜索新规格。

CHARLS为联系频率这一相邻构念的外部分析，非CFPS情感亲近度的同构复现。时间载荷0,2,4,7,9；新样本>=60岁，基期至少2名有有效频率的子女、基期X/Y有效且两过程各有后续信息。沿用已存子女长表的来源选择边界；不声称重建全部原始家庭花名册。CESD逐波须完整10题。本批未调整线性模型不构成已完成协变量控制、调节或资源异质性的外部验证。

预算7200秒是上限，不是必须耗完的目标。没有本批证据支持的家族不自动扩展。研究尚未完成的部分保留明确后续入口；不能将首批交付当四项调节或H4已完成。
''',encoding='utf-8')
print(json.dumps({'historical_CFPS_receipts':len(rows),'branches':len(branches),'H4_registered_specs':len(hc)}))
