"""汇总已结束的估计和剩余科学任务；不启动新估计。"""
from pathlib import Path
import json,csv,hashlib,datetime,math
import pandas as pd,numpy as np,psutil
root=Path('<LOCAL_USER_HOME>/pp_lgcm_review/reopen_observed_charls_20261015')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
write=lambda p,o:p.write_text(json.dumps(o,ensure_ascii=False,indent=2),encoding='utf-8')
budget=read(root/'runtime/budget_status.json');assert all(r['seconds'] is not None for r in budget['rows']) and budget['engine_seconds']<7200
assert not (root/'runtime/engine.lock').exists()
calls=[];checks=[];processes=[];params=[]
for r in budget['rows']:
 d=root/'models'/r['id'];e=read(d/'engine_receipt.json');s=read(d/'receipt.json');j=read(d/'job.json')
 assert all(sha(d/f)==h for f,h in e['hashes'].items())
 assert sha(d/'model.out')==s['output_sha256']
 p=read(d/'process.json');live=False
 try:live=abs(psutil.Process(p['pid']).create_time()-p['created'])<.001
 except psutil.NoSuchProcess:pass
 processes.append({'id':r['id'],'owned_runner_still_live':live});assert not live
 if (d/'failure_classification.json').exists():classification=read(d/'failure_classification.json')['status']
 else:classification=s['status']
 calls.append({'id':r['id'],'category':r['category'],'status':classification,'seconds':e['seconds'],'output_sha256':sha(d/'model.out'),'data_sha256':sha(d/'data.dat'),'input_sha256':sha(d/'model.inp'),'peak_tree_rss_MiB':e['peak_tree_rss']/2**20})
 if (d/'key_paths.csv').exists():
  a=pd.read_csv(d/'key_paths.csv');a['model']=r['id'];a['status']=classification;a['low95']=a.estimate-1.959963984540054*a.se;a['high95']=a.estimate+1.959963984540054*a.se;params.append(a)
 if classification in ['USABLE','USABLE_SINGLE_DATASET']:
  a=pd.read_csv(d/'parameters_high_precision.csv');V=np.loadtxt(d/'parameter_covariance.csv',delimiter=',');sd=np.sqrt(np.diag(V));C=V/np.outer(sd,sd)
  seok=bool(np.allclose(sd,a.se,rtol=1e-5,atol=1e-8));ev=float(np.linalg.eigvalsh(C).min());checks.append({'id':r['id'],'parameters':len(a),'saved_SE_matches_TECH3':seok,'minimum_correlation_eigenvalue':ev});assert seok and ev>1e-10
assert read(root/'audit/CHARLS_INDEPENDENT_VALIDATION.json')['status']=='PASS'
pd.DataFrame(calls).to_csv(root/'results/CALLS.csv',index=False);pd.concat(params,ignore_index=True).to_csv(root/'results/PILOT_PATHS.csv',index=False)
write(root/'audit/FINAL_READBACK.json',{'status':'PASS','inputs_outputs_hash_verified':len(calls),'independent_saved_covariance_checks':checks,'owned_runner_identity_checks':processes,'lock_absent':True,'CHARLS_measurement_independent':'PASS','not_checked':'Not a second fit or full MI validation'})
chars=read(root/'results/CHARLS_PILOTS.json');p=chars['PP_syntax_fix'];fit=p['fit'][0]
receipt={'status':'FIRST_BOUNDED_RESEARCH_BATCH_COMPLETE','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'Mplus_calls':len(calls),'charged_runner_engine_seconds':budget['engine_seconds'],'budget_seconds':7200,'new_usable_estimates':4,'CFPS_moderation_complete_MI_families':0,'CFPS_H4_complete_MI_families':0,'CHARLS_legal_unadjusted_models':3,'CHARLS_N':3006,'CHARLS_households':3006,'full_external_validation':False,'prior_scoped_manuscript':'UNCHANGED_SCOPED_CLOSEOUT_COMPLETE','automatic_queue':'STOPPED_AT_APPROVED_PILOT_BOUNDARY','next':'H4.1 SD x education complete MI feasibility; CHARLS prespecified adjustment/missingness contract; no unchanged CFPS E1 retry'}
write(root/'reports/BATCH_RECEIPT.json',receipt)
table='\n'.join('| '+c['id']+' | '+c['status']+' | '+f"{c['seconds']:.2f}"+' |' for c in calls)
cf=read(root/'results/CFPS_PILOTS.json');pp=pd.read_csv(root/'models/CHARLS_PP_LINEAR_UNADJUSTED_syntax_fix/key_paths.csv')
pathlines='\n'.join(f"| {a.row} ← {a.column} | {a.estimate:.6f} | [{a.estimate-1.959963984540054*a.se:.6f}, {a.estimate+1.959963984540054*a.se:.6f}] |" for a in pp.itertuples())
report=f'''# 四项调节、H4与CHARLS：首批有限研究重启报告

2026-10-15。本轮承接作者重新授权的研究任务。此前范围收缩稿和公开交付不修改；本报告不是新论文定稿。

## 实际完成

共8次Mplus调用，累计保守计费{budget['engine_seconds']:.2f}秒（约{budget['engine_seconds']/60:.2f}分钟，含Rscript启动及结束开销），低于7200秒上限。原生ClaudeR连接default@8787，经R/MplusAutomation调用Windows Mplus9；估计采用单槽，R数据准备与估计重叠。没有恢复历史分类队列，没有启动全量MI、Bayes、bootstrap或新NLM。

| 尝试 | 判定 | 计费秒 |
|---|---|---:|
{table}

正常退出不是合法估计。两个CFPS自由E1的SY残差方差分别为{cf['CFPS_SD_E1_DERIV_A']['sy']:.9f}、{cf['CFPS_SD_E1_DERIV_B']['sy']:.9f}，不能进入正式推断。唯一数值调整为导数准则1e-5，未改数据、积分点数或SY约束。本批没有执行旧SY@0 E1B可选试验。

H4.1的SD×教育得到一份合法估计；这是可行性进展，非H4已完成。H4.2的SD×教育三重交互600秒到限停止，计费{cf['CFPS_SD_H42_EDU_MI01']['seconds']:.2f}秒包含轮询/终止延迟。保留输入和部分输出，不将超时判为无效应。其他三个调节分支复用28份历史CFPS回执和原输出哈希，不重复未改变的失败规格。四项完整调节MI仍为0，完整H4 MI仍为0。

## CHARLS推进

新的连续PP-LGCM使用2011/2013/2015/2018/2020，载荷0/2/4/7/9；X是1—9级见面频率的子女均值，Y是0—30 CESD-10。基期>=60岁、至少2名有效频率子女、基期X/Y齐全且两过程各有后续观测，共3006人/3006家庭。各波统一按基期样本均值/SD标准化。

五波CESD从原始十题重算，反向题与题号逐波核对，2018题目在Cognition，2020为dc016—dc025。完整十题才形成总分。完整回答与旧得分逐人一致，但2013/2015/2018分别有198/268/394条旧有效值在严格完整作答规则下转为缺失；这是明确的缺失规则改变，不能据此称所有旧分数错误。

居住编码逐波不同，不能把邻院/邻楼自动填每天见面。新规则令2011/2013/2015/2018的12/73/144/955条已存子女频率转为缺失；2020没有此类变化。保留明确同住的最高频率。数据仍来自已存子女长表，继承历史有效联系选择边界，不冒称重新恢复全部原始家庭花名册。排行并列不按行号任意打破，相关基期差值暂缺失。

独立pandas核验3006×5×3=45090个CESD、X均值、X标准差槽位，含缺失状态，最终差异0；原始来源哈希未变。最初核验器对2011/2013保留float32，产生约1e-7舍入差；改为float64后与R double一致。旧失败记录也保留。

三条预定未调整线性模型均合法。联合模型CFI={fit['CFI']:.3f}、TLI={fit['TLI']:.3f}、RMSEA={fit['RMSEA_Estimate']:.3f}、SRMR={fit['SRMR']:.3f}。首次联合调用为生成器标签语法错误，未开始估计；拆开三条带标签回归语句后，在新目录成功，数据/路径不变。该修复也计费，失败输入保留。

| 联合模型路径 | 估计 | 95%正态近似区间 |
|---|---:|---|
{pathlines}

这里的起点关联为负，变化关联区间较宽。它们来自未调整模型，不能作因果、调节或资源差异结论。联系频率是相邻构念，不能称对CFPS情感亲近度的同构复现。TYPE=COMPLEX且一人一家庭不等于完成复杂调查权重校正。

## 效率与故障

Windows准入时约有3 GiB可用物理内存，实际模型进程内存占用较小；现有证据未显示本批受内存容量卡住。CFPS交互耗时与非法残差边界才是本批主要限制。不能从该观察宣称多开必定解决，也未做多引擎加速基准。本批使用单引擎和并行R准备，及时关闭无新增信息的尝试，不为耗完两小时继续估计。

准备阶段修复了把科学计数法e误认成变量的检查器；增加真实未知变量的反例校验。首个CFPS异步提交source未用local=TRUE，MCP阶段停在started，但独立进程心跳和持久日志正常推进；CHARLS改用local=TRUE后MCP进度与终态正常。该显示问题没有触发重估。

## 下一步科学入口

1. CFPS H4.1：优先把已合法的SD×教育扩为完整固定MI家族；先核验第二起点、完整控制集与同样本，再估计其余9份。任一成员不可采用即保留失败，不删成员合并。第一份合法不能预测另外9份。当前只登记后续任务，本批不自动扩展。
2. CFPS四调节：自由E1的负残差问题没有解决。其他三个分支保留原失败，不再加迭代/换种子盲重跑；只有对约束、量尺、联合结构或估计对象提出明确科学变更时，另列有限比较。不得让其拖住CHARLS。
3. H4.2：本批只有超时证据，不能宣称已证实不识别或零效应。下一批先定位积分与迭代日志，再决定是否值得在同规格/科学上等价实现下做一次有界性能比较。不得以缩短运行时间为由悄悄删低阶项或固定SY。
4. CHARLS：以三条合法未调整模型为父模型，先冻结与CFPS可比但不机械照搬的基期调整集、收入定义与缺失处理；依次加基期观测差异E0和四项交互。不得复用旧类别模型的FCS插补；不把部分子女缺失当零。正式估计前保留结构性缺失、同源指标和波次覆盖诊断。
5. H4正式分析：H4.1/H4.2各12规格，分别保留完整检验范围；按参数和协方差合并，直接检验组间差。登记表包含教育/城乡/个人正收入含义，个人正收入不叫高收入。本次书面矩阵在小试后整理，非事前预注册；用于冻结后续完整家族。
6. 论文与发布：原稿不覆盖。只有后续新增完整可采用推断才形成新的稿件候选并进入既定NLM流程。本批只发布诊断报告、汇总图和模型证据，微观数据/MI对象留本机。

## 文件入口

- results/CALLS.csv：全部调用及输入输出哈希。
- results/CHARLS_PILOTS.json、CFPS_PILOTS.json：原生读取与判定。
- audit/FINAL_READBACK.json：输出身份、保存SE/TECH3、终态与原生门槛。
- contracts/H4_REGISTER.csv：24规格，完整MI仍未完成。
- results/FOUR_MODERATION_REGISTER.json：四调节的已知失败与当前入口。
- results/CHARLS_DESCRIPTIVE_TRAJECTORIES.pdf：描述性均值图，样本构成随波次变化，非拟合轨迹。

本批已完成；四项调节完整推断、完整H4及调整后的CHARLS外部研究未完成。
'''
(root/'reports/REPORT.md').write_text(report,encoding='utf-8')
(root/'reports/FOR_WEB_REVIEWERS.md').write_text('''# 网页审阅入口：2026-10-15首批研究重启

先读REPORT.md及BATCH_RECEIPT.json。本次作者重新授权有限研究，不改此前已验收的范围收缩稿。新增8次调用，约19.2分钟（含启动）；CFPS自由E1两次仍负残差，H4.1单份合法，H4.2超时；CHARLS三个未调整线性模型合法。四项调节和H4完整MI仍未完成。

请只评价后续研究的边际价值：H4.1完整家族是否是CFPS最低成本入口；H4.2超时是否有具体同规格优化依据；CHARLS基期调整/缺失合同如何冻结。请区分未估计、非法解、超时和无明确关联，不要求重复收尾审阅，不把未调整CHARLS当完整外部验证。

包内不含微观DAT、RDS、逐人ID或真实MI对象，不能声称在云端重拟合。可用参数、TECH3、原始out复核保存结果。公开代码中的<LOCAL_USER_HOME>须替换为本机根路径，重新运行还需本地授权数据、上游代码/对象和Mplus许可证。源码本机哈希与公开脱敏载荷哈希在清单中分开记录。
''',encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
