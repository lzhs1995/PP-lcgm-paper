# 仅重绘已经合并的统计量，避免长标题/横轴文字被面板裁切。
library(jsonlite)
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_baseline_income_models_20261018'
p<-read.csv(file.path(ROOT,'results/POOLED_PATHS.csv'))
pdf(file.path(ROOT,'results/RESOURCE_GROUP_DIFFERENCES.pdf'),width=10,height=6)
par(mfrow=c(1,2),mar=c(4,8,3,1),oma=c(1.2,0,0,0))
for(lab in c('gizg','gszg')){
 a<-subset(p,label==lab)
 plot(a$estimate,seq_len(nrow(a)),xlim=range(a$lower,a$upper),yaxt='n',xlab='Group difference [95% CI]',ylab='',main=if(lab=='gizg')'Depression intercept'else'Annual depression change',pch=19)
 axis(2,at=seq_len(nrow(a)),labels=a$family,las=2,cex.axis=.8)
 segments(a$lower,seq_len(nrow(a)),a$upper,seq_len(nrow(a)));abline(v=0,lty=2,col='gray50')
}
mtext('G1: baseline annual net household income >8730 CNY. Pointwise conditional MI intervals.',outer=TRUE,side=1,line=0,cex=.75)
dev.off()
jsonlite::write_json(list(status='PLOTTED_FROM_POOLED_STATISTICS',families=length(unique(p$family)),contrasts_plotted=2L*length(unique(p$family)),new_model_calls=0,new_imputations=0),file.path(ROOT,'audit/H41_PLOT_RECEIPT.json'),auto_unbox=TRUE,pretty=TRUE)
cat('H41_GROUP_DIFFERENCE_PLOT_COMPLETE\n')
