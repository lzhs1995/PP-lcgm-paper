"""独立按实际来源复算十二项Holm，未检验项不冒充P=1或零效应。"""
from pathlib import Path
import csv,json,hashlib,math
R=Path(__file__).resolve().parents[1];Z=R.parent/'charls_corrected_baseline_h41_20261018'
def rows(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def main():
    zfile=R/'related/Z_JOINT_D1.csv'
    if not zfile.exists():zfile=Z/'results/JOINT_D1.csv'
    src={r['family']:r for r in rows(zfile)}
    inc=R/'results/JOINT_D1.csv'
    if inc.exists():
        for r in rows(inc):assert r['family'] not in src;src[r['family']]=r
    expected={z+'_'+g for z in ('SD','GENDER','OLDEST','SON') for g in ('EDU','URBAN','INC')}
    out=rows(R/'results/CORRECTED_TWELVE_RESOURCE_JOINT_D1.csv')
    assert len(out)==12 and {r['family'] for r in out}==expected and set(src)<=expected
    ranked=sorted(src,key=lambda n:float(src[n]['p']));adjusted={};last=0.
    for i,n in enumerate(ranked):last=max(last,min(1.,(12-i)*float(src[n]['p'])));adjusted[n]=last
    for r in out:
        n=r['family']
        if n not in src:
            assert all(r[k]=='' for k in ('F','df1','df2','p','RIV','holm_p_planned12','bonferroni_p_planned12'));continue
        for k in ('F','df1','df2','p','RIV'):assert math.isclose(float(r[k]),float(src[n][k]),rel_tol=1e-12,abs_tol=1e-12)
        assert math.isclose(float(r['holm_p_planned12']),adjusted[n],rel_tol=1e-12,abs_tol=1e-12)
        assert math.isclose(float(r['bonferroni_p_planned12']),min(1.,12*float(src[n]['p'])),rel_tol=1e-12,abs_tol=1e-12)
    rec=dict(status='PASS',registered=12,available=len(src),unavailable=sorted(expected-set(src)),result_sha256=hashlib.sha256((R/'results/CORRECTED_TWELVE_RESOURCE_JOINT_D1.csv').read_bytes()).hexdigest(),full_H4_complete=False)
    (R/'audit/INDEPENDENT_TWELVE_RESOURCE_CHECK.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print(json.dumps(rec),flush=True)
if __name__=='__main__':main()
