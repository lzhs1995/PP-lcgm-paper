"""先渲染实际PDF；agent目视后另行绑定PNG哈希并核对绘图值。"""
from pathlib import Path
import csv,json,hashlib,sys
R=Path(__file__).resolve().parents[1]
pdf=R/'results/RESOURCE_GROUP_DIFFERENCES.pdf';png=R/'reports/RESOURCE_GROUP_DIFFERENCES.png'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
po=json.loads((R/'results/POOLING_RECEIPT.json').read_text())
assert po['pooled']>0,'No complete family; do not generate a misleading figure'
if sys.argv[1]=='render':
 import fitz
 with fitz.open(pdf) as d:
  assert len(d)==1
  d[0].get_pixmap(matrix=fitz.Matrix(1.7,1.7),alpha=False).save(png)
 print(json.dumps(dict(status='RENDERED_REQUIRES_ACTUAL_VIEW',png_sha256=sha(png),file=str(png))),flush=True)
elif sys.argv[1]=='confirm-viewed':
 assert len(sys.argv)==3 and sha(png)==sys.argv[2]
 def rows(p):
  with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
 p=rows(R/'results/POOLED_PATHS.csv');c=rows(R/'results/GROUP_CONTRASTS.csv');checks=[]
 for label,contrast in [('gizg','IY_group_difference'),('gszg','SY_group_difference')]:
  for x in [x for x in p if x['label']==label]:
   y=next(y for y in c if y['family']==x['family'] and y['contrast']==contrast)
   for n in ('estimate','lower','upper'):assert abs(float(x[n])-float(y[n]))<1e-12
   checks.append(dict(family=x['family'],label=label,estimate=float(x['estimate']),lower=float(x['lower']),upper=float(x['upper'])))
 assert len(checks)==2*po['pooled']
 rec=dict(status='PASS',actual_render_viewed=True,pages=1,panels=2,checks=checks,hashes={str(x.relative_to(R)):sha(x) for x in [pdf,png]},new_models=0,new_MI=0)
 (R/'audit/FIGURE_REVIEW.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('FIGURE_NUMERIC_AND_RENDER_REVIEW_PASS',flush=True)
else:raise ValueError('Unknown figure stage')
