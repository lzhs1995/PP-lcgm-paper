# 从全部40个合法成员和完整TECH3合并；正式组差检验而非比较两组星号。
library(jsonlite);library(mitml)
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_baseline_income_models_20261018';Sys.setenv(R2E_ROOT=ROOT)
source(file.path(ROOT,'code/r2e_local.R'),local=TRUE)
families<-rj(file.path(ROOT,'results/FAMILY_STATUS.json'));admission<-rj(file.path(ROOT,'audit/MI_ADMISSIONS.json'))
stopifnot(length(families)==4L,file.exists(file.path(ROOT,'runtime/MODELS_TERMINAL')))
stopifnot(!any(vapply(families,function(f)f$status=='RUNNING',TRUE)))
labs<-c('bii','bis','bss','bsyiy','gi0','gs0','gizg','gszg');overview<-list();joint<-list();allpaths<-list();allcontrast<-list();comparison<-list()
for(fam in names(families)){
 f<-families[[fam]];parts<-strsplit(fam,'_',fixed=TRUE)[[1]];z<-tolower(parts[1]);g<-parts[2]
 overview[[fam]]<-data.frame(family=fam,status=f$status,members=f$members,N=admission[[z]]$N)
 if(f$status!='FORTY_USABLE_PENDING_POOLING')next
 dest<-file.path(ROOT,'results',fam);dir.create(dest,showWarnings=FALSE)
 Q<-matrix(NA_real_,40,8,dimnames=list(NULL,labs));U<-list();src<-list();fits<-list()
 for(k in 1:40){
  d<-file.path(ROOT,'models',sprintf('CHARLS_%s_H41_%s_MI%02d_A',toupper(z),g,k));r<-rj(file.path(d,'receipt.json'));stopifnot(r$status=='USABLE_SINGLE_DATASET',r$N==f$N,identical(r$output_sha256,hashf(file.path(d,'model.out'))))
  p<-read.csv(file.path(d,'key_paths.csv'));p<-p[match(labs,p$label),];V<-as.matrix(read.csv(file.path(d,'parameter_covariance.csv'),header=FALSE));Q[k,]<-p$estimate;U[[k]]<-V[p$parameter,p$parameter];dimnames(U[[k]])<-list(labs,labs);stopifnot(max(abs(diag(U[[k]])-p$se^2))<1e-6)
  src[[k]]<-data.frame(member=k,source_dir=d,output_sha256=r$output_sha256,data_sha256=hashf(file.path(d,'data.dat')))
  ff<-r$fit[[1L]];fits[[k]]<-data.frame(member=k,CFI=ff$CFI,TLI=ff$TLI,RMSEA=ff$RMSEA_Estimate,SRMR=ff$SRMR)
 }
 po<-rubin_pool(Q,U);tab<-data.frame(family=fam,label=labs,po$table,row.names=NULL)
 csv(tab,file.path(dest,'POOLED_PATHS.csv'));csv(data.frame(label=labs,rubin_pool(Q,U,nu_com=admission[[z]]$communities-1)$table,row.names=NULL),file.path(dest,'CLUSTER_DF_SENSITIVITY.csv'))
 test<-mitml::testConstraints(qhat=lapply(1:40,function(k)setNames(Q[k,],labs)),uhat=U,constraints=c('gizg','gszg'),method='D1')
 jt<-data.frame(family=fam,F=test$test[1,1],df1=test$test[1,2],df2=test$test[1,3],p=test$test[1,4],RIV=test$test[1,5],bonferroni_p_planned12=min(1,12*test$test[1,4]))
 cs<-list(IY_Z_G0=c(gi0=1),IY_Z_G1=c(gi0=1,gizg=1),IY_group_difference=c(gizg=1),SY_Z_G0=c(gs0=1),SY_Z_G1=c(gs0=1,gszg=1),SY_group_difference=c(gszg=1))
 ct<-do.call(rbind,lapply(names(cs),function(n){a<-setNames(rep(0,8),labs);a[names(cs[[n]])]<-cs[[n]];data.frame(family=fam,contrast=n,pool_contrast(Q,U,a),row.names=NULL)}))
 csv(ct,file.path(dest,'GROUP_CONTRASTS.csv'));csv(jt,file.path(dest,'JOINT_D1.csv'));csv(data.frame(member=1:40,Q),file.path(dest,'MEMBER_ESTIMATES.csv'))
 csv(do.call(rbind,lapply(1:40,function(k)data.frame(member=k,expand.grid(row=labs,column=labs,stringsAsFactors=FALSE),covariance=as.vector(U[[k]])))),file.path(dest,'MEMBER_COVARIANCES.csv'))
 csv(do.call(rbind,src),file.path(dest,'MEMBER_SOURCES.csv'));csv(do.call(rbind,fits),file.path(dest,'FIT_BY_MEMBER.csv'))
 stable<-all(tab$MCSE_over_SE<.1)&&all(ct$MCSE_over_SE<.1)
 rec<-list(status=if(stable)'FORTY_CONDITIONAL_MI_POOLED'else'FORTY_POOLED_MCSE_LIMIT_RETAINED',family=fam,m=40,N=f$N,communities=admission[[z]]$communities,MCSE_over_SE_max=max(c(tab$MCSE_over_SE,ct$MCSE_over_SE)),group='0 annual net household income <=8730 CNY;1 >8730 CNY',conditional_interpretation='z0 and z0*G also predict x1/y1, so latent intercept paths are conditional, not total observed baseline associations',compatibility=admission[[z]]$compatibility,full_H4_complete=FALSE)
 wj(rec,file.path(dest,'RECEIPT.json'));overview[[fam]]$status<-rec$status;joint[[fam]]<-jt;allpaths[[fam]]<-tab;allcontrast[[fam]]<-ct
 comparison[[paste0(fam,'_MI')]]<-data.frame(family=fam,analysis='MI40',N=f$N,label=labs,tab[c('estimate','se','lower','upper')])
 d<-file.path(ROOT,'models',paste0('CHARLS_',toupper(z),'_H41_',g,'_CC_A'));r<-rj(file.path(d,'receipt.json'))
 if(r$status=='USABLE_SINGLE_DATASET'){p<-read.csv(file.path(d,'key_paths.csv'));comparison[[paste0(fam,'_CC')]]<-data.frame(family=fam,analysis='CC',N=r$N,label=p$label,estimate=p$estimate,se=p$se,lower=p$estimate-qnorm(.975)*p$se,upper=p$estimate+qnorm(.975)*p$se)}
}
csv(do.call(rbind,overview),file.path(ROOT,'results/FAMILY_OVERVIEW.csv'))
if(length(joint)){
 j<-do.call(rbind,joint);j$holm_p_planned12<-p.adjust(j$p,'holm',n=12)
 csv(j,file.path(ROOT,'results/JOINT_D1.csv'));csv(do.call(rbind,allpaths),file.path(ROOT,'results/POOLED_PATHS.csv'));csv(do.call(rbind,allcontrast),file.path(ROOT,'results/GROUP_CONTRASTS.csv'));csv(do.call(rbind,comparison),file.path(ROOT,'results/CC_MI_COMPARISON.csv'))
 source(file.path(ROOT,'code/plot_h41_results.R'),local=TRUE)
}
wj(list(status='FOUR_INCOME_FAMILIES_ADJUDICATED',registered=4,pooled=length(joint),complete_income_only=length(joint)==4,full_H4_complete=FALSE,original_CFPS_moderations_complete=FALSE),file.path(ROOT,'results/POOLING_RECEIPT.json'))
cat('CHARLS_H41_POOLING_TERMINAL complete families=',length(joint),'of4\n')
