# 只合并已冻结同来源的十二个H4.1资源比较；未形成推断项保持NA。
local({
 R<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_baseline_income_models_20261018'
 Z<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_baseline_h41_20261018'
 library(jsonlite);library(digest)
 stopifnot(fromJSON(file.path(R,'audit/INDEPENDENT_H41_VERIFICATION.json'))$status=='PASS',fromJSON(file.path(Z,'audit/INDEPENDENT_H41_VERIFICATION.json'))$status=='PASS')
 zfile<-file.path(Z,'results/JOINT_D1.csv');whitelist<-fromJSON(file.path(Z,'audit/PUBLIC_FILE_WHITELIST.json'))$files
 row<-whitelist[whitelist$file=='results/JOINT_D1.csv',]
 stopifnot(nrow(row)==1L,digest(file=zfile,algo='sha256')==row$local_source_sha256)
 zj<-read.csv(zfile);mjfile<-file.path(R,'results/JOINT_D1.csv')
 mj<-if(file.exists(mjfile))read.csv(mjfile)else zj[FALSE,]
 keep<-c('family','F','df1','df2','p','RIV');actual<-rbind(zj[keep],mj[keep]);stopifnot(!anyDuplicated(actual$family))
 families<-as.vector(t(outer(c('SD','GENDER','OLDEST','SON'),c('EDU','URBAN','INC'),paste,sep='_')))
 stopifnot(length(families)==12L,all(actual$family%in%families))
 out<-data.frame(family=families,stringsAsFactors=FALSE)
 for(n in setdiff(keep,'family'))out[[n]]<-actual[[n]][match(families,actual$family)]
 overview<-rbind(read.csv(file.path(Z,'results/FAMILY_OVERVIEW.csv')),read.csv(file.path(R,'results/FAMILY_OVERVIEW.csv')))
 stopifnot(nrow(overview)==12L,setequal(overview$family,families),!anyDuplicated(overview$family))
 for(n in c('status','members','N'))out[[n]]<-overview[[n]][match(families,overview$family)]
 valid<-!is.na(out$p);stopifnot(all(is.finite(out$p[valid])),all(out$p[valid]>=0&out$p[valid]<=1))
 out$holm_p_planned12<-NA_real_;out$holm_p_planned12[valid]<-p.adjust(out$p[valid],method='holm',n=12)
 out$bonferroni_p_planned12<-ifelse(valid,pmin(1,12*out$p),NA_real_)
 write.csv(out,file.path(R,'results/CORRECTED_TWELVE_RESOURCE_JOINT_D1.csv'),row.names=FALSE,na='')
 write_json(list(status='REGISTERED_TWELVE_DISPOSITIONS',registered=12,available_joint_tests=sum(valid),unavailable=out$family[!valid],source_education_urban_sha256=digest(file=zfile,algo='sha256'),source_income_sha256=if(file.exists(mjfile))digest(file=mjfile,algo='sha256')else NULL,method='Holm across actual corrected-source tests, n=12; unavailable tests remain NA',full_H4_complete=FALSE,original_four_complete=FALSE),file.path(R,'audit/TWELVE_RESOURCE_COMBINATION.json'),auto_unbox=TRUE,pretty=TRUE)
 cat('CORRECTED_TWELVE_RESOURCE_COMBINATION_DONE',sum(valid),'available of12\n')
})
