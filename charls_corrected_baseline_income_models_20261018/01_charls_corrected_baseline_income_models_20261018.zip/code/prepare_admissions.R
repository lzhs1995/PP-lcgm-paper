# 只接纳完整40份且独立核验通过的当前来源收入插补，不估计、不替换失败成员。
local({
 ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_baseline_income_models_20261018';I<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_baseline_income_20261018'
 library(jsonlite);library(digest)
 # 只有当前模型协调器刷新准入；未完成的范围等待，不阻塞已核验40份的独立范围。
 states<-c(fromJSON(file.path(I,'results/SCOPE_STATUS_q1.json'),simplifyVector=FALSE),fromJSON(file.path(I,'results/SCOPE_STATUS_q2.json'),simplifyVector=FALSE));stopifnot(!anyDuplicated(names(states)),all(names(states)%in%c('sd','gender','oldest','son')))
 priorfile<-file.path(ROOT,'audit/MI_ADMISSIONS.json');prior<-if(file.exists(priorfile))fromJSON(priorfile,simplifyVector=FALSE)else list()
 priorbindings<-file.path(ROOT,'audit/MI_SOURCE_BINDINGS.json');bindings<-if(file.exists(priorbindings))fromJSON(priorbindings,simplifyVector=FALSE)else list()
 input<-fromJSON(file.path(I,'contracts/INPUT_SOURCES.json'),simplifyVector=FALSE);entries<-list();sources<-list()
 for(z in c('sd','gender','oldest','son')){
  e<-input[[z]];stopifnot(digest(file=e$file,algo='sha256')==e$sha256);a<-readRDS(e$file);root<-file.path(I,'mi',z)
  if(!is.null(prior[[z]])&&prior[[z]]$status=='ADMITTED_WORKING_MI'){
   stopifnot(prior[[z]]$source_input_sha256==e$sha256);entries[[z]]<-prior[[z]];sources[[z]]<-bindings[[z]];next
  }
  queue<-if(z%in%c('sd','oldest'))'q1'else'q2';finished<-file.exists(file.path(I,'runtime',paste0('SCOPES_TERMINAL_',queue)))
  entries[[z]]<-list(status=if(finished)'IMPUTATION_NOT_ADMITTED'else'WAITING_FOR_ORIGINAL_MI_QUEUE',N=nrow(a$data),communities=length(unique(a$data$cluster)),reason=states[[z]],full_H4=FALSE)
  p<-file.path(root,'audit/INDEPENDENT_MI.json')
  if(!file.exists(p))next
  v<-fromJSON(p);ad<-fromJSON(file.path(root,'audit/MI_ADMISSION.json'))
  stopifnot(v$status=='PASS',ad$status=='ADMITTED_WORKING_MI',v$m==40L,ad$m==40L,digest(file=ad$mids_path,algo='sha256')==ad$mids_sha256)
  manifest<-read.csv(file.path(root,'audit/MI_MEMBERS.csv'));stopifnot(nrow(manifest)==40L)
  for(k in 1:40)stopifnot(digest(file=manifest$path[k],algo='sha256')==manifest$sha256[k])
  cc<-fromJSON(file.path(root,'audit/CC_INPUT.json'));stopifnot(digest(file=file.path(root,'private/CC.dat'),algo='sha256')==cc$sha256)
  entries[[z]]<-list(status='ADMITTED_WORKING_MI',N=nrow(a$data),communities=length(unique(a$data$cluster)),m=40,columns=c(names(a$analysis),'g'),data_root=file.path(root,'private'),compatibility='Working FCS with observed interactions; MAR and exact latent substantive-model compatibility not established',source_input_sha256=e$sha256,mids_sha256=ad$mids_sha256)
  sources[[z]]<-list(admission=ad,independent=v,source_manifest=manifest,source_hash=as.list(setNames(c(digest(file=p,algo='sha256'),e$sha256),c(p,e$file))))
 }
 write_json(entries,file.path(ROOT,'audit/MI_ADMISSIONS.json'),auto_unbox=TRUE,pretty=TRUE)
 write_json(sources,file.path(ROOT,'audit/MI_SOURCE_BINDINGS.json'),auto_unbox=TRUE,pretty=TRUE)
 write_json(list(status='PASS',admitted=sum(vapply(entries,function(x)x$status=='ADMITTED_WORKING_MI',TRUE)),scopes=names(entries),failed_or_unfinished_scopes_preserved=TRUE),file.path(ROOT,'audit/INDEPENDENT_MI.json'),auto_unbox=TRUE,pretty=TRUE)
 cat('INCOME_MODEL_ADMISSIONS_PREPARED_ZERO_MODELS\n')
})
