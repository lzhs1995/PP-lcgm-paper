# 临时Windows读取锁不应终止估计；检查点/最终结果仍要求写入成功。
publish_status <- function(x,p,critical=TRUE,attempts=if(critical)25L else 2L) {
  tmp <- paste0(p,'.',Sys.getpid(),'.tmp')
  jsonlite::write_json(x,tmp,auto_unbox=TRUE,pretty=TRUE,digits=16,na='null')
  err <- NULL
  for(i in seq_len(attempts)) {
    ok <- tryCatch({fs::file_move(tmp,p);TRUE},error=function(e){err<<-e;FALSE})
    if(ok)return(invisible(TRUE))
    if(i<attempts)Sys.sleep(.2)
  }
  if(critical)stop(err)
  # 待发布临时文件和追加事件日志均保留，下一次心跳可再次发布。
  invisible(FALSE)
}
append_status_event <- function(rec,p) {
  tryCatch({cat(jsonlite::toJSON(rec,auto_unbox=TRUE,digits=16),'\n',file=p,append=TRUE);TRUE},error=function(e)FALSE)
}
