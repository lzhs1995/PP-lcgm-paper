# 仅接纳当前worker身份的监控就绪回执；启动等待与条件拟合预算分开。
wait_for_owned_watch <- function(watch, root, created, seconds=60) {
 started<-Sys.time();last_message<--Inf
 repeat {
  elapsed<-as.numeric(difftime(Sys.time(),started,units='secs'))
  if(!watch$is_alive())stop('Owned watcher exited before readiness; see watch log')
  p<-file.path(root,'runtime/WATCH.json')
  rec<-if(file.exists(p))tryCatch(jsonlite::fromJSON(p),error=function(e)NULL)else NULL
  if(!is.null(rec)&&identical(as.integer(rec$owner_pid),as.integer(Sys.getpid()))&&abs(rec$created-created)<.01)return(invisible(rec))
  if(elapsed>=seconds)stop('Owned watcher readiness timed out before conditional fits')
  if(elapsed-last_message>=5){progress('watch_startup',paste('Waiting for current worker monitor;',round(elapsed),'seconds'));last_message<-elapsed}
  Sys.sleep(.2)
 }
}
