# 独立核对冻结来源、原观察缺失掩码、40份实际DAT及两块原始随机抽样。
local({
 BATCH<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_baseline_income_20261018';Z<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_baseline_h41_20261018';R<-file.path(BATCH,'mi',MI_SCOPE)
 library(mice);library(jsonlite);library(digest)
 ad<-fromJSON(file.path(R,'audit/MI_ADMISSION.json'));stopifnot(ad$status=='ADMITTED_WORKING_MI',ad$m==40)
 a<-readRDS(file.path(BATCH,'private',paste0(MI_SCOPE,'_INPUTS.rds')))
 stopifnot(digest(file=a$source_file,algo='sha256')==a$source_sha256)
 src<-readRDS(a$source_file);sources<-fromJSON(file.path(Z,'audit/SOURCE_HASHES.json'),simplifyVector=FALSE)
 for(p in names(sources))stopifnot(digest(file=p,algo='sha256')==sources[[p]])
 stopifnot(setequal(unname(unlist(src$source_hashes)),unname(unlist(sources))))
 imp<-readRDS(ad$mids_path);stopifnot(digest(file=ad$mids_path,algo='sha256')==ad$mids_sha256,identical(imp$data,a$data))
 # 收入G来自原始缺失掩码；其余分析列须与已独立核验过的当前来源一致。
 fixed<-setdiff(names(src$analysis),'g');stopifnot(isTRUE(all.equal(a$analysis[fixed],src$analysis[fixed],check.attributes=FALSE)))
 same<-function(x,y){x<-as.matrix(x);y<-as.matrix(y);stopifnot(identical(dim(x),dim(y)),identical(unname(is.na(x)),unname(is.na(y))));d<-max(abs(x-y),na.rm=TRUE);stopifnot(d<1e-10);d}
 same(a$data$g,src$income_group);same(a$data$g,ifelse(is.na(src$income_raw),NA_real_,as.numeric(src$income_raw>8730)));same(a$data$adl,src$analysis$c7)
 checks<-list();og<-!is.na(a$data$g);oa<-!is.na(a$data$adl)
 for(k in 1:40){
  v<-complete(imp,k);expected<-a$analysis;expected$g<-v$g;expected$c7<-v$adl
  # mice合并后0/1整数可成为double；严格核值而非存储类型，不改变原观察。
  stopifnot(identical(as.numeric(v$g[og]),as.numeric(a$data$g[og])),identical(as.numeric(v$adl[oa]),as.numeric(a$data$adl[oa])),all(v$g%in%0:1),all(v$adl[!oa]%in%a$data$adl[oa]),max(abs(v$zg-v$z0*v$g))<1e-12,max(abs(v$z_adl-v$z0*v$adl))<1e-12)
  p<-file.path(R,'private',sprintf('MI%02d.dat',k));delta<-same(read.table(p,na.strings='-9999'),expected)
  checks[[k]]<-data.frame(member=k,N=nrow(expected),maximum_export_difference=delta,source_masks_and_observed_values_preserved=TRUE,sha256=digest(file=p,algo='sha256'))
 }
 cc<-a$analysis;cc$g<-a$data$g;same(read.table(file.path(R,'private/CC.dat'),na.strings='-9999'),cc[og&oa,])
 tab<-do.call(rbind,checks);write.csv(tab,file.path(R,'audit/INDEPENDENT_MI_MEMBERS.csv'),row.names=FALSE)
 write_json(list(status='PASS',scope=MI_SCOPE,m=40,N=nrow(a$data),missing_income_group=sum(!og),missing_ADL=sum(!oa),both_missing=sum(!og&!oa),maximum_export_difference=max(tab$maximum_export_difference),original_sources_unchanged=TRUE,old_completed_MI_reused=FALSE,not_proof_of_MAR_or_exact_latent_compatibility=TRUE,new_Mplus_calls=0),file.path(R,'audit/INDEPENDENT_MI.json'),auto_unbox=TRUE,pretty=TRUE,digits=16)
 cat('INDEPENDENT_SCOPE_MI_PASS',MI_SCOPE,'\n')
})
