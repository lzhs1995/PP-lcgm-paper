"""最多两个互斥收入范围队列；用已运行worker实测峰值重新核验增量余量。"""
from pathlib import Path
import ctypes,json,sys,psutil
from engine import Memory,write,utc
R=Path(__file__).resolve().parents[1];scope=sys.argv[1];pid=int(sys.argv[2]);created=float(sys.argv[3]);current=psutil.Process(pid)
assert abs(current.create_time()-created)<.01
live={};seen=set()
for p in (R/'runtime').glob('QUEUE_OWNER_q*.json'):
 j=json.loads(p.read_text())
 try:
  proc=psutil.Process(j['pid'])
  if abs(proc.create_time()-j['created'])<.01:
   assert not seen.intersection(j['scopes']);seen.update(j['scopes']);live[proc.pid]=j
 except psutil.NoSuchProcess:pass
assert pid in live and scope in live[pid]['scopes'] and len(live)<=2
for p in (R/'mi').glob('*/*/runtime/lease.json'):
 j=json.loads(p.read_text())
 try:
  proc=psutil.Process(j['pid'])
  if abs(proc.create_time()-j['created'])<.01:assert proc.pid in live,'Unknown live chain worker'
 except psutil.NoSuchProcess:pass
paths=list((R/'pilot').glob('*/runtime/WATCH_TERMINAL.json'))+list((R/'mi').glob('*/*/runtime/WATCH*.json'))
observed=[]
for p in paths:
 try:observed.append(json.loads(p.read_text()))
 except (OSError,ValueError):pass
peak=max(x.get('peak_rss_bytes',0) for x in observed)/2**30;private=max(x.get('peak_private_bytes',0) for x in observed)/2**30
m=Memory();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m));mi=current.memory_info();cpu=psutil.cpu_percent(interval=.5)
required=1.25+max(0,peak-mi.rss/2**30);commit_required=2+max(0,private-getattr(mi,'private',0)/2**30)
passed=m.avail/2**30>=required and m.commit_avail/2**30>=commit_required and cpu<85
rec=dict(utc=utc(),scope=scope,queue=live[pid]['queue'],owner_pid=pid,created=created,passed=passed,live_queue_pids=list(live),maximum_queues=2,available_gib=m.avail/2**30,commit_available_gib=m.commit_avail/2**30,cpu_percent=cpu,observed_peak_gib=peak,required_available_gib=required,external_processes_modified=False)
write(R/'audit'/('RESOURCE_ADMISSION_'+live[pid]['queue']+'.json'),rec)
with (R/'audit'/('RESOURCE_HISTORY_'+live[pid]['queue']+'.jsonl')).open('a',encoding='utf-8') as f:f.write(json.dumps(rec)+'\n')
print(json.dumps(rec),flush=True);sys.exit(0 if passed else 2)
