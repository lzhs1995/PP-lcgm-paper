# 8787接口恢复：事实、操作与边界

本次未重启RStudio，原主R PID8764及创建时间1792308599.6514845保持不变。四范围收入MI各40份已独立PASS；q2原job3404ecd8的真实终态在服务恢复后成功读回，保存于audit/FULL_Q2_NATIVE_TERMINAL.json。

- 14:04 UTC原生短调用成功；随后原生工具多次返回addin未运行，部分为短暂误报。
- q2实际07:11:43 PDT（14:11:43 UTC）完成，原worker23076退出。三个早先完成范围及son的完整40份、随机状态和原始输入均保全。
- Windows直接POST /execute发生30秒读超时；主R依然存在并监听8787。R执行日志后来记录该诊断代码于07:21:12 PDT执行，说明请求超时不能等同于请求未被服务接纳。不能据此推断它当时已及时返回。
- 所读bridge源码check_addin_status使用GET /的2秒超时并捕获全部异常，统一向工具层返回False；“addin未运行”不是对R进程死亡的验证。
- 所有自有后台分析已结束后，仅操作本会话Viewer Stop Server/Start Server，Fresh start保持未选。截图实证Stopped；RStudio及未保存脚本未关闭。新服务日志为clauder_default_8787_20261018_073702.R。
- 重启后list_sessions实测默认连接漂移到default3@8789。未向该会话提交分析；显式connect_session(default)，并用stopifnot(Sys.getpid()==8764L)确认归属。HTTP根路径返回200，原生短调用成功。
- 07:40:00 PDT原生提交收入模型返回通信错误，但R实际日志已登记ASYNC JOB d8e08b2b。没有重复提交；同ID原生轮询显示H41_model_start。其原始错误和恢复轮询分别在模型目录audit/MODELS_SUBMIT_TRANSPORT_ERROR.json及MODELS_RECOVERED_NATIVE_POLL.json。
- models guard登记d8e08b2b，协调器PID16824/1792334401.17183。首个CHARLS_SD_H41_PARENT_MI01_A经MplusAutomation调用Mplus9后合法，耗时105.9015428秒（含Rscript启动与IO），输出SHA256 c7146d7cc553e80af97eb8d6f16d8bcb2f06c65b62a5582acd80a1377609af4b。
- FCS均退出后，仅迁移本模型协调器及其当时存活的4个后代到CPU8—11，留有OWNED_MODEL_AFFINITY_REBALANCE.json；首次两次适配脚本因ps函数名称不匹配在任何修改前报错，按实际命名空间更正后执行通过。不修改其他研究的进程或统计规格，不把迁移本身宣传为实测加速。

初始HTTP停滞的底层原因尚未唯一确定。可确认的恢复链为：独立核对进程及完成文件→保留会话的HTTP服务重启→重新显式绑定→原job终态→识别模糊提交的真实job→原job轮询→实际Mplus结果。单次恢复成功不代表所有未来故障都能由服务重启解决。

截图只在本机保留，不进入公开包。其他原数据、MI、成功和失败输出不搬动、不覆盖。**四项调节完整推断、完整H4仍未完成。** 收入家族模型继续，不另开CFPS失败规格。
# 后续实测补充（2026-10-18 16:10 UTC）

同一原生 job `d8e08b2b` 在性别差 MI10 左右的一次轮询再次返回 `addin not running`。没有重启 HTTP/R，也没有重复提交。随后会话列表仍绑定 `default@8787`、PID8764；后台 FAMILY_STATUS 已推进到12份，原生轮询恢复并报告 MI13。Windows 原生 `urllib.request.urlopen` 对根端点实测 HTTP200、响应4.3904214秒。本次观测与桥接器2秒健康探测超时产生短暂假阴性相符，不能据此认定最初的长期阻塞也具有同一根因。遇此情形先保留原job并核对持续产出、使用有界只读探测，不因为一次通用报错重启正在工作的会话。
