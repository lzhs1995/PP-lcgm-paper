"""单个自有 worker：从完整检查点续算，40份全部验收后才运行41次以内Mplus。"""
from pathlib import Path
import ctypes,datetime,hashlib,json,os,subprocess,time,psutil
R=Path(__file__).resolve().parents[1]
RS='<LOCAL_USER_HOME>/Downloads/RStudio/R_ducument/R-4.5.2/bin/x64/Rscript.exe'
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def put(name,x):
    p=R/name;t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
    for i in range(12):
        try:os.replace(t,p);return
        except PermissionError:
            if i==11:raise
            time.sleep(.2)
def progress(stage,**kw):put('runtime/PIPELINE.json',dict(stage=stage,updated_at=utc(),**kw))
class MEM(ctypes.Structure):
    _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ('total','available','page_total','page_available','virtual_total','virtual_available','extended')]
def admission():
    deadline=time.monotonic()+600
    while True:
        m=MEM();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
        cpu=psutil.cpu_percent(interval=1,percpu=True)
        rec=dict(available_GiB=m.available/2**30,commit_free_GiB=m.page_available/2**30,cpu=sum(cpu)/len(cpu),per_core=cpu)
        if rec['available_GiB']>=1 and rec['commit_free_GiB']>=2 and rec['cpu']<85:return rec
        progress('RESOURCE_WAIT',resources=rec)
        if time.monotonic()>deadline:raise TimeoutError('No resource admission in 600s')
        time.sleep(10)
def stage(name,args,limit):
    resources=admission();env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    started=time.monotonic();last_key=None;phase_clock=started;reason=None;rc=None
    with (R/'runtime'/f'{name}.log').open('xb') as log:
        child=subprocess.Popen([RS,*args],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
        p=psutil.Process(child.pid);born=p.create_time();allowed=p.cpu_affinity();idle=[i for i in allowed if resources['per_core'][i]<50]
        if len(idle)>=2 and any(resources['per_core'][i]>=90 for i in allowed):p.cpu_affinity(idle)
        p.nice(psutil.ABOVE_NORMAL_PRIORITY_CLASS);pf=R/'runtime/progress.json'
        while child.poll() is None:
            s={}
            try:
                s=json.loads(pf.read_text());key=(s.get('stage'),str(s.get('message')))
                if key!=last_key:last_key=key;phase_clock=time.monotonic()
            except (OSError,ValueError):pass
            elapsed=time.monotonic()-started
            try:cpu_sec=sum(p.cpu_times()[:2]);rss=p.memory_info().rss
            except psutil.Error:cpu_sec=rss=None
            progress(name,pid=child.pid,created=born,elapsed=elapsed,cpu_seconds=cpu_sec,rss=rss,worker=s,resources_at_admission=resources)
            bootstrap=(name=='imputation' and not s and elapsed>300)
            conditional=(name=='imputation' and s.get('stage')=='MI_CONDITIONAL_START' and time.monotonic()-phase_clock>180)
            if bootstrap or conditional or elapsed>limit:
                reason='BOOTSTRAP_300S' if bootstrap else 'CONDITIONAL_150S' if conditional else 'STAGE_WALL_LIMIT'
                if p.is_running() and abs(p.create_time()-born)<.01:
                    for c in p.children(recursive=True):
                        try:c.kill()
                        except psutil.NoSuchProcess:pass
                    child.kill();child.wait(20)
                rc=124;break
            time.sleep(3)
        if rc is None:rc=child.returncode
    rec=dict(stage=name,exitcode=rc,seconds=time.monotonic()-started,pid=child.pid,created=born,watchdog=reason,resources=resources,utc=utc())
    put(f'audit/{name}_TERMINAL.json',rec)
    if rc:raise RuntimeError(f'{name} failed: {rec}')
    return rec

lock=R/'runtime/coordinator.lock';fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
os.write(fd,json.dumps({'pid':os.getpid(),'created':psutil.Process().create_time()}).encode());os.close(fd)
awake=False;terminal={'status':'FAILED','CFPS_reruns':0,'full_H4_complete':False}
try:
    assert not (R/'audit/RESUME_TERMINAL.json').exists()
    put('audit/FROZEN_CODE_RESUME.json',{str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in list((R/'code').glob('*'))+list((R/'contracts').glob('*')) if p.is_file()})
    awake=bool(ctypes.windll.kernel32.SetThreadExecutionState(0x80000001))
    stage('imputation_resume',[str(R/'code/prepare_mi.R')],1200)
    admissions=json.loads((R/'audit/MI_ADMISSIONS.json').read_text())
    assert len(admissions)==4 and all(v['passed'] for v in admissions.values())
    stage('models',[str(R/'code/run_models.R')],9000)
    fs=json.loads((R/'results/FAMILY_STATUS.json').read_text())
    if any(v['status']=='RESOURCE_DEFERRED' for v in fs.values()):
        stage('models_resource_resume',[str(R/'code/run_models.R')],9000)
    (R/'runtime/MODELS_TERMINAL').write_text(utc(),encoding='utf-8')
    stage('pool',[str(R/'code/pool.R')],600)
    terminal.update(status='DYNAMIC_MI_SENSITIVITY_TERMINAL',pooling=json.loads((R/'results/POOLING_RECEIPT.json').read_text()))
except Exception as e:terminal['error']=repr(e)
finally:
    if awake:ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
    terminal.update(utc=utc(),awake_released=True);put('audit/RESUME_TERMINAL.json',terminal);progress(terminal['status'],processes=[],awake=False)
    lock.unlink()
print(json.dumps(terminal),flush=True)
raise SystemExit(0 if terminal['status']=='DYNAMIC_MI_SENSITIVITY_TERMINAL' else 1)
