# 仅ADL缺失且所有预测变量固定：每份一次新条件抽样，不需要链式烧入。
.libPaths(c('<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
library(mice);library(miceadds);library(lme4);library(jsonlite);library(digest)
BATCH<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_dynamic_mi_sensitivity_20261016'
H<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_h41_mi_20261016'
P<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_observed_moderation_20261016'
contract<-fromJSON(file.path(BATCH,'contracts/RUN_CONTRACT.json'),simplifyVector=FALSE)
entries<-fromJSON(file.path(P,'contracts/DATA_ENTRIES.json'),simplifyVector=FALSE)
progress<-function(stage,message){write_json(list(stage=stage,message=message,updated_at=format(Sys.time(),tz='UTC',usetz=TRUE)),file.path(BATCH,'runtime/progress.json'),auto_unbox=TRUE);cat(stage,message,'\n');flush.console()}
admissions<-list()
for(z in unlist(contract$indicators)){
 ROOT<-file.path(BATCH,'mi',z);for(d in c('private','audit','runtime'))dir.create(file.path(ROOT,d),recursive=TRUE,showWarnings=FALSE)
 source_path<-file.path(H,'mi',z,'private/INPUTS.rds');source_hash<-digest(file=source_path,algo='sha256');a<-readRDS(source_path);cc<-a$data
 stopifnot(identical(names(which(colSums(is.na(cc))>0)),'adl'))
 aux<-grep('^(obs_|missing_)',names(cc),value=TRUE)
 for(v in aux)cc[[paste0('z_',v)]]<-cc$z0*cc[[v]]
 cc$z_squared<-cc$z0^2
 method<-make.method(cc);method[]<-'';method['adl']<-'2l.pmm.cached'
 pm<-matrix(0,ncol(cc),ncol(cc),dimnames=list(names(cc),names(cc)));pm['adl',setdiff(names(cc),c('adl','cluster'))]<-1;pm['adl','cluster']<--2
 source(file.path(BATCH,'code/mi_exact_fit_cache.R'),local=TRUE)
 warnings<-character();progress('MI_CONDITIONAL_START',paste(z,'20 independent conditional draws; fixed auxiliary predictors'))
 cp<-file.path(ROOT,'private/MIDS.rds');reused_draws<-file.exists(cp)
 if(reused_draws){
  imp<-readRDS(cp);stopifnot(identical(imp$data,cc),imp$m==20L,imp$iteration==1L)
  prior<-fromJSON(file.path(ROOT,'runtime/mi_fit_cache.json'));cache_env$misses<-prior$misses;cache_env$hits<-20L-prior$misses
  progress('REUSED_COMPLETED_DRAWS',paste(z,'20 existing draws; only export validation repaired'))
 }else{
  imp<-withCallingHandlers(mice(cc,m=20,maxit=1,method=method,predictorMatrix=pm,seed=contract$mi_seeds[[z]],donors=5,printFlag=FALSE,remove.collinear=FALSE),warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')})
 }
 write_json(list(reused_completed_draws=reused_draws,misses=cache_env$misses,hits=cache_env$hits,counter_source=if(reused_draws)'MIDS20 complete plus last fit-start miss counter'else'live cache counters'),file.path(ROOT,'audit/DRAW_EXECUTION.json'),auto_unbox=TRUE,pretty=TRUE)
 saveRDS(imp,file.path(ROOT,'private/MIDS.rds'));saveRDS(list(data=cc,analysis=a$analysis,source=source_path,source_sha256=source_hash),file.path(ROOT,'private/INPUTS.rds'))
 fit<-readRDS(file.path(ROOT,'private/MI_ADL_CONDITIONAL_LMER.rds'))
 critical<-c('z0','z_squared',paste0('z_',aux));retained<-all(imp$predictorMatrix['adl',critical]==1)
 fixed_rank_ok<-is.null(attr(lme4::getME(fit,'X'),'col.dropped'))
 passed<-fit@optinfo$conv$opt==0&&length(fit@optinfo$conv$lme4$messages)==0&&retained&&fixed_rank_ok&&cache_env$misses==1&&cache_env$hits==19
 members<-list();summaries<-list();obs<-!is.na(cc$adl)
 for(k in 1:20){
  v<-complete(imp,k);stopifnot(all(vapply(setdiff(names(v),'adl'),function(n)identical(as.numeric(v[[n]]),as.numeric(cc[[n]])),TRUE)),identical(v$adl[obs],cc$adl[obs]),all(v$adl[!obs]%in%cc$adl[obs]),all(v$adl%in%0:6))
  b<-a$analysis;b$c7<-v$adl;stopifnot(identical(b[setdiff(names(b),'c7')],a$analysis[setdiff(names(a$analysis),'c7')]))
  path<-file.path(ROOT,'private',sprintf('MI%02d.dat',k));write.table(b,path,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
  members[[k]]<-data.frame(member=k,N=nrow(b),data_sha256=digest(file=path,algo='sha256'),observed_preserved=TRUE,XY_masks_preserved=TRUE)
  summaries[[k]]<-data.frame(scope=z,member=k,imputed_mean=mean(v$adl[!obs]),imputed_sd=sd(v$adl[!obs]))
 }
 write.csv(do.call(rbind,members),file.path(ROOT,'audit/MEMBER_VALIDATION.csv'),row.names=FALSE)
 write.csv(do.call(rbind,summaries),file.path(ROOT,'audit/DRAW_SUMMARY.csv'),row.names=FALSE)
 write.csv(data.frame(variable=rownames(imp$predictorMatrix),imp$predictorMatrix,check.names=FALSE),file.path(ROOT,'audit/PREDICTORS_ACTUAL.csv'),row.names=FALSE)
 if(!is.null(imp$loggedEvents))write.csv(imp$loggedEvents,file.path(ROOT,'audit/LOGGED_EVENTS.csv'),row.names=FALSE)
 # 只有一个缺失目标，供体与拟合仅用其原观测值；记录函数和随机状态边界。
 rec<-list(scope=z,passed=passed,N=nrow(cc),communities=length(unique(cc$cluster)),missing_ADL=sum(!obs),m=20,iterations=1,cache_misses=cache_env$misses,cache_hits=cache_env$hits,critical_predictors_retained=retained,fixed_rank_ok=fixed_rank_ok,random_intercept_boundary=isSingular(fit),warnings=warnings,source_sha256=source_hash,compatibility=contract$compatibility,
  no_markov_iteration_needed='Exactly one incomplete variable; its conditional fitting, covariates and donor observations do not depend on previous imputed values. Every call retains fresh parameter/random-effect/donor draws.',
  mice_version=as.character(packageVersion('mice')),miceadds_version=as.character(packageVersion('miceadds')))
 write_json(rec,file.path(ROOT,'audit/ADMISSION.json'),auto_unbox=TRUE,pretty=TRUE,digits=16);admissions[[z]]<-rec
 entries[[z]]$N<-nrow(cc);entries[[z]]$communities<-rec$communities;entries[[z]]$columns<-names(a$analysis)
 stopifnot(identical(source_hash,digest(file=source_path,algo='sha256')))
 progress('MI_CONDITIONAL_DONE',paste(z,'admitted',passed));rm(imp,fit,cc,a);gc()
}
write_json(admissions,file.path(BATCH,'audit/MI_ADMISSIONS.json'),auto_unbox=TRUE,pretty=TRUE,digits=16)
write_json(entries,file.path(BATCH,'contracts/DATA_ENTRIES.json'),auto_unbox=TRUE,pretty=TRUE,digits=16)
writeLines(capture.output(sessionInfo()),file.path(BATCH,'audit/MI_SESSION_INFO.txt'))
stopifnot(all(vapply(admissions,function(a)isTRUE(a$passed),TRUE)))
progress('MI_TERMINAL','Four full working-imputation families prepared; no exact SMC claim')
