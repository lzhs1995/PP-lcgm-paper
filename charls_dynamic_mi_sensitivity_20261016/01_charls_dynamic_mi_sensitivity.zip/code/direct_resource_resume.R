# 同一原生后台R直接运行剩余队列，去掉空闲R监控包装层；全部旧输出复用。
library(jsonlite);library(processx);library(ps);library(digest)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_dynamic_mi_sensitivity_20261016'
entry<-function(){
 stopifnot(!file.exists(file.path(ROOT,'audit/DIRECT_TERMINAL.json')),!file.exists(file.path(ROOT,'runtime/engine.lock')),!file.exists(file.path(ROOT,'runtime/DIRECT_OWNER.json')))
 owner<-ps_handle();born<-as.numeric(ps_create_time(owner));old_affinity<-ps_get_cpu_affinity(owner)
 # 本机刚核验的空闲核；不改变其他会话，且只影响这个临时自有R进程。
 ps_set_cpu_affinity(owner,intersect(old_affinity,0:3));ps_set_nice(owner,'above_normal')
 write_json(list(pid=Sys.getpid(),created=born,affinity_before=old_affinity,affinity_after=ps_get_cpu_affinity(owner),priority=ps_get_nice(owner)),file.path(ROOT,'runtime/DIRECT_OWNER.json'),auto_unbox=TRUE,pretty=TRUE)
 stopfile<-file.path(ROOT,'runtime/DIRECT_TERMINAL');guard<-process$new('<LOCAL_USER_HOME>/AppData/Local/Programs/Python/Python314/python.exe',c('-X','utf8',file.path(ROOT,'code/coordinator_awake.py'),'--owner-pid',Sys.getpid(),'--owner-created',born,'--receipt',file.path(ROOT,'runtime/DIRECT_AWAKE.json'),'--max-seconds','7200','--stop-file',stopfile),stdout=file.path(ROOT,'runtime/direct_awake.log'),stderr='2>&1',cleanup=FALSE)
 on.exit(writeLines('Direct queue terminal',stopfile),add=TRUE)
 source(file.path(ROOT,'code/queue_functions.R'),local=TRUE)
 original_run<-run
 run<-function(j){invisible(gc(full=TRUE));original_run(j)}
 clauder_progress('DIRECT_QUEUE_RESUME','Reusing all saved MI and completed models; no extra idle R supervisor')
 frozen<-list(queue_functions_sha256=digest(file=file.path(ROOT,'code/queue_functions.R'),algo='sha256'),entry_sha256=digest(file=file.path(ROOT,'code/direct_resource_resume.R'),algo='sha256'))
 write_json(frozen,file.path(ROOT,'audit/DIRECT_EXECUTED_CODE.json'),auto_unbox=TRUE,pretty=TRUE)
 result<-tryCatch({main();source(file.path(ROOT,'code/pool.R'),local=TRUE);list(status='DIRECT_RESOURCE_CONTINUATION_TERMINAL',pooling=fromJSON(file.path(ROOT,'results/POOLING_RECEIPT.json')))},error=function(e)list(status='FAILED',error=conditionMessage(e)))
 result$utc<-format(Sys.time(),tz='UTC',usetz=TRUE);result$CFPS_reruns<-0;write_json(result,file.path(ROOT,'audit/DIRECT_TERMINAL.json'),auto_unbox=TRUE,pretty=TRUE)
 print(result);stopifnot(result$status=='DIRECT_RESOURCE_CONTINUATION_TERMINAL');cat('DYNAMIC_DIRECT_NATIVE_TERMINAL\n')
}
entry()
