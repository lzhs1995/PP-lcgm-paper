# 从完整检查点接续，所有产物写入独立目录。
library(processx);library(jsonlite)
elapsed_label<-function(x)if(is.numeric(x)&&length(x)==1L&&is.finite(x))as.character(round(x))else'not_applicable'
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_dynamic_mi_sensitivity_20261016'
clauder_progress('DYNAMIC_MI','Four scoped working-imputation sensitivities; no unchanged CFPS rerun')
p<-process$new('<LOCAL_USER_HOME>/AppData/Local/Programs/Python/Python314/python.exe',c('-u','-X','utf8',file.path(ROOT,'code/coordinator.py')),stdout=file.path(ROOT,'runtime/coordinator.log'),stderr='2>&1',cleanup=TRUE)
while(p$is_alive()){
 p$wait(5000L);s<-tryCatch(fromJSON(file.path(ROOT,'runtime/PIPELINE.json')),error=function(e)NULL)
 if(!is.null(s))clauder_progress('DYNAMIC_MI',paste(s$stage,s$worker$message,elapsed_label(s$elapsed)))
}
print(fromJSON(file.path(ROOT,'audit/TERMINAL.json')));stopifnot(p$get_exit_status()==0)
cat('DYNAMIC_MI_NATIVE_TERMINAL\n')
