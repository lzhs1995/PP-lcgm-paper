"""轻量调度侧车：只处理已核验本批协调器的当前后代，不改变统计输入。"""
import ctypes
ctypes.windll.kernel32.SetProcessAffinityMask(ctypes.windll.kernel32.GetCurrentProcess(),255)
from pathlib import Path
import datetime,json,time,psutil
R=Path(__file__).resolve().parents[1];read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
first=read(R/'runtime/PIPELINE.json');anchor_pid=first['pid'];born=first['created'];anchor=psutil.Process(anchor_pid)
assert abs(anchor.create_time()-born)<.01
initial_allowed=anchor.cpu_affinity();deadline=time.monotonic()+9000;done=set();last_sample=0;allowed=initial_allowed;rows=0
me=psutil.Process();meta=dict(pid=me.pid,created=me.create_time(),anchor_pid=anchor_pid,anchor_created=born,initial_allowed=initial_allowed,statistics_changed=False,foreign_processes_modified=False)
(R/'runtime/SCHEDULING_WATCHER.json').write_text(json.dumps(meta),encoding='utf-8')
try:
 while time.monotonic()<deadline:
  if not anchor.is_running() or abs(anchor.create_time()-born)>.01:break
  if time.monotonic()-last_sample>30:
   load=psutil.cpu_percent(interval=1,percpu=True);idle=[i for i in initial_allowed if load[i]<70]
   if len(idle)>=2:allowed=idle
   last_sample=time.monotonic()
  for p in [anchor]+anchor.children(recursive=True):
   try:
    if p.name().lower() not in ('rscript.exe','python.exe','mplus.exe','cmd.exe'):continue
    identity=(p.pid,p.create_time());old=p.cpu_affinity();priority=p.nice()
    if p.pid!=anchor_pid:assert anchor_pid in [x.pid for x in p.parents()]
    new=[i for i in allowed if i in old]
    if new and new!=old:p.cpu_affinity(new)
    if priority==psutil.NORMAL_PRIORITY_CLASS:p.nice(psutil.ABOVE_NORMAL_PRIORITY_CLASS)
    if identity not in done or p.cpu_affinity()!=old or p.nice()!=priority:
     rec=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=p.pid,created=identity[1],name=p.name(),parent_chain_verified=True,affinity_before=old,affinity_after=p.cpu_affinity(),priority_before=int(priority),priority_after=int(p.nice()),host_per_core=load)
     with (R/'audit/OWNED_SCHEDULING_CHANGES.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec)+'\n')
     rows+=1;done.add(identity)
   except psutil.NoSuchProcess:continue
  time.sleep(5)
except psutil.NoSuchProcess:pass
finally:
 (R/'audit/SCHEDULING_WATCHER_TERMINAL.json').write_text(json.dumps(dict(status='EXITED',records=rows,anchor_pid=anchor_pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())),encoding='utf-8')
 print(json.dumps({'status':'EXITED','records':rows}),flush=True)
