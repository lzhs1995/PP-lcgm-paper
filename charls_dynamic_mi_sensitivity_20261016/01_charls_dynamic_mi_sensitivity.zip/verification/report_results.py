"""从已核验的完整家族生成对照、图和报告，保留未完成范围。"""
from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd
from scipy.stats import norm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
P=R.parent/'charls_observed_moderation_20261016'
def main():
 v=read(R/'audit/INDEPENDENT_VERIFICATION.json');assert v['status']=='PASS'
 ad=read(R/'audit/MI_ADMISSIONS.json');status=pd.read_csv(R/'results/FAMILY_OVERVIEW.csv')
 d=pd.read_csv(R/'results/FOUR_MODERATIONS.csv') if (R/'results/FOUR_MODERATIONS.csv').exists() else pd.DataFrame()
 calls=read(R/'results/CALL_RESULTS.json');eng=[read(p) for p in (R/'models').glob('*/engine_receipt.json')];seconds=sum(x['seconds'] for x in eng)
 rows=[];cn={'sd':'见面频率SD','gender':'儿子−女儿差','oldest':'最年长子女−其他子女','son':'长子−所有其他子女'};en={'sd':'SD','gender':'Son minus daughter','oldest':'Oldest minus others','son':'Eldest son minus others'}
 for z in ad:
  cdir=P/'models'/f'CHARLS_{z.upper()}_E1_A';rc=read(cdir/'receipt.json');k=pd.read_csv(cdir/'key_paths.csv');k=k.loc[k.label=='dc'].iloc[0]
  assert hashlib.sha256((cdir/'model.out').read_bytes()).hexdigest()==rc['output_sha256']
  rows.append(dict(scope=z,analysis='Complete case (reused)',N=rc['N'],estimate=k.estimate,se=k.se,lower=k.estimate-norm.ppf(.975)*k.se,upper=k.estimate+norm.ppf(.975)*k.se,source_sha256=rc['output_sha256']))
  if not d.empty and z in set(d.scope):
   p=d.loc[d.scope==z].iloc[0];rows.append(dict(scope=z,analysis='Enriched working MI20',N=ad[z]['N'],estimate=p.estimate,se=p.se,lower=p.lower,upper=p.upper,source_sha256=hashlib.sha256((R/'results'/z/'POOLED_PATHS.csv').read_bytes()).hexdigest()))
 compare=pd.DataFrame(rows);compare.to_csv(R/'results/CC_MI_COMPARISON.csv',index=False)
 fig,ax=plt.subplots(figsize=(8.4,5.3));scopes=list(ad)
 for i,z in enumerate(scopes):
  for label,color,off in [('Complete case (reused)','#888888',-.10),('Enriched working MI20','#2369a0',.10)]:
   sub=compare[(compare.scope==z)&(compare.analysis==label)]
   if len(sub):
    a=sub.iloc[0];ax.errorbar(a.estimate,i+off,xerr=[[a.estimate-a.lower],[a.upper-a.estimate]],fmt='o',color=color,capsize=3,label=label if i==0 else None)
 ax.axvline(0,color='black',linewidth=.7);ax.set_yticks(range(4),[en[z] for z in scopes]);ax.invert_yaxis();ax.set_xlabel('SX × standardized baseline Z → SY: estimate and pointwise 95% interval')
 ax.set_title('CHARLS: four observed-baseline moderation sensitivities');ax.legend(fontsize=8)
 fig.text(.04,.02,'Same prior Z scale; distinct scope samples. Working MI does not establish exact SMC compatibility or full H4.',fontsize=8);fig.tight_layout(rect=(0,.05,1,1))
 fig.savefig(R/'results/FOUR_MODERATIONS.pdf');fig.savefig(R/'results/FOUR_MODERATIONS.png',dpi=160);plt.close(fig)
 lines=['# CHARLS四项动态调节：完整工作插补敏感性分析','', '**四项调节完整推断、完整 H4 仍未完成。**', '',
 '本批接续已交付的CHARLS条件H4.1十二个完整家族，不修改已收尾正文/补充材料，不原样重跑失败CFPS。本批估计SX×观测基期Z0→SY；它不同于基期Z0×资源的H4.1，也没有执行SX×Z0×资源的H4.2。', '',
 f'实际新增{len(eng)}次Mplus/启动器调用，调用墙钟合计{seconds:.3f}秒。完整工作插补家族{len(v["pooled_families"])}/4，每家族20份；不同起点不是插补成员。所有结果均保留，不按P值筛选。', '',
 '| 基期指标 | N | 调节系数 | 95%条件MI区间 | 原始P | 四项Holm P |', '|---|---:|---:|---|---:|---:|']
 if len(d):
  for a in d.itertuples():lines.append(f'| {cn[a.scope]} | {ad[a.scope]["N"]} | {a.estimate:.6f} | [{a.lower:.6f}, {a.upper:.6f}] | {a.p:.6g} | {a.holm_p_fixed4:.6g} |')
 nominal=int((d.p<.05).sum()) if len(d) else 0;corrected=int((d.holm_p_fixed4<.05).sum()) if len(d) else 0
 lines+=['',f'已合并家族中，名义P<.05有{nominal}项，固定四项Holm校正后有{corrected}项。区间包含零不证明无效应；本批只报告现有条件模型及其估计精度。全部路径、完整协方差、有限社区自由度敏感性和bss+dc×Z的点态条件斜率另见results目录。', '',
 '## 缺失处理与本批能说明的范围', '',
 '四个范围分别保留2745/2171/2529/2387人，ADL普通缺失18/15/18/18。其余插补预测变量为完整的固定辅助表达：各波已观测值的原有填补表示及对应缺失旗标，不是把这些表示当作分析中真实观测。Mplus实际X/Y值与FIML缺失掩码原样保留。结构性无定义差异、未通过来源核验的子女记录不插补。基期量尺沿用先前完整案例尺度，可直接对照旧小试。', '',
 'ADL采用社区随机截距PMM5，在原有预测变量中加入Z平方、Z与各波辅助值及缺失旗标的乘积。原观测保持、ADL支持/供体、预测矩阵和所有实际DAT已独立核验。仅ADL一个目标缺失，条件拟合和供体不依赖先前补值；因此每份一次新的参数、随机效应和供体抽样即可，无需重复二十轮烧入。四个范围各只拟合一次确定性混合模型，另十九次复用完全相同拟合，随机抽样仍每次执行。', '',
 '增加观测乘积不是精确实质模型相容性的证明。PMM工作条件模型、辅助缺失表示、MAR、序数量表近似及潜变量交互仍有限制。本批属于完整20份的条件敏感性推断，不能据此宣布CFPS四项原调节或完整H4完成。关于相容性的区别参见[Bartlett等原始方法论文](https://pmc.ncbi.nlm.nih.gov/articles/PMC4513015/)。', '',
 'CHARLS的X是见面频率，非CFPS情感亲近度；SD为绝对离散，其余Z为有方向差值。SD模型含x1/y1 ON Z0，潜截距路径不是Z0与实测基期结局的全部关联。使用0/2/4/7/9年时间载荷、原11列基期控制、社区稳健标准误与同期残差关联。', '',
 '## 运行、修复与停止规则', '',
 '原生job24ab431d在SD20份抽样保存后因data.frame行名重置的验收错误终止，尚无Mplus。51列非ADL值逐列相等。修复只比较按原顺序的数值列，保留原错误和执行前代码；job3364422a复用原SD20份，继续其他三家族，没有重复抽样凑结果。', '',
 '四范围各保留一次MI01父模型、两套分别源于该父模型的交互起点，再推进MI02—20。最多88次、单次180秒、总调用5400秒，单个自有计算任务；不得清零负方差、替换失败成员或自动增加积分/迭代。Windows资源准入保留物理内存1GiB与commit2GiB、CPU85%限制；只调整自有进程的CPU亲和与优先级，未关闭外部会话。', '',
 '## 资源恢复与实际执行链', '', '首轮38次已完成调用及阶段验收完整保留；资源暂缓没有当作估计失败。后续原生job375e8a4d直接由一个后台R执行同一队列，省去闲置R监控包装层，复用现有MI和成功输出，物理内存/commit门槛与88次预算均不变。最终以DIRECT_TERMINAL及当前成员回执为准，不把旧RESUME_TERMINAL当当前完成证明。', '', '调度侧车曾把自身负载误作外部繁忙并逐次缩小CPU集合；核验身份后只停止侧车并恢复worker集合，没有停止估计器。记录保留，不把该观察说成受控加速实验。WSL旧interop通道报错后改用经只读命令核验的当前通道，没有重启RStudio/WSL，也没有把观察错误当成重估理由。', '', '## 后续边界', '',
 'CHARLS条件H4.1十二家族和CFPS三个SD条件家族保持已有裁定。本批四个观测Z动态调节是缺失处理敏感性扩展，完整H4.2尚需单独明确资源项、全部低阶项和缺失相容边界。不得把不显著说成机制不存在，也不得把数值合法说成所有假设获得检验。原稿与冻结交付版本保持不变。', '',
 '本包只含汇总、代码、模型参数/协方差与审计证据。个人DAT/RDS/MIDS、原始数据与逐人记录不公开。未重开NLM或全量CI。']
 (R/'reports/REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 receipt=dict(status='DYNAMIC_MI_SENSITIVITY_REPORT_READY',models=len(eng),engine_seconds=seconds,pooled_families=len(v['pooled_families']),full_H4_complete=False,full_four_moderation_inference_complete=False)
 (R/'reports/RECEIPT.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(receipt))
if __name__=='__main__':main()
