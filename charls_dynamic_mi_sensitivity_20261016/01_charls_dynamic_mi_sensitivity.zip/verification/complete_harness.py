"""绑定真实原生终态、已完成复算与实际PDF目视记录；不提交估计。"""
import ctypes
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.GetCurrentProcess.restype=ctypes.c_void_p
k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
assert k.SetProcessAffinityMask(k.GetCurrentProcess(),15),ctypes.get_last_error()
from pathlib import Path
import contextlib,datetime,hashlib,io,json,sys
sys.path.insert(0,'<LOCAL_USER_HOME>/.codex/skills/clauder-rstudio-workbench')
from clauder_workbench.cli import main as cli
R=Path(__file__).resolve().parents[1]
KEY='pp-lgcm-charls-dynamic-direct-20261016'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def evidence(eid):
    files=list((Path.home()/'.clauder_workbench/evidence').glob('*_'+eid+'.json'))
    assert len(files)==1,(eid,files)
    return str(files[0])
def run(args,name):
    b=io.StringIO()
    with contextlib.redirect_stdout(b):rc=cli(args)
    (R/'audit'/name).write_text(b.getvalue(),encoding='utf-8')
    j=json.loads(b.getvalue());assert rc==0 and j['decision']=='PASS',j
    print(json.dumps({'step':args[:2],'decision':j['decision'],'id':j['evidence_id']}),flush=True)
    return j
def main():
    assert read(R/'audit/POSTPROCESS_FINAL.json')['status']=='NUMERIC_REPORT_AND_PDF_READY'
    raw=read(R/'audit/NATIVE_FINAL_RESULT.json')
    text='\n'.join(x.get('text','') for x in raw['content'])
    assert 'DYNAMIC_DIRECT_NATIVE_TERMINAL' in text and 'still running' not in text and 'Async job error' not in text
    assert read(R/'audit/DIRECT_TERMINAL.json')['pooling']['pooled']==4
    assert not (R/'runtime/engine.lock').exists()
    figure={'status':'PASS','reviewer':'Codex','method':'Actual PDF page rendered by fitz and inspected with view_image; four paired estimates and intervals, labels and scope caveat visible without clipping; MI values checked against REPORT and CSV.',
            'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'sha256':{n:hashlib.sha256((R/'results'/n).read_bytes()).hexdigest() for n in ('FOUR_MODERATIONS.pdf','PDF_RENDER.png','FOUR_MODERATIONS.csv')}}
    (R/'audit/FIGURE_REVIEW.json').write_text(json.dumps(figure,indent=2),encoding='utf-8')
    archived=run(['async-guard','complete','--task-key',KEY,'--job-id','375e8a4d','--reason','Actual native terminal DYNAMIC_DIRECT_NATIVE_TERMINAL; four complete20 families independently verified; no new estimates'],'FINAL_ASYNC_ARCHIVE.json')
    args=['completion-check','--mode','formal','--task-key',KEY,'--require-transport-class','NATIVE_MCP_OK','--require-job-complete','--state-file',str(R/'audit/INDEPENDENT_VERIFICATION.json'),'--parent-evidence',evidence('ccb5b1f2-412c-4b90-9593-cc8f59d42a0d'),evidence(archived['evidence_id'])]
    for n in ('audit/NATIVE_FINAL_RESULT.json','audit/INDEPENDENT_VERIFICATION.json','audit/FIGURE_REVIEW.json','reports/REPORT.md','results/FOUR_MODERATIONS.csv','results/FOUR_MODERATIONS.pdf'):
        args.extend(['--require-file','file::'+str(R/n)+',min_bytes=1,max_age_h=24'])
    run(args,'CLAUDER_COMPLETION.json')
if __name__=='__main__':main()
