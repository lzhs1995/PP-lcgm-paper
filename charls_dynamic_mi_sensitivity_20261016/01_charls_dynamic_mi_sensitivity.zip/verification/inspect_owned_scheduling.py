"""核对本批树内进程的实际调度；仅身份/父链双重确认后调整自有Mplus。"""
import ctypes,os
# 本机近期实测0—7空闲、8—15繁忙；仅短诊断自身bootstrap，非外部进程策略。
ctypes.windll.kernel32.SetProcessAffinityMask(ctypes.windll.kernel32.GetCurrentProcess(),255)
from pathlib import Path
import datetime,json,psutil
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
s=read(R/'runtime/PIPELINE.json');co=psutil.Process(s['pid']);assert abs(co.create_time()-s['created'])<.01
load=psutil.cpu_percent(interval=1,percpu=True);rows=[]
for p in [co]+co.children(recursive=True):
 try:
  old=p.cpu_affinity();priority=p.nice();rec=dict(pid=p.pid,created=p.create_time(),name=p.name(),affinity_before=old,priority_before=int(priority),cpu_seconds=sum(p.cpu_times()[:2]),rss=p.memory_info().rss)
  if p.name().lower()=='mplus.exe':
   ids=[q.pid for q in p.parents()];assert co.pid in ids
   hb=next(x for x in s['worker']['processes'] if x['pid']==p.pid);assert abs(hb['created']-p.create_time())<.01
   idle=[i for i in old if load[i]<70]
   if idle and len(idle)<len(old):p.cpu_affinity(idle)
   if priority==psutil.NORMAL_PRIORITY_CLASS:p.nice(psutil.ABOVE_NORMAL_PRIORITY_CLASS)
   rec.update(affinity_after=p.cpu_affinity(),priority_after=int(p.nice()),ownership_verified=True)
  rows.append(rec)
 except psutil.NoSuchProcess:continue
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),per_core=load,owned_rows=rows,foreign_processes_modified=False,statistical_options_changed=False)
(R/'audit/OWNED_SCHEDULING.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))
