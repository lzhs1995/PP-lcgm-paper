"""实际解压、逐字节核验和公开参数复算；不接触源微观数据。"""
from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
R=Path(__file__).resolve().parents[1];S=R/'public_stage';read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def main():
 target=R/'public_verification';target.mkdir(exist_ok=False);allnames=set()
 for p in read(S/'PACKAGE_MANIFEST.json')['packages']:
  zpath=S/p['file'];assert zpath.stat().st_size==p['bytes']<25_000_000;assert hashlib.sha256(zpath.read_bytes()).hexdigest()==p['sha256']
  with zipfile.ZipFile(zpath) as z:
   assert z.testzip() is None
   for name in z.namelist():
    q=Path(name);assert not q.is_absolute() and '..' not in q.parts and 'private' not in q.parts and q.suffix.lower() not in ('.rds','.dta','.rdata');assert name not in allnames;allnames.add(name)
    if q.suffix=='.dat':assert q.name in ('estimates.dat','tech3.dat')
   z.extractall(target)
 manifest=read(target/'PAYLOAD_MANIFEST.json');assert allnames=={x['path'] for x in manifest}|{'PAYLOAD_MANIFEST.json'}
 for p in manifest:assert hashlib.sha256((target/p['path']).read_bytes()).hexdigest()==p['sha256']
 run=subprocess.run([sys.executable,'-X','utf8',str(target/'verification/verify_results.py'),'--public'],cwd=target,text=True,encoding='utf-8',capture_output=True,timeout=300)
 (R/'audit/PUBLIC_REPLAY_LOG.txt').write_text(run.stdout+'\n'+run.stderr,encoding='utf-8');assert run.returncode==0,run.stderr
 out=dict(status='PASS',payloads=len(manifest),files=len(allnames),public_replay=read(target/'audit/PUBLIC_PARAMETER_REPLAY.json')['status'])
 (R/'audit/PUBLIC_PACKAGE_VERIFICATION.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))
if __name__=='__main__':main()
