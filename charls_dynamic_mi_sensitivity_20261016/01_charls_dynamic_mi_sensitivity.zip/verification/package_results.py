"""只发布显式选择的汇总、模型参数和代码；禁止个人数据进入包。"""
from pathlib import Path
import csv,hashlib,io,json,re,zipfile
R=Path(__file__).resolve().parents[1];read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
def main():
 assert read(R/'audit/INDEPENDENT_VERIFICATION.json')['status']=='PASS'
 assert read(R/'audit/CLAUDER_COMPLETION.json')['decision']=='PASS'
 assert read(R/'audit/FIGURE_REVIEW.json')['status']=='PASS'
 S=R/'public_stage';S.mkdir(exist_ok=True);assert not list(S.glob('*.zip'))
 selected={}
 def add(rel,required=True):
  p=R/rel
  if not p.exists():assert not required,p;return
  assert 'private' not in Path(rel).parts and p.is_file() and p.suffix.lower() not in ('.rds','.dta','.rdata')
  if p.suffix.lower()=='.dat':assert p.name in ('estimates.dat','tech3.dat')
  selected[rel]=p
 for n in ('REPORT.md','RECEIPT.json'):add('reports/'+n)
 for n in ('RUN_CONTRACT.json','DATA_ENTRIES.json'):add('contracts/'+n)
 for n in ('REUSED_CODE.json','FROZEN_CODE.json','FROZEN_CODE_RESUME.json','MI_ADMISSIONS.json','TERMINAL.json','RESUME_TERMINAL.json','INDEPENDENT_VERIFICATION.json','CLAUDER_COMPLETION.json','FIGURE_REVIEW.json','EXPORT_DIAGNOSIS_NATIVE.json','EXPORT_REPAIR.json','NATIVE_SUBMIT.json','NATIVE_INITIAL_ERROR.json','NATIVE_RESUME_SUBMIT.json','NATIVE_FINAL_RESULT.json','MI_SESSION_INFO.txt','imputation_TERMINAL.json','imputation_resume_TERMINAL.json','models_TERMINAL.json','pool_TERMINAL.json'):add('audit/'+n)
 for n in ('FINAL_ASYNC_ARCHIVE.json','FINAL_RUNTIME.json'):add('audit/'+n)
 add('verification/complete_harness.py')
 for n in ('prepare_mi.R','coordinator.py','launch.R','watch_owned_scheduling.py'):add('audit/attempt01_code/'+n)
 for n in ('DIRECT_RESOURCE_RECOVERY.json','DIRECT_EXECUTED_CODE.json','DIRECT_TERMINAL.json','NATIVE_FIRST_TERMINAL.json','NATIVE_DIRECT_SUBMIT.json','SCHEDULER_REPAIR.json','OWNED_SCHEDULING.json','OWNED_SCHEDULING_CHANGES.jsonl','OWNED_SCHEDULING_V2.jsonl','SCHEDULING_WATCHER_V2_TERMINAL.json','POSTPROCESS_FINAL.json'):add('audit/'+n)
 for p in sorted((R/'code').glob('*')):
  if p.suffix in ('.R','.py'):add('code/'+p.name)
 for n in ('verify_results.py','report_results.py','package_results.py','verify_package.py','postprocess_final.py','inspect_owned_scheduling.py','watch_owned_scheduling.py','watch_owned_scheduling_v2.py'):add('verification/'+n)
 for z in ('sd','gender','oldest','son'):
  for n in ('ADMISSION.json','DRAW_EXECUTION.json','MEMBER_VALIDATION.csv','DRAW_SUMMARY.csv','PREDICTORS_ACTUAL.csv','MI_FIT_CACHE_FIRST.json'):add(f'mi/{z}/audit/{n}')
  add(f'mi/{z}/audit/LOGGED_EVENTS.csv',False)
 for n in ('CALL_RESULTS.json','FAMILY_STATUS.json','FAMILY_OVERVIEW.csv','POOLING_RECEIPT.json','FOUR_MODERATIONS.csv','POOLED_PATHS.csv','CONDITIONAL_SLOPES.csv','CC_MI_COMPARISON.csv','FOUR_MODERATIONS.pdf'):
  add('results/'+n,required=n not in ('FOUR_MODERATIONS.csv','POOLED_PATHS.csv','CONDITIONAL_SLOPES.csv'))
 for z in ('sd','gender','oldest','son'):
  add('results/'+z.upper()+'_START_COMPARISON.json',False)
  for n in ('POOLED_PATHS.csv','CLUSTER_DF_SENSITIVITY.csv','CONDITIONAL_SLOPES.csv','MEMBER_ESTIMATES.csv','MEMBER_COVARIANCES.csv','MEMBER_SOURCES.csv','RECEIPT.json'):add(f'results/{z}/{n}',False)
 for name in read(R/'results/CALL_RESULTS.json'):
  for n in ('model.inp','model.out','job.json','engine_receipt.json','receipt.json','mplus_execution.log','start_mapping.csv','validation.json','parameters_high_precision.csv','matrix_values.csv','tech1_parameter_map.csv','parameter_covariance.csv','key_paths.csv','estimates.dat','tech3.dat','not_run.json'):
   add(f'models/{name}/{n}',required=n in ('model.inp','job.json','start_mapping.csv'))
 add('runtime/budget_status.json');add('runtime/PIPELINE.json')
 payload={};manifest=[]
 for name,p in selected.items():
  raw=p.read_bytes()
  if p.suffix=='.pdf':data=raw
  else:
   text=raw.decode('utf-8-sig')
   for prefix in ('<LOCAL_USER_HOME>','<LOCAL_USER_HOME>','C:\\\\Users\\\\LZHS','<LOCAL_USER_HOME>','<LOCAL_USER_HOME>'):text=text.replace(prefix,'<LOCAL_USER_HOME>')
   assert not re.search(r'(?i)(?:api[_-]?key|access_token)\s*[:=]\s*["\x27]?[A-Za-z0-9_-]{20,}',text),name
   if p.suffix=='.csv' and p.name!='parameter_covariance.csv':
    head={x.lower() for x in next(csv.reader(io.StringIO(text)))};assert not head&{'pid','fid','childid','householdid','communityid'},name
   data=text.encode('utf-8')
  payload[name]=data;manifest.append(dict(path=name,bytes=len(data),sha256=sha(data),local_source_sha256=sha(raw),role='explicit_aggregate_code_or_model_parameter'))
 payload['PAYLOAD_MANIFEST.json']=json.dumps(manifest,indent=2).encode()
 groups=[sorted(payload.items())]
 while True:
  revised=[];split=False
  for items in groups:
   b=io.BytesIO()
   with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,data in items:z.writestr(n,data)
   if len(b.getvalue())>=25_000_000:mid=len(items)//2;assert mid;revised.extend([items[:mid],items[mid:]]);split=True
   else:revised.append(items)
  groups=revised
  if not split:break
 packs=[]
 for i,items in enumerate(groups,1):
  p=S/f'{i:02d}_charls_dynamic_mi_sensitivity.zip'
  with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
   for n,data in items:z.writestr(n,data)
  assert p.stat().st_size<25_000_000
  with zipfile.ZipFile(p) as z:assert z.testzip() is None
  packs.append(dict(file=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes()),files=len(items)))
 pm=dict(packages=packs,privacy='No individual DAT/DTA/RDS/MIDS; estimates.dat and tech3.dat contain aggregate model parameters only',full_H4_complete=False,full_four_moderation_inference_complete=False)
 (S/'PACKAGE_MANIFEST.json').write_text(json.dumps(pm,indent=2),encoding='utf-8')
 for source,target in [('reports/REPORT.md','REPORT.md'),('results/FOUR_MODERATIONS.csv','FOUR_MODERATIONS.csv'),('results/CC_MI_COMPARISON.csv','CC_MI_COMPARISON.csv'),('results/FOUR_MODERATIONS.pdf','FOUR_MODERATIONS.pdf')]:
  if source in payload:(S/target).write_bytes(payload[source])
 text='''# CHARLS四项动态调节：工作插补敏感性批次

**四项调节完整推断、完整 H4 仍未完成。**

[报告](REPORT.md) · [条件结果](FOUR_MODERATIONS.csv) · [完整案例对照](CC_MI_COMPARISON.csv) · [区间图](FOUR_MODERATIONS.pdf) · [包清单](PACKAGE_MANIFEST.json)

本批为SX×观测Z0→SY动态调节的工作插补敏感性分析。完整20份不等于已证明实质模型精确相容，也不是原CFPS四项调节或完整H4完成。未原样重跑失败CFPS、未修改冻结论文、未重新开启NLM。

所有ZIP<25,000,000字节。合并解压后按PAYLOAD_MANIFEST.json校验，运行 `python verification/verify_results.py --public` 直接复算原始保存参数/TECH3和完整家族合并；需要numpy、pandas、scipy，不读取未公开个人数据、不重新拟合。

此前CHARLS条件H4.1十二家族：[固定交付](https://github.com/lzhs1995/PP-lcgm-paper/tree/87941423437c589809a2c95833c220e387fc0f5d/charls_son_income_resume_20261016)。四项完整案例：[固定交付](https://github.com/lzhs1995/PP-lcgm-paper/tree/04e97911e2008343aacc7ccc1c38e4c84cffbbc8/charls_observed_moderation_20261016)。旧证据不重复上传。
'''
 (S/'README.md').write_text(text,encoding='utf-8')
 (S/'FOR_WEB_REVIEWERS.md').write_text('# 给网页端审阅者\n\n先看REPORT中的完整家族数、失败记录和工作插补边界，再看四项固定多重比较、原完整案例对照与条件斜率。不要把完整成员数当成精确相容性证明，不推断未运行的H4.2。原始参数可公开复算；个人资料不公开，无需再拟合或重开NLM。\n\n'+text,encoding='utf-8')
 (R/'audit/PUBLIC_FILE_SELECTION.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');print(json.dumps(pm))
if __name__=='__main__':main()
