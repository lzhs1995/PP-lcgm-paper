"""按模型心跳直接定位自有进程；固定阶段CPU集合，不把自身负载逐次排除。"""
import ctypes
ctypes.windll.kernel32.SetProcessAffinityMask(ctypes.windll.kernel32.GetCurrentProcess(),255)
from pathlib import Path
import datetime,json,time,psutil
R=Path(__file__).resolve().parents[1];read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
old=read(R/'audit/SCHEDULER_REPAIR.json');anchor_pid=old['watcher_stopped']['anchor_pid'];born=old['watcher_stopped']['anchor_created'];mask=old['anchor_after']
anchor=psutil.Process(anchor_pid);assert abs(anchor.create_time()-born)<.01
deadline=time.monotonic()+9000;done=set();records=0;me=psutil.Process()
(R/'runtime/SCHEDULING_WATCHER_V2.json').write_text(json.dumps(dict(pid=me.pid,created=me.create_time(),anchor_pid=anchor_pid,anchor_created=born,fixed_stage_mask=mask)),encoding='utf-8')
try:
 while time.monotonic()<deadline:
  if (R/'audit/RESUME_TERMINAL.json').exists() or not anchor.is_running() or abs(anchor.create_time()-born)>.01:break
  try:hb=read(R/'runtime/progress.json')
  except (OSError,ValueError):time.sleep(5);continue
  for q in hb.get('processes',[]):
   ident=(q['pid'],q['created'])
   if ident in done:continue
   try:
    p=psutil.Process(q['pid']);assert abs(p.create_time()-q['created'])<.01
    assert p.name().lower() in ('rscript.exe','cmd.exe','mplus.exe')
    assert anchor_pid in [a.pid for a in p.parents()]
    before=p.cpu_affinity();pri=p.nice();p.cpu_affinity(mask)
    if pri==psutil.NORMAL_PRIORITY_CLASS:p.nice(psutil.ABOVE_NORMAL_PRIORITY_CLASS)
    rec=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=p.pid,created=p.create_time(),name=p.name(),affinity_before=before,affinity_after=p.cpu_affinity(),priority_before=int(pri),priority_after=int(p.nice()),parent_chain_verified=True)
    with (R/'audit/OWNED_SCHEDULING_V2.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec)+'\n')
    records+=1;done.add(ident)
   except psutil.NoSuchProcess:continue
  time.sleep(3)
except psutil.NoSuchProcess:pass
finally:
 (R/'audit/SCHEDULING_WATCHER_V2_TERMINAL.json').write_text(json.dumps(dict(status='EXITED',records=records,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())),encoding='utf-8')
 print(json.dumps({'status':'EXITED','records':records}),flush=True)
