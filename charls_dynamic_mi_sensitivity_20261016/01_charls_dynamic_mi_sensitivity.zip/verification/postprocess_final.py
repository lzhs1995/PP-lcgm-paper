"""终态后自动进行一次独立验收/报告；只读已有估计，不提交模型。"""
import ctypes
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
assert k.SetProcessAffinityMask(k.GetCurrentProcess(),15),ctypes.get_last_error()
from pathlib import Path
import datetime,json,os,subprocess,sys,time,psutil
R=Path(__file__).resolve().parents[1];read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def main():
 assert not (R/'audit/POSTPROCESS_FINAL.json').exists()
 me=psutil.Process();me.nice(psutil.ABOVE_NORMAL_PRIORITY_CLASS);deadline=time.monotonic()+10000
 (R/'runtime/POSTPROCESS_FINAL_OWNER.json').write_text(json.dumps({'pid':me.pid,'created':me.create_time()}),encoding='utf-8')
 while not (R/'audit/DIRECT_TERMINAL.json').exists():
  assert time.monotonic()<deadline,'No terminal before bounded wait deadline';time.sleep(15)
 terminal=read(R/'audit/DIRECT_TERMINAL.json');assert terminal['status']=='DIRECT_RESOURCE_CONTINUATION_TERMINAL',terminal
 assert not (R/'runtime/engine.lock').exists()
 logs={};env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
 for name in ('verify_results.py','report_results.py'):
  start=time.monotonic()
  with (R/'verification'/f'final_{name}.log').open('xb') as log:
   p=subprocess.Popen([sys.executable,'-X','utf8',str(R/'verification'/name)],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
   child=psutil.Process(p.pid);child.nice(psutil.ABOVE_NORMAL_PRIORITY_CLASS)
   code=p.wait(timeout=600)
  logs[name]=dict(exitcode=code,seconds=time.monotonic()-start)
  (R/'audit/POSTPROCESS_FINAL_PROGRESS.json').write_text(json.dumps(logs,indent=2),encoding='utf-8');assert code==0,name
 import fitz
 doc=fitz.open(R/'results/FOUR_MODERATIONS.pdf');assert len(doc)==1
 doc[0].get_pixmap(matrix=fitz.Matrix(1.5,1.5)).save(R/'results/PDF_RENDER.png');doc.close()
 out=dict(status='NUMERIC_REPORT_AND_PDF_READY',steps=logs,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (R/'audit/POSTPROCESS_FINAL.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out),flush=True)
if __name__=='__main__':main()
