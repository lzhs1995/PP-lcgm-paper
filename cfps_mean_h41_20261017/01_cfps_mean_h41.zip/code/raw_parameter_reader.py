"""直接解析原始TECH1、RESULTS和TECH3，独立核验R汇总；公开包可复用。"""
from pathlib import Path
import csv,hashlib,json,re
import numpy as np
import pandas as pd
from scipy.stats import norm

ROOT=Path(__file__).resolve().parents[1]
def read_json(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def tech1(text):
    text=text.split('PARAMETER SPECIFICATION',1)[1].split('STARTING VALUES',1)[0]
    lines=text.splitlines();result=[];i=0
    mats={'NU','LAMBDA','THETA','ALPHA','BETA','PSI','GAMMA','TAU','KAPPA'}
    while i<len(lines)-2:
        mat=lines[i].strip()
        if mat not in mats or not re.fullmatch(r'[_ ]+',lines[i+2]) or not lines[i+2].strip():i+=1;continue
        cols=lines[i+1].split();i+=3
        while i<len(lines) and lines[i].strip() and lines[i].strip() not in mats:
            tk=lines[i].split()
            if mat in {'NU','ALPHA','TAU','KAPPA'} and re.match(r'^[-+\d]',tk[0]):row='1';vals=tk
            else:row=tk[0];vals=tk[1:]
            for col,value in zip(cols,vals,strict=False):result.append((mat,row,col,int(value)))
            i+=1
    return result
def raw_model(d):
    out=(d/'model.out').read_text(encoding='latin1');mapping=tech1(out)
    n=max(r[3] for r in mapping);assert set(r[3] for r in mapping if r[3])==set(range(1,n+1))
    q=np.fromstring((d/'estimates.dat').read_text(),sep=' ');t=np.fromstring((d/'tech3.dat').read_text(),sep=' ')
    assert len(q)>=2*n and len(t)==n*(n+1)//2
    v=np.zeros((n,n));ix=np.tril_indices(n);v[ix]=t;v=v+v.T-np.diag(v.diagonal())
    assert np.allclose(np.sqrt(v.diagonal()),q[n:2*n],rtol=1e-6,atol=1e-8)
    p=pd.read_csv(d/'parameters_high_precision.csv').sort_values('parameter')
    assert len(p)==n and np.allclose(p.estimate,q[:n],atol=1e-12) and np.allclose(p.se,q[n:2*n],atol=1e-12)
    assert np.allclose(pd.read_csv(d/'parameter_covariance.csv',header=None),v,rtol=1e-12,atol=1e-12)
    k=pd.read_csv(d/'key_paths.csv')
    for r in k.itertuples():
        matches={m[3] for m in mapping if m[0] in {'BETA','GAMMA'} and m[1:3]==(r.row,r.column) and m[3]>0}
        assert matches=={r.parameter},(d.name,r.label,matches)
        assert np.allclose([r.estimate,r.se],[q[r.parameter-1],q[n+r.parameter-1]],atol=1e-12)
    return out,mapping,q[:n],q[n:2*n],v,k,q[2*n+1]
