"""冻结本批范围，复制既有已验证执行依赖；不启动估计。"""
from pathlib import Path
import json,hashlib,shutil,datetime
R=Path(__file__).resolve().parents[1]
Y=R.parent/'cfps_yshape_parent_20261017'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (R/'contracts/RUN_CONTRACT.json').exists()
files=['r2e_local.R','r2e_tools.R','r2e_upstream_math.R','engine.py','run_one.R','windows_awake_guard.py','mplus_queue.py','process_ownership.py','raw_parameter_reader.py']
deps=[]
for name in files:
 src=Y/'code'/name;dst=R/'code'/name
 assert src.exists() and not dst.exists()
 shutil.copyfile(src,dst);assert sha(src)==sha(dst)
 deps.append(dict(name=name,source=str(src),sha256=sha(src)))
(R/'audit/REUSED_DEPENDENCIES.json').write_text(json.dumps(deps,indent=2),encoding='utf-8')
c=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 authorization='Authorized original H4 follow-up; original-script mean-resource paths not present in 1124 inventoried corrected model inputs',
 scope='CFPS corrected SW parent plus resource moderation of IX->IY, IX->SY, SX->SY; no Z trajectory; conditional working-MI inference only',
 groups={'EDU':'c2: education binary, original fixed definition','URBAN':'c3: urban binary','INC':'ginc: positive personal income, NOT high household income'},
 models={'parent':'X free endpoint0/1; Y fixed calendar endpoint0/1; same-wave residuals; c1-c24','EDU_URBAN':'reuse existing ten SW parents; G main terms already in c1-c24','INC':'first legal E0 adding ginc main terms on ix sx iy sy; no other adjustment changes','interactions':['IXG=IX*G -> IY','IXG -> SY','SXG=SX*G -> SY']},
 data='Preserve SW 35 original text columns exactly; append ginc from row-bound R2D SD data; no source writes; ten frozen existing imputations',
 max_calls=34,total_engine_seconds=3600,category_seconds={g:1200 for g in ['EDU','URBAN','INC']},per_call_seconds=240,
 numerical_agreement=dict(LL_absolute=.01,parameter_SE_fraction=.05,parameter_absolute_floor=.001,SE_relative=.05),
 starts='A uses legal own-member SW high precision values and new interactions +0.10. B uses same MI01 parent with deterministic +/-0.02 common-path perturbation, interactions -0.10. No third start.',
 integration=dict(method='standard deterministic quadrature',points=20,processors=1,expected_dimensions=2),
 admission='Each family: legal parent -> MI01 A -> if legal MI01 B -> if agreement MI02-10, first bad member stops remaining family. No omitted-member pooling, variance fixing or unbounded repairs.',
 inference='Complete 10 only: Rubin full covariance, joint three interaction paths D1 with complete-data df=Inf, Holm across 3 resource families; group contrasts use all covariance terms. Incomplete families stay NA, planned denominator=3. No mean P.',
 resource_admission_revision=dict(owned_engine_slots=1,max_external_mplus_at_admission=2,minimum_available_gib=1,minimum_commit_available_gib=2,max_host_cpu_percent=85,resource_wait_seconds=120,foreign_processes_never_modified=True),
 full_original_H4_complete=False,original_four_moderation_complete=False,original_files_immutable=True,
 limitation='Conditional on frozen covariate working MI; no claim of exact latent-interaction congeniality or full original H4 coverage',
 primary_sources=['https://www.statmodel.com/HTML_UG/chapter17V8.htm','https://www.statmodel.com/HTML_UG/chapter5V8.htm'])
p=R/'contracts/RUN_CONTRACT.json';p.write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding='utf-8')
(R/'audit/PREFLIGHT_ROUNDING_NOTE.json').write_text(json.dumps(dict(first_check='Strict numeric equality of SW and R2D exports failed before engine or final manifest',diagnosis='Same missing mask and FID row order; maximum difference 4.830091882e-11 from decimal export precision',resolution='Analysis retains every original SW token; R2D only supplies row-bound integer ginc',new_engine_calls=0),indent=2),encoding='utf-8')
print(json.dumps(dict(status='CONTRACT_FROZEN',sha256=sha(p),copied=len(deps))))
