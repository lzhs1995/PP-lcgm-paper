# 只读父模型验收及语法准备；此脚本不调用Mplus。
source('<LOCAL_USER>/pp_lgcm_review/cfps_mean_h41_20261017/code/mean_tools.R',local=TRUE)
inv<-rj(file.path(ROOT,'audit/SOURCE_INVENTORY.json'));stopifnot(length(inv$members)==10L,!length(inv$latent_intercept_candidates))
checks<-list()
for(k in 1:10){
 rec<-inv$members[[k]];d<-rec$source_parent
 for(n in names(rec$parent_hashes))stopifnot(hashf(file.path(d,n))==rec$parent_hashes[[n]])
 stopifnot(hashf(rec$data)==rec$data_sha256)
 m<-read_mplus_raw(d);si<-mean_spec('EDU',FALSE);gt<-gate_r2e(m,si)
 stopifnot(m$P==128L,gt$passed)
 checks[[k]]<-list(member=k,parameters=m$P,passed=gt$passed,source=d,hash=hashf(file.path(d,'model.out')))
 for(g in c('EDU','URBAN','INC')){
  ss<-mean_spec(g);mm<-mean_mapping(ss,d,'A')
  stopifnot(mm$expected_free==if(g=='INC')135L else 131L)
  xx<-mean_input(paste('PREPARED',g,k),ss,mm)
  stopifnot(!any(grepl('sy@0',xx,fixed=TRUE)))
 }
 if(exists('clauder_progress',mode='function'))clauder_progress('validating_parents',paste(k,'/10 legal SW parents'))
}
writeLines(capture.output(sessionInfo()),file.path(ROOT,'audit/PREPARE_R_SESSION.txt'))
wj(list(status='MEAN_H41_PREPARED',parents=checks,contract_sha256=hashf(file.path(ROOT,'contracts/RUN_CONTRACT.json')),new_mplus_calls=0),file.path(ROOT,'audit/PREPARE_RECEIPT.json'))
cat('MEAN_H41_PREPARED\n')
