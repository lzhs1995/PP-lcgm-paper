"""限定修正数据模型目录的来源审查；不扫描公开副本、不重估。"""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import hashlib,json,re,shutil,datetime
import numpy as np
R=Path(__file__).resolve().parents[1];B=R.parent
for n in ('audit','contracts','runtime','results','models','private','reports'):(R/n).mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
roots=[p for p in B.iterdir() if p.is_dir() and p.name!=R.name and p.name.startswith(('cfps_','reopen_','h41_','charls_','round2'))]
checked=[];candidates=[]
for root in roots:
 md=root/'models'
 if not md.is_dir():continue
 for p in md.rglob('*.inp'):
  txt=p.read_text(encoding='utf-8-sig',errors='replace');clean='\n'.join(s.split('!')[0] for s in txt.splitlines())
  checked.append(str(p.relative_to(B)))
  # 保留全部潜截距交互候选供人工判别，不用文件名推断是否相同。
  matches=re.findall(r'(\w+)\s*\|\s*(i\w*)\s+XWITH\s+(\w+)\s*;',clean,re.I)
  if matches:
   d=p.parent;dp=d/'data.dat'
   candidates.append(dict(path=str(p.relative_to(B)),input_sha256=sha(p),interactions=matches,data_sha256=sha(dp) if dp.exists() else None,output_exists=p.with_suffix('.out').exists()))
src=Path('<LOCAL_USER>/Desktop/interge_rela/20251003 closeness&depression_relative.R')
lines=src.read_text(encoding='utf-8-sig').splitlines()
hits=[]
for i,line in enumerate(lines):
 if re.search(r'i1\s+XWITH\s+(edu12|urban12|pinc412)',line,re.I):
  hits.append(dict(line=i+1,syntax=line.strip(),nearby_paths=[s.strip() for s in lines[i:i+35] if re.search(r'^\s*(i5|s5)\s+on\s+(i1|s1|i1sx_int|s1sx_int)',s,re.I)]))
members=[]
zcontract=json.loads((B/'round2D_20261008/audit/Z_CONTRACT.json').read_text(encoding='utf-8-sig'))
for k in range(1,11):
 sw=B/'round2C_20261007/models'/f'SW_MI{k:02d}'/'attempt01';dat=B/'round2D_20261008/private/SD'/f'Z0_member_{k:02d}.dat'
 assert dat.exists() and sw.is_dir()
 old=np.genfromtxt(sw/'data.dat',missing_values='.',filling_values=np.nan);new=np.genfromtxt(dat,missing_values='.',filling_values=np.nan)
 assert old.shape==(3274,35) and new.shape==(3274,44)
 selected=np.column_stack((new[:,:11],new[:,20:44]))
 # 两个历史导出采用不同小数精度：只用于绑定收入行序，实际分析保留SW原token。
 assert np.array_equal(np.isnan(old),np.isnan(selected)) and np.array_equal(old[:,0],selected[:,0])
 discrepancy=float(np.nanmax(abs(old-selected)));assert discrepancy<1e-9
 assert sha(dat)==zcontract['samples']['SD_Z0']['data_sha256'][k-1]
 assert np.array_equal(new[:,17],new[:,21]) and np.array_equal(new[:,18],new[:,22])
 assert set(new[:,19])=={0.,1.}
 target=R/'private'/f'MI{k:02d}.dat';assert not target.exists()
 source_lines=[s for s in (sw/'data.dat').read_text().splitlines() if s.strip()]
 assert len(source_lines)==3274 and all(len(s.split())==35 for s in source_lines)
 target.write_text('\n'.join(s+' '+str(int(new[i,19])) for i,s in enumerate(source_lines))+'\n',encoding='ascii')
 appended=np.genfromtxt(target,missing_values='.',filling_values=np.nan)
 assert np.array_equal(appended[:,:35],old,equal_nan=True)
 members.append(dict(member=k,source_parent=str(sw),data=str(target),data_sha256=sha(target),source_group_data=str(dat),source_group_data_sha256=sha(dat),parent_hashes={n:sha(sw/n) for n in ('model.inp','model.out','data.dat','estimates.dat','tech3.dat','receipt.json')},SW_analysis_columns_exactly_equal=True,SW_to_R2D_max_export_rounding=discrepancy,N=3274,households=len(set(new[:,0])),group_counts={g:{str(v):int(np.sum(new[:,col]==v)) for v in (0,1)} for g,col in [('EDU',21),('URBAN',22),('INC',19)]}))
result=dict(status='SOURCE_INVENTORY_COMPLETE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),roots=[x.name for x in roots],inputs_examined=len(checked),latent_intercept_candidates=candidates,original_script_sha256=sha(src),original_mean_resource_lines=hits,members=members,scope='Canonical models/ directories only; no claim that every historical file on the computer was scanned')
(R/'audit/SOURCE_INVENTORY.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(status=result['status'],inputs_examined=len(checked),candidates=candidates,original_lines=hits,verified_members=len(members)),ensure_ascii=False))
