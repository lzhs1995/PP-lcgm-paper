"""独立核对每次调用、原始参数及完整家族合并；绝不重新拟合。"""
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[name]='1'
from pathlib import Path
import hashlib,json,re,sys
import numpy as np
import pandas as pd
from scipy.stats import t
from raw_parameter_reader import raw_model
R=Path(__file__).resolve().parents[1]
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
public='--public' in sys.argv
term=load(R/'audit/BATCH_TERMINAL.json');pool=load(R/'results/POOLING_RECEIPT.json');contract=load(R/'contracts/RUN_CONTRACT.json')
assert term['status']=='MEAN_H41_BATCH_ADJUDICATED'
records=[];raw={};total=0
for d in sorted((R/'models').iterdir()):
 if not d.is_dir():continue
 rr=load(d/'receipt.json');job=load(d/'job.json');er=rr.get('engine')
 if not public:
  for n,h in job['hashes'].items():assert sha(d/n)==h
  if (d/'model.out').exists():assert sha(d/'model.out')==rr['output_sha256']==er['output_sha256']
 txt=(d/'model.inp').read_text();model=txt.split('MODEL:',1)[1].split('OUTPUT:',1)[0]
 if job['interaction']:
  assert len(re.findall(r'\bXWITH\b',model,re.I))==2
  for lhs,rhs in [('iy','ixg'),('sy','ixg'),('sy','sxg')]:assert re.search(rf'\b{lhs}\s+ON\s+{rhs}\b',model,re.I)
 assert not re.search(r'\b(?:ix|sx|iy|sy)\s*@\s*0\s*;',model,re.I)
 row=dict(id=d.name,group=job['group'],member=job['member'],interaction=job['interaction'],status=rr['status'],engine_seconds=er['seconds'] if er else 0)
 total+=row['engine_seconds']
 if er:
  assert er['seconds']<=job['cap_seconds']+10
  row['peak_tree_rss_MiB']=er['peak_tree_rss']/2**20
  row['sampled_tree_cpu_seconds']=er['sampled_tree_cpu_seconds']
 if (d/'parameters_high_precision.csv').exists():
  text,mapping,q,se,V,paths,_=raw_model(d);raw[d.name]=(mapping,q,se,V,paths)
  assert len(q)==job['expected_free']
  ix={r[3]-1 for r in mapping if r[:3]==('PSI','SY','SY')};assert len(ix)==1
  i=next(iter(ix));row.update(parameters=len(q),SY=float(q[i]),SY_SE=float(se[i]))
  assert np.isclose(q[i],rr['SY'],rtol=1e-10,atol=1e-10)
  if rr['status']=='USABLE':
   assert q[i]>0 and load(d/'validation.json')['passed'] and np.linalg.eigvalsh(V).min()>0
   assert 'THE MODEL ESTIMATION TERMINATED NORMALLY' in text
 else:
  assert rr['status']!='USABLE'
 records.append(row)
assert len(records)<=contract['max_calls'] and total<=contract['total_engine_seconds']+10
fs=load(R/'results/FAMILY_STATUS.json');complete=sum(x['complete_MI'] for x in fs.values());assert complete==pool['complete']
for g,f in fs.items():
 members=[r for r in records if r['group']==g and r['interaction'] and r['status']=='USABLE' and r['id'].endswith('_A')]
 if not f['complete_MI']:continue
 assert sorted(x['member'] for x in members)==list(range(1,11))
 Q=[];U=[]
 for row in sorted(members,key=lambda x:x['member']):
  mp,q,se,v,p=raw[row['id']];ids=p.parameter.to_numpy(int)-1;Q.append(q[ids]);U.append(v[np.ix_(ids,ids)])
 Q=np.array(Q);W=np.mean(U,axis=0);B=np.cov(Q,rowvar=False);T=W+1.1*B
 est=Q.mean(0);se=np.sqrt(T.diagonal());r=1.1*B.diagonal()/W.diagonal();df=np.where(r>0,9*(1+1/r)**2,np.inf)
 want=pd.read_csv(R/'results/POOLED_PATHS.csv').query('group==@g')
 assert np.allclose(want.estimate,est,atol=1e-10) and np.allclose(want.se,se,atol=1e-10)
 assert np.allclose(want.lower,est-t.ppf(.975,df)*se,atol=1e-8)
if not public:
 # 原始数据仅本机再核对，公开模式不需要也不含逐人数据。
 inv=load(R/'audit/SOURCE_INVENTORY.json')
 for rec in inv['members']:
  assert sha(Path(rec['data']))==rec['data_sha256']
  for n,h in rec['parent_hashes'].items():assert sha(Path(rec['source_parent'])/n)==h
result=dict(status='PASS',new_calls=len([r for r in records if r['engine_seconds']>0]),engine_seconds=total,attempts=records,
 complete_mean_resource_families=complete,existing_baseline_difference_H41_families='CFPS3/12;CHARLS12/12;different registry',
 original_four_moderation_complete=False,full_original_H4_complete=False,public_mode=public)
(R/'audit/INDEPENDENT_MEAN.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
