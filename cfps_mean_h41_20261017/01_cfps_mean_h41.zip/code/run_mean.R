# 原生ClaudeR后台唯一协调器；逐家族停止规则，不重提已有输出。
source('<LOCAL_USER>/pp_lgcm_review/cfps_mean_h41_20261017/code/mean_tools.R',local=TRUE)
library(MplusAutomation);library(ps)
safe_progress<-function(stage,message)tryCatch(progress(stage,message),error=function(e){cat(conditionMessage(e),'\n');flush.console()})
run_member<-function(group,k,start='A',interaction=TRUE,parent=NULL){
 si<-mean_spec(group,interaction);if(is.null(parent))parent<-swpath(k)
 id<-sprintf('CFPS_MEAN_%s_%s_MI%02d_%s',group,if(interaction)'H41' else 'E0',k,start)
 d<-file.path(ROOT,'models',id);stopifnot(!dir.exists(d));dir.create(d)
 mm<-mean_mapping(si,parent,start);expected<-128L+if(group=='INC')4L else 0L
 if(interaction)expected<-expected+3L
 stopifnot(mm$expected_free==expected)
 writeLines(mean_input(id,si,mm),file.path(d,'model.inp'));csv(mm$mapping,file.path(d,'start_mapping.csv'))
 source_data<-file.path(ROOT,'private',sprintf('MI%02d.dat',k))
 stopifnot(file.copy(source_data,file.path(d,'data.dat'),overwrite=FALSE))
 j<-list(id=id,root=ROOT,dest=d,group=group,member=k,start=start,interaction=interaction,category=group,
   cap_seconds=240,rscript=file.path(R.home('bin'),'Rscript.exe'),mplus=MPLUS,expected_free=expected,parent=parent,
   hashes=list(model.inp=hashf(file.path(d,'model.inp')),data.dat=hashf(file.path(d,'data.dat'))))
 wj(j,file.path(d,'job.json'));safe_progress('MEAN_H41_MODEL_START',id)
 p<-processx::process$new(PY,c('-X','utf8',file.path(ROOT,'code/engine.py'),file.path(d,'job.json')),
   stdout=file.path(d,'supervisor.log'),stderr='2>&1',cleanup=FALSE)
 last<-0
 while(p$is_alive()){
  p$wait(1000L)
  if(as.numeric(Sys.time())-last>25){
   hb<-tryCatch(rj(file.path(ROOT,'runtime/progress.json')),error=function(e)NULL)
   msg<-if(is.null(hb))paste(id,'admission') else paste(id,hb$stage,if(!is.null(hb$elapsed_seconds))round(hb$elapsed_seconds,1) else '')
   if(exists('clauder_progress',mode='function'))try(clauder_progress('estimating',msg),silent=TRUE)
   cat(msg,'\n');flush.console();last<-as.numeric(Sys.time())
  }
 }
 er<-rj(file.path(d,'engine_receipt.json'));nr<-rj(file.path(d,'not_run.json'))
 rr<-list(id=id,dest=d,group=group,member=k,start=start,interaction=interaction,
   status=if(!is.null(er))er$status else if(!is.null(nr))nr$status else 'SUPERVISOR_NO_RECEIPT',engine=er)
 if(!is.null(er)&&er$status=='EXITED')rr<-tryCatch({
  native<-MplusAutomation::readModels(file.path(d,'model.out'),what='all',quiet=TRUE)
  saveRDS(native,file.path(d,'mplusautomation_readback.rds'))
  m<-read_mplus_raw(d);stopifnot(m$P==expected)
  gt<-gate_r2e(m,si);rr$status<-classify_local(m,si,gt)
  if(any(grepl('FIXED TO AVOID SINGULARITY',m$lines,fixed=TRUE)))rr$status<-'AUTOFIX_REJECTED'
  dimline<-grep('Dimensions of numerical integration',m$lines,value=TRUE)
  rr$integration_dimensions<-if(length(dimline))as.integer(sub('.*?([0-9]+)\\s*$','\\1',dimline[1])) else 0L
  if(interaction&&rr$integration_dimensions!=2L)rr$status<-'INTEGRATION_DIMENSION_MISMATCH'
  rr$parameters<-m$P;rr$negative<-gt$negative;rr$SY<-mval(m,'PSI','SY','SY');rr$LL<-m$extra[['H0 Loglikelihood']]
  csv(m$par,file.path(d,'parameters_high_precision.csv'));csv(key_paths_r2e(m,si$key),file.path(d,'key_paths.csv'))
  csv(m$spec,file.path(d,'tech1_parameter_map.csv'));csv(m$values,file.path(d,'matrix_values.csv'))
  write.table(m$V,file.path(d,'parameter_covariance.csv'),sep=',',row.names=FALSE,col.names=FALSE)
  wj(gt,file.path(d,'validation.json'));wj(m$extra,file.path(d,'saved_fit.json'));rr
 },error=function(e){rr$status<-'READBACK_OR_ESTIMATION_FAILURE';rr$error<-conditionMessage(e);rr})
 if(file.exists(file.path(d,'model.out')))rr$output_sha256<-hashf(file.path(d,'model.out'))
 wj(rr,file.path(d,'receipt.json'));safe_progress('MEAN_H41_MODEL_END',paste(id,rr$status));rr
}
main<-function(){
 stopifnot(!file.exists(file.path(ROOT,'audit/BATCH_TERMINAL.json')))
 contract<-rj(file.path(ROOT,'contracts/RUN_CONTRACT.json'))
 stopifnot(hashf(file.path(ROOT,'contracts/RUN_CONTRACT.json'))==rj(file.path(ROOT,'audit/PREPARE_RECEIPT.json'))$contract_sha256)
 owner<-list(pid=Sys.getpid(),created=as.numeric(ps::ps_create_time(ps::ps_handle())))
 wj(list(owner=owner),file.path(ROOT,'runtime/OWNER.json'))
 awake<-processx::process$new(PY,c('-X','utf8',file.path(ROOT,'code/windows_awake_guard.py'),'--owner-file',file.path(ROOT,'runtime/OWNER.json'),'--output',file.path(ROOT,'runtime/awake'),'--interval','5'),stdout=file.path(ROOT,'runtime/awake.log'),stderr='2>&1',cleanup=FALSE)
 on.exit({writeLines('release owned guard',file.path(ROOT,'runtime/awake/stop.request'));awake$wait(8000L)},add=TRUE)
 active<-FALSE
 for(i in 1:40){
  a<-rj(file.path(ROOT,'runtime/awake/identity.json'));hb<-rj(file.path(ROOT,'runtime/awake/heartbeat.json'))
  if(!is.null(a)&&!is.null(hb)&&a$owner$pid==owner$pid&&abs(a$owner$created-owner$created)<.01&&awake$is_alive()){active<-TRUE;break}
  if(!awake$is_alive())stop('Awake helper failed');Sys.sleep(.5)
 };stopifnot(active)
 registry<-list();all_attempts<-list()
 save_attempt<-function(rr){all_attempts[[rr$id]]<<-rr;wj(all_attempts,file.path(ROOT,'results/ATTEMPTS.json'))}
 for(g in c('EDU','URBAN','INC')){
  fam<-list(group=g,status='STARTING',complete_MI=FALSE,planned_members=10,usable_members=0)
  parent<-swpath(1)
  if(g=='INC'){
   ep<-run_member(g,1,'A',FALSE,parent);save_attempt(ep)
   if(ep$status!='USABLE'){
    fam$status<-'PARENT_FAILED';fam$reason<-ep$status;registry[[g]]<-fam;wj(registry,file.path(ROOT,'results/FAMILY_STATUS.json'));next
   };parent<-ep$dest
  }
  a<-run_member(g,1,'A',TRUE,parent);save_attempt(a)
  if(a$status!='USABLE'){
   fam$status<-'FIRST_MEMBER_FAILED';fam$reason<-a$status;registry[[g]]<-fam;wj(registry,file.path(ROOT,'results/FAMILY_STATUS.json'));next
  }
  b<-run_member(g,1,'B',TRUE,parent);save_attempt(b)
  if(b$status!='USABLE'){
   fam$status<-'SECOND_START_FAILED';fam$reason<-b$status;registry[[g]]<-fam;wj(registry,file.path(ROOT,'results/FAMILY_STATUS.json'));next
  }
  aa<-list(key=read.csv(file.path(a$dest,'key_paths.csv')),receipt=a)
  bb<-list(key=read.csv(file.path(b$dest,'key_paths.csv')),receipt=b)
  cmp<-compare_numeric(aa,bb,'start',list(start_LL=.01,start_path_abs=.001,start_path_se=.05,integration_path_se=.05,se_rel=.05))
  wj(cmp,file.path(ROOT,'results',paste0(g,'_START_AGREEMENT.json')))
  if(!isTRUE(cmp$passed)){
   fam$status<-'START_DISAGREEMENT';registry[[g]]<-fam;wj(registry,file.path(ROOT,'results/FAMILY_STATUS.json'));next
  }
  fam$usable_members<-1;members<-list(a);fam$status<-'EXTENDING_MI'
  for(k in 2:10){
   rr<-run_member(g,k,'A',TRUE,swpath(k));save_attempt(rr)
   if(rr$status!='USABLE'){fam$status<-'MI_FAMILY_INCOMPLETE';fam$reason<-rr$status;break}
   members[[k]]<-rr;fam$usable_members<-k
   registry[[g]]<-fam;wj(registry,file.path(ROOT,'results/FAMILY_STATUS.json'))
  }
  fam$complete_MI<-fam$usable_members==10L
  if(fam$complete_MI)fam$status<-'COMPLETE_CONDITIONAL_WORKING_MI'
  fam$member_paths<-vapply(members,function(x)x$dest,'')
  registry[[g]]<-fam;wj(registry,file.path(ROOT,'results/FAMILY_STATUS.json'))
 }
 writeLines(capture.output(sessionInfo()),file.path(ROOT,'audit/R_SESSION_INFO.txt'))
 wj(list(status='MEAN_H41_BATCH_ADJUDICATED',groups=registry,budget=rj(file.path(ROOT,'runtime/budget_status.json')),
   original_four_moderation_complete=FALSE,full_original_H4_complete=FALSE),file.path(ROOT,'audit/BATCH_TERMINAL.json'))
 safe_progress('MEAN_H41_NATIVE_TERMINAL','All three bounded resource families adjudicated; no unchanged retries')
 cat('MEAN_H41_NATIVE_TERMINAL\n')
}
main()
