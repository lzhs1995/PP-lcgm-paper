"""Windows真实短进程验收，不调用Mplus。保留故障而不自动重复。"""
from pathlib import Path
import json,subprocess,sys,time,threading
from bounded_child import run_child
R=Path(__file__).resolve().parents[1]/'control_tests'
assert not R.exists();R.mkdir()
sentinel=subprocess.Popen([sys.executable,'-c','import time; time.sleep(120)'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
checks=[]
try:
 r=run_child([sys.executable,'-u','-c','print("NATURAL_EXIT",flush=True)'],R/'natural',20)
 assert r['state']=='EXITED' and r['exitcode']==0 and (R/'natural/stdout.log').read_text().strip()=='NATURAL_EXIT'
 checks.append(dict(name='normal_exit_preserves_stdout',result=r))
 # 慢观察器并发等待，不处于截止检测路径。
 observer=threading.Thread(target=lambda:time.sleep(10),daemon=True);observer.start()
 r=run_child([sys.executable,'-u','-c','import time; print("BEFORE_TIMEOUT",flush=True); time.sleep(60)'],R/'timeout',4)
 assert r['state']=='TIMEOUT' and r['process_exited'] and 'BEFORE_TIMEOUT' in (R/'timeout/stdout.log').read_text()
 assert sentinel.poll() is None,'Unrelated same-name process must survive'
 assert r['detected_seconds']<5.5 and r['exit_confirmed_seconds']<7,'Measured deadline budget exceeded; do not retry silently'
 checks.append(dict(name='timeout_retains_stdout_and_spares_unrelated_process',result=r))
 assert observer.is_alive(),'Slow observation must not block deadline completion'
 checks.append(dict(name='slow_observer_not_on_control_path',status='PASS'))
 (R/'VALIDATION.json').write_text(json.dumps(dict(status='PASS_WINDOWS_DIRECT_CHILD_CONTROL',checks=checks,
    real_Mplus_calls=0,production_queue_integrated=False,direct_child_only=True),indent=2))
 print((R/'VALIDATION.json').read_text(),flush=True)
finally:
 if sentinel.poll() is None:sentinel.kill();sentinel.wait(timeout=10)
 (R/'SENTINEL_CLEANUP.json').write_text(json.dumps(dict(pid=sentinel.pid,exited=sentinel.poll() is not None)))
