"""直接子进程控制候选：计时路径不做进程扫描或日志读取。尚未接入研究队列。"""
from pathlib import Path
import math,subprocess,time
def run_child(command,directory,timeout_seconds):
    if not math.isfinite(timeout_seconds) or timeout_seconds<=0:raise ValueError('Positive finite limit required')
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=False)
    with (directory/'stdout.log').open('xb') as stdout,(directory/'stderr.log').open('xb') as stderr:
        started=time.monotonic();deadline=started+timeout_seconds
        process=subprocess.Popen(command,cwd=directory,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,shell=False)
        launched=time.monotonic();detected=None;kill_requested=None;state='EXITED'
        try:
            process.wait(timeout=max(0,deadline-time.monotonic()))
        except subprocess.TimeoutExpired:
            detected=time.monotonic();state='TIMEOUT'
            # Popen保留自己创建的进程句柄；不使用PID名称匹配或全局taskkill。
            kill_requested=time.monotonic();process.kill();process.wait(timeout=10)
        exited=time.monotonic()
    return dict(state=state,pid=process.pid,exitcode=process.returncode,
      configured_seconds=timeout_seconds,launch_seconds=launched-started,
      detected_seconds=None if detected is None else detected-started,
      kill_requested_seconds=None if kill_requested is None else kill_requested-started,
      exit_confirmed_seconds=exited-started,process_exited=process.poll() is not None,
      direct_child_only=True)
