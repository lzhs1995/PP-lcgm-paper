# 原生ClaudeR异步入口；长期监督不占用RStudio前台。
local({
  library(processx);library(jsonlite)
  root <- 'C:/Users/LZHS/pp_lgcm_review/mplus_live_output_probe_20261019'
  py <- 'C:/Users/LZHS/AppData/Local/Programs/Python/Python314/python.exe'
  progress <- function(stage,message) {
    if(exists('clauder_progress',mode='function',inherits=TRUE))clauder_progress(stage,message)
    cat(stage,message,'\n');flush.console()
  }
  progress('stream_probe_start','Two synthetic attempts maximum; real data calls zero')
  p <- process$new(py,c('-X','utf8',file.path(root,'code/stream_supervisor.py')),
    stdout=file.path(root,'runtime/supervisor.log'),stderr='2>&1',cleanup_tree=TRUE)
  last <- ''
  while(p$is_alive()) {
    Sys.sleep(3)
    f <- file.path(root,'runtime/PROGRESS.json')
    if(file.exists(f)) {
      x <- tryCatch(fromJSON(f),error=function(e)NULL)
      if(!is.null(x)&&x$updated_at!=last) {progress(x$stage,x$message);last<-x$updated_at}
    }
  }
  stopifnot(p$get_exit_status()==0L,file.exists(file.path(root,'audit/TERMINAL.json')))
  t <- fromJSON(file.path(root,'audit/TERMINAL.json'))
  progress('stream_probe_terminal',t$status)
  cat('STREAM_PROBE_TERMINAL\n')
})
