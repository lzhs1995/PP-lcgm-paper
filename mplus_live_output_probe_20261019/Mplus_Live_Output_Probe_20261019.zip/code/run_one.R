# 外层监督器拥有超时责任；禁用MplusAutomation按进程名全局清理。
args <- commandArgs(TRUE)
stopifnot(length(args)==2L)
.libPaths(c('C:/Users/LZHS/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
library(MplusAutomation)
setwd(normalizePath(args[1],winslash='/'))
cat('RUNMODELS_BEGIN',as.character(packageVersion('MplusAutomation')),'\n');flush.console()
runModels(target='model.inp',recursive=FALSE,showOutput=TRUE,replaceOutfile='never',
  Mplus_command=normalizePath(args[2],winslash='/'),killOnFail=FALSE)
cat('RUNMODELS_END\n');flush.console()
