"""有意义的解析边界：实际输出、截断尾行、错误标题和D指数。"""
from pathlib import Path
import unittest
from parse_trace import parse_trace
R=Path(__file__).resolve().parents[1]
class TraceTests(unittest.TestCase):
 def test_actual_interrupted_log(self):
  rows=parse_trace((R/'inprocess/models/complete/mplus_stdout.log').read_bytes())
  self.assertEqual(len(rows),38);self.assertEqual(rows[-1]['algorithm'],'FS')
  self.assertAlmostEqual(rows[-1]['loglikelihood'],-4233.4184)
 def test_no_false_trace_from_normal_parameter_rows(self):
  self.assertEqual(parse_trace('TECHNICAL 8\n 1 0.25 0.1\n'),[])
 def test_partial_last_row_not_admitted(self):
  raw=(R/'inprocess/models/complete/mplus_stdout.log').read_bytes()
  end=raw.rfind(b'    38 ')
  self.assertGreater(end,0);self.assertEqual(len(parse_trace(raw[:end+25])),37)
 def test_actual_live_prefixes(self):
  prefixes=sorted((R/'inprocess/models/complete').glob('live_prefix_*.log'))
  counts=[len(parse_trace(p.read_bytes())) for p in prefixes]
  self.assertEqual(counts,sorted(counts));self.assertTrue(any(x>0 for x in counts))
if __name__=='__main__':unittest.main()
