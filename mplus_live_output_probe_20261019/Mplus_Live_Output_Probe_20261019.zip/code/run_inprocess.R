# 一个ClaudeR后台worker仅加载一次MplusAutomation，监督器只拥有当前后台身份。
local({
 library(jsonlite);library(processx);library(ps)
 root <- 'C:/Users/LZHS/pp_lgcm_review/mplus_live_output_probe_20261019/inprocess'
 code <- dirname(root)
 atomic <- function(obj,path) {
   tmp <- paste0(path,'.r.tmp');write_json(obj,tmp,auto_unbox=TRUE,pretty=TRUE)
   for(k in 1:10) { if(file.rename(tmp,path))return(invisible(TRUE));Sys.sleep(.1) }
   stop('State publication failed: ',path)
 }
 stage <- function(value,case='') {
   atomic(list(stage=value,case=case,at=format(Sys.time(),tz='UTC')),file.path(root,'runtime/STATE.json'))
   if(exists('clauder_progress',mode='function',inherits=TRUE))clauder_progress(value,paste('In-process synthetic probe',case))
   cat(value,case,'\n');flush.console()
 }
 owner <- list(pid=Sys.getpid(),created=as.numeric(ps::ps_create_time(ps::ps_handle())))
 stopifnot(!owner$pid %in% c(8764L,18112L))
 atomic(owner,file.path(root,'runtime/OWNER.json'));stage('LOADING')
 watcher <- process$new('C:/Users/LZHS/AppData/Local/Programs/Python/Python314/python.exe',
   c('-X','utf8',file.path(code,'code/inprocess_watch.py')),
   stdout=file.path(root,'runtime/watcher.log'),stderr='2>&1',cleanup_tree=TRUE)
 .libPaths(c('C:/Users/LZHS/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
 library(MplusAutomation)
 atomic(list(version=as.character(packageVersion('MplusAutomation')),path=find.package('MplusAutomation'),at=format(Sys.time(),tz='UTC')),file.path(root,'audit/PACKAGE_LOADED.json'))
 for(case in c('complete','interrupted')) {
   dest <- file.path(root,'models',case);stopifnot(!file.exists(file.path(dest,'model.out')))
   stage('REQUEST',case)
   while(!file.exists(file.path(dest,'GO.json'))) {
     stopifnot(watcher$is_alive());if(file.exists(file.path(root,'runtime/STOP_REQUEST.json')))stop('Resource hold; no estimate started')
     Sys.sleep(1)
   }
   oldwd<-getwd();setwd(dest);stage('ESTIMATING',case)
   started<-Sys.time()
   error<-tryCatch({runModels(target='model.inp',recursive=FALSE,showOutput=TRUE,replaceOutfile='never',
     Mplus_command=file.path(dest,'mplus_stream.cmd'),killOnFail=FALSE);NULL},error=function(e)conditionMessage(e))
   setwd(oldwd)
   normal<-file.exists(file.path(dest,'model.out'))&&any(grepl('THE MODEL ESTIMATION TERMINATED NORMALLY',readLines(file.path(dest,'model.out'),warn=FALSE),fixed=TRUE))
   atomic(list(at=format(Sys.time(),tz='UTC'),seconds=as.numeric(difftime(Sys.time(),started,units='secs')),normal=normal,error=error),file.path(dest,'RUN_RECEIPT.json'))
   stage('CASE_DONE',case)
   while(!file.exists(file.path(dest,'WATCH_DONE.json'))) {stopifnot(watcher$is_alive());Sys.sleep(.2)}
   if(case=='complete'&&!normal)stop('Completion specimen failed; stop dependent interruption test')
 }
 stage('TERMINAL');watcher$wait(10000);stopifnot(!watcher$is_alive(),watcher$get_exit_status()==0L)
 atomic(list(status='INPROCESS_ATTEMPTS_TERMINAL',at=format(Sys.time(),tz='UTC')),file.path(root,'audit/TERMINAL.json'))
 cat('INPROCESS_PROBE_TERMINAL\n')
})
