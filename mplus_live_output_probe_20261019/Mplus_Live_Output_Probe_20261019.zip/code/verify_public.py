"""便携复核：仅读取公开包，不运行R/Mplus、不依赖Windows。"""
from pathlib import Path
import csv,hashlib,json,sys
from parse_trace import parse_trace
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
manifest=json.loads((root/'MANIFEST.json').read_text())
expected={x['path'] for x in manifest['files']}
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
assert actual==expected|{'MANIFEST.json'}
for x in manifest['files']:
 b=(root/x['path']).read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
d=root/'inprocess/models/complete';raw=(d/'mplus_stdout.log').read_bytes()
trace=parse_trace(raw);assert len(trace)==38 and trace[-1]['algorithm']=='FS'
observed=[json.loads(x) for x in (d/'OBSERVATIONS.jsonl').read_text().splitlines()]
events=[x for x in observed if 'prefix_sha256' in x];prefixes=sorted(d.glob('live_prefix_*.log'))
assert len(events)==len(prefixes)==35
live=0
for x,p in zip(events,prefixes):
 b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==x['prefix_sha256'] and raw.startswith(b) and x['engines']
 live+=bool(parse_trace(b))
assert live==34
run=json.loads((d/'RUN_RECEIPT.json').read_text());assert run['normal'] is False
assert 'THE MODEL ESTIMATION TERMINATED NORMALLY' not in (d/'model.out').read_text()
saved=list(csv.DictReader((root/'audit/TECH8_ITERATIONS.csv').open()))
for a,b in zip(trace,saved):
 for key,value in a.items():assert str(value)==b[key] or (isinstance(value,(float,int)) and abs(value-float(b[key]))<1e-10)
print(json.dumps(dict(status='PASS_PUBLIC_TRACE_REPLAY',files=len(expected),iterations=len(trace),live_prefixes=len(prefixes),normal_estimate=False,real_data_calls=0)))
