"""合成日志试验：独占目录、字节日志、真实进程归属、原样保留计划中断。"""
from pathlib import Path
import ctypes, datetime, hashlib, json, os, re, subprocess, sys, time
import psutil
ROOT = Path(__file__).resolve().parents[1]
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(path, obj):
    path=Path(path); tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    for attempt in range(6):
        try: os.replace(tmp,path); return
        except PermissionError:
            if attempt==5: raise
            time.sleep(.1*(attempt+1))
class Memory(ctypes.Structure):
    _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(k,ctypes.c_ulonglong) for k in ['total','avail','commit_limit','commit_avail','virtual','virtual_avail','extended']]
def resources():
    m=Memory();m.length=ctypes.sizeof(m)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)): raise OSError('Memory query failed')
    return dict(at=utc(),available_gib=m.avail/2**30,commit_available_gib=m.commit_avail/2**30,
                disk_free_gib=psutil.disk_usage(str(ROOT)).free/2**30)
def identity(p):
    return dict(pid=p.pid,created=p.create_time(),name=p.name(),exe=p.exe(),cwd=p.cwd(),parent=p.ppid())
def same(row):
    try:return abs(psutil.Process(row['pid']).create_time()-row['created'])<.001
    except psutil.NoSuchProcess:return False
def owned_tree(parent, born):
    if abs(parent.create_time()-born)>.001:raise RuntimeError('Root PID identity changed')
    return [parent]+parent.children(recursive=True)
def stop_owned(parent,born):
    rows=[identity(p) for p in owned_tree(parent,born)]
    write(ROOT/'runtime/STOP_INTENT.json',dict(at=utc(),owned=rows))
    # 深层后代优先；不使用进程名称或系统级kill。
    for row in reversed(rows):
        if same(row):
            try:psutil.Process(row['pid']).kill()
            except psutil.NoSuchProcess:pass
    deadline=time.monotonic()+10
    while any(same(x) for x in rows) and time.monotonic()<deadline:time.sleep(.1)
    remaining=[x for x in rows if same(x)]
    if remaining:raise RuntimeError('Owned tree did not exit: '+repr(remaining))
    return rows
def run(case,contract):
    dest=ROOT/'models'/case
    assert not (dest/'RECEIPT.json').exists() and not (dest/'model.out').exists()
    pre=resources();write(dest/'RESOURCE_BEFORE.json',pre)
    start_wait=time.monotonic()
    while pre['available_gib']<contract['minimum_available_gib'] or pre['commit_available_gib']<contract['minimum_commit_available_gib']:
        if time.monotonic()-start_wait>=contract['maximum_resource_wait_seconds']:
            write(dest/'NOT_RUN.json',dict(status='RESOURCE_HOLD',resource=pre));return False
        time.sleep(3);pre=resources()
    assert pre['disk_free_gib']>=1,'Insufficient log disk space'
    inputs={f:sha(dest/f) for f in ['model.inp','synthetic.dat','mplus_stream.cmd']}
    cap=contract[case+'_cap_seconds'];started=time.monotonic();status='START_FAILED';process=None;parent=None;born=None
    live_growth=[];seen={};stopped=[];iteration_seen=False;last_size=0;max_cpu=0;exit_code=None
    write(dest/'RESERVATION.json',dict(at=utc(),cap_seconds=cap,inputs=inputs,case=case))
    try:
        with (dest/'runModels.log').open('wb') as outer,(dest/'OBSERVATIONS.jsonl').open('w',encoding='utf-8') as obs:
            process=subprocess.Popen([contract['rscript'],'--vanilla',str(ROOT/'code/run_one.R'),str(dest),str(dest/'mplus_stream.cmd')],cwd=dest,stdout=outer,stderr=subprocess.STDOUT)
            parent=psutil.Process(process.pid);born=parent.create_time()
            write(dest/'OWNER.json',identity(parent))
            while process.poll() is None:
                elapsed=time.monotonic()-started;engines=[]
                try:
                    for p in owned_tree(parent,born):
                        try:
                            if p.name().lower()=='mplus.exe':
                                row=identity(p);ct=p.cpu_times();row['cpu_seconds']=ct.user+ct.system
                                engines.append(row);seen[(row['pid'],row['created'])]=row;max_cpu=max(max_cpu,row['cpu_seconds'])
                        except psutil.NoSuchProcess:pass
                except psutil.NoSuchProcess:pass
                log=dest/'mplus_stdout.log';data=log.read_bytes() if log.exists() else b''
                text=data.decode('utf-8',errors='replace')
                # TECH8各版本标题不同，保留原字节，规则只作中断触发。
                tech=('TECHNICAL 8' in text.upper() or 'TECH8' in text.upper() or 'EM ITERATION' in text.upper())
                numeric=bool(re.search(r'^\s*\d+\s+[-+]?\d+\.\d+',text,re.M))
                iteration_seen=iteration_seen or (tech and numeric)
                row=dict(at=utc(),elapsed=elapsed,stdout_bytes=len(data),stderr_bytes=(dest/'mplus_stderr.log').stat().st_size if (dest/'mplus_stderr.log').exists() else 0,
                         live_engines=engines,tech8_title=tech,numeric_iteration=numeric)
                if engines and len(data)>last_size:
                    row['prefix_sha256']=hashlib.sha256(data).hexdigest();live_growth.append(row.copy())
                    # 保存实际运行中的字节快照；不能靠结束后日志伪造实时证据。
                    snap=dest/f'live_prefix_{len(live_growth):03d}.log';snap.write_bytes(data)
                last_size=len(data);obs.write(json.dumps(row)+'\n');obs.flush()
                write(ROOT/'runtime/PROGRESS.json',dict(stage='SYNTHETIC_'+case.upper(),message=f'{len(data)} bytes; Mplus alive={bool(engines)}; elapsed={elapsed:.1f}s',updated_at=utc()))
                if case=='interrupted' and engines and iteration_seen and elapsed>=2:
                    status='PLANNED_TECH8_INTERRUPTION';stopped=stop_owned(parent,born);process.wait(timeout=10);exit_code=process.returncode;break
                if elapsed>=cap:
                    status='TIME_LIMIT';stopped=stop_owned(parent,born);process.wait(timeout=10);exit_code=process.returncode;break
                time.sleep(.2)
            if status=='START_FAILED':
                exit_code=process.returncode;status='EXITED' if exit_code==0 else 'RUNNER_FAILED'
    except Exception as exc:
        status='SUPERVISOR_ERROR'
        write(dest/'ERROR.json',dict(at=utc(),type=type(exc).__name__,message=str(exc)))
        if process is not None and process.poll() is None and parent is not None:
            stopped=stop_owned(parent,born);process.wait(timeout=10)
        raise
    finally:
        normal=False
        if (dest/'model.out').exists():normal='THE MODEL ESTIMATION TERMINATED NORMALLY' in (dest/'model.out').read_text(errors='replace')
        receipt=dict(case=case,status=status,exit_code=exit_code,seconds=time.monotonic()-started,cap_seconds=cap,
          live_growth_events=len(live_growth),iteration_seen=iteration_seen,engine_identities=list(seen.values()),
          observed_engine_cpu_seconds=max_cpu,owned_processes_stopped=stopped,normal_model_termination=normal,
          input_hashes=inputs,inputs_unchanged=all(sha(dest/f)==h for f,h in inputs.items()),
          hashes={f:sha(dest/f) for f in ['mplus_stdout.log','mplus_stderr.log','runModels.log','model.out','parameters.dat'] if (dest/f).exists()},at=utc())
        write(dest/'RECEIPT.json',receipt)
    print(json.dumps(receipt),flush=True)
    return status=='EXITED' and normal if case=='complete' else status=='PLANNED_TECH8_INTERRUPTION'
def main():
    contract=json.loads((ROOT/'contracts/RUN_CONTRACT.json').read_text())
    lock=ROOT/'runtime/engine.lock'
    fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    os.write(fd,json.dumps(identity(psutil.Process())).encode());os.close(fd)
    awake=bool(ctypes.windll.kernel32.SetThreadExecutionState(0x80000001))
    try:
        for case in ['complete','interrupted']:
            if not run(case,contract):
                write(ROOT/'audit/TERMINAL.json',dict(status='STOPPED_CHECK_REQUIRED',case=case,at=utc()));return
        write(ROOT/'audit/TERMINAL.json',dict(status='TWO_SYNTHETIC_ATTEMPTS_TERMINAL',at=utc(),real_data_calls=0))
    finally:
        if awake:ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
        lock.unlink()
if __name__=='__main__':main()
