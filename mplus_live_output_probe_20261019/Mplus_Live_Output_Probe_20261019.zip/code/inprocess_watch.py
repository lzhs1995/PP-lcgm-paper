"""只监督一个已绑定ClaudeR后台worker；前台RStudio绝不作为终止目标。"""
from pathlib import Path
import ctypes,hashlib,json,os,re,sys,time
import psutil
from stream_supervisor import utc,write,resources,identity,same
R=Path(__file__).resolve().parents[1]/'inprocess'
C=json.loads((R/'contracts/RUN_CONTRACT.json').read_text())
owner=json.loads((R/'runtime/OWNER.json').read_text());p=psutil.Process(owner['pid'])
assert abs(p.create_time()-owner['created'])<.01
assert p.name().lower() in ('rterm.exe','rscript.exe') and p.pid not in (8764,18112)
case=None;observations={};start=time.monotonic();running_since=None;request_since=None;stop_done=False
awake=bool(ctypes.windll.kernel32.SetThreadExecutionState(0x80000001))
write(R/'runtime/WATCH_READY.json',dict(at=utc(),identity=identity(psutil.Process()),owner=owner))
def tree():
 if not same(owner):return []
 return psutil.Process(owner['pid']).children(recursive=True)
def engines():
 out=[]
 for x in tree():
  try:
   if x.name().lower()=='mplus.exe' and case and Path(x.cwd()).resolve()==(R/'models'/case).resolve():out.append(x)
  except psutil.NoSuchProcess:pass
 return out
def kill_engines(reason):
 rows=[]
 for x in engines():
  row=identity(x);rows.append(row)
  if same(row):x.kill()
 deadline=time.monotonic()+10
 while any(same(x) for x in rows) and time.monotonic()<deadline:time.sleep(.1)
 assert not any(same(x) for x in rows),'Engine exit unconfirmed'
 write(R/'models'/case/'STOP.json',dict(at=utc(),reason=reason,identities=rows,engine_exit_verified=True,worker_kept_alive=same(owner)))
 return rows
try:
 while same(owner):
  elapsed=time.monotonic()-start
  f=R/'runtime/STATE.json'
  try:s=json.loads(f.read_text())
  except (FileNotFoundError,json.JSONDecodeError):time.sleep(.1);continue
  if elapsed>=C['overall_cap_seconds'] or (s['stage']=='LOADING' and elapsed>=C['startup_cap_seconds']):
   if case:kill_engines('OVERALL_OR_STARTUP_LIMIT')
   write(R/'audit/WATCH_FAILURE.json',dict(status='STARTUP_OR_OVERALL_LIMIT',state=s,seconds=elapsed))
   if same(owner):psutil.Process(owner['pid']).kill()
   break
  if s['stage']=='REQUEST':
   if case!=s['case']:
    case=s['case'];request_since=time.monotonic();running_since=None;stop_done=False
   pf=resources();write(R/'models'/case/'RESOURCE_ADMISSION.json',pf)
   if pf['available_gib']>=C['minimum_available_gib'] and pf['commit_available_gib']>=C['minimum_commit_available_gib'] and pf['disk_free_gib']>=1:
    go=R/'models'/case/'GO.json'
    if not go.exists():write(go,dict(at=utc(),resource=pf))
   elif time.monotonic()-request_since>=C['maximum_resource_wait_seconds']:
    write(R/'runtime/STOP_REQUEST.json',dict(status='RESOURCE_HOLD',case=case,at=utc()))
  if s['stage']=='ESTIMATING':
   if running_since is None:running_since=time.monotonic()
   t=time.monotonic()-running_since;d=R/'models'/case
   ep=engines();live=[identity(x) for x in ep]
   log=d/'mplus_stdout.log';data=log.read_bytes() if log.exists() else b''
   text=data.decode('utf-8',errors='replace');has_tech=bool(re.search('TECHNICAL 8|TECH8|EM ITERATION',text,re.I))
   numeric=bool(re.search(r'^\s*\d+\s+[-+]?\d+\.\d+',text,re.M))
   prev=observations.get(case,dict(bytes=0,events=0,engines={},tech8_live=False))
   row=dict(at=utc(),elapsed=t,stdout_bytes=len(data),engines=live,tech8_title=has_tech,numeric_iteration=numeric)
   if live and len(data)>prev['bytes']:
    prev['events']+=1;(d/f'live_prefix_{prev["events"]:03d}.log').write_bytes(data)
    row['prefix_sha256']=hashlib.sha256(data).hexdigest()
   for e in live:prev['engines'][str(e['pid'])+':'+str(e['created'])]=e
   prev['bytes']=len(data);prev['tech8_live']=prev['tech8_live'] or bool(live and has_tech and numeric);observations[case]=prev
   with (d/'OBSERVATIONS.jsonl').open('a') as out:out.write(json.dumps(row)+'\n')
   write(d/'LIVE_SUMMARY.json',prev)
   if not stop_done and case=='interrupted' and live and has_tech and numeric and t>=1:
    kill_engines('PLANNED_TECH8_INTERRUPTION');stop_done=True
   elif not stop_done and t>=C[case+'_cap_seconds']:
    kill_engines('TIME_LIMIT');stop_done=True
  if s['stage']=='CASE_DONE':
   d=R/'models'/s['case'];write(d/'WATCH_DONE.json',dict(at=utc(),observations=observations.get(s['case'],{})))
  if s['stage']=='TERMINAL':break
  time.sleep(.2)
finally:
 if awake:ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
 write(R/'audit/WATCH_TERMINAL.json',dict(at=utc(),owner_alive=same(owner),observations=observations))
