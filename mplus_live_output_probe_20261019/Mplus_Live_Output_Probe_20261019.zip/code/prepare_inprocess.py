"""一次运营修订：在ClaudeR原worker加载包一次，移除每模型嵌套Rscript。"""
from pathlib import Path
import datetime,hashlib,json,shutil
R=Path(__file__).resolve().parents[1];V=R/'inprocess'
assert not V.exists()
old=json.loads((R/'models/complete/RECEIPT.json').read_text())
assert old['status']=='TIME_LIMIT' and old['engine_identities']==[]
assert json.loads((R/'audit/GUARD_complete.json').read_text())['decision']=='PASS'
for d in ['audit','runtime','contracts','models/complete','models/interrupted']: (V/d).mkdir(parents=True,exist_ok=True)
for case in ['complete','interrupted']:
 for f in ['model.inp','synthetic.dat','mplus_stream.cmd']:shutil.copy2(R/'models'/case/f,V/'models'/case/f)
c=json.loads((R/'contracts/RUN_CONTRACT.json').read_text());c.update(dict(
 execution='MplusAutomation directly in one native ClaudeR async worker; no nested Rscript',
 startup_cap_seconds=180,overall_cap_seconds=390,previous_failed_runner_seconds=old['seconds'],
 actual_Mplus_calls_before=0,additional_engine_slots=0,
 reason='Previous nested Rscript never reached namespace-loaded marker. Reuse already-prepared synthetic inputs and load namespace once in existing async worker. Keep engine caps120/60 and max2 calls; one architecture change, no subsequent retries.',
 at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
(V/'contracts/RUN_CONTRACT.json').write_text(json.dumps(c,indent=2))
(V/'audit/INPUT_IDENTICAL.json').write_text(json.dumps({case:{f:hashlib.sha256((V/'models'/case/f).read_bytes()).hexdigest() for f in ['model.inp','synthetic.dat','mplus_stream.cmd']} for case in ['complete','interrupted']},indent=2))
print('INPROCESS_PREPARED max_engine_calls=2 new_real_data_calls=0')
