# 隔离合成数据：只验证实时日志与受控终止，不运行CFPS或CHARLS。
local({
  root <- 'C:/Users/LZHS/pp_lgcm_review/mplus_live_output_probe_20261019'
  dirs <- c('audit','contracts','models/complete','models/interrupted','runtime','reports')
  for (d in dirs) dir.create(file.path(root,d),recursive=TRUE,showWarnings=FALSE)
  .libPaths(c('C:/Users/LZHS/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
  library(MplusAutomation)
  library(jsonlite)
  detected <- MplusAutomation::detectMplus()
  resolved <- if(grepl('[/\\\\]',detected)) detected else unname(Sys.which(detected))
  stopifnot(nzchar(resolved),file.exists(resolved),!dir.exists(resolved))
  mplus <- normalizePath(resolved,winslash='/',mustWork=TRUE)
  rscript <- normalizePath(file.path(R.home('bin'),'Rscript.exe'),winslash='/',mustWork=TRUE)
  contract <- list(purpose='Synthetic streaming and planned interruption only',
    max_mplus_calls=2L,total_engine_seconds=180,maximum_owned_slots=1L,
    complete_cap_seconds=120,interrupted_cap_seconds=60,
    real_data_models=0L,processors=1L,minimum_available_gib=1.2,
    minimum_commit_available_gib=2,maximum_resource_wait_seconds=30,
    mplus=mplus,rscript=rscript,library=normalizePath(find.package('MplusAutomation'),winslash='/'),
    package_version=as.character(packageVersion('MplusAutomation')),
    interruption_rule='Stop owned tree after a numeric TECH8 iteration is durable while engine is alive; otherwise 60 seconds; no retry',
    original_four_complete=FALSE,full_H4_complete=FALSE)
  stopifnot(!file.exists(file.path(root,'contracts/RUN_CONTRACT.json')))
  write_json(contract,file.path(root,'contracts/RUN_CONTRACT.json'),pretty=TRUE,auto_unbox=TRUE)
  for (id in c('complete','interrupted')) {
    n <- if(id=='complete') 500L else 15000L
    set.seed(if(id=='complete') 26101901L else 26101902L)
    f <- rnorm(n); g <- .25*f+sqrt(1-.25^2)*rnorm(n)
    d <- data.frame(x1=f+rnorm(n,sd=.5),x2=.8*f+rnorm(n,sd=.6),x3=.9*f+rnorm(n,sd=.5),
      z1=g+rnorm(n,sd=.5),z2=.8*g+rnorm(n,sd=.6),z3=.9*g+rnorm(n,sd=.5),
      y=.3*f+.2*g+.25*f*g+rnorm(n))
    dest <- file.path(root,'models',id)
    # 使用MplusAutomation导出，不加载任何研究微观数据。
    prepareMplusData(d,filename=file.path(dest,'synthetic.dat'),keepCols=names(d),writeData='always')
    inp <- c(paste0('TITLE: Synthetic stdout ',id,';'), 'DATA: FILE = synthetic.dat;',
      'VARIABLE: NAMES = x1 x2 x3 z1 z2 z3 y;',
      'ANALYSIS: TYPE = RANDOM; ESTIMATOR = MLR; ALGORITHM = INTEGRATION;',
      ' INTEGRATION = 15; PROCESSORS = 1; MITERATIONS = 150;',
      'MODEL: f BY x1@1 x2*.8 x3*.9; g BY z1@1 z2*.8 z3*.9;',
      ' f WITH g; fxg | f XWITH g; y ON f g fxg;',
      'OUTPUT: TECH1 TECH3 TECH8;', 'SAVEDATA: RESULTS = parameters.dat;')
    writeLines(inp,file.path(dest,'model.inp'),useBytes=TRUE)
    # 独立cmd入口只改变输出去向；runModels和实际Mplus引擎保持不变。
    cmd <- c('@echo off',paste0('"',chartr('/','\\',mplus),'" "%~1" 1>"mplus_stdout.log" 2>"mplus_stderr.log"'),
      'exit /b %ERRORLEVEL%')
    writeLines(cmd,file.path(dest,'mplus_stream.cmd'),sep='\r\n',useBytes=TRUE)
  }
  writeLines(capture.output(sessionInfo()),file.path(root,'audit/PREPARATION_SESSION.txt'))
  cat('SYNTHETIC_INPUTS_READY package=',as.character(packageVersion('MplusAutomation')),'\n',sep='')
})
