@echo off
"C:\Users\LZHS\Downloads\Mplus\mplus9\ducument\Mplus.exe" "%~1" 1>"mplus_stdout.log" 2>"mplus_stderr.log"
exit /b %ERRORLEVEL%
