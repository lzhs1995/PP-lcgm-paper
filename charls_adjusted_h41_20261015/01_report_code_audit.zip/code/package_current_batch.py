"""显式文件清单发布汇总证据；不打包真实DAT、RDS或个体标识。"""
from pathlib import Path
import json,csv,hashlib,zipfile,io,re
root=Path(__file__).resolve().parents[1];stage=root/'public_stage';stage.mkdir(exist_ok=True)
paths='''reports/REPORT.md
reports/FOR_WEB_REVIEWERS.md
reports/BATCH_RECEIPT.json
contracts/RUN_CONTRACT.json
contracts/CHARLS_CORE_MI_ACTUAL.json
results/CALLS.csv
results/H4_REGISTER_UPDATED.csv
results/H41_SD_FAMILY_OVERVIEW.csv
results/H41_SD_RESOURCE_DIFFERENCES.png
results/H41_SD_RESOURCE_DIFFERENCES.pdf
results/H41_FAMILIES.json
results/H41_URBAN_START_CHECK.json
results/H41_INC_START_CHECK.json
results/CHARLS_MI_RECEIPT.json
results/CHARLS_MI_SUMMARIES.csv
results/CHARLS_MI_CHAINS.pdf
results/CHARLS_FAMILY_STATUS.json
results/CHARLS_CORE_POOLED.csv
results/CHARLS_CORE_DF439_SENSITIVITY.csv
results/CHARLS_CORE_COMPARISON.csv
results/CHARLS_CORE_MEMBER_ESTIMATES.csv
results/CHARLS_CORE_MEMBER_COVARIANCES.csv
results/CHARLS_CORE_FIT_BY_MEMBER.csv
results/CHARLS_POOLING_RECEIPT.json
results/CHARLS_ADJUSTED_COMPARISON.png
results/CHARLS_ADJUSTED_COMPARISON.pdf
audit/INDEPENDENT_POOLING.json
audit/CHARLS_CORE_MEMBER_SOURCES.csv
audit/CHARLS_MI_ADMISSION.json
audit/CHARLS_MI_MEMBER_VALIDATION.csv
audit/CHARLS_MI_PREDICTORS_ACTUAL.csv
audit/CHARLS_ADL_CONVERGENCE.csv
audit/CHARLS_MI_SESSION.txt
audit/MI_CACHE_SUMMARY.json
audit/MI_CACHE_EQUIVALENCE.json
audit/MI_FIT_CACHE_FIRST.json
audit/SEX_SOURCE_RECOVERY.json
audit/MI_PERFORMANCE_RECOVERY.json
audit/MI_PROFILE_LIMIT.json
audit/ENGINE_ATOMIC_RECOVERY_TEST.json
audit/COORDINATOR_RECOVERY.json
audit/TIMING_RECONCILIATION.json
audit/TIMING_RECONCILIATION.csv
audit/CHARLS_FIRST_COORDINATOR_TERMINAL.json
audit/CLAUDER_COMPLETION.json
code/h41_remaining_sd.R
code/charls_core_mi.R
code/charls_core_mi_v2.R
code/mi_exact_fit_cache.R
code/admit_charls_mi.R
code/charls_adjusted_models.R
code/pool_h41_extensions.R
code/pool_charls_core.R
code/verify_current_pooling.py
code/plot_current_results.py
code/build_batch_report.py
code/package_current_batch.py
code/engine.py
code/run_one.R
code/pilot.R
code/r2e_local.R
code/r2e_tools.R
code/r2e_upstream_math.R'''.splitlines()
for g in ['URBAN','INC']:
 for f in ['POOLED_PATHS.csv','GROUP_CONTRASTS.csv','JOINT_D1.csv','RECEIPT.json','MEMBER_SOURCES.csv','MEMBER_ESTIMATES.csv','MEMBER_COVARIANCES.csv']:
  paths.append('results/H41_'+g+'/'+f)
selected={n:root/n for n in paths}
model_files=['model.inp','model.out','engine_receipt.json','receipt.json','validation.json','parameters_high_precision.csv','key_paths.csv','matrix_values.csv','tech1_parameter_map.csv','parameter_covariance.csv','estimates.dat','tech3.dat','mplus_execution.log','supervisor_error.json','receipt_before_claim_recovery.json']
for row in csv.DictReader((root/'results/CALLS.csv').open(encoding='utf-8-sig')):
 d=root/'models'/row['model']
 for f in model_files:
  if (d/f).is_file():selected['models/'+d.name+'/'+f]=d/f
payload={};manifest=[];sha=lambda b:hashlib.sha256(b).hexdigest()
for n,p in selected.items():
 assert p.is_file(),n
 assert not n.startswith('private/') and p.name not in ['data.dat','job.json'] and p.suffix!='.rds'
 b=p.read_bytes();original_sha=sha(b);redacted=False
 if p.suffix.lower() not in ['.pdf','.png']:
  s=b.decode('utf-8-sig')
  for prefix in ['<LOCAL_USER_HOME>','<LOCAL_USER_HOME>','C:\\\\Users\\\\LZHS','<LOCAL_USER_HOME>','<LOCAL_USER_HOME>']:
   if prefix in s:s=s.replace(prefix,'<LOCAL_USER_HOME>');redacted=True
  assert not re.search(r'(?i)(?:api[_-]?key|access_token)\s*[:=]\s*["\']?[A-Za-z0-9_-]{20,}',s)
  if p.suffix=='.csv' and p.name!='parameter_covariance.csv':
   hdr=next(csv.reader(io.StringIO(s)),[]);assert not set(x.lower() for x in hdr)&{'pid','fid','householdid','communityid','id'},(n,hdr)
  b=s.encode('utf-8')
 payload[n]=b;manifest.append({'path':n,'bytes':len(b),'sha256':sha(b),'local_source_sha256':original_sha,'paths_redacted':redacted})
payload['PAYLOAD_MANIFEST.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
packages=[]
for models,fn in [(False,'01_report_code_audit.zip'),(True,'02_model_evidence.zip')]:
 names=[n for n in payload if n.startswith('models/')==models];p=stage/fn
 with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n in names:z.writestr(n,payload[n])
 assert p.stat().st_size<25_000_000
 with zipfile.ZipFile(p) as z:assert z.testzip() is None
 packages.append({'file':fn,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'files':len(names)})
for n in ['REPORT.md','FOR_WEB_REVIEWERS.md','BATCH_RECEIPT.json']:(stage/n).write_bytes(payload['reports/'+n])
pm={'packages':packages,'payload_files':len(payload),'privacy':'Explicit per-file allowlist; no personal DAT/RDS/MI/IDs; estimates.dat and tech3.dat contain aggregate parameters/covariance only'}
(stage/'PACKAGE_MANIFEST.json').write_text(json.dumps(pm,ensure_ascii=False,indent=2),encoding='utf-8')
(root/'audit/PUBLIC_FILE_SELECTION.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
(stage/'README.md').write_text('''# H4.1 SD资源分支与CHARLS核心调整模型

**四项调节完整推断、完整 H4 仍未完成。**

[报告](REPORT.md) · [网页评议说明](FOR_WEB_REVIEWERS.md) · [回执](BATCH_RECEIPT.json) · [包清单](PACKAGE_MANIFEST.json)

本批新增SD×城乡、SD×收入的完整十份条件MI合并，接续既有SD×教育；推进CHARLS基期控制、缺失处理与连续PP-LGCM核心调整家族。未重跑旧失败CFPS科学规格，未替换已收尾稿件。

两包均小于25MB。解压到同一目录后，可执行 `python code/verify_current_pooling.py` 独立复算保存结果；这不重新估计微观数据。实际科研限制见报告。

技能增量见 [mplusautomation-guide PR25](https://github.com/lzhs1995/clauder-rstudio-workbench/pull/25)。
''',encoding='utf-8')
print(json.dumps(pm,ensure_ascii=False))
