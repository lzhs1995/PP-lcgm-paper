# 原始全协方差合并四条路径；不平均P值或拟合指标。
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015'
Sys.setenv(R2E_ROOT=ROOT);source(file.path(ROOT,'code/r2e_local.R'),local=TRUE)
f<-rj(file.path(ROOT,'results/CHARLS_FAMILY_STATUS.json'));stopifnot(f$status=='TWENTY_USABLE_PENDING_POOLING')
labs<-c('bii','bis','bss','bsyiy');Q<-matrix(NA_real_,20,4,dimnames=list(NULL,labs));U<-list();src<-list();fit<-list();compare<-list()
for(k in 1:20){
 d<-file.path(ROOT,'models',sprintf('CHARLS_CORE_MI%02d',k));r<-rj(file.path(d,'receipt.json'))
 stopifnot(r$status=='USABLE_SINGLE_DATASET',r$N==3006,identical(r$output_sha256,hashf(file.path(d,'model.out'))))
 p<-read.csv(file.path(d,'key_paths.csv'));p<-p[match(labs,p$label),];v<-as.matrix(read.csv(file.path(d,'parameter_covariance.csv'),header=FALSE))
 Q[k,]<-p$estimate;U[[k]]<-v[p$parameter,p$parameter];dimnames(U[[k]])<-list(labs,labs)
 stopifnot(max(abs(diag(U[[k]])-p$se^2))<1e-6)
 src[[k]]<-data.frame(member=k,source_dir=d,output_sha256=r$output_sha256,data_sha256=hashf(file.path(d,'data.dat')))
 ff<-r$fit[[1L]];fit[[k]]<-data.frame(member=k,CFI=ff$CFI,TLI=ff$TLI,RMSEA=ff$RMSEA_Estimate,SRMR=ff$SRMR)
}
po<-rubin_pool(Q,U);tab<-data.frame(label=labs,po$table,row.names=NULL);stopifnot(max(tab$MCSE_over_SE)<.1)
csv(tab,file.path(ROOT,'results/CHARLS_CORE_POOLED.csv'))
# 440社区的有限聚类自由度敏感性独立列出，不替换MLR的渐近主推断。
csv(data.frame(label=labs,rubin_pool(Q,U,nu_com=439)$table,row.names=NULL),file.path(ROOT,'results/CHARLS_CORE_DF439_SENSITIVITY.csv'))
csv(do.call(rbind,src),file.path(ROOT,'audit/CHARLS_CORE_MEMBER_SOURCES.csv'));csv(do.call(rbind,fit),file.path(ROOT,'results/CHARLS_CORE_FIT_BY_MEMBER.csv'))
csv(data.frame(member=1:20,Q),file.path(ROOT,'results/CHARLS_CORE_MEMBER_ESTIMATES.csv'))
csv(do.call(rbind,lapply(1:20,function(k)data.frame(member=k,expand.grid(row=labs,column=labs,stringsAsFactors=FALSE),covariance=as.vector(U[[k]])))),file.path(ROOT,'results/CHARLS_CORE_MEMBER_COVARIANCES.csv'))
for(sp in c('UNADJ','CC')){
 d<-file.path(ROOT,'models',paste0('CHARLS_',sp,'_COMMUNITY'));r<-rj(file.path(d,'receipt.json'))
 if(r$status=='USABLE_SINGLE_DATASET'){p<-read.csv(file.path(d,'key_paths.csv'));p<-p[match(labs,p$label),];compare[[sp]]<-data.frame(model=sp,N=r$N,label=labs,estimate=p$estimate,se=p$se,lower=p$estimate-qnorm(.975)*p$se,upper=p$estimate+qnorm(.975)*p$se)}
}
compare$MI<-data.frame(model='CORE_MI20',N=3006,label=labs,tab[c('estimate','se','lower','upper')])
csv(do.call(rbind,compare),file.path(ROOT,'results/CHARLS_CORE_COMPARISON.csv'))
wj(list(status='CHARLS_CORE20_MI_COMPLETE',m=20,N=3006,communities=440,scale='2011 baseline standardized continuous scores; actual-year time0,2,4,7,9',MCSE_over_SE_max=max(tab$MCSE_over_SE),
 estimand='Adjusted continuous parallel-growth association; no dynamic moderation or H4',
 limitations='Unweighted selected baseline60+ cohort; valid-child reports define contact exposure; MAR/PMM working MI; baseline linear shape only; not causal or full robustness evidence',
 source_recovery='1 missing2011 sex from concordant2013/2015 originals; complete-case sensitivity retains original2011 missing',
 method='MLR community-cluster TECH3 covariance, Rubin finite-MI df; df439 sensitivity separately reported'),file.path(ROOT,'results/CHARLS_POOLING_RECEIPT.json'))
cat('CHARLS_CORE_POOLING_COMPLETE\n');print(tab)
