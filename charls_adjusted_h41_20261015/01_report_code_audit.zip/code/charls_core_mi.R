# 独立CHARLS主调整集MI：只填控制变量，五期X/Y不改，不重用历史类别MI。
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015'
.libPaths(c(file.path(ROOT,'library'),.libPaths()))
library(mice);library(miceadds);library(jsonlite);library(digest)
src<-'<LOCAL_USER_HOME>/pp_lgcm_review/h41_mi_charls_covariates_20261015/private/charls_covariate_cohort.rds'
wj<-function(x,p)write_json(x,file.path(ROOT,p),auto_unbox=TRUE,pretty=TRUE,na='null',digits=16)
csv<-function(x,p)write.csv(x,file.path(ROOT,p),row.names=FALSE,na='')
update<-function(s,m){wj(list(stage=s,message=m,updated_at=format(Sys.time(),tz='UTC',usetz=TRUE)),'runtime/charls_mi_progress.json');cat(s,m,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(s,m)}
hash0<-digest(file=src,algo='sha256');d<-readRDS(src);stopifnot(nrow(d)==3006,!anyDuplicated(d$pid))
cc<-data.frame(cluster=as.integer(factor(d$community)),age=(d$age-70)/10,female=d$female,edu=d$edu_junior,urban=d$urban,partner=d$partnered,nchild=d$n_reported_valid,adl=d$adl_difficulties)
for(k in 2:5)cc[[paste0('health',k)]]<-as.numeric(d$health_poorer==k)
for(v in c(paste0('x',1:5),paste0('y',1:5))){cc[[paste0('obs_',v)]]<-ifelse(is.na(d[[v]]),0,d[[v]]);if(anyNA(d[[v]]))cc[[paste0('missing_',v)]]<-as.integer(is.na(d[[v]]))}
targets<-c('female','adl');stopifnot(identical(as.integer(colSums(is.na(cc[targets]))),c(1L,20L)),all(complete.cases(cc[setdiff(names(cc),targets)])))
method<-make.method(cc);method[]<-'';method['female']<-'2l.binary';method['adl']<-'2l.pmm'
pm<-matrix(0,ncol(cc),ncol(cc),dimnames=list(names(cc),names(cc)))
for(v in targets){pm[v,setdiff(names(cc),c(v,'cluster'))]<-1;pm[v,'cluster']<--2}
saveRDS(list(data=cc,raw=d,methods=method,predictors=pm,mask=is.na(cc),source_sha256=hash0),file.path(ROOT,'private/charls_core_mi_inputs.rds'))
csv(data.frame(variable=rownames(pm),pm,check.names=FALSE),'audit/CHARLS_MI_PREDICTORS_REQUESTED.csv')
wj(list(m=20,seed=26101541,maxit=20,community_random_intercept=TRUE,methods=as.list(method),
 auxiliary_rule='Observed standardized X/Y entries with explicit missing indicators; zero placeholders are predictors only, never written as observed outcomes',
 target_rule='Only 1 missing sex and20 missing ADL; original observed values preserved',
 package_versions=list(mice=as.character(packageVersion('mice')),miceadds=as.character(packageVersion('miceadds'))),
 binary_implementation='miceadds::mice.impute.2l.binary; separate from mice 3.19.0 2l.bin marginal random-effect implementation',
 limitations='FCS MAR working imputation, not proved congenial to future latent interactions; no population weighting'), 'contracts/CHARLS_CORE_MI_ACTUAL.json')
warnings_log<-list();iteration<-0L
catch<-function(expr)withCallingHandlers(expr,warning=function(w){warnings_log[[length(warnings_log)+1L]]<<-data.frame(iteration=iteration,type='warning',message=conditionMessage(w));invokeRestart('muffleWarning')},message=function(m){warnings_log[[length(warnings_log)+1L]]<<-data.frame(iteration=iteration,type='message',message=conditionMessage(m));invokeRestart('muffleMessage')})
checkpoint<-file.path(ROOT,'private/charls_core_mids.rds')
if(file.exists(checkpoint)){imp<-readRDS(checkpoint);stopifnot(identical(imp$data,cc))}else{
 update('charls_mi_initializing','20 chains; random intercept by community; binary and PMM covariates')
 iteration<-1L;imp<-catch(mice(cc,m=20,maxit=1,method=method,predictorMatrix=pm,seed=26101541,donors=5,printFlag=FALSE,remove.collinear=TRUE));saveRDS(imp,checkpoint)
}
while(imp$iteration<20){
 iteration<-imp$iteration+1L;update('charls_mi_iteration',paste('iteration',iteration,'of20; same checkpoint'))
 imp<-catch(mice.mids(imp,maxit=1,donors=5,printFlag=FALSE));saveRDS(imp,checkpoint)
 if(length(warnings_log))csv(do.call(rbind,warnings_log),'audit/CHARLS_MI_WARNINGS.csv')
}
stopifnot(all(imp$method[targets]==method[targets]),all(imp$predictorMatrix[targets,'cluster']==-2))
csv(data.frame(variable=rownames(imp$predictorMatrix),imp$predictorMatrix,check.names=FALSE),'audit/CHARLS_MI_PREDICTORS_ACTUAL.csv')
if(!is.null(imp$loggedEvents))csv(imp$loggedEvents,'audit/CHARLS_MI_LOGGED_EVENTS.csv')
conv<-tryCatch(mice::convergence(imp),error=function(e)data.frame(error=conditionMessage(e)));csv(conv,'audit/CHARLS_MI_CONVERGENCE.csv')
valid<-list();miout<-list();summ<-list()
for(k in 1:20){
 z<-complete(imp,k);stopifnot(!anyNA(z[targets]))
 for(v in targets){idx<-!is.na(cc[[v]]);stopifnot(identical(z[[v]][idx],cc[[v]][idx]))}
 stopifnot(all(z$female%in%0:1),all(z$adl%in%0:6))
 a<-data.frame(cluster=cc$cluster);for(v in c(paste0('x',1:5),paste0('y',1:5)))a[[v]]<-d[[v]]
 a$c1<-z$age;a$c2<-z$female;a$c3<-z$edu;a$c4<-z$urban;a$c5<-z$partner;a$c6<-z$nchild;a$c7<-z$adl
 for(i in 2:5)a[[paste0('c',i+6)]]<-z[[paste0('health',i)]]
 stopifnot(identical(a[paste0('x',1:5)],d[paste0('x',1:5)]),identical(a[paste0('y',1:5)],d[paste0('y',1:5)]))
 path<-file.path(ROOT,'private',sprintf('CHARLS_CORE_MI%02d.dat',k));write.table(a,path,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
 miout[[k]]<-a;valid[[k]]<-data.frame(member=k,N=nrow(a),original_observations_preserved=TRUE,original_XY_masks_preserved=TRUE,support_valid=TRUE,data_sha256=digest(file=path,algo='sha256'))
 summ[[k]]<-data.frame(member=k,mean_female=mean(z$female),mean_adl=mean(z$adl),mean_imputed_female=mean(z$female[is.na(cc$female)]),mean_imputed_adl=mean(z$adl[is.na(cc$adl)]))
}
saveRDS(miout,file.path(ROOT,'private/charls_core_completed.rds'));csv(do.call(rbind,valid),'audit/CHARLS_MI_MEMBER_VALIDATION.csv');csv(do.call(rbind,summ),'results/CHARLS_MI_SUMMARIES.csv')
pdf(file.path(ROOT,'results/CHARLS_MI_CHAINS.pdf'),width=9,height=5);print(plot(imp,c('female','adl')));dev.off()
stopifnot(identical(hash0,digest(file=src,algo='sha256')))
wj(list(status='20_MEMBERS_GENERATED_PENDING_DIAGNOSTIC_ADMISSION',m=20,iterations=imp$iteration,N=nrow(d),communities=length(unique(cc$cluster)),data_columns=names(miout[[1]]),source_sha256=hash0,source_unchanged=TRUE,warnings=length(warnings_log),valid_all=TRUE),'results/CHARLS_MI_RECEIPT.json')
writeLines(capture.output(sessionInfo()),file.path(ROOT,'audit/CHARLS_MI_SESSION.txt'))
update('charls_mi_generated','20 members saved; inspect chains and warnings before any Mplus admission')
