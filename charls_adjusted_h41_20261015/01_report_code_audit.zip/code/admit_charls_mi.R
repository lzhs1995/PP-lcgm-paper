# 只做插补证据检查；缓存与未缓存函数同随机种子逐值、RNG状态一致。
BASE<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015'
.libPaths(c(file.path(BASE,'library'),.libPaths()));library(mice);library(miceadds);library(jsonlite)
i<-readRDS(file.path(BASE,'private/charls_core_mids.rds'))
ROOT<-file.path(BASE,'runtime/cache_equivalence');for(x in c('private','runtime','audit'))dir.create(file.path(ROOT,x),recursive=TRUE,showWarnings=FALSE)
source(file.path(BASE,'code/mi_exact_fit_cache.R'),local=TRUE)
type<-i$predictorMatrix['adl',];sel<-type!=0;x<-as.matrix(i$data[,sel]);tt<-type[sel]
y<-mice::complete(i,1)$adl;ry<-!is.na(i$data$adl)
set.seed(26101542);a<-miceadds::mice.impute.2l.pmm(y,ry,x,tt,donors=5);sa<-.Random.seed
set.seed(26101542);b<-cached_pmm(y,ry,x,tt,donors=5);sb<-.Random.seed
set.seed(26101542);c<-cached_pmm(y,ry,x,tt,donors=5);sc<-.Random.seed
stopifnot(identical(a,b),identical(a,c),identical(sa,sb),identical(sa,sc),cache_env$hits==1L)
write_json(list(status='PASS',same_imputed_values=TRUE,same_RNG_state=TRUE,cold_and_warm_cache=TRUE,values_checked=length(a),unmodified_package='miceadds3.20.10',new_Mplus=0),file.path(BASE,'audit/MI_CACHE_EQUIVALENCE.json'),auto_unbox=TRUE,pretty=TRUE)
fit<-readRDS(file.path(BASE,'private/MI_ADL_CONDITIONAL_LMER.rds'))
conv<-mice::convergence(i);v<-subset(conv,vrb=='adl');last<-tail(v,1)
stopifnot(is.null(fit@optinfo$conv$lme4$messages),fit@optinfo$conv$opt==0,all(unlist(i$imp$adl)%in%0:6),is.finite(last$psrf),last$psrf<1.1)
receipt<-fromJSON(file.path(BASE,'results/CHARLS_MI_RECEIPT.json'));stopifnot(receipt$valid_all,receipt$source_unchanged,receipt$warnings==0)
write.csv(v,file.path(BASE,'audit/CHARLS_ADL_CONVERGENCE.csv'),row.names=FALSE)
write_json(list(passed=TRUE,scope='20 core covariate MI members; eligible for adjusted PP-LGCM, not future interaction compatibility',m=i$m,iterations=i$iteration,psrf=last$psrf,autocorrelation=last$ac,fit_converged=TRUE,source_preservation=TRUE,sex_source_recovery=1,adl_missing=20,cache_equivalence=TRUE,
 limitations='MAR and PMM multilevel working assumptions remain; no claim of congeniality to future latent interactions; future reported-path MCSE gate applies after model pooling'),file.path(BASE,'audit/CHARLS_MI_ADMISSION.json'),auto_unbox=TRUE,pretty=TRUE,digits=16)
cat('CHARLS_CORE_MI_ADMITTED\n');print(last)
