"""从本批终态和汇总结果生成报告，不以正常终止或星号代替完整家族。"""
from pathlib import Path
import json,csv,datetime
import pandas as pd
root=Path('<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015');old=root.parent/'h41_mi_charls_covariates_20261015'
j=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
budget=j(root/'runtime/budget_status.json');calls=[]
timing=j(root/'audit/TIMING_RECONCILIATION.json')
for a in budget['rows']:
 d=root/'models'/a['id'];r=j(d/'receipt.json');e=j(d/'engine_receipt.json')
 calls.append({'model':a['id'],'category':a['category'],'seconds':a['seconds'],'engine_status':e['status'],'adjudication':r['status'],'output_sha256':r.get('output_sha256'),'source_dir':str(d)})
pd.DataFrame(calls).to_csv(root/'results/CALLS.csv',index=False)
rows=[]
for g,d in [('EDU',old/'results'),('URBAN',root/'results/H41_URBAN'),('INC',root/'results/H41_INC')]:
 p=d/('H41_JOINT_D1.csv' if g=='EDU' else 'JOINT_D1.csv')
 if p.exists():
  z=pd.read_csv(p).iloc[0];rows.append({'Z':'SD','G':g,'members':10,'F':z.F,'df1':z.df1,'df2':z.df2,'p':z.p,'bonferroni12':min(1,12*z.p),'source':str(p)})
pd.DataFrame(rows).to_csv(root/'results/H41_SD_FAMILY_OVERVIEW.csv',index=False)
charls=j(root/'results/CHARLS_FAMILY_STATUS.json');checks=j(root/'audit/INDEPENDENT_POOLING.json')
if (root/'results/CHARLS_POOLING_RECEIPT.json').exists():charls['status']=j(root/'results/CHARLS_POOLING_RECEIPT.json')['status']
receipt={'status':'BOUNDED_EXTENSION_COMPLETE','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'H41_SD_complete_families':len(rows),'H41_registered_total':12,'four_dynamic_moderations_complete':False,'full_H4_complete':False,'CHARLS_status':charls['status'],'Mplus_calls':len(calls),'engine_seconds':sum(a['seconds'] for a in calls),'failed_numerical_CFPS_specifications_repeated':0,'infrastructure_retry':1,'new_manuscript':False,'new_NLM':0,'raw_data_published':False,'independent_verification':checks}
(root/'reports/BATCH_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
table='\n'.join(f"| SD × {r['G']} | 10/10 | {r['p']:.6f} | {r['bonferroni12']:.6f} |" for r in rows)
cp=root/'results/CHARLS_CORE_POOLED.csv'
ct='完整调整MI家族未形成，详见终态和逐次回执。'
if cp.exists():
 t=pd.read_csv(cp);ct='\n'.join(f"| {r.label} | {r.estimate:.6f} | [{r.lower:.6f}, {r.upper:.6f}] |" for r in t.itertuples())
body=f'''# H4.1 SD资源分支与CHARLS调整模型增量

**四项调节完整推断、完整 H4 仍未完成。**

本批接续既有成果。原始数据、原稿、已收尾的范围收缩稿均不覆盖。没有原样重跑因负方差、不可采用解或超时失败的旧CFPS科学规格。

## H4.1：完整成员与统计范围

| 家族 | 插补成员 | 双路径联合D1 P | 固定12项Bonferroni P |
|---|---:|---:|---:|
{table}

EDU来自前一批已发表十份结果，未重估；URBAN与INC为本批新增。起点检查不算插补成员。各分支保留八路径、六组间/组内对比、全协方差和独立Python复算。使用直接组间差异和联合D1，不比较两组星号，不平均P值。固定12项校正仅为保守的阶段报告，尚未完成整个家族的Holm检验。

EDU=初中及以上，URBAN=城市，INC=有正个人收入；INC不是高低收入分组。H4.1此处检验基期相对SD关联的资源差异，不是SX×Z0动态调节，也不是H4.2。既有FCS与交互模型的相容性尚未得到证明，因此报告为冻结插补条件下的推断，不能仅凭低FMI宣布该限制消失。

## CHARLS：从基期方案进入实际估计

冻结队列3,006人、440社区；五期时间0、2、4、7、9，X/Y使用2011基期标准化尺度，缺失轨迹保持FIML入口。X是子女见面频率等级，不是CFPS情感亲近度的同一测量。

核心控制包括年龄、性别、教育、城乡、伴侣、有效子女报告数、ADL、自评健康四个虚拟变量。2011缺失性别1例，经同一人2013、2015原始访谈及整合记录一致核查后在隔离分析副本恢复；原始缺失标记保留。20个ADL缺失以社区随机截距PMM处理，20份、20轮。原有观测单元格与X/Y缺失掩码逐份核对，源哈希不变。

20条链最终PSRF=1.003677，条件拟合收敛，未记录警告；只缓存确定性拟合，400次插补均重新抽样。未缓存、冷缓存、热缓存使用同种子时的20个填充值及最终RNG状态完全一致。

CHARLS家族状态：`{charls['status']}`。另保留同社区聚类未调整对照和原始基期完整案例2,985人敏感性。

| 路径 | 合并估计 | 95%条件MI区间 |
|---|---:|---:|
{ct}

bii=IX→IY，bis=IX→SY，bss=SX→SY，bsyiy=IY→SY。参数和TECH3协方差按Rubin合并，有限插补自由度；另列439自由度敏感性，拟合逐份列示而非平均。该模型是观察性纵向关联，不是因果效应，也没有完成CHARLS调节/异质性。扩展收入、消费控制，其他轨迹形状及跨窗口检验尚未完成。

## 实际执行与修复

本批共{len(calls)}次Mplus启动尝试，监督器计费{sum(a['seconds'] for a in calls):.3f}秒，包含Rscript启动与Mplus墙钟；不是端到端耗时。INC首份因监督器PermissionError中断，原失败目录完整保存，修复有界原子写入重试后在新目录恢复；该故障不是不显著或非法统计解。旧日志没有完整调用栈，不能断言具体失败文件；修复后追加栈记录。

UTC与单调计时的引擎跨度相符；CORE_MI12引擎完成到R读回回执之间另有约{timing['coordinator_readback_gap']['gap_seconds']:.0f}秒间隔，原因尚未确定，不能归因于Mplus运算或内存不足。后续驱动已增加独立读回阶段标记；本批没有为修复进度显示而重跑任何成功估计。

CHARLS第一插补任务的二分类拟合诊断超过180秒且原批首轮长期没有检查点，已按归属核验主动结束并保留记录。随后通过可靠来源恢复和确定性拟合缓存完成新MI，而非无限等待或清空无关程序。原20份首轮未完成，不能算一套已生成的MI。

协调器PID时间类型错误曾使CHARLS在H4.1间隙提前运行两个合法对照；文件锁阻止了CORE01重复领取，该次没有Mplus调用。已改为比较真实PID创建时间，接续复用合法对照。另有一个生成回执误写Documents/results，已核实归属后移回本批audit，后续全部用绝对路径。后台vanilla Rscript包库也已显式固定：此前成功调用为MplusAutomation1.2，修复后调用为1.3；没有为统一历史版本而重估合法结果。

## 后续边界

H4.1仍有其他差异指标的资源分支未形成完整推断；不能以本批SD分支替代。四项动态调节和H4.2仍未完成。不重提旧失败规格；新的科学规格须说明改变了什么、为何值得估计，并冻结小试/完整家族门槛。CHARLS下一步可在当前核心调整模型基础上处理收入/消费扩展和其缺失方案，之后才进入与原理论可比的差异与调节设计。

本报告不替换论文，不新增NLM审稿轮次。公开包只包含汇总结果、代码和模型证据；个人数据、真实DAT、MI/RDS、个体得分留在本机。缓存方法的范围依据也见[lme4性能说明](https://lme4.github.io/lme4/articles/lmerperf.html)；本批没有关闭导数计算或改变拟合精度来提速。
'''
(root/'reports/REPORT.md').write_text(body,encoding='utf-8')
(root/'reports/FOR_WEB_REVIEWERS.md').write_text('''# 给网页评议者

本批属于已关闭范围收缩稿之后，经作者授权的新研究增量。请先阅读REPORT.md和BATCH_RECEIPT.json。

请区分：H4.1 SD各资源分支十份条件MI合并、四项动态调节、完整H4、CHARLS核心调整关联。后面三者不能由前者替代。

请审查来源恢复是否充分披露、ADL多层PMM和既有CFPS FCS的限制、组间差异/联合D1及CHARLS主路径合并。不要以取得显著结果或补齐所有P值作为批次验收条件，不默认启动旧失败规格、NLM或新数值容差循环。

包内未含个体数据，因此只能独立核对保存参数、协方差、合并和代码，不能声称在云端重新拟合了CFPS或CHARLS。各ZIP均小于25MB；SHA256与逐文件载荷清单随包。
''',encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
