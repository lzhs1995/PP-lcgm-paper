# 只扩展有十份合法父模型的SD分支；不重复已完成EDU和失败动态交互。
NEW<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015'
Sys.setenv(PP_PREPARE_ONLY='1');source(file.path(NEW,'code/pilot.R'),local=TRUE);Sys.unsetenv('PP_PREPARE_ONLY')
ROOT<-NEW;Sys.setenv(R2E_ROOT=NEW)
custom_spec<-function(sp){
 si<-spec_info_r2e('SD',sub('H41_','H4_',sp),'c1-c24')
 si$model<-si$model[!grepl('XWITH|ON sxz|ON sxg|ON sxzg',si$model)]
 si$kind<-'linear';si$key<-si$key[!si$key$label%in%c('dc','bxg','dcg'),];si
}
prepare_next<-function(g,k,second=FALSE){
 id<-sprintf('CFPS_SD_H41_%s_MI%02d%s',g,k,if(second)'_startB' else '')
 original_dir<-file.path(ROOT,'models',id)
 old_receipt<-rj(file.path(original_dir,'receipt.json'))
 if(!is.null(old_receipt)&&old_receipt$status=='SUPERVISOR_ERROR')id<-paste0(id,'_infrastructure_recovery1')
 d<-file.path(ROOT,'models',id);dir.create(d,showWarnings=FALSE)
 if(file.exists(file.path(d,'job.json')))return(rj(file.path(d,'job.json')))
 si<-custom_spec(paste0('H41_',g));dd<-read_dat(datpath('SD',k),R2D_NAMES)
 a<-dd[c('z0',if(g=='INC')'ginc',paste0('c',1:24))];a$zg<-dd$z0*dd[[si$g]]
 mat<-cbind(1,as.matrix(a));stopifnot(!anyNA(mat));rank<-qr(mat)$rank
 wj(list(rows=nrow(mat),columns=ncol(mat),rank=rank,full_rank=rank==ncol(mat)),file.path(d,'design_rank.json'))
 stopifnot(rank==ncol(mat))
 mm<-make_model(si,file.path(E,'models',sprintf('CFPS_SD_E0_%02d_base',k)),perturb=second)
 sc<-splice_check(mm$lines,si);stopifnot(isTRUE(sc$ok));wj(sc,file.path(d,'splice_check.json'));csv(mm$mapping,file.path(d,'start_mapping.csv'))
 lines<-inp_text(id,si$use,wrap90(analysis_r2e('linear')),mm$lines,define=si$define,kind='linear');writeLines(lines,file.path(d,'model.inp'))
 stopifnot(file.copy(datpath('SD',k),file.path(d,'data.dat'),overwrite=FALSE))
 j<-list(id=id,root=ROOT,dest=d,spec=paste0('H41_',g),group=g,member=k,second_start=second,category='H41',cap_seconds=180,rscript=file.path(R.home('bin'),'Rscript.exe'),mplus=MPLUS,hashes=list(model.inp=hashf(file.path(d,'model.inp')),data.dat=hashf(file.path(d,'data.dat'))))
 wj(j,file.path(d,'job.json'));j
}
main<-function(){
 all<-rj(file.path(ROOT,'results/H41_FAMILIES.json'));if(is.null(all))all<-list()
 groups<-if(Sys.getenv('H41_ONLY_INC')=='1')'INC' else c('URBAN','INC')
 for(g in groups){
  progress('H41_family_start',g)
  results<-list();a<-prepare_next(g,1);ra<-run(a);results$MI01<-c(ra,list(source_dir=a$dest))
  if(ra$status!='USABLE'){all[[g]]<-list(status='PILOT_NOT_USABLE',members=results);wj(all,file.path(ROOT,'results/H41_FAMILIES.json'));next}
  b<-prepare_next(g,1,TRUE);rb<-run(b)
  comp<-if(rb$status=='USABLE')compare_numeric(list(key=read.csv(file.path(a$dest,'key_paths.csv')),receipt=ra),list(key=read.csv(file.path(b$dest,'key_paths.csv')),receipt=rb)) else list(passed=FALSE,reason=rb$status)
  wj(comp,file.path(ROOT,'results',paste0('H41_',g,'_START_CHECK.json')))
  if(!isTRUE(comp$passed)){all[[g]]<-list(status='START_CHECK_FAILED',members=results);wj(all,file.path(ROOT,'results/H41_FAMILIES.json'));next}
  for(k in 2:10){j<-prepare_next(g,k);r<-run(j);results[[sprintf('MI%02d',k)]]<-c(r,list(source_dir=j$dest));all[[g]]<-list(status='RUNNING',members=results);wj(all,file.path(ROOT,'results/H41_FAMILIES.json'));if(r$status!='USABLE')break}
  all[[g]]<-list(status=if(length(results)==10L&&all(vapply(results,function(x)x$status=='USABLE',logical(1))))'TEN_USABLE_PENDING_POOLING' else 'INCOMPLETE_STOPPED',members=results)
  wj(all,file.path(ROOT,'results/H41_FAMILIES.json'))
 }
 progress('H41_SD_EXTENSIONS_TERMINAL','Both registered extensions adjudicated; no other CFPS failed family repeated')
}
main()
