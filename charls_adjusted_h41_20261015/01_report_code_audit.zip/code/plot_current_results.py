"""汇总结果图；不绘制或输出个体数据。"""
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
root=Path('<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015')
old=root.parent/'h41_mi_charls_covariates_20261015'
rows=[]
for g,d in [('EDU',old/'results'),('URBAN',root/'results/H41_URBAN'),('INC',root/'results/H41_INC')]:
    p=d/('H41_POOLED_PATHS.csv' if g=='EDU' else 'POOLED_PATHS.csv')
    if not p.exists():continue
    a=pd.read_csv(p)
    for label in ['gizg','gszg']:
        z=a.loc[a.label==label].iloc[0];rows.append((g+' / '+('IY difference' if label=='gizg' else 'SY difference'),z.estimate,z.lower,z.upper))
fig,ax=plt.subplots(figsize=(8,4.5))
for y,(name,e,lo,hi) in enumerate(rows):ax.errorbar(e,y,xerr=[[e-lo],[hi-e]],fmt='o',color='#24618C',capsize=4)
ax.set_yticks(range(len(rows)),[x[0] for x in rows]);ax.invert_yaxis();ax.axvline(0,color='grey',ls='--');ax.set_xlabel('Pooled group difference and 95% conditional MI interval')
ax.set_title('CFPS H4.1: baseline relative SD by resource group')
fig.text(.01,.015,'EDU: junior+; URBAN: urban; INC: positive personal income (not high income).\nConditional on existing FCS imputations; full H4 and dynamic moderation remain incomplete.',fontsize=8)
fig.tight_layout(rect=(0,.1,1,1))
for ext in ['png','pdf']:fig.savefig(root/f'results/H41_SD_RESOURCE_DIFFERENCES.{ext}',dpi=180)
plt.close(fig)
p=root/'results/CHARLS_CORE_COMPARISON.csv'
if p.exists():
    a=pd.read_csv(p);fig,axes=plt.subplots(2,2,figsize=(9,6));names={'bii':'IX -> IY','bis':'IX -> SY','bss':'SX -> SY','bsyiy':'IY -> SY'}
    for ax,(lab,title) in zip(axes.flat,names.items()):
        t=a[a.label==lab]
        for y,r in enumerate(t.itertuples()):ax.errorbar(r.estimate,y,xerr=[[r.estimate-r.lower],[r.upper-r.estimate]],fmt='o',capsize=4)
        ax.set_yticks(range(len(t)),t.model);ax.invert_yaxis();ax.axvline(0,color='grey',ls='--');ax.set_title(title);ax.xaxis.set_major_locator(MaxNLocator(4));ax.tick_params(axis='x',labelsize=9)
    fig.suptitle('CHARLS continuous parallel growth: community-clustered estimates')
    fig.text(.01,.01,'Baseline standardized scores; actual-year loadings. Observational associations; no moderation claim.',fontsize=8)
    fig.tight_layout(rect=(0,.035,1,.95))
    for ext in ['png','pdf']:fig.savefig(root/f'results/CHARLS_ADJUSTED_COMPARISON.{ext}',dpi=180)
