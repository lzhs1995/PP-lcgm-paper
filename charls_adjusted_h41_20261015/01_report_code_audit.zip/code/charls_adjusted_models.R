# CHARLS主调整集：真实20份MI、完整案例敏感性、同社区聚类未调整对照。
Sys.setenv(PP_PREPARE_ONLY='1')
source('<LOCAL_USER_HOME>/pp_lgcm_review/reopen_observed_charls_20261015/code/charls_pilot.R',local=TRUE)
Sys.unsetenv('PP_PREPARE_ONLY')
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015';Sys.setenv(R2E_ROOT=ROOT)
base_spec<-specs$PP;specs$CORE<-base_spec;specs$CORE$model<-c(base_spec$model,'ix sx iy sy ON c1-c11;');specs$CC<-specs$CORE;specs$UNADJ<-base_spec
base_check<-check
check<-function(j){
 # 原生readModels+原高精度矩阵核验；复用原PP路径提取器。
 jj<-j;jj$spec<-'PP';saved<-specs$PP;specs$PP<<-specs[[j$spec]]
 on.exit({specs$PP<<-saved},add=TRUE)
 r<-base_check(jj);r$spec<-j$spec;r$adjustment<-if(j$spec=='UNADJ')'none, community clustering' else 'frozen 11-column core adjustment, community clustering'
 r$member<-j$member;r$N_expected<-j$N
 if(r$status=='USABLE_SINGLE_DATASET'&&!identical(as.integer(r[['N',exact=TRUE]]),as.integer(j$N)))r$status<-'SAMPLE_MISMATCH'
 wj(r,file.path(j$dest,'receipt.json'));r
}
prepare_model<-function(sp,k=1L){
 id<-if(sp=='CORE')sprintf('CHARLS_CORE_MI%02d',k) else paste0('CHARLS_',sp,'_COMMUNITY')
 d<-file.path(ROOT,'models',id);dir.create(d,showWarnings=FALSE)
 if(file.exists(file.path(d,'job.json')))return(rj(file.path(d,'job.json')))
 rec<-rj(file.path(ROOT,'results/CHARLS_MI_RECEIPT.json'));nn<-unlist(rec$data_columns)
 if(sp=='CORE'){dat<-file.path(ROOT,'private',sprintf('CHARLS_CORE_MI%02d.dat',k));N<-3006L}
 else{
  original<-readRDS(file.path(ROOT,'private/charls_core_mi_inputs.rds'));raw<-original$raw;cc<-original$data
  a<-data.frame(cluster=cc$cluster);for(v in c(paste0('x',1:5),paste0('y',1:5)))a[[v]]<-raw[[v]]
  a$c1<-cc$age;a$c2<-if(sp=='CC')raw$female else cc$female;a$c3<-cc$edu;a$c4<-cc$urban;a$c5<-cc$partner;a$c6<-cc$nchild;a$c7<-cc$adl
  for(i in 2:5)a[[paste0('c',i+6)]]<-cc[[paste0('health',i)]]
  if(sp=='CC')a<-a[complete.cases(a[paste0('c',1:11)]),]
  dat<-file.path(ROOT,'private',paste0(id,'.dat'));N<-nrow(a);write.table(a,dat,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
 }
 si<-specs[[sp]];use<-c(tolower(si$obs),if(sp!='UNADJ')'c1-c11')
 lines<-c(paste0('TITLE: ',id,';'),'DATA: FILE=data.dat;','VARIABLE:',wrap90(paste('NAMES=',paste(nn,collapse=' '),';')),wrap90(paste0('USEVARIABLES=',paste(use,collapse=' '),';')),'MISSING=ALL(-9999);','CLUSTER=cluster;','ANALYSIS: TYPE=COMPLEX; ESTIMATOR=MLR; PROCESSORS=1;','ITERATIONS=2000; COVERAGE=.005;','MODEL:',si$model,'OUTPUT: TECH1 TECH3 TECH4 TECH8 SVALUES CINTERVAL;','SAVEDATA: RESULTS=estimates.dat; TECH3=tech3.dat;')
 stopifnot(all(nchar(lines)<=90));writeLines(lines,file.path(d,'model.inp'));stopifnot(file.copy(dat,file.path(d,'data.dat')))
 j<-list(id=id,root=ROOT,dest=d,spec=sp,member=k,N=N,category='CHARLS',cap_seconds=180,rscript=file.path(R.home('bin'),'Rscript.exe'),mplus=MPLUS,hashes=list(model.inp=hashf(file.path(d,'model.inp')),data.dat=hashf(file.path(d,'data.dat'))));wj(j,file.path(d,'job.json'));j
}
run_model<-function(j){
 rp<-file.path(j$dest,'receipt.json')
 if(file.exists(rp)){
  prior<-rj(rp)
  if(prior$status=='NOT_RUN_RESOURCE_OR_BUDGET'&&!file.exists(file.path(j$dest,'engine_receipt.json'))&&!file.exists(file.path(j$dest,'model.out'))){
   stopifnot(file.rename(rp,file.path(j$dest,'receipt_before_claim_recovery.json')))
  }else return(prior)
 }
 progress('charls_adjusted_start',j$id)
 p<-processx::process$new(PY,c('-X','utf8',file.path(ROOT,'code/engine.py'),file.path(j$dest,'job.json')),stdout=file.path(j$dest,'supervisor.log'),stderr='2>&1',cleanup=TRUE)
 last<-0;while(p$is_alive()){p$wait(1000L);if(as.numeric(Sys.time())-last>25){if(exists('clauder_progress',mode='function'))clauder_progress('charls_estimating',j$id);last<-as.numeric(Sys.time())}}
 progress('charls_readback',j$id);r<-check(j);progress('charls_adjusted_end',paste(j$id,r$status));r
}
main<-function(){
 admission<-rj(file.path(ROOT,'audit/CHARLS_MI_ADMISSION.json'));stopifnot(isTRUE(admission$passed))
 # 不和SD协调器争用单槽；只轮询它的实际终态，不提交第二个监督器。
 t0<-Sys.time();repeat{hh<-rj(file.path(ROOT,'results/H41_FAMILIES.json'));owner<-rj(file.path(ROOT,'runtime/h41_coordinator.json'))
  live<-if(is.null(owner))FALSE else tryCatch({h<-ps::ps_handle(as.integer(owner$pid));ps::ps_is_running(h)&&abs(as.numeric(ps::ps_create_time(h))-as.numeric(owner$created))<.01},error=function(e)FALSE)
  done<-!live&&length(hh)==2&&!any(vapply(hh,function(z)z$status=='RUNNING',logical(1)))
  if(done&&!file.exists(file.path(ROOT,'runtime/engine.lock')))break
  if(as.numeric(difftime(Sys.time(),t0,units='secs'))>3600)stop('H41 ownership not terminal within wait budget')
  if(exists('clauder_progress',mode='function'))clauder_progress('waiting_registered_engine','H41 owns slot; no duplicate Mplus launch');Sys.sleep(20)}
 results<-list()
 for(sp in c('UNADJ','CC')){j<-prepare_model(sp);results[[j$id]]<-run_model(j);wj(results,file.path(ROOT,'results/CHARLS_MODELS.json'))}
 for(k in 1:20){j<-prepare_model('CORE',k);r<-run_model(j);results[[j$id]]<-r;wj(results,file.path(ROOT,'results/CHARLS_MODELS.json'));if(r$status!='USABLE_SINGLE_DATASET')break}
 core<-results[grepl('^CHARLS_CORE',names(results))]
 wj(list(status=if(length(core)==20L&&all(vapply(core,function(r)r$status=='USABLE_SINGLE_DATASET',logical(1))))'TWENTY_USABLE_PENDING_POOLING' else 'INCOMPLETE_STOPPED',members=length(core),complete_case_sensitivity=results$CHARLS_CC_COMMUNITY$status,unadjusted_cluster_control=results$CHARLS_UNADJ_COMMUNITY$status),file.path(ROOT,'results/CHARLS_FAMILY_STATUS.json'))
 progress('CHARLS_ADJUSTED_TERMINAL','Core family adjudicated; pool only if all20 usable')
}
main()
