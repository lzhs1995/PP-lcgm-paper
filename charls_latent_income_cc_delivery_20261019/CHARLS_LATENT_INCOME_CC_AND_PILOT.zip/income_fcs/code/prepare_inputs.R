# 完整潜轨迹队列的收入工作FCS；原观测、家庭键和XYZ缺失掩码保持。
local({
 BATCH<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_income_mi_20261019'
 OLD<-'C:/Users/LZHS/pp_lgcm_review/charls_corrected_baseline_income_20261018'
 CC<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_income_cc_20261019'
 .libPaths(c('C:/Users/LZHS/pp_lgcm_review/charls_income_mi_pilot_20261016/library','C:/Users/LZHS/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
 library(jsonlite);library(digest);library(mice)
 progress<-function(s,m){cat(s,m,'\n');flush.console();clauder_progress(s,m)}
 audit<-fromJSON(file.path(BATCH,'contracts/COHORT_AUDIT.json'),simplifyVector=FALSE)
 refs<-fromJSON(file.path(BATCH,'contracts/CC_SOURCES.json'),simplifyVector=FALSE)
 strictfile<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_trajectory_readiness_20261018/private/STRICT_FIVEWAVE_CONTRASTS.rds'
 stopifnot(digest(file=strictfile,algo='sha256')==audit$strict_source_sha256)
 strict<-readRDS(strictfile);yr<-c(2011,2013,2015,2018,2020);records<-list()
 for(z in c('sd','gender','oldest','son')){
  progress('LATENT_INCOME_PREPARE',paste(z,'full cohort and explicit auxiliary/predictor contract'))
  file<-file.path(OLD,'private',paste0(z,'_INPUTS.rds'));h<-digest(file=file,algo='sha256');a<-readRDS(file)
  e<-audit$indicators[[z]]$source;stopifnot(a$source_sha256==e$sha256,digest(file=e$file,algo='sha256')==e$sha256)
  s<-readRDS(e$file);v<-matrix(NA_real_,nrow(s$analysis),5);states<-matrix('',nrow(s$analysis),5)
  for(k in 1:5){b<-strict[strict$indicator==z&strict$year==yr[k],];ix<-match(as.character(s$pid),as.character(b$pid));stopifnot(!anyNA(ix));v[,k]<-(b$absolute[ix]-s$z_mean)/s$z_sd;states[,k]<-b$status[ix]}
  keep<-!apply(states,1,function(x)any(grepl('^STRUCTURAL_',x)))&rowSums(states=='AMBIGUOUS_EARLIEST_BIRTH_YEAR')==0&rowSums(!is.na(v))>=2
  stopifnot(nrow(a$data)==nrow(s$analysis),identical(a$analysis,s$analysis),sum(keep)==refs[[z]]$latent_N)
  d<-a$data[keep,,drop=FALSE];initial<-a$initial[keep,,drop=FALSE]
  original<-a$analysis[keep,setdiff(names(a$analysis),'z0'),drop=FALSE]
  for(k in 1:5)original[[paste0('z',k)]]<-v[keep,k]
  stopifnot(max(abs(original$z1-d$z0),na.rm=TRUE)<1e-12)
  g<-as.integer(as.numeric(s$income_raw[keep])>8730)
  stopifnot(identical(is.na(g),is.na(d$g)),all(g[!is.na(g)]==d$g[!is.na(g)]),sum(is.na(g))==refs[[z]]$missing_income)
  for(k in 2:5){vv<-v[keep,k];n<-paste0('obs_z',k);d[[n]]<-ifelse(is.na(vv),0,vv);d[[paste0('missing_z',k)]]<-as.numeric(is.na(vv));d[[paste0('zsq',k)]]<-d[[n]]^2}
  passive<-list(zg=c('z0','g'),z_adl=c('z0','adl'))
  aux<-grep('^(obs_|missing_)',names(d),value=TRUE)
  for(n in aux)passive[[paste0('g_',n)]]<-c(n,'g')
  for(k in 2:5)passive[[paste0('adl_obs_z',k)]]<-c(paste0('obs_z',k),'adl')
  for(n in names(passive))d[[n]]<-d[[passive[[n]][1]]]*d[[passive[[n]][2]]]
  for(n in setdiff(names(d),names(initial)))initial[[n]]<-d[[n]]
  for(n in names(passive))initial[[n]]<-initial[[passive[[n]][1]]]*initial[[passive[[n]][2]]]
  initial<-initial[names(d)];stopifnot(!anyNA(initial))
  method<-setNames(rep('',ncol(d)),names(d));method[c('g','adl')]<-c('2l.bin.logged','2l.pmm.logged')
  for(n in names(passive))method[n]<-paste0('~I(',paste(passive[[n]],collapse='*'),')')
  gproducts<-names(passive)[vapply(passive,function(x)'g'%in%x,TRUE)]
  adlproducts<-names(passive)[vapply(passive,function(x)'adl'%in%x,TRUE)]
  pm<-matrix(0,ncol(d),ncol(d),dimnames=list(names(d),names(d)))
  pm['g',setdiff(names(d),c('cluster','g',gproducts))]<-1;pm['g','cluster']<--2
  adlpred<-unique(c(names(which(a$predictors['adl',]==1)),aux,gproducts))
  pm['adl',setdiff(adlpred,c('cluster','adl',adlproducts))]<-1;pm['adl','cluster']<--2
  visit<-c('g',gproducts,'adl',adlproducts)
  blots<-setNames(vector('list',ncol(d)),names(d));blots$adl<-list(donors=5L)
  essential_G<-c('z0','z2','z_adl',paste0('obs_z',2:5),paste0('zsq',2:5),paste0('adl_obs_z',2:5))
  essential_ADL<-c('g','z0','zg',paste0('obs_z',2:5),paste0('g_obs_z',2:5),paste0('g_obs_x',1:5),paste0('g_obs_y',1:5))
  stopifnot(all(pm['g',essential_G]==1),all(pm['adl',essential_ADL]==1),all(pm['g',gproducts]==0),all(pm['adl',adlproducts]==0))
  original$c12<-g;cols<-unlist(refs[[z]]$columns);original<-original[cols]
  cc<-original[complete.cases(original[paste0('c',1:12)]),,drop=FALSE]
  back<-as.matrix(read.table(refs[[z]]$data,na.strings='-9999'));want<-as.matrix(cc)
  stopifnot(identical(dim(back),dim(want)),identical(unname(is.na(back)),unname(is.na(want))),max(abs(back-want),na.rm=TRUE)<1e-10)
  # 私有身份证键只留本地，不进入公开模型证据包。
  out<-list(data=d,analysis=original,method=method,predictors=pm,visit=visit,initial=initial,blots=blots,passive=passive,g_products=gproducts,adl_products=adlproducts,essential_G=essential_G,essential_ADL=essential_ADL,pid=s$pid[keep],source_file=e$file,source_sha256=e$sha256,definition_template=file,definition_template_sha256=h,strict_source_sha256=audit$strict_source_sha256)
  dest<-file.path(BATCH,'private',paste0(z,'_INPUTS.rds'));stopifnot(!file.exists(dest));saveRDS(out,dest)
  write.csv(data.frame(variable=rownames(pm),pm,check.names=FALSE),file.path(BATCH,'contracts',paste0(z,'_PREDICTORS_PLANNED.csv')),row.names=FALSE)
  records[[z]]<-list(N=nrow(d),communities=length(unique(d$cluster)),missing_G=sum(is.na(d$g)),missing_ADL=sum(is.na(d$adl)),N_CC=nrow(cc),predictors_G=sum(pm['g',]==1),predictors_ADL=sum(pm['adl',]==1),passive=passive,essential_G=essential_G,essential_ADL=essential_ADL,source_sha256=e$sha256,template_sha256=h,input_sha256=digest(file=dest,algo='sha256'),CC_identity=TRUE,XYZ_imputed=FALSE,raw_income_imputed=FALSE,new_Mplus=0)
  stopifnot(digest(file=file,algo='sha256')==h,digest(file=e$file,algo='sha256')==e$sha256)
 }
 stopifnot(digest(file=strictfile,algo='sha256')==audit$strict_source_sha256)
 write_json(records,file.path(BATCH,'audit/INPUTS_PREPARED.json'),auto_unbox=TRUE,pretty=TRUE)
 progress('LATENT_INCOME_INPUTS_DONE','Four frozen input scopes; no new MI draws yet')
})
