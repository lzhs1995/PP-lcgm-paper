Sys.setenv(OMP_NUM_THREADS=1,OPENBLAS_NUM_THREADS=1,MKL_NUM_THREADS=1)
# 两链两轮仅检验接口/条件拟合，不作为完整MI或研究推断。
BATCH<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_income_mi_20261019';stopifnot(exists('MI_SCOPE'),MI_SCOPE%in%c('sd','gender','oldest','son'));ROOT<-file.path(BATCH,'pilot',MI_SCOPE)
for(sub in c('audit','runtime','results','private','checkpoints'))dir.create(file.path(ROOT,sub),recursive=TRUE,showWarnings=FALSE)
.libPaths(c('C:/Users/LZHS/pp_lgcm_review/charls_income_mi_pilot_20261016/library','C:/Users/LZHS/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
library(mice);library(miceadds);library(lme4);library(glmmTMB);library(jsonlite);library(digest);library(processx);library(ps);library(fs)
contract<-fromJSON(file.path(BATCH,'contracts/RUN_CONTRACT.json'),simplifyVector=FALSE);contract$max_conditional_calls<-contract$pilot$max_conditional_calls
stopifnot(!file.exists(file.path(ROOT,'audit/PILOT_TERMINAL.json')))
source(file.path(BATCH,'code/atomic_status.R'),local=TRUE)
wj<-publish_status
progress<-function(stage,message){rec<-list(stage=stage,message=paste(MI_SCOPE,message),updated_at=format(Sys.time(),tz='UTC',usetz=TRUE),pid=Sys.getpid(),fit_n=if(exists('fit_env'))fit_env$fit_n else 0,target=if(exists('fit_env'))fit_env$target else '');append_status_event(rec,file.path(ROOT,'runtime/progress_events.jsonl'));wj(rec,file.path(ROOT,'runtime/progress.json'),critical=FALSE);cat(stage,rec$message,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(stage,rec$message)}
source(file.path(BATCH,'code/income_imputers.R'),local=TRUE);fit_env$scope<-paste0('LATENT_',MI_SCOPE);a<-readRDS(file.path(BATCH,'private',paste0(MI_SCOPE,'_INPUTS.rds')));warnings<-list()
capture<-function(expr)withCallingHandlers(expr,warning=function(w){warnings[[length(warnings)+1L]]<<-list(iteration=fit_env$iteration,fit_n=fit_env$fit_n,message=conditionMessage(w));invokeRestart('muffleWarning')})
main<-function(){
 started<-Sys.time();PY<-'C:/Users/LZHS/AppData/Local/Programs/Python/Python314/python.exe';created<-as.numeric(ps::ps_create_time(ps::ps_handle()))
 watch<-process$new(PY,c('-X','utf8',file.path(BATCH,'code/mi_watch.py'),'--pid',Sys.getpid(),'--created',sprintf('%.6f',created),'--root',ROOT,'--seconds',contract$pilot$wall_seconds,'--fit-seconds',contract$per_fit_seconds),stdout=file.path(ROOT,'runtime/watch.log'),stderr='2>&1',cleanup=FALSE)
 on.exit({writeLines('release',file.path(ROOT,'runtime/stop.request'));watch$wait(8000L)},add=TRUE)
 source(file.path(BATCH,'code/watch_ready.R'),local=TRUE)
 wait_for_owned_watch(watch,ROOT,created)
 fit_env$iteration<-1L;progress('income_pilot','Two chains, two iterations, no Mplus')
 imp<-capture(mice(a$data,m=2,maxit=1,method=a$method,predictorMatrix=a$predictors,visitSequence=a$visit,seed=contract$pilot$seeds[[MI_SCOPE]],data.init=a$initial,blots=a$blots,printFlag=FALSE));saveRDS(imp,file.path(ROOT,'checkpoints/ITER01.rds'))
 fit_env$iteration<-2L;imp<-capture(mice.mids(imp,maxit=1,printFlag=FALSE));saveRDS(imp,file.path(ROOT,'checkpoints/ITER02.rds'))
 saveRDS(imp,file.path(ROOT,'private/MIDS.rds'));saveRDS(.Random.seed,file.path(ROOT,'private/RNG_FINAL.rds'))
 write.csv(data.frame(variable=rownames(imp$predictorMatrix),imp$predictorMatrix,check.names=FALSE),file.path(ROOT,'audit/PREDICTORS_ACTUAL.csv'),row.names=FALSE)
 if(!is.null(imp$loggedEvents))write.csv(imp$loggedEvents,file.path(ROOT,'audit/LOGGED_EVENTS.csv'),row.names=FALSE)
 checks<-list();values<-list()
 for(k in 1:2){
  v<-complete(imp,k);original<-as.matrix(a$data);vv<-as.matrix(v);obs<-!is.na(original);unchanged<-isTRUE(all.equal(as.numeric(original[obs]),as.numeric(vv[obs]),tolerance=0));identities<-all(vapply(names(a$passive),function(n)max(abs(v[[n]]-v[[a$passive[[n]][1]]]*v[[a$passive[[n]][2]]]))<1e-12,TRUE))
  support<-all(v$g%in%0:1)&&all(v$adl%in%0:6)&&all(v$adl[is.na(a$data$adl)]%in%a$data$adl[!is.na(a$data$adl)])
  checks[[k]]<-data.frame(member=k,observed_preserved=unchanged,passive_products=identities,support=support,missing=sum(is.na(v)),imputed_G_mean=mean(v$g[is.na(a$data$g)]),imputed_ADL_mean=mean(v$adl[is.na(a$data$adl)]));values[[k]]<-v
 }
 checks<-do.call(rbind,checks);write.csv(checks,file.path(ROOT,'results/MEMBER_CHECKS.csv'),row.names=FALSE)
 essential<-all(imp$predictorMatrix['g',a$essential_G]==1)&&all(imp$predictorMatrix['adl',a$essential_ADL]==1)&&all(imp$predictorMatrix[c('g','adl'),'cluster']==-2)
 no_self<-all(imp$predictorMatrix['g',a$g_products]==0)&&all(imp$predictorMatrix['adl',a$adl_products]==0)
 fits<-lapply(readLines(file.path(ROOT,'audit/FIT_LOG.jsonl')),fromJSON);fit_valid<-length(fits)==8&&all(vapply(fits,function(x)isTRUE(x$valid),TRUE))
 valid<-all(checks$observed_preserved&checks$passive_products&checks$support&checks$missing==0)&&essential&&no_self&&fit_valid
 rec<-list(status=if(valid)'CONDITIONAL_INTERFACE_PASS_NOT_FULL_MI' else 'CONDITIONAL_INTERFACE_FAIL',passed=valid,m=2,iterations=2,N=nrow(a$data),essential_predictors=essential,no_self_products=no_self,all_conditional_fits_valid=fit_valid,conditional_fits=length(fits),distinct_imputed_G=sum(values[[1]]$g[is.na(a$data$g)]!=values[[2]]$g[is.na(a$data$g)]),seconds=as.numeric(difftime(Sys.time(),started,units='secs')),full_MI_complete=FALSE,new_Mplus=0L,compatibility=contract$compatibility)
 wj(rec,file.path(ROOT,'audit/PILOT_TERMINAL.json'));progress('CHARLS_INCOME_PILOT_TERMINAL',rec$status);cat('CHARLS_INCOME_PILOT_TERMINAL\n')
}
tryCatch(main(),error=function(e){wj(list(status='PILOT_ERROR',passed=FALSE,error=conditionMessage(e),new_Mplus=0L),file.path(ROOT,'audit/PILOT_TERMINAL.json'));stop(e)},finally={wj(warnings,file.path(ROOT,'audit/WARNINGS.json'));writeLines(capture.output(sessionInfo()),file.path(ROOT,'audit/R_SESSION_INFO.txt'))})
