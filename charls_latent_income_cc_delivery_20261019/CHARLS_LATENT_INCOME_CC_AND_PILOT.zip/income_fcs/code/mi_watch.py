"""仅约束创建者指定的MI子R；记录真实峰值，不接管其他研究进程。"""
from pathlib import Path
import argparse,ctypes,json,time
import psutil
from engine import write,Memory,utc
from active_clock import active_now,BudgetClock
p=argparse.ArgumentParser();p.add_argument('--pid',type=int,required=True);p.add_argument('--created',type=float,required=True);p.add_argument('--root',required=True);p.add_argument('--seconds',type=float,required=True);p.add_argument('--fit-seconds',type=float,required=True);a=p.parse_args()
R=Path(a.root);target=psutil.Process(a.pid);born=target.create_time();cmd=target.cmdline()
assert target.name().lower() in {'rscript.exe','rterm.exe','r.exe'} and abs(born-a.created)<.01 and a.pid in [x.pid for x in psutil.Process().parents()]
def read(path):
    try:return json.loads(path.read_text(encoding='utf-8-sig'))
    except (OSError,ValueError):return {}
def progress_record():
    cached=read(R/'runtime/progress.json')
    try:
        with (R/'runtime/progress_events.jsonl').open('rb') as h:
            h.seek(0,2);h.seek(max(0,h.tell()-16384));lines=h.read().decode('utf-8',errors='replace').splitlines()
        for line in reversed(lines):
            try:
                event=json.loads(line)
                return event if event.get('updated_at','')>=cached.get('updated_at','') else cached
            except ValueError:pass
    except OSError:pass
    return cached
def lastfit():
    try:
        with (R/'audit/FIT_LOG.jsonl').open('rb') as h:h.seek(0,2);h.seek(max(0,h.tell()-16384));lines=h.read().decode('utf-8',errors='replace').splitlines()
        for line in reversed(lines):
            try:return json.loads(line)
            except ValueError:pass
    except OSError:pass
    return {}
clock=BudgetClock();started=active_now();peak=peak_private=0;last_n=None;fit_started=None;status='WATCH_ERROR';awake=False
def quick_profile():
    # 监控自己的worker无需遍历全机进程；CPU首读仅作诊断，不作准入裁决。
    m=Memory();m.length=ctypes.sizeof(m)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):raise OSError('Windows memory unavailable')
    return dict(utc=utc(),available_gib=m.avail/2**30,commit_available_gib=m.commit_avail/2**30,cpu_percent=psutil.cpu_percent(interval=None))
try:
    awake=bool(ctypes.windll.kernel32.SetThreadExecutionState(0x80000001))
    write(R/'runtime/WATCH.json',dict(status='WATCH_READY',utc=utc(),owner_pid=a.pid,created=born,awake=awake))
    while True:
        if (R/'runtime/stop.request').exists():status='STOP_REQUESTED';break
        if not target.is_running() or abs(target.create_time()-born)>.01:status='CREATOR_EXITED';break
        timing=clock.sample();elapsed=timing['active_seconds'];mi=target.memory_info();peak=max(peak,mi.rss);peak_private=max(peak_private,getattr(mi,'private',0));pr=progress_record();n=pr.get('fit_n',0)
        if n and n!=last_n:last_n=n;fit_started=elapsed
        complete=lastfit().get('fit_n')==n
        fit_elapsed=0 if complete or fit_started is None else elapsed-fit_started
        pf=quick_profile();record=dict(status='WATCHING',utc=utc(),owner_pid=a.pid,created=born,elapsed_seconds=elapsed,clocks=timing,fit_n=n,fit_elapsed_seconds=fit_elapsed,peak_rss_bytes=peak,peak_private_bytes=peak_private,resource=pf,awake=awake)
        write(R/'runtime/WATCH.json',record,critical=False)
        if elapsed>a.seconds or fit_elapsed>a.fit_seconds:
            status='OWNED_WORKER_ACTIVE_TIMEOUT' if elapsed>a.seconds else 'OWNED_CONDITIONAL_FIT_TIMEOUT';record['status']=status;write(R/'audit/WATCH_TIMEOUT.json',record)
            assert target.create_time()==born and target.cmdline()==cmd;target.terminate();break
        time.sleep(3)
except psutil.NoSuchProcess:status='CREATOR_EXITED'
finally:
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
    timing=clock.sample();write(R/'runtime/WATCH_TERMINAL.json',dict(status=status,owner_pid=a.pid,created=born,elapsed_seconds=timing['active_seconds'],clocks=timing,peak_rss_bytes=peak,peak_private_bytes=peak_private,awake_released=True))
