# 一次原生异步提交，四个独立条件接口；不启动Mplus或正式40链。
local({
 BATCH<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_income_mi_20261019'
 Sys.setenv(OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1,MKL_NUM_THREADS=1)
 library(jsonlite);library(ps);library(processx)
 PY<-'C:/Users/LZHS/AppData/Local/Programs/Python/Python314/python.exe'
 stopifnot(!file.exists(file.path(BATCH,'runtime/PILOTS_RESERVED.json')))
 probe<-processx::run(PY,c('-X','utf8',file.path(BATCH,'code/resource_gate.py')),timeout=30,error_on_status=TRUE)
 resource<-fromJSON(probe$stdout);ps_set_cpu_affinity(ps_handle(),resource$chosen)
 write_json(resource,file.path(BATCH,'audit/PILOT_RESOURCE_ADMISSION.json'),auto_unbox=TRUE,pretty=TRUE)
 write_json(list(pid=Sys.getpid(),created=as.numeric(ps_create_time(ps_handle())),created_exact=sprintf('%.17g',as.numeric(ps_create_time(ps_handle())))),file.path(BATCH,'runtime/PILOTS_RESERVED.json'),auto_unbox=TRUE,pretty=TRUE,digits=NA)
 source(file.path(BATCH,'code/prepare_inputs.R'),local=TRUE)
 for(z in c('sd','gender','oldest','son')){
  local({MI_SCOPE<-z;tryCatch(source(file.path(BATCH,'code/run_pilot.R'),local=TRUE),error=function(e){cat('PILOT_SCOPE_ERROR_PRESERVED',MI_SCOPE,conditionMessage(e),'\n');flush.console()})})
  gc(FALSE)
 }
 result<-setNames(lapply(c('sd','gender','oldest','son'),function(z){p<-file.path(BATCH,'pilot',z,'audit/PILOT_TERMINAL.json');if(file.exists(p))jsonlite::fromJSON(p,simplifyVector=FALSE)else list(passed=FALSE,status='NO_TERMINAL')}),c('sd','gender','oldest','son'))
 write_json(result,file.path(BATCH,'audit/PILOT_SCOPE_TERMINALS.json'),auto_unbox=TRUE,pretty=TRUE)
 clauder_progress('LATENT_INCOME_PILOTS_TERMINAL','Conditional interface dispositions saved; no formal MI or Mplus')
 cat('LATENT_INCOME_PILOTS_TERMINAL\n')
})
