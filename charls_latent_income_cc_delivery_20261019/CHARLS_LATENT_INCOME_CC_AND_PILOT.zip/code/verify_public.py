"""只读复算原始RESULTS/TECH3到公开参数的映射；不调用模型normalizer。"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
from calibrated_reader import matrices,pid
R=Path(__file__).resolve().parents[1];read=lambda p:json.loads(p.read_text())
outdir=R/'audit_recomputed';outdir.mkdir(exist_ok=False)
rows=[]
for d in sorted((R/'models').iterdir()):
 if not (d/'receipt.json').exists():continue
 rec=read(d/'receipt.json')
 if rec['status']!='USABLE':continue
 txt,mp,q,se,V,ll=matrices(d);par=pd.read_csv(d/'parameters_high_precision.csv');job=read(d/'job.json');P=len(q)
 J=np.zeros((P,P))
 for i,p in enumerate(par.itertuples()):
  m=p.matrix.upper();r=p.row;c=p.column
  if not job['ordinary'] and m in ('BETA','GAMMA') and c==job['g']:
   J[i,pid(mp[2],'ALPHA','1',r)]=1;J[i,pid(mp[1],'ALPHA','1',r)]=-1
  elif m in ('BETA','GAMMA') and c in ('IXG','SXG','IZG','SZG'):
   J[i,pid(mp[2],'BETA',r,c[:2])]=1;J[i,pid(mp[1],'BETA',r,c[:2])]=-1
  else:J[i,pid(mp[1],m,r,c)]=1
 est=J@q;vc=J@V@J.T;cov=np.loadtxt(d/'parameter_covariance.csv',delimiter=',');savedJ=np.loadtxt(d/'parameter_transform.csv',delimiter=',')
 assert np.array_equal(J,savedJ) and np.linalg.matrix_rank(J)==P
 assert np.allclose(est,par.estimate,rtol=1e-10,atol=1e-11)
 assert np.allclose(np.sqrt(vc.diagonal()),par.se,rtol=1e-9,atol=1e-11)
 assert np.allclose(vc,cov,rtol=1e-9,atol=1e-11)
 assert hashlib.sha256((d/'model.out').read_bytes()).hexdigest()==rec['output_sha256']
 assert abs(ll+(0 if job['ordinary'] else job['N']*np.log(2))-rec['LL'])<1e-7
 rows.append(dict(model=d.name,N=job['N'],parameters=P,independent_full_transform=True,max_estimate_difference=float(np.max(abs(est-par.estimate))),max_SE_difference=float(np.max(abs(np.sqrt(vc.diagonal())-par.se))),max_full_covariance_difference=float(np.max(abs(vc-cov))),output_sha256=rec['output_sha256']))
assert rows
pd.DataFrame(rows).to_csv(outdir/'INDEPENDENT_PARAMETER_CHECK.csv',index=False)
(outdir/'INDEPENDENT_PARAMETER_CHECK.json').write_text(json.dumps(dict(status='PASS',models=len(rows),free_parameters=sum(x['parameters'] for x in rows),all_full_covariances_checked=True,new_engines=0),indent=2))
print('INDEPENDENT_PARAMETER_CHECK_PASS',len(rows),sum(x['parameters'] for x in rows))
