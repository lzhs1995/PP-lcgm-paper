# 只在隔离目录构造收入完整案例；原收入、XYZ、控制及插补文件保持。
local({
 ROOT<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_income_cc_20261019'
 I<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_income_design_20261019'
 library(jsonlite);library(digest)
 rj<-function(p)fromJSON(p,simplifyVector=FALSE)
 wj<-function(x,p)write_json(x,p,auto_unbox=TRUE,pretty=TRUE,digits=NA,null='null')
 a<-rj(file.path(ROOT,'contracts/COHORT_AUDIT.json'));parents<-rj(file.path(ROOT,'contracts/STARTING_SOURCE_PARENTS.json'))
 strictpath<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_trajectory_readiness_20261018/private/STRICT_FIVEWAVE_CONTRASTS.rds'
 stopifnot(digest(file=strictpath,algo='sha256')==a$strict_source_sha256)
 strict<-readRDS(strictpath);map<-readRDS(file.path(I,'private/HOUSEHOLD_MAPPING.rds'));out<-list();yr<-c(2011,2013,2015,2018,2020)
 cols<-c('cluster',paste0('x',1:5),paste0('y',1:5),paste0('c',1:12),paste0('z',1:5))
 for(z in c('sd','gender','oldest','son')){
  progress('INCOME_INPUTS',paste(z,'same original latent cohort; observed income and ADL only'))
  e<-a$indicators[[z]]$source;stopifnot(digest(file=e$file,algo='sha256')==e$sha256)
  s<-readRDS(e$file);v<-matrix(NA_real_,nrow(s$analysis),5);states<-matrix('',nrow(s$analysis),5)
  for(k in 1:5){b<-strict[strict$indicator==z&strict$year==yr[k],];ix<-match(as.character(s$pid),as.character(b$pid));stopifnot(!anyNA(ix));v[,k]<-(b$absolute[ix]-s$z_mean)/s$z_sd;states[,k]<-b$status[ix]}
  stopifnot(identical(is.na(v),states!='DEFINED'))
  keep<-!apply(states,1,function(x)any(grepl('^STRUCTURAL_',x)))&rowSums(states=='AMBIGUOUS_EARLIEST_BIRTH_YEAR')==0&rowSums(!is.na(v))>=2
  m<-map[[z]];stopifnot(identical(as.character(s$pid),m$pid),identical(keep,m$latent_cohort),all(!is.na(m$fid)),!anyDuplicated(m$fid[keep]))
  g<-as.integer(as.numeric(s$income_raw)>8730);stopifnot(identical(is.na(g),is.na(m$g)),all(g[!is.na(g)]==m$g[!is.na(g)]))
  d<-s$analysis[keep,setdiff(names(s$analysis),'z0'),drop=FALSE]
  for(k in 1:5)d[[paste0('z',k)]]<-v[keep,k]
  stopifnot(nrow(d)==a$indicators[[z]]$N_two_Z_waves)
  # 先逐值匹配原已成功父模型，证明观察资料未变化。
  cc_old<-complete.cases(d[paste0('c',1:11)])
  prior<-as.matrix(read.table(file.path(parents[[z]]$parent,'data.dat'),na.strings='-9999'))
  want<-as.matrix(d[cc_old,,drop=FALSE]);stopifnot(identical(dim(prior),dim(want)),identical(unname(is.na(prior)),unname(is.na(want))),max(abs(prior-want),na.rm=TRUE)<1e-10)
  d$c12<-g[keep];cc<-complete.cases(d[paste0('c',1:12)]);d<-d[cc,cols,drop=FALSE]
  stopifnot(nrow(d)>0,all(d$c12%in%0:1),length(unique(d$c12))==2,!anyNA(d[paste0('c',1:12)]))
  dest<-file.path(ROOT,'private',z);dir.create(dest,showWarnings=FALSE)
  file<-file.path(dest,'data.dat');stopifnot(!file.exists(file));write.table(d,file,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
  got<-as.matrix(read.table(file,na.strings='-9999'));want<-as.matrix(d);stopifnot(identical(unname(is.na(got)),unname(is.na(want))),max(abs(got-want),na.rm=TRUE)<1e-10)
  saveRDS(list(pid=s$pid[keep][cc],fid=m$fid[keep][cc],data=d,source_pid=s$pid,latent_keep=keep,complete_income_adl=cc),file.path(dest,'INPUTS.rds'))
  out[[z]]<-list(indicator=z,N=nrow(d),communities=length(unique(d$cluster)),group_counts=as.list(table(factor(d$c12,levels=0:1))),latent_N=sum(keep),missing_income=sum(is.na(g[keep])),excluded_any_control=sum(!cc),columns=cols,data=file,data_sha256=digest(file=file,algo='sha256'),source=e,starting_parent=parents[[z]],income_threshold=8730,observed_preserved=TRUE,structural_imputation=FALSE,new_MI=0)
  stopifnot(digest(file=e$file,algo='sha256')==e$sha256)
  wj(out,file.path(ROOT,'contracts/SOURCES.json'));progress('INCOME_INPUTS_DONE',paste(z,'N',nrow(d)))
 }
 stopifnot(digest(file=strictpath,algo='sha256')==a$strict_source_sha256)
 wj(list(status='PASS_INPUT_READBACK',indicators=out,new_models=0,new_MI=0),file.path(ROOT,'audit/INPUTS_READBACK.json'))
 cat('LATENT_INCOME_CC_INPUTS_DONE\n')
})
