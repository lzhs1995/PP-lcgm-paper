# 原生后台执行：新输入→普通父→同数据等价父→资源组差A/B；每阶段持久输出。
local({
 ROOT<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_income_cc_20261019'
 PY<-'C:/Users/LZHS/AppData/Local/Programs/Python/Python314/python.exe'
 Sys.setenv(OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1,MKL_NUM_THREADS=1)
 .libPaths(c('C:/Users/LZHS/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
 library(jsonlite);library(ps);library(processx);library(digest);library(MplusAutomation)
 rj<-function(p)fromJSON(p,simplifyVector=FALSE)
 wj<-function(x,p)write_json(x,p,auto_unbox=TRUE,pretty=TRUE,digits=NA,null='null')
 progress<-function(s,m){cat(format(Sys.time(),tz='UTC'),s,m,'\n');flush.console();clauder_progress(s,m);wj(list(stage=s,message=m,updated_at=format(Sys.time(),tz='UTC')),file.path(ROOT,'runtime/PROGRESS.json'))}
 cp<-processx::run(PY,c('-X','utf8','-c',"import psutil,json;v=psutil.cpu_percent(2,percpu=True);assert len(v)==16;g=min([list(range(8)),list(range(8,16))],key=lambda q:sum(v[i] for i in q));print(json.dumps({'per_cpu':v,'chosen':g}))"),timeout=30,error_on_status=TRUE)
 cp<-fromJSON(cp$stdout);ps_set_cpu_affinity(ps_handle(),cp$chosen);wj(cp,file.path(ROOT,'audit/CPU_ADMISSION.json'))
 identity<-list(pid=Sys.getpid(),created=as.numeric(ps_create_time(ps_handle())),created_exact=sprintf('%.17g',as.numeric(ps_create_time(ps_handle()))),MplusAutomation=as.character(getNamespaceVersion('MplusAutomation')))
 wj(identity,file.path(ROOT,'audit/EXECUTION_RUNTIME.json'))
 stopifnot(!file.exists(file.path(ROOT,'runtime/RESERVED.json')));wj(identity,file.path(ROOT,'runtime/RESERVED.json'))
 stopifnot(rj(file.path(ROOT,'audit/COMPILER_EXTENSION_CHECK.json'))$status=='PASS_ZERO_EFFECT_EXTENSION')
 progress('PREPARING_INCOME_CC','Original source values and threshold, new complete-case subset only')
 source(file.path(ROOT,'code/prepare_inputs.R'),local=TRUE)
 source(file.path(ROOT,'code/model_service_client.R'),local=TRUE)
 main<-function(){
  on.exit(helper_close(),add=TRUE)
  c<-rj(file.path(ROOT,'contracts/RUN_CONTRACT.json'));calls<-list();families<-list();held<-FALSE
  saveall<-function(){wj(calls,file.path(ROOT,'results/CALL_RESULTS.json'));wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'))}
  run<-function(z,g,st){
   id<-paste0('CHARLS_',toupper(z),'_LATENT_INCOME_',g,'_',st);d<-file.path(ROOT,'models',id)
   stopifnot(!dir.exists(d))
   helper_call('models.py',c('prepare',z,g,st),file.path(ROOT,'runtime',paste0(id,'_prepare.log')))
   cmd<-file.path(d,'launch.cmd');writeLines(c('@echo off',paste0('"',PY,'" -X utf8 "',ROOT,'/code/adapter.py" "%~dp0job.json" "%~1"'),'exit /b %ERRORLEVEL%'),cmd)
   helper_close();helper_state$p<-NULL;gc(FALSE);progress('INCOME_CC_ESTIMATING',id)
   warnings<-character();error<-NULL
   withCallingHandlers(tryCatch(MplusAutomation::runModels(file.path(d,'model.inp'),recursive=FALSE,showOutput=TRUE,replaceOutfile='never',Mplus_command=cmd,killOnFail=FALSE,logFile=file.path(d,'MplusAutomation.log')),error=function(e)error<<-conditionMessage(e)),warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')})
   wj(list(warnings=warnings,error=error),file.path(d,'R_WRAPPER_RETURN.json'))
   stopifnot(file.exists(file.path(d,'engine_receipt.json')))
   helper_call('models.py',c('normalize',d),file.path(ROOT,'runtime',paste0(id,'_normalize.log')))
   rec<-rj(file.path(d,'receipt.json'));calls[[id]]<<-rec;saveall();progress('INCOME_CC_MODEL_TERMINAL',paste(id,rec$status))
   if(rec$status=='NOT_RUN_RESOURCE_HOLD')held<<-TRUE
   rec
  }
  for(z in unlist(c$indicators)){
   a<-run(z,'ORDINARY','A');if(held)break
   if(a$status!='USABLE'){families[[z]]<-list(status='ORDINARY_PARENT_NOT_ADMITTED',reason=a$status,complete_MI=FALSE);saveall();next}
   b<-run(z,'PARENT','A');if(held)break
   if(b$status!='USABLE'){families[[z]]<-list(status='KNOWNCLASS_PARENT_NOT_ADMITTED',reason=b$status,complete_MI=FALSE);saveall();next}
   helper_call('models.py',c('calibrate',z),file.path(ROOT,'runtime',paste0(z,'_calibrate.log')))
   if(!isTRUE(rj(file.path(ROOT,'results',paste0(z,'_CALIBRATION.json')))$passed)){families[[z]]<-list(status='CALIBRATION_FAILED',complete_MI=FALSE);saveall();next}
   a<-run(z,'INCOME','A');if(held)break
   if(a$status!='USABLE'){families[[z]]<-list(status='GROUP_A_NOT_ADMITTED',reason=a$status,complete_MI=FALSE);saveall();next}
   b<-run(z,'INCOME','B');if(held)break
   if(b$status!='USABLE'){families[[z]]<-list(status='GROUP_B_NOT_ADMITTED',reason=b$status,complete_MI=FALSE);saveall();next}
   target<-file.path(ROOT,'results',paste0(z,'_START_COMPARISON.json'))
   helper_call('models.py',c('agree',a$dest,b$dest,target),file.path(ROOT,'runtime',paste0(z,'_agree.log')))
   families[[z]]<-list(status=if(isTRUE(rj(target)$passed))'TWO_START_CC_FEASIBLE_NOT_MI'else'START_CHECK_FAILED',complete_MI=FALSE);saveall()
  }
  rec<-list(terminal=TRUE,resource_hold=held,actual_calls=sum(vapply(calls,function(x)x$engine$actual_engine_calls,numeric(1))),families=families,new_MI=0,original_four_complete=FALSE,full_H4_complete=FALSE)
  wj(rec,file.path(ROOT,'results/BATCH_RECEIPT.json'));progress('INCOME_CC_TERMINAL','See explicit indicator dispositions; no CC result is full MI');cat('LATENT_INCOME_CC_DONE\n')
 }
 main()
})
