# 原生异步提交回执丢失，找回原任务而不重复估计

2026-10-19，本批原生 `execute_r_async` 返回 `Error starting async job: Error communicating with RStudio:`，但外层 `isError:false`。该返回不能证明提交未被接收。

处理顺序与实际证据：

1. 原始错误原样保存于 `audit/NATIVE_SUBMIT.json`。立即暂停新的提交，没有重启 RStudio 或杀进程。
2. 短原生调用恢复，前台仍为 R PID 8764。检查 ClaudeR 内存任务登记，找到 `629d98e5`；登记中的完整 `code`、agent、session、port 与本次隔离目录完全一致，worker 为 PID 11112。绑定证据保存于 `NATIVE_RECOVERED_BINDING.json`。
3. 对该原编号调用 `get_async_result`，先得到 `started`，随后阶段推进到 `INCOME_CC_ESTIMATING`。进程、创建时间、预留文件和实际输出共同确认归属；没有仅凭端口开放就宣称接口健康。
4. 将真实任务编号登记到原 pre-submit guard，启动只读监控并核对第一条真实采样。原编号完成 16 次 Mplus 调用，终态完整保存在 `NATIVE_RUN_TERMINAL.json`。
5. 独立复算全部 2160 个自由参数及完整协方差通过；原 worker 与监控器均退出，guard 完成归档。原主 R 及另一 R 会话的 PID、创建时间保持。

提交阶段的准确底层故障原因未被唯一证明。没有证据可据此认定模型失败、内存耗尽或 RStudio 已退出。回执丢失与后台接受任务同时发生，是本次直接观察到的事实。

技能落地：`mplusautomation-guide/references/recovery-runbook.md` 已明确规定 ambiguous async submission 的身份核对与同 job 恢复；PR58 又加入前台同步长任务、误导性的工具正文错误、监控器启动失败和证据边界。合并提交 `69796be09d588e43e04a73a69f912e2c9b5bb779` 已经通过原生管理器安装并验证七入口，本批使用该程序再次成功恢复。不为相同已覆盖规则重复创建安装、CI 或全局自动重启服务。

恢复成本只包含只读核对和原任务轮询：新增重复统计提交 0、RStudio 重启 0、原数据修改 0。完整案例通过不等于完整 MI、四项原调节或完整 H4 已完成。
