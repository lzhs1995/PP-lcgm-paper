# 当前RStudio只读核验新覆盖表：独立重算已登记检验集合的Holm校正，不拟合模型。
stopifnot(requireNamespace("jsonlite", quietly = TRUE), requireNamespace("digest", quietly = TRUE))
root <- "C:/Users/LZHS/pp_lgcm_review/pp_lgcm_hypothesis_coverage_20261019"
cat("[coverage] 读取聚合来源与覆盖表\n"); flush.console()
read_table <- function(path) read.csv(file.path(root, path), fileEncoding = "UTF-8-BOM", stringsAsFactors = FALSE)
families <- read_table("results/CHARLS_CURRENT_31_FAMILIES.csv")
specs <- list(
  H41_MEAN = list(path="sources/CHARLS_MEAN_RESOURCES.csv", id="group", adjusted="holm_planned3"),
  H41_BASELINE_Z = list(path="sources/CHARLS_H41_Z_RESOURCES.csv", id="family", adjusted="holm_p_planned12"),
  OBSERVED_Z_DYNAMIC = list(path="sources/CHARLS_OBSERVED_Z_DYNAMIC.csv", id="scope", adjusted="holm_p_fixed4"),
  H42_OBSERVED_Z = list(path="sources/CHARLS_H42_RESOURCES.csv", id="family", adjusted="Holm_12")
)
checks <- lapply(names(specs), function(kind) {
  s <- specs[[kind]]; original <- read_table(s$path)
  current <- families[families$kind == kind, , drop=FALSE]
  index <- match(current$family, original[[s$id]])
  stopifnot(!anyNA(index), !anyDuplicated(index), length(index) == nrow(original))
  raw_p <- original$p[index]
  recomputed <- p.adjust(raw_p, method="holm")
  stopifnot(all(is.finite(raw_p)), all(raw_p >= 0 & raw_p <= 1))
  stopifnot(max(abs(raw_p-current$primary_p)) < 1e-12)
  stopifnot(max(abs(recomputed-current$within_registered_family_Holm)) < 1e-12)
  stopifnot(max(abs(recomputed-original[[s$adjusted]][index])) < 1e-12)
  if ("estimate" %in% names(original)) {
    for (name in c("estimate","se","lower","upper"))
      stopifnot(max(abs(original[[name]][index]-current[[name]])) < 1e-12)
  }
  cat("[coverage] ",kind," ",nrow(current)," 家族来源/校正一致\n",sep=""); flush.console()
  list(kind=kind, families=nrow(current), members=sum(current$MI_members),
       max_Holm_error=max(abs(recomputed-current$within_registered_family_Holm)))
})
cfps <- read_table("results/CFPS_CURRENT_H4_COVERAGE.csv")
cfps_complete <- sum(cfps$family == "H4.1" & grepl("^TEN_ESTIMATES",cfps$formal_MI))
paths <- read_table("results/ORIGINAL_FIVE_PATH_COVERAGE.csv")
stopifnot(nrow(families)==sum(vapply(checks,function(x)x$families,numeric(1))))
stopifnot(sum(families$MI_members)==sum(vapply(checks,function(x)x$members,numeric(1))))
stopifnot(!any(families$original_CFPS_target_complete), all(families$within_registered_family_Holm >= .05))
stopifnot(length(unique(paths$original_target))==5, nrow(paths)==length(unique(paths$indicator))*5)
map <- jsonlite::fromJSON(file.path(root,"audit/SOURCE_MAP.json"))
for (i in seq_len(nrow(map))) {
  if (!is.na(map$copy_is_extract[i]) && map$copy_is_extract[i]) next
  path <- file.path(root,map$copy[i])
  stopifnot(identical(digest::digest(file=path,algo="sha256",serialize=FALSE),map$sha256[i]))
}
receipt <- list(status="PASS_AGGREGATE_SOURCE_AND_MULTIPLICITY_READBACK", at=format(Sys.time(),tz="UTC",usetz=TRUE),
  pid=Sys.getpid(), R=R.version.string, checks=checks, family_rows=nrow(families),
  MI_member_entries=sum(families$MI_members), cfps_H41_completed=cfps_complete,
  original_path_cells=nrow(paths), original_four_complete=FALSE, full_H4_complete=FALSE,
  new_Mplus_calls=0L, new_MI=0L, new_NLM=0L,
  limit="Aggregate source readback only; reuse prior raw-parameter verification; no new fit and no global 31-test multiplicity claim.")
out <- file.path(root,"audit/R_AGGREGATE_READBACK.json")
stopifnot(!file.exists(out))
jsonlite::write_json(receipt,out,auto_unbox=TRUE,pretty=TRUE,na="null")
writeLines(capture.output(sessionInfo()),file.path(root,"audit/R_SESSION_INFO.txt"),useBytes=TRUE)
cat("COVERAGE_READBACK_PASS families=",receipt$family_rows," MI_member_entries=",receipt$MI_member_entries,"\n",sep="")
