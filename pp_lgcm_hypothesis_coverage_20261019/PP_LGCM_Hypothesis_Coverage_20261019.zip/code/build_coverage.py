"""只读原稿与最新聚合结果，建立研究目标覆盖表；不拟合、不修改历史资产。"""
from pathlib import Path
from datetime import datetime, timezone
import csv, hashlib, io, json, math, re, shutil, zipfile
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT.parent
for name in ['audit','sources','results','reports','contracts']:(ROOT/name).mkdir(parents=True,exist_ok=True)
MANUSCRIPT=Path('C:/Users/LZHS/OneDrive/20251026 PP-LGCM整合/20260214 附件/20260214 代际亲近度对老年心理健康的影响——基于家内差异的视角.docx')
EXPECTED_DOC='0fffe9e24b480bd35c700399c3a4961589f71a304637d7fca5c76eb6ce97d870'
sha=lambda b:hashlib.sha256(b).hexdigest()
source_records=[]

def save_json(path,obj):
    with path.open('x',encoding='utf-8') as f:json.dump(obj,f,ensure_ascii=False,indent=2)

def source(batch,relative,alias):
    p=BASE/batch/relative;data=p.read_bytes()
    target=ROOT/'sources'/alias
    with target.open('xb') as f:f.write(data)
    source_records.append(dict(batch=batch,source=relative,copy='sources/'+alias,sha256=sha(data),bytes=len(data)))
    return data

def csv_source(batch,relative,alias):
    return list(csv.DictReader(io.StringIO(source(batch,relative,alias).decode('utf-8-sig'))))

def json_source(batch,relative,alias):
    return json.loads(source(batch,relative,alias).decode('utf-8-sig'))

def write_csv(name,rows):
    assert rows
    fields=list(dict.fromkeys(k for row in rows for k in row))
    with (ROOT/'results'/name).open('x',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)

raw=MANUSCRIPT.read_bytes();assert sha(raw)==EXPECTED_DOC
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
xml=ET.fromstring(zipfile.ZipFile(io.BytesIO(raw)).read('word/document.xml'))
paragraphs=xml.find('w:body',ns).findall('w:p',ns)
selected=[]
for index in [26,29,30,32,33,34,35,36,39,40,43,44,45,46,80,114,115,117,119]:
    text=''.join(t.text or '' for t in paragraphs[index].findall('.//w:t',ns))
    selected.append(dict(paragraph_index_zero_based=index,text=text))
assert '5条调节路径' in next(x['text'] for x in selected if x['paragraph_index_zero_based']==114)
save_json(ROOT/'sources'/'ORIGINAL_HYPOTHESES.json',dict(document_sha256=EXPECTED_DOC,paragraph_numbering='Direct body w:p, zero based; not page number',paragraphs=selected))
source_records.append(dict(batch='20260214_manuscript',source=MANUSCRIPT.name,copy='sources/ORIGINAL_HYPOTHESES.json',sha256=EXPECTED_DOC,bytes=len(raw),copy_is_extract=True))

M='charls_corrected_mean_resources_20261018'
Z='charls_corrected_baseline_income_models_20261018'
D='charls_corrected_dynamic_mi_models_20261018'
H='charls_sd_urban_family_recovery_20261019'
F='h41_remaining_charls_resources_20261015'
L='charls_corrected_latent_feasibility_20261018'
C='charls_latent_integration_calibration_20261018'
mean=csv_source(M,'results/CORRECTED_THREE_RESOURCE_JOINT_D1.csv','CHARLS_MEAN_RESOURCES.csv')
h41=csv_source(Z,'results/CORRECTED_TWELVE_RESOURCE_JOINT_D1.csv','CHARLS_H41_Z_RESOURCES.csv')
dynamic=csv_source(D,'results/FOUR_MODERATIONS.csv','CHARLS_OBSERVED_Z_DYNAMIC.csv')
dynamic_scope=csv_source(D,'results/FAMILY_OVERVIEW.csv','CHARLS_DYNAMIC_FAMILY_OVERVIEW.csv')
h42=csv_source(H,'results/TWELVE_H42_RESOURCES.csv','CHARLS_H42_RESOURCES.csv')
cfps=csv_source(F,'results/H4_REGISTER_UPDATED.csv','CFPS_H4_REGISTER.csv')
latent=json_source(L,'results/BRANCH_STATUS.json','CHARLS_LATENT_BRANCH_STATUS.json')
calibration=json_source(C,'results/CALIBRATION_STATUS.json','CHARLS_LATENT_CALIBRATION_STATUS.json')
json_source(M,'audit/JOINT_SCOPE_RECEIPT.json','MEAN_SCOPE_RECEIPT.json')
json_source(Z,'audit/INDEPENDENT_TWELVE_RESOURCE_CHECK.json','H41_PRIOR_INDEPENDENT_CHECK.json')
json_source(D,'audit/INDEPENDENT_VERIFICATION.json','DYNAMIC_PRIOR_INDEPENDENT_CHECK.json')
json_source(H,'audit/TWELVE_RESOURCES_INDEPENDENT.json','H42_PRIOR_INDEPENDENT_CHECK.json')
source(C,'contracts/RUN_CONTRACT.json','LATENT_CALIBRATION_CONTRACT.json')
source(M,'reports/REPORT.md','MEAN_PRIOR_REPORT.md')
source(Z,'reports/REPORT.md','H41_PRIOR_REPORT.md')
source(D,'reports/REPORT.md','DYNAMIC_PRIOR_REPORT.md')
source(H,'reports/REPORT_V2.md','H42_PRIOR_REPORT.md')

commits={M:'0e0508e378dbdd92162f2203805f3a8076e04fac',Z:'5f426bd6b8532c1b79dcdcec2c841a07f369920b',
 D:'f6e7c9448d5f0fd14e4b8e7b33bc8c07ebcfcca0',H:'d14700475982290e6b668475a9a5090ec09e50e2',
 F:'437518be9ba2c55313ad91ff2fd079eec73df0d1',L:'a21d24f03ef09d82d79f542e69f6ee82cdb4da65',
 C:'217baf71ab6079ce1382101d038e1a932c7975f2'}
url=lambda batch:'https://github.com/lzhs1995/PP-lcgm-paper/tree/'+commits[batch]+'/'+batch
families=[]
def add(kind,family,batch,n,m,p,adjusted,scope,**extra):
    families.append(dict(dataset='CHARLS',kind=kind,family=family,N=n,MI_members=m,
        status='COMPLETE_CONDITIONAL_WORKING_MI',primary_p=p,within_registered_family_Holm=adjusted,
        estimand=scope,source_url=url(batch),original_CFPS_target_complete=False,**extra))

assert len(mean)==3 and len(h41)==12 and len(dynamic)==4 and len(h42)==12
for row in mean:
    g=row['group'];add('H41_MEAN',g,M,2983,40 if g=='INCOME' else 20,float(row['p']),float(row['holm_planned3']),
        'Resource difference in IX->IY, IX->SY, SX->SY; joint D1(3)')
for row in h41:
    add('H41_BASELINE_Z',row['family'],Z,int(row['N']),int(row['members']),float(row['p']),float(row['holm_p_planned12']),
        'Resource difference in observed Z0->IY and Z0->SY; joint D1(2)')
scopes={r['scope']:r for r in dynamic_scope}
for row in dynamic:
    s=scopes[row['scope']];add('OBSERVED_Z_DYNAMIC',row['scope'],D,int(s['N']),int(s['members']),float(row['p']),float(row['holm_p_fixed4']),
        'SX * observed baseline Z0 -> SY',estimate=float(row['estimate']),se=float(row['se']),lower=float(row['lower']),upper=float(row['upper']))
for row in h42:
    add('H42_OBSERVED_Z',row['family'],H,int(row['N']),int(row['members']),float(row['p']),float(row['Holm_12']),
        'Resource difference in SX * observed baseline Z0 -> SY',estimate=float(row['estimate']),se=float(row['se']),lower=float(row['lower']),upper=float(row['upper']))
assert len(families)==31 and sum(x['MI_members'] for x in families)==800
assert all(x['within_registered_family_Holm']>=.05 for x in families)
write_csv('CHARLS_CURRENT_31_FAMILIES.csv',families)
write_csv('CFPS_CURRENT_H4_COVERAGE.csv',cfps)
cfps_h41=[x for x in cfps if x['family']=='H4.1']
assert len(cfps_h41)==12 and sum(x['formal_MI'].startswith('TEN_ESTIMATES') for x in cfps_h41)==3
assert len(latent)==4 and all(not x['complete_MI'] for x in latent.values())
assert calibration['status']=='Q15_A_TIMEOUT'

# 按原文五条路径建覆盖表；不是把新敏感性路径伪装成原稿同量尺复现。
paths=[('M1a','IX*IZ -> IY'),('M1b','IX*IZ -> SY'),('M2','IX*SZ -> SY'),('M3','SX*IZ -> SY'),('M4','SX*SZ -> SY')]
coverage=[]
for z in ['sd','gender','oldest','son']:
    for model,term in paths:
        coverage.append(dict(indicator=z,original_paragraph=114,original_submodel=model,original_target=term,
            corrected_CHARLS_full_latent_MI='NOT_COMPLETED',
            observed_baseline_alternative='COMPLETE_20_MEMBER_WORKING_MI_DIFFERENT_ESTIMAND' if model=='M3' else 'NOT_ESTIMATED_IN_CURRENT_FOUR_FAMILY_ROUTE',
            observed_H42_resource_alternative='COMPLETE_3_RESOURCE_FAMILIES_DIFFERENT_ESTIMAND' if model=='M3' else 'NOT_ESTIMATED_IN_CURRENT_H42_ROUTE',
            full_original_CFPS_inference='NOT_ESTABLISHED_BY_CHARLS',
            latent_pilot_status=latent[z]['status'] if model=='M3' else 'NO_NEW_PILOT_CLAIM',
            note='Original source used factor-score moderator approximations; latent reformulation and observed baseline sensitivity are distinct. This is an estimand map, not a count of every historical fit.'))
write_csv('ORIGINAL_FIVE_PATH_COVERAGE.csv',coverage)

mapping=[
 ('H2.1',35,'家内差异调节均值关联','四项SX×Z0工作MI；原潜在IZ家族未形成','CHARLS邻近构念、观测基期替代，不替代原CFPS完整推断'),
 ('H2.2',36,'均值调节家内差异关联','没有为反向轨迹路线取得完整当前MI家族','同一个乘积可重述条件关系，但不能把SX×Z0改称IX×SZ或SX×SZ'),
 ('H3.1',39,'女性直接关联更强','本批资源家族不检验女性组差','本批范围记录，未自动开启性别新队列'),
 ('H3.2',40,'女性调节更强','本批教育/城乡/收入三重交互不检验女性三重交互','未检验不等于不显著'),
 ('H4.1a',43,'高资源关联较弱','CFPS基期Z家族3/12；CHARLS基期Z12/12、均值3/3工作家族','当前组差检验不补齐家内差异变化轨迹关联'),
 ('H4.1b',44,'高资源关联较强','与H4.1a共享直接组差检验；当前CHARLS固定校正后无明确证据','竞争假设不能按组内星号或单一交互符号裁定'),
 ('H4.2a',45,'高资源动态调节较弱','CHARLS SX×观测Z0×资源12/12工作家族，完整潜变量路线未完成','低阶项、组差、测量和插补边界保留'),
 ('H4.2b',46,'高资源动态调节较强','同12项组差均区间跨零，Holm均1；原CFPS未形成完整推断','不支持当前证据下的确认主张，不是证明效应不存在')]
write_csv('HYPOTHESIS_TO_CURRENT_EVIDENCE.csv',[dict(hypothesis=x[0],original_paragraph=x[1],question=x[2],current_evidence=x[3],limit=x[4]) for x in mapping])

save_json(ROOT/'audit'/'SOURCE_MAP.json',source_records)
summary=dict(status='CURRENT_SCOPE_RECONCILED',at=datetime.now(timezone.utc).isoformat(),original_document_sha256=EXPECTED_DOC,
    charls_complete_working_families=len(families),charls_MI_member_fits=sum(x['MI_members'] for x in families),
    charls_families_by_kind={k:sum(x['kind']==k for x in families) for k in sorted({x['kind'] for x in families})},
    charls_primary_Holm_below_005=sum(x['within_registered_family_Holm']<.05 for x in families),
    cfps_baseline_h41_complete=3,cfps_baseline_h41_registered=12,cfps_baseline_h42_complete=0,
    charls_latent_moderation_complete=0,original_four_complete=False,full_H4_complete=False,
    original_path_cells=len(coverage),new_Mplus_calls=0,new_MI=0,new_NLM=0,
    caveat='800 is a sum of model-family imputation members, not participants or independent samples; separate planned multiplicity families, not global 31-test FWER.')
save_json(ROOT/'audit'/'COVERAGE_SUMMARY.json',summary)
assert sha(MANUSCRIPT.read_bytes())==EXPECTED_DOC
print(json.dumps(summary,ensure_ascii=False),flush=True)
