"""便携标准库回读；检查覆盖表与保存的聚合结果，不声称重新拟合模型。"""
from pathlib import Path
import csv,hashlib,json,math,sys
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def table(path):
    with (root/path).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def close(a,b):assert math.isclose(float(a),float(b),rel_tol=1e-12,abs_tol=1e-12),(a,b)
def holm(values):
    order=sorted(range(len(values)),key=values.__getitem__);out=[0.0]*len(values);previous=0.0
    for rank,i in enumerate(order):previous=max(previous,min(1,(len(values)-rank)*values[i]));out[i]=previous
    return out
manifest=root/'PACKAGE_FILE_MANIFEST.json'
if manifest.exists():
    files=read(manifest)['files']
    for entry in files:
        p=root/entry['path'];assert p.is_file() and p.stat().st_size==entry['bytes']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
    assert {str(p.relative_to(root)).replace('\\','/') for p in root.rglob('*') if p.is_file()}=={x['path'] for x in files}|{'PACKAGE_FILE_MANIFEST.json'}
families=table('results/CHARLS_CURRENT_31_FAMILIES.csv')
specs=[('H41_MEAN','CHARLS_MEAN_RESOURCES.csv','group','holm_planned3'),
 ('H41_BASELINE_Z','CHARLS_H41_Z_RESOURCES.csv','family','holm_p_planned12'),
 ('OBSERVED_Z_DYNAMIC','CHARLS_OBSERVED_Z_DYNAMIC.csv','scope','holm_p_fixed4'),
 ('H42_OBSERVED_Z','CHARLS_H42_RESOURCES.csv','family','Holm_12')]
checks=[]
for kind,filename,key,adjusted in specs:
    source=table('sources/'+filename);lookup={x[key]:x for x in source};current=[x for x in families if x['kind']==kind]
    assert len(lookup)==len(current) and {x['family'] for x in current}==set(lookup)
    ps=[float(lookup[x['family']]['p']) for x in current];recomputed=holm(ps)
    for row,p,a in zip(current,ps,recomputed):
        original=lookup[row['family']];close(row['primary_p'],p);close(row['within_registered_family_Holm'],a);close(original[adjusted],a)
        if 'estimate' in original:
            for field in ['estimate','se','lower','upper']:close(row[field],original[field])
    checks.append(dict(kind=kind,families=len(current),members=sum(int(x['MI_members']) for x in current)))
cfps=table('results/CFPS_CURRENT_H4_COVERAGE.csv');paths=table('results/ORIGINAL_FIVE_PATH_COVERAGE.csv')
assert sum(x['family']=='H4.1' and x['formal_MI'].startswith('TEN_ESTIMATES') for x in cfps)==3
assert all(x['original_CFPS_target_complete']=='False' for x in families)
assert len(families)==31 and sum(int(x['MI_members']) for x in families)==800
assert len(paths)==20 and len({x['original_target'] for x in paths})==5
for entry in read(root/'audit/SOURCE_MAP.json'):
    if entry.get('copy_is_extract'):continue
    assert hashlib.sha256((root/entry['copy']).read_bytes()).hexdigest()==entry['sha256']
print(json.dumps(dict(status='PASS_AGGREGATE_COVERAGE_REPLAY',checks=checks,
    original_four_complete=False,full_H4_complete=False,new_Mplus_calls=0,new_MI=0,
    independent_raw_model_recalculation_this_packet=False),ensure_ascii=False))
