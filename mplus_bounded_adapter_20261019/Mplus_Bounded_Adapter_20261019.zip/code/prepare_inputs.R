# 400条独立合成记录；不读取任何CFPS或CHARLS文件。
local({
 root <- 'C:/Users/RESEARCH_USER/pp_lgcm_review/mplus_bounded_adapter_20261019'
 stopifnot(!file.exists(file.path(root,'models/normal/synthetic.dat')))
 set.seed(104729);x<-rnorm(400);y<-.4+1.5*x+rnorm(400)
 old<-options(digits=17);on.exit(options(old),add=TRUE)
 d<-data.frame(x=x,y=y)
 write.table(d,file.path(root,'models/normal/synthetic.dat'),row.names=FALSE,col.names=FALSE,quote=FALSE)
 inp<-c('TITLE: Bounded adapter synthetic normal model;', 'DATA: FILE = synthetic.dat;',
 'VARIABLE: NAMES = x y;','ANALYSIS: ESTIMATOR = ML; PROCESSORS = 1;',
 'MODEL: y ON x;','OUTPUT: TECH1 TECH3;','SAVEDATA: RESULTS = parameters.dat;')
 writeLines(inp,file.path(root,'models/normal/model.inp'))
 writeLines('TITLE: FAKE ENGINE TIMEOUT TEST ONLY; MODEL: y ON x;',file.path(root,'models/expected_timeout/model.inp'))
 # 独立闭式ML参考值：Mplus默认条件于外生x，误差方差分母n。
 X<-cbind(Intercept=1,x=x);b<-drop(solve(crossprod(X),crossprod(X,y)));e<-drop(y-X%*%b);n<-length(y)
 v<-sum(e^2)/n;V<-v*solve(crossprod(X));se<-sqrt(diag(V))
 ref<-data.frame(parameter=c('Y.ON.X','Intercepts.Y','Residual.Variances.Y'),
 estimate=c(b[2],b[1],v),se=c(se[2],se[1],sqrt(2/n)*v))
 write.csv(ref,file.path(root,'audit/CLOSED_FORM_REFERENCE.csv'),row.names=FALSE)
 write.csv(V,file.path(root,'audit/CLOSED_FORM_COEFFICIENT_VCOV.csv'))
 saveRDS(list(n=n,beta=b,sigma2=v,vcov=V),file.path(root,'audit/CLOSED_FORM_REFERENCE.rds'))
 cat('SYNTHETIC_ADAPTER_INPUTS_READY n=',n,'\n',sep='')
})
