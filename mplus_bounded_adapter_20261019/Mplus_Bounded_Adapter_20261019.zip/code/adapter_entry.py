"""由runModels的独立cmd调用，直接创建并保留实际引擎的进程句柄。"""
from pathlib import Path
import ctypes,datetime,hashlib,json,math,os,sys,time
from bounded_child import run_child
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def publish(p,obj):
 tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(obj,indent=2),encoding='utf-8');os.replace(tmp,p)
class Memory(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(k,ctypes.c_ulonglong) for k in ['total','avail','commit_limit','commit_avail','virtual','virtual_avail','extended']]
def resource():
 m=Memory();m.length=ctypes.sizeof(m)
 if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):raise OSError('Windows memory unavailable')
 return dict(at=utc(),available_gib=m.avail/2**30,commit_available_gib=m.commit_avail/2**30)
def main():
 started=time.monotonic();jobpath=Path(sys.argv[1]).resolve();job=json.loads(jobpath.read_text());d=jobpath.parent
 assert d.parent==ROOT/'models' and Path(sys.argv[2]).name=='model.inp'
 assert not (d/'LAUNCH_RECEIPT.json').exists() and not (d/'execution').exists()
 assert sha(d/'model.inp')==job['input_sha256']
 c=json.loads((ROOT/'contracts/RUN_CONTRACT.json').read_text())
 if job['kind']=='licensed_mplus':
  assert d.name in ('normal','normal_after_resource_hold') and sha(d/'synthetic.dat')==job['data_sha256']
  assert sha(c['executable'])==c['executable_sha256']
  command=[c['executable'],'model.inp'];cap=c['normal_engine_seconds']
 elif job['kind']=='explicit_fake_timeout':
  assert d.name=='expected_timeout';command=[sys.executable,'-u',str(ROOT/'code/fake_engine.py'),'model.inp'];cap=c['fake_timeout_seconds']
 else:raise ValueError('Unknown engine kind')
 # 新执行只能领取一次；不把启动失败静默重置成未运行。
 with (d/'RESERVATION.json').open('x') as f:json.dump(dict(at=utc(),kind=job['kind'],command=command,cap=cap),f)
 pf=resource();waited=time.monotonic()
 while pf['available_gib']<c['minimum_available_gib'] or pf['commit_available_gib']<c['minimum_commit_available_gib']:
  if time.monotonic()-waited>=c['resource_wait_seconds']:
   publish(d/'LAUNCH_RECEIPT.json',dict(status='NOT_RUN_RESOURCE_HOLD',resource=pf,at=utc(),actual_engine_calls=0));return 75
  time.sleep(2);pf=resource()
 publish(d/'RESOURCE_ADMITTED.json',pf)
 awake=bool(ctypes.windll.kernel32.SetThreadExecutionState(0x80000001))
 try:
  preflight=time.monotonic()-started
  result=run_child(command,d/'execution',cap,working_directory=d)
  result.update(at=utc(),kind=job['kind'],adapter_preflight_seconds=preflight,adapter_total_seconds=time.monotonic()-started,
    input_sha256=job['input_sha256'],actual_engine_calls=1,stdout_sha256=sha(d/'execution/stdout.log'),stderr_sha256=sha(d/'execution/stderr.log'))
  publish(d/'LAUNCH_RECEIPT.json',result)
  return 124 if result['state']=='TIMEOUT' else result['exitcode']
 finally:
  if awake:ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
if __name__=='__main__':raise SystemExit(main())
