"""明确标记的集成负例；不是Mplus，也不产生.out。"""
import time
print('SYNTHETIC_FAKE_ENGINE_BEFORE_TIMEOUT_NOT_MPLUS',flush=True)
time.sleep(60)
