# 只用原生ClaudeR后台worker一次加载；所有输入和输出均在隔离根。
local({
 root<-'C:/Users/RESEARCH_USER/pp_lgcm_review/mplus_bounded_adapter_20261019'
 library(jsonlite)
 say<-function(stage,message){
   if(exists('clauder_progress',mode='function',inherits=TRUE))clauder_progress(stage,message)
   cat(format(Sys.time(),tz='UTC'),stage,message,'\n');flush.console()
   write_json(list(stage=stage,message=message,at=format(Sys.time(),tz='UTC')),file.path(root,'runtime/PROGRESS.json'),auto_unbox=TRUE,pretty=TRUE)
 }
 start<-Sys.time();say('LOADING','Load MplusAutomation once; no engine yet')
 .libPaths(c('C:/Users/RESEARCH_USER/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
 library(MplusAutomation)
 write_json(list(version=as.character(packageVersion('MplusAutomation')),library=find.package('MplusAutomation'),
   loading_seconds=as.numeric(difftime(Sys.time(),start,units='secs')),pid=Sys.getpid()),file.path(root,'audit/EXECUTION_RUNTIME_RECOVERY.json'),auto_unbox=TRUE,pretty=TRUE)
 run_case<-function(case){
   d<-file.path(root,'models',case);stopifnot(!file.exists(file.path(d,'LAUNCH_RECEIPT.json')))
   say('RUNMODELS',case);started<-Sys.time();warn<-character();err<-NULL
   withCallingHandlers(tryCatch({runModels(target=file.path(d,'model.inp'),recursive=FALSE,showOutput=TRUE,
     replaceOutfile='never',Mplus_command=file.path(d,'launch.cmd'),killOnFail=FALSE,
     logFile=file.path(d,'MplusAutomation.log'))},error=function(e){err<<-conditionMessage(e)}),
     warning=function(w){warn<<-c(warn,conditionMessage(w));invokeRestart('muffleWarning')})
   write_json(list(wrapper_error=err,wrapper_warnings=warn,call_seconds=as.numeric(difftime(Sys.time(),started,units='secs'))),file.path(d,'R_WRAPPER_RETURN.json'),auto_unbox=TRUE,pretty=TRUE)
   stopifnot(file.exists(file.path(d,'LAUNCH_RECEIPT.json')))
   fromJSON(file.path(d,'LAUNCH_RECEIPT.json'))
 }
 normal<-run_case('normal_after_resource_hold')
 if(identical(normal$status,'NOT_RUN_RESOURCE_HOLD'))stop('NOT_RUN_RESOURCE_HOLD: engine_calls=0; no automatic retry')
 stopifnot(normal$state=='EXITED',normal$exitcode==0L,normal$process_exited)
 d<-file.path(root,'models/normal_after_resource_hold');out<-readLines(file.path(d,'model.out'),warn=FALSE)
 stopifnot(any(grepl('THE MODEL ESTIMATION TERMINATED NORMALLY',out,fixed=TRUE)),!any(grepl('*** ERROR',out,fixed=TRUE)))
 say('VERIFY_NORMAL','Read actual output and compare every fitted coefficient/SE with closed-form ML')
 model<-readModels(file.path(d,'model.out'),what=c('parameters','summaries','tech1','tech3'),quiet=TRUE)
 saveRDS(model,file.path(root,'audit/READMODEL.rds'))
 p<-model$parameters$unstandardized
 write.csv(p,file.path(root,'audit/MPLUS_PARAMETERS.csv'),row.names=FALSE)
 expected<-read.csv(file.path(root,'audit/CLOSED_FORM_REFERENCE.csv'))
 keys<-paste(p$paramHeader,p$param,sep='.')
 idx<-match(expected$parameter,keys);stopifnot(!anyNA(idx))
 comparison<-data.frame(parameter=expected$parameter,expected_estimate=expected$estimate,actual_estimate=p$est[idx],
   expected_se=expected$se,actual_se=p$se[idx])
 comparison$estimate_difference<-comparison$actual_estimate-comparison$expected_estimate
 comparison$se_difference<-comparison$actual_se-comparison$expected_se
 write.csv(comparison,file.path(root,'audit/CLOSED_FORM_COMPARISON.csv'),row.names=FALSE)
 stopifnot(all(abs(comparison$estimate_difference)<=.0005001),all(abs(comparison$se_difference)<=.0005001))
 say('NORMAL_ACCEPTED','All three free estimates and SE match to printed precision')
 failed<-run_case('expected_timeout')
 stopifnot(failed$kind=='explicit_fake_timeout',failed$state=='TIMEOUT',failed$process_exited,
   file.exists(file.path(root,'models/expected_timeout/execution/stdout.log')),
   !file.exists(file.path(root,'models/expected_timeout/model.out')))
 txt<-readLines(file.path(root,'models/expected_timeout/execution/stdout.log'),warn=FALSE)
 stopifnot(any(grepl('SYNTHETIC_FAKE_ENGINE_BEFORE_TIMEOUT_NOT_MPLUS',txt,fixed=TRUE)))
 receipt<-list(status='PASS_BOUNDED_ADAPTER_INTEGRATION',licensed_Mplus_calls=1L,fake_engine_calls=1L,
   normal_model_adopted=TRUE,fake_timeout_adopted=FALSE,parameters_compared=3L,se_compared=3L,
   numerical_tolerance='Half of printed0.001 plus0.0000001; reference uses ML variance denominator n',
   real_data_calls=0L,new_MI=0L,production_queue_integrated=FALSE,
   runtime=normal,fake_runtime=failed,original_four_complete=FALSE,full_H4_complete=FALSE)
 write_json(receipt,file.path(root,'audit/VALIDATION.json'),auto_unbox=TRUE,pretty=TRUE)
 say('INTEGRATION_TERMINAL','Normal model validated; fake timeout rejected despite wrapper return')
 cat('BOUNDED_ADAPTER_INTEGRATION_DONE\n')
})
