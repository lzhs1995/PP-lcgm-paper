"""只读取公开合成包；独立闭式核对，不调用R或Mplus。"""
from pathlib import Path
import csv,hashlib,json,math,sys
r=Path(sys.argv[1]);manifest=json.loads((r/'MANIFEST.json').read_text(encoding='utf-8'))
for item in manifest['files']:
 b=(r/item['path']).read_bytes();assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
data=[list(map(float,l.split())) for l in (r/'models/normal_after_resource_hold/synthetic.dat').read_text().splitlines()]
n=len(data);assert n==400
x=[v[0] for v in data];y=[v[1] for v in data];xm=sum(x)/n;ym=sum(y)/n
sxx=sum((v-xm)**2 for v in x);b=sum((a-xm)*(b-ym) for a,b in zip(x,y))/sxx;a=ym-b*xm
v=sum((yi-a-b*xi)**2 for xi,yi in zip(x,y))/n
expected={'Y.ON.X':(b,math.sqrt(v/sxx)),'Intercepts.Y':(a,math.sqrt(v*(1/n+xm*xm/sxx))),'Residual.Variances.Y':(v,math.sqrt(2/n)*v)}
rows=list(csv.DictReader((r/'audit/CLOSED_FORM_COMPARISON.csv').open()))
assert len(rows)==3
for row in rows:
 est,se=expected[row['parameter']]
 assert abs(est-float(row['expected_estimate']))<1e-12 and abs(se-float(row['expected_se']))<1e-12
 assert abs(est-float(row['actual_estimate']))<=.0005001 and abs(se-float(row['actual_se']))<=.0005001
for case,state in [('normal_after_resource_hold','EXITED'),('expected_timeout','TIMEOUT')]:
 d=r/'models'/case;q=json.loads((d/'LAUNCH_RECEIPT.json').read_text())
 assert q['state']==state and q['process_exited']
 for stream in ['stdout','stderr']:assert hashlib.sha256((d/'execution'/f'{stream}.log').read_bytes()).hexdigest()==q[stream+'_sha256']
normal=r/'models/normal_after_resource_hold/model.out';text=normal.read_text()
assert 'THE MODEL ESTIMATION TERMINATED NORMALLY' in text and '*** ERROR' not in text
assert not (r/'models/expected_timeout/model.out').exists()
hold=json.loads((r/'models/normal/LAUNCH_RECEIPT.json').read_text());assert hold['actual_engine_calls']==0 and hold['status']=='NOT_RUN_RESOURCE_HOLD'
print(json.dumps(dict(status='PASS_PUBLIC_ADAPTER_REPLAY',payloads=len(manifest['files']),independent_estimates=3,independent_SE=3,real_Mplus_calls=1,fake_engine_calls=1,real_data_calls=0)))
