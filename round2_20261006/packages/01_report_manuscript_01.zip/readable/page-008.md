# PDF物理页 8

[PDF](../manuscript/PP_LGCM_review_v46_round2A_NOT_RELEASED.pdf#page=8)

```text
图3.1 样本筛选流程。箭头表示依次筛选或取交集；childnumb4 为原始程序中的操作化计数字段，定义见正文。Sample2—4 表示至少一期相应差异指标可得
                          的人数，模型样本量另按输出报告。

    Measures 测量

    Dependent variable
  抑郁是反映心理健康状态的核心指标。除了2010、2014 年采用了凯斯勒心理疾患量表（K6）外，CFPS 在其余年份均使用流调中心抑郁量表CES-D，其
中2012 年使用的是 20 个条目的全量表版本，2016 年同时包含20 题长版与8 题短版，2018—2022 年采用8 个条目的精简版。为支持跨轮次比较，CFPS 同时
```
