"""独立 pandas 读取原始 Stata 文件，复算构建名册及基期四项差异；不输出个人记录。"""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = Path('<LOCAL_USER_HOME>/Desktop/20230505 毕业论文/开题报告/开题报告/CHARLS')
paths = [RAW/'charls11_20_harmonized/data_2011/child.dta', RAW/'CHARLS2011/Data/family_information.dta', RAW/'CHARLS2011/Data/household_roster.dta']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before = {str(p):sha(p) for p in paths}
child = pd.read_stata(paths[0], convert_categoricals=False)
fam = pd.read_stata(paths[1], convert_categoricals=False)
hh = pd.read_stata(paths[2], convert_categoricals=False)
ref = pd.read_csv(ROOT/'private/COHORT_REFERENCE.csv', dtype={'pid':str})
rref = pd.read_csv(ROOT/'private/R_CONTRAST_REFERENCE.csv', dtype={'pid':str})
elig = pd.read_csv(ROOT/'private/ELIGIBILITY_REFERENCE.csv', dtype={'pid':str})
fi = fam.set_index('ID'); hi = hh.set_index('ID')
assert not child.duplicated(['ID','childID']).any()
rows=[]; source_diffs={k:0 for k in ['sex','birth','nonHH_residence']}
for row in child.itertuples(index=False):
    household = pd.notna(row.HHmemberID)
    ci = int(row.childID)
    ri = fi.loc[row.ID]
    if household:
        h = int(row.HHmemberID); hr = hi.loc[row.ID]
        sex, birth = float(row.a002),float(row.a003_1)
        rs, rb = float(hr[f'a002_{h}_']), float(hr[f'a003_1_{h}_'])
        meet=9.0
    else:
        sex,birth = float(row.cb049),float(row.cb051_1)
        rs,rb = float(ri.get(f'cb049_{ci}_',np.nan)),float(ri.get(f'cb051_1_{ci}_',np.nan))
        code=float(ri.get(f'cd003_{ci}_',np.nan)); meet=10.0-code if code in range(1,10) else np.nan
        if pd.isna(meet) and row.cb053==1: meet=9.0
        x=float(ri.get(f'cb053_{ci}_',np.nan)); y=float(row.cb053)
        source_diffs['nonHH_residence'] += not ((pd.isna(x) and pd.isna(y)) or x==y)
    for key,x,y in [('sex',sex,rs),('birth',birth,rb)]:
        source_diffs[key] += not ((pd.isna(x) and pd.isna(y)) or x==y)
    sex=sex if sex in (1,2) else np.nan
    birth=birth if 1800<=birth<=2011 else np.nan
    rows.append((str(row.householdID)+'0'+str(row.ID)[-2:], ci, sex,birth,meet))
assert not any(source_diffs.values()),source_diffs
d = pd.DataFrame(rows,columns=['pid','child','sex','birth','meet'])
d = d[d.pid.isin(ref.pid)]
records=[]
for pid,z in d.groupby('pid',sort=True):
    row={'pid':pid,'n_reported':len(z),'n_valid':int(z.meet.notna().sum())}
    for v in ('sd','gender','oldest','son'):
        status='DEFINED'; group=None
        if len(z)<2: status='STRUCTURAL_FEWER_THAN_TWO'
        elif v in ('gender','son') and z.sex.isna().any(): status='MISSING_CHILD_SEX'
        elif v=='gender' and z.sex.nunique()<2:status='STRUCTURAL_ONE_SEX_ONLY'
        elif v=='son' and not z.sex.eq(1).any():status='STRUCTURAL_NO_SON'
        elif v in ('oldest','son'):
            if z.birth.isna().any():status='MISSING_BIRTH_YEAR'
            else:
                candidate=z.sex.eq(1) if v=='son' else pd.Series(True,index=z.index)
                group=candidate & z.birth.eq(z.loc[candidate,'birth'].min())
                if group.sum()!=1:status='AMBIGUOUS_EARLIEST_BIRTH_YEAR'
        if status=='DEFINED' and z.meet.isna().any():status='MISSING_CHILD_CONTACT'
        value=np.nan
        if status=='DEFINED':
            if v=='sd':value=float(z.meet.astype('float64').std(ddof=1))
            else:
                if v=='gender':group=z.sex.eq(1)
                value=float(z.loc[group,'meet'].mean()-z.loc[~group,'meet'].mean())
        row[v+'_status']=status;row[v+'_absolute']=value;row[v+'_relative']=value/z.meet.mean()
    records.append(row)
actual=pd.DataFrame(records).set_index('pid').reindex(rref.pid)
expect=rref.set_index('pid')
assert actual.index.equals(expect.index)
checked=0;maxdiff=0.0
for col in expect:
    a,b=actual[col],expect[col]
    if col.endswith('_status'): assert (a==b).all(),col
    else:
        assert a.isna().equals(b.isna()),col
        delta=(a-b).abs().max();maxdiff=max(maxdiff,float(delta))
        assert np.allclose(a,b,equal_nan=True,rtol=0,atol=1e-12),col
    checked+=len(a)
flow=pd.read_csv(ROOT/'results/MODERATION_ENTRY_FLOW.csv').set_index('indicator')
e=elig.set_index('pid').reindex(actual.index)
for v in ('sd','gender','oldest','son'):
    defined=actual[v+'_status'].eq('DEFINED')
    assert int((defined&e.compatible&e.core_cc).sum())==int(flow.loc[v,'plus_original_core_complete'])
after={str(p):sha(p) for p in paths};assert before==after
out={'status':'PASS','reader':'pandas '+pd.__version__,'cohort_N':len(actual),'constructed_child_N':len(d),'checked_person_fields':checked,'max_numeric_abs_difference':maxdiff,'source_field_mismatches':source_diffs,'four_ready_sample_counts_verified':True,'raw_sources_unchanged':True,'scope':'Private raw-data re-read; no Mplus, MI or causal validity claim'}
(ROOT/'audit/INDEPENDENT_ROSTER_VERIFICATION.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
