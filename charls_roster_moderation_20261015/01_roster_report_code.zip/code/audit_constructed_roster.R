# 核验官方构建子女文件的 childID—HHmemberID 对照；按明确标识避免同住子女双计。
library(haven);library(dplyr);library(jsonlite);library(digest)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_roster_moderation_20261015'
OLD<-'<LOCAL_USER_HOME>/pp_lgcm_review/reopen_observed_charls_20261015'
CORE<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015'
RAW<-'<LOCAL_USER_HOME>/Desktop/20230505 毕业论文/开题报告/开题报告/CHARLS'
wj<-function(a,p)write_json(a,file.path(ROOT,p),auto_unbox=TRUE,pretty=TRUE,digits=16,na='null',null='null')
csv<-function(a,p)write.csv(a,file.path(ROOT,p),row.names=FALSE,na='')
progress<-function(stage,message){cat(stage,message,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(stage,message)}
src<-c(file.path(RAW,'charls11_20_harmonized/data_2011/child.dta'),file.path(RAW,'CHARLS2011/Data/family_information.dta'),file.path(RAW,'CHARLS2011/Data/household_roster.dta'),file.path(OLD,'private/charls_cohort.rds'),file.path(CORE,'private/charls_core_mi_inputs.rds'))
src<-c(src,'<LOCAL_USER_HOME>/Desktop/开题报告/0_data_clo/contact_2011_long.dta')
before<-vapply(src,function(p)digest(file=p,algo='sha256'),'')
progress('constructed_crosswalk','Read childID and explicit HHmemberID before interpreting missing fields')
c<-read_dta(src[1]);f<-read_dta(src[2]);h<-read_dta(src[3]);cohort<-readRDS(src[4]);core<-readRDS(src[5])
normalpid<-function(id,fid)paste0(as.character(fid),'0',substr(as.character(id),nchar(as.character(id))-1,nchar(as.character(id))))
stopifnot(all(nchar(c$ID)==11),!anyDuplicated(paste(c$ID,c$childID)),!anyDuplicated(f$ID),!anyDuplicated(h$ID))
num<-function(x)as.numeric(x)
getcell<-function(dat,row,col){ans<-rep(NA_real_,length(row));for(n in unique(col)){j<-which(col==n);if(n%in%names(dat))ans[j]<-num(dat[[n]])[row[j]]};ans}
fi<-match(c$ID,f$ID);hi<-match(c$ID,h$ID);stopifnot(!anyNA(fi),!anyNA(hi))
hh<-!is.na(c$HHmemberID);cs<-num(c$childID);hs<-num(c$HHmemberID)
d<-data.frame(pid=normalpid(c$ID,c$householdID),fid=paste0(c$householdID,'0'),child_slot=cs,hh_slot=hs,is_hh=hh,
 sex=ifelse(hh,num(c$a002),num(c$cb049)),birth=ifelse(hh,num(c$a003_1),num(c$cb051_1)),month=ifelse(hh,num(c$a003_2),num(c$cb051_2)),
 residence=num(c$cb053),meet_code=getcell(f,fi,paste0('cd003_',cs,'_')))
d$legacy_slot<-ifelse(hh,as.integer(paste0('11',hs)),cs)
d$sex[!d$sex%in%1:2]<-NA_real_;d$birth[is.na(d$birth)|d$birth<1800|d$birth>2011]<-NA_real_
d$meet<-ifelse(d$meet_code%in%1:9,10-d$meet_code,NA_real_)
d$meet[hh]<-9;d$meet[is.na(d$meet)&d$residence%in%1]<-9
# 交叉表不是用性别/出生年模糊匹配；源值差异全部记录。
rawsex<-ifelse(hh,getcell(h,hi,paste0('a002_',hs,'_')),getcell(f,fi,paste0('cb049_',cs,'_')))
rawbirth<-ifelse(hh,getcell(h,hi,paste0('a003_1_',hs,'_')),getcell(f,fi,paste0('cb051_1_',cs,'_')))
rawres<-getcell(f,fi,paste0('cb053_',cs,'_'));rawsex[!rawsex%in%1:2]<-NA_real_;rawbirth[is.na(rawbirth)|rawbirth<1800|rawbirth>2011]<-NA_real_
same<-function(a,b)sum((is.na(a)!=is.na(b))|(!is.na(a)&!is.na(b)&abs(a-b)>1e-10))
agree<-data.frame(field=c('sex','birth','nonHH_residence'),all_mismatch=c(same(d$sex,rawsex),same(d$birth,rawbirth),same(d$residence[!hh],rawres[!hh])))
csv(agree,'audit/CONSTRUCTED_RAW_FIELD_COMPARISON.csv')
stopifnot(all(agree$all_mismatch==0),!anyDuplicated(paste(d$pid,d$legacy_slot)))
base<-readRDS(file.path(ROOT,'private/BASELINE_REPORTED_CHILDREN.rds'))
bk<-paste(base$pid,base$slot);dk<-paste(d$pid,d$legacy_slot)
# 官方明确列出的子女可能全部问答缺失；不能要求它必然进入按非缺失问答识别的初始槽位集合。
wj(list(constructed_keys_absent_from_raw_nonmissing_union=sum(!dk%in%bk),constructed_cohort_keys_absent=sum(!dk%in%bk&d$pid%in%cohort$pid)), 'audit/CONSTRUCTED_KEY_COVERAGE.json')
extra<-base[!bk%in%dk,];j<-match(paste(extra$pid,extra$slot),paste(d$pid,d$child_slot));matched_hh<-!is.na(j)&d$is_hh[j]
extra$classification<-ifelse(matched_hh,'HOUSEHOLD_CHILD_ALREADY_LINKED','RAW_SLOT_NOT_IN_CONSTRUCTED_FILE')
ex<-as.data.frame(table(extra$classification));names(ex)<-c('reason','N');csv(ex,'audit/RAW_SLOT_DISPOSITION.csv')
saveRDS(list(data=d,excluded_raw_slots=extra,source_hashes=before),file.path(ROOT,'private/CONSTRUCTED_BASELINE_CHILDREN.rds'))
progress('baseline_contrasts','Recompute available-child values and all-listed-child contrasts')
sel<-d[d$pid%in%cohort$pid,];stopifnot(length(unique(sel$pid))==nrow(cohort))
gap<-function(v,g){if(anyNA(g)||!any(g)||all(g))return(NA_real_);mean(v[g])-mean(v[!g])}
rankgap<-function(v,b,s=NULL){if(anyNA(b)||(!is.null(s)&&anyNA(s)))return(NA_real_);eligible<-if(is.null(s))rep(TRUE,length(b))else s==1;if(!any(eligible))return(NA_real_);g<-eligible&b==min(b[eligible]);if(sum(g)!=1L)return(NA_real_);gap(v,g)}
measure<-function(z){v<-z$meet;data.frame(mean=if(length(v)>=2)mean(v)else NA_real_,sd=if(length(v)>=2)sd(v)else NA_real_,gender=gap(v,z$sex==1),oldest=rankgap(v,z$birth),son=rankgap(v,z$birth,z$sex))}
observed<-bind_rows(lapply(split(sel,sel$pid),function(z)cbind(pid=z$pid[1],n_reported=nrow(z),n_valid=sum(!is.na(z$meet)),measure(z[!is.na(z$meet),]))))
observed<-observed[match(cohort$pid,observed$pid),];stopifnot(identical(as.character(observed$pid),as.character(cohort$pid)))
cmp<-data.frame(variable=c('mean','sd','gender','oldest','son'),legacy_column=c('x1','sd1','gender1','oldest1','son1'))
cmp$unequal<-mapply(function(a,b)same(observed[[a]],cohort[[b]]),cmp$variable,cmp$legacy_column)
csv(cmp,'audit/CONSTRUCTED_AVAILABLE_COMPARISON.csv')
# 新名册不是旧样本的无损替代；旧暴露保留，明确核查共同键与差异范围。
legacy<-read_dta(src[6],col_select=all_of(c('pid','fid','ID_c2gc','cb049_','cb051_1_','cb053_','cd003_')))
lp<-normalpid(legacy$pid,legacy$fid);lk<-paste(lp,legacy$ID_c2gc);li<-match(lk,dk)
lm<-ifelse(legacy$cd003_%in%1:9,10-num(legacy$cd003_),NA_real_);lm[is.na(lm)&legacy$cb053_%in%1]<-9
lb<-num(legacy$cb051_1_);lb[is.na(lb)|lb<1800|lb>2011]<-NA_real_;ls<-num(legacy$cb049_);ls[!ls%in%1:2]<-NA_real_
common<-!is.na(li)
lc<-data.frame(field=c('contact','sex','birth'),common_key_mismatch=c(same(lm[common],d$meet[li[common]]),same(ls[common],d$sex[li[common]]),same(lb[common],d$birth[li[common]])))
csv(lc,'audit/LEGACY_COMMON_KEY_COMPARISON.csv');stopifnot(all(lc$common_key_mismatch==0))
bad_parent<-unique(lp[is.na(li)&lp%in%cohort$pid]);compatible<-!cohort$pid%in%bad_parent
wj(list(legacy_rows_not_in_constructed=sum(is.na(li)),cohort_legacy_rows_not_in_constructed=sum(is.na(li)&lp%in%cohort$pid),cohort_affected_parents=length(bad_parent),compatible_parent_N=sum(compatible),common_key_fields_unchanged=TRUE), 'audit/LEGACY_KEY_DISPOSITION.json')
saveRDS(list(legacy_unmatched=legacy[is.na(li),],affected_parents=bad_parent),file.path(ROOT,'private/LEGACY_CONSTRUCTED_DISCREPANCIES.rds'))
status<-function(z,type){
 if(nrow(z)<2)return('STRUCTURAL_FEWER_THAN_TWO')
 if(type%in%c('gender','son')){
  if(anyNA(z$sex))return('MISSING_CHILD_SEX')
  if(type=='gender'&&length(unique(z$sex))<2)return('STRUCTURAL_ONE_SEX_ONLY')
  if(type=='son'&&!any(z$sex==1))return('STRUCTURAL_NO_SON')
 }
 if(type%in%c('oldest','son')){
  if(anyNA(z$birth))return('MISSING_BIRTH_YEAR')
  eligible<-if(type=='son')z$sex==1 else rep(TRUE,nrow(z))
  if(sum(eligible&z$birth==min(z$birth[eligible]))!=1)return('AMBIGUOUS_EARLIEST_BIRTH_YEAR')
 }
 if(anyNA(z$meet))return('MISSING_CHILD_CONTACT')
 'DEFINED'
}
strict<-bind_rows(lapply(split(sel,sel$pid),function(z){a<-measure(z);ans<-data.frame(pid=z$pid[1],n_reported=nrow(z),n_valid=sum(!is.na(z$meet)))
 for(v in c('sd','gender','oldest','son')){st<-status(z,v);ans[[paste0(v,'_status')]]<-st;ans[[paste0(v,'_absolute')]]<-if(st=='DEFINED')a[[v]] else NA_real_;ans[[paste0(v,'_relative')]]<-ans[[paste0(v,'_absolute')]]/a$mean};ans}))
strict<-strict[match(cohort$pid,strict$pid),];stopifnot(identical(as.character(core$raw$pid),as.character(cohort$pid)))
missingness<-bind_rows(lapply(c('sd','gender','oldest','son'),function(v){t<-as.data.frame(table(strict[[paste0(v,'_status')]]),stringsAsFactors=FALSE);names(t)<-c('status','N');cbind(indicator=v,t)}))
csv(missingness,'results/CONSTRUCTED_CONTRAST_MISSINGNESS.csv')
corecc<-!is.na(core$data$adl)&!is.na(core$raw$female)
readiness<-bind_rows(lapply(c('sd','gender','oldest','son'),function(v){idx<-strict[[paste0(v,'_status')]]=='DEFINED';data.frame(indicator=v,available_children_N=sum(!is.na(observed[[v]])),all_listed_children_N=sum(idx),core_complete_case_N=sum(idx&corecc),matched_roster_N=sum(idx&compatible),matched_roster_core_CC_N=sum(idx&compatible&corecc),mean_absolute=mean(strict[[paste0(v,'_absolute')]],na.rm=TRUE),sd_absolute=sd(strict[[paste0(v,'_absolute')]],na.rm=TRUE),mean_relative=mean(strict[[paste0(v,'_relative')]],na.rm=TRUE),sd_relative=sd(strict[[paste0(v,'_relative')]],na.rm=TRUE))}))
csv(readiness,'results/CONSTRUCTED_CONTRAST_READINESS.csv')
composition<-as.data.frame(table(reported=observed$n_reported,valid=observed$n_valid));composition<-subset(composition,Freq>0);csv(composition,'results/CONSTRUCTED_VS_VALID_CHILD_COUNTS.csv')
saveRDS(list(observed=observed,all_listed=strict,children=sel,core_complete_case=corecc,legacy_keys_compatible=compatible,source_hashes=before),file.path(ROOT,'private/CONSTRUCTED_BASELINE_CONTRASTS.rds'))
after<-vapply(src,function(p)digest(file=p,algo='sha256'),'');stopifnot(identical(before,after));csv(data.frame(file=src,sha256=before,unchanged=before==after),'audit/CONSTRUCTED_SOURCE_HASHES.csv')
wj(list(status='CONSTRUCTED_ROSTER_AUDIT_COMPLETE_WITH_EXPLICIT_SOURCE_DIFFERENCES',N_cohort=nrow(cohort),constructed_children=nrow(d),constructed_household_children=sum(hh),cohort_children=nrow(sel),cohort_missing_contact=sum(is.na(sel$meet)),cohort_any_missing_contact=sum(observed$n_reported>observed$n_valid),legacy_measurement_unchanged=all(cmp$unequal==0),common_key_measurement_unchanged=TRUE,
 scope='Explicit childID-HHmemberID crosswalk from local constructed child file, raw family and household fields exactly verified; living-child coverage beyond file not proven',
 supersedes='BASELINE_AUDIT_RECEIPT raw union overcounted linked household children and included CB048 from deceased-child module; these preliminary counts are not scientific missingness estimates',
 rule='Structural no-son/one-sex not imputed, birth-year ties unresolved, primary numeric contrast absolute, ratio sensitivity depends on ordinal score origin; no model called'),
 'results/CONSTRUCTED_AUDIT_RECEIPT.json')
progress('CONSTRUCTED_AUDIT_TERMINAL','Official key crosswalk verified, common values unchanged, source differences and missingness saved')
