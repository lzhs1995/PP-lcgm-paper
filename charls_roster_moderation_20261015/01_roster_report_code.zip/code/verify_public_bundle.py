"""公开汇总包验收；不声称复算未提供的个人记录或拟合模型。"""
from pathlib import Path
import csv,json,hashlib
R=Path(__file__).resolve().parents[1]
manifest=json.loads((R/'PAYLOAD_MANIFEST.json').read_text(encoding='utf-8-sig'))
for item in manifest:
    name=item['path'];p=R/name
    assert not name.startswith('private/') and p.suffix not in ('.rds','.dta','.dat')
    assert p.is_file() and p.stat().st_size==item['bytes'],name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],name
receipt=json.loads((R/'reports/BATCH_RECEIPT.json').read_text(encoding='utf-8-sig'))
assert receipt['new_Mplus_calls']==receipt['new_MI']==receipt['new_NLM_rounds']==0
assert receipt['independent_verification']['status']=='PASS'
counts={}
for row in csv.DictReader((R/'results/CONSTRUCTED_CONTRAST_MISSINGNESS.csv').open(encoding='utf-8-sig')):
    counts[row['indicator']]=counts.get(row['indicator'],0)+int(row['N'])
assert len(counts)==4 and all(n==receipt['CHARLS_new']['cohort_N'] for n in counts.values())
for row in csv.DictReader((R/'results/MODERATION_ENTRY_FLOW.csv').open(encoding='utf-8-sig')):
    assert int(row['plus_original_core_complete'])==receipt['CHARLS_new']['ready_CC_entries'][row['indicator']]
    assert int(row['cohort'])>=int(row['listed_contrast_defined'])>=int(row['plus_legacy_keys_compatible'])>=int(row['plus_original_core_complete'])
print(json.dumps({'status':'PASS','payload_files':len(manifest),'four_scope_counts_consistent':True,'scope':'Public hashes and aggregate consistency only; private raw-data verification is a separately recorded local check'}))
