# 整理可复用的基期模型入口；只写隔离目录，当前脚本不调用Mplus。
library(jsonlite);library(digest)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_roster_moderation_20261015'
OLD<-'<LOCAL_USER_HOME>/pp_lgcm_review/reopen_observed_charls_20261015'
CORE<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015'
r<-readRDS(file.path(ROOT,'private/CONSTRUCTED_BASELINE_CONTRASTS.rds'))
c<-readRDS(file.path(OLD,'private/charls_cohort.rds'));cc<-readRDS(file.path(CORE,'private/charls_core_mi_inputs.rds'))
stopifnot(identical(as.character(c$pid),as.character(cc$raw$pid)),length(r$legacy_keys_compatible)==nrow(c))
wj<-function(x,p)write_json(x,file.path(ROOT,p),pretty=TRUE,auto_unbox=TRUE,digits=16,na='null',null='null')
csv<-function(x,p)write.csv(x,file.path(ROOT,p),row.names=FALSE,na='')
# 给独立读取器的私人参考；这些逐人文件明确禁止进入公开白名单。
csv(c[,c('pid','x1','sd1','gender1','oldest1','son1')],'private/COHORT_REFERENCE.csv')
csv(r$all_listed,'private/R_CONTRAST_REFERENCE.csv')
csv(data.frame(pid=c$pid,core_cc=r$core_complete_case,compatible=r$legacy_keys_compatible),'private/ELIGIBILITY_REFERENCE.csv')
base<-data.frame(cluster=cc$data$cluster)
for(v in c(paste0('x',1:5),paste0('y',1:5)))base[[v]]<-cc$raw[[v]]
for(i in seq_along(vars<-c('age','female','edu','urban','partner','nchild','adl','health2','health3','health4','health5')))base[[paste0('c',i)]]<-cc$data[[vars[i]]]
# 完整案例严格遵从原始基期性别缺失标记，不以跨波恢复冒充完整案例。
base$c2<-cc$raw$female
stopifnot(identical(complete.cases(base[paste0('c',1:11)]),r$core_complete_case))
flows<-list();selection<-list();entry<-list()
for(v in c('sd','gender','oldest','son')){
 defined<-r$all_listed[[paste0(v,'_status')]]=='DEFINED'
 idx<-defined&r$legacy_keys_compatible&r$core_complete_case
 a<-base[idx,];z<-r$all_listed[[paste0(v,'_absolute')]][idx]
 stopifnot(length(z)>100,!anyNA(z),sd(z)>0,!anyNA(a[paste0('c',1:11)]))
 # 同一已验证名册入口不静默改写旧X基期；各期X/Y沿用冻结尺度与缺失掩码。
 stopifnot(max(abs(r$observed$mean[idx]-c$x1[idx]))<1e-10,max(abs(r$observed$sd[idx]-c$sd1[idx]))<1e-10)
 a$z0<-(z-mean(z))/sd(z);p<-file.path(ROOT,'private',paste0('CHARLS_',toupper(v),'_VERIFIED_CC.dat'))
 write.table(a,p,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
 entry[[v]]<-list(status='DATA_READY_NOT_ESTIMATED',N=nrow(a),communities=length(unique(a$cluster)),columns=names(a),z_definition=paste0('absolute_',v),z_mean=mean(z),z_sd=sd(z),data_file=p,data_sha256=digest(file=p,algo='sha256'),trajectory_scaling='existing baseline 3006-person scales unchanged',controls=vars)
 flows[[v]]<-data.frame(indicator=v,cohort=nrow(c),listed_contrast_defined=sum(defined),plus_legacy_keys_compatible=sum(defined&r$legacy_keys_compatible),plus_original_core_complete=nrow(a),controls_missing_after_source_gate=sum(defined&r$legacy_keys_compatible&!r$core_complete_case))
 for(n in c('age','female','edu_junior','urban','partnered','n_reported_valid','adl_difficulties','hh_income','hh_consumption','x1','y1')){
  all<-cc$raw[[n]];yes<-all[idx];no<-all[!idx];den<-sd(all,na.rm=TRUE)
  selection[[length(selection)+1L]]<-data.frame(indicator=v,variable=n,N_eligible=sum(!is.na(yes)),N_other=sum(!is.na(no)),mean_eligible=mean(yes,na.rm=TRUE),mean_other=mean(no,na.rm=TRUE),mean_difference_over_cohort_SD=(mean(yes,na.rm=TRUE)-mean(no,na.rm=TRUE))/den)
 }
}
csv(do.call(rbind,flows),'results/MODERATION_ENTRY_FLOW.csv');csv(do.call(rbind,selection),'results/ELIGIBLE_SAMPLE_DESCRIPTIVES.csv')
wj(entry,'contracts/VERIFIED_CC_ENTRIES.json')
wj(list(status='BASELINE_INPUTS_READY',Mplus_calls=0,MI_created=0,source_scope='22 parents with unmatched legacy child keys excluded in this explicitly restricted pilot entry; no silent replacement of old cohort',primary_controls=vars,
 missing_policy='Structural contrasts never imputed. Missing contact/sex/birth and ambiguous year-rank retained as distinct reasons; do not impute derived Z directly. Complete case is a scoped feasibility entry, not unbiased population inference or full MI.',
 future_MI='Existing additive core20/resource40 results remain additive-only. Before interaction MI, define substantive-model-compatible or joint latent-observed procedure with clustering and deterministic derived contrasts; diagnose before full family, without borrowing small FMI as proof.',
 sensitivity='Income and consumption remain separate resource adjustments. Absolute ordinal contrasts are primary numeric operationalizations; relative contrasts are origin-dependent sensitivity only.'),'results/BASELINE_ENTRY_RECEIPT.json')
cat('BASELINE_ENTRY_READY: four isolated datasets; no Mplus called\n');flush.console()
