"""显式白名单：仅发布基期核验汇总与代码，不发布逐人/逐子女文件。"""
from pathlib import Path
import csv,io,json,hashlib,re,zipfile
R=Path(__file__).resolve().parents[1];S=R/'public_stage';S.mkdir(exist_ok=True)
files='''reports/REPORT.md
reports/FOR_WEB_REVIEWERS.md
reports/BATCH_RECEIPT.json
contracts/SCOPE.json
contracts/VERIFIED_CC_ENTRIES.json
contracts/NEXT_BATCH_ADMISSION.json
results/CONSTRUCTED_AUDIT_RECEIPT.json
results/CONSTRUCTED_CONTRAST_MISSINGNESS.csv
results/CONSTRUCTED_CONTRAST_READINESS.csv
results/CONSTRUCTED_VS_VALID_CHILD_COUNTS.csv
results/MODERATION_ENTRY_FLOW.csv
results/ELIGIBLE_SAMPLE_DESCRIPTIVES.csv
results/BASELINE_ENTRY_RECEIPT.json
audit/CONSTRUCTED_SOURCE_HASHES.csv
audit/CONSTRUCTED_AVAILABLE_COMPARISON.csv
audit/CONSTRUCTED_KEY_COVERAGE.json
audit/CONSTRUCTED_RAW_FIELD_COMPARISON.csv
audit/LEGACY_KEY_DISPOSITION.json
audit/LEGACY_COMMON_KEY_COMPARISON.csv
audit/RAW_SLOT_DISPOSITION.csv
audit/INDEPENDENT_ROSTER_VERIFICATION.json
audit/QUESTIONNAIRE_RULES.json
audit/FINAL_SOURCE_AND_INPUT_CHECK.json
audit/CLAUDER_COMPLETION.json
runtime/constructed_attempt1_terminal.json
runtime/constructed_attempt2_terminal.json
runtime/constructed_v3_terminal.json
code/audit_baseline_roster.R
code/audit_constructed_roster.R
code/prepare_verified_scope.R
code/verify_roster_independent.py
code/finalize_batch.py
code/package_batch.py
code/verify_public_bundle.py'''.splitlines()
completion=json.loads((R/'audit/CLAUDER_COMPLETION.json').read_text(encoding='utf-8-sig'));assert completion['decision']=='PASS'
hash_=lambda b:hashlib.sha256(b).hexdigest()
payload={};manifest=[]
for name in files:
    p=R/name;assert p.is_file(),name
    assert not name.startswith('private/') and p.suffix not in ('.rds','.dta','.dat')
    raw=p.read_bytes();text=raw.decode('utf-8-sig')
    for prefix in ['<LOCAL_USER_HOME>','<LOCAL_USER_HOME>','C:\\\\Users\\\\LZHS','<LOCAL_USER_HOME>','<LOCAL_USER_HOME>']:text=text.replace(prefix,'<LOCAL_USER_HOME>')
    assert not re.search(r'(?i)(?:api[_-]?key|access_token)\s*[:=]\s*["\']?[A-Za-z0-9_-]{20,}',text),name
    if p.suffix=='.csv':
        rows=list(csv.reader(io.StringIO(text)));assert rows and len(rows)<500
        assert not set(s.lower() for s in rows[0])&{'id','pid','fid','householdid','communityid','childid'},name
    data=text.encode('utf-8');payload[name]=data
    manifest.append({'path':name,'bytes':len(data),'sha256':hash_(data),'local_source_sha256':hash_(raw),'paths_redacted':data!=raw})
payload['PAYLOAD_MANIFEST.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
zpath=S/'01_roster_report_code.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,data in payload.items():z.writestr(name,data)
assert zpath.stat().st_size<25_000_000
with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
pm={'packages':[{'file':zpath.name,'bytes':zpath.stat().st_size,'sha256':hash_(zpath.read_bytes()),'files':len(payload)}],'payload_files':len(payload),'privacy':'Explicit per-file allowlist; no individual or child records, DAT/DTA/RDS or MI; source paths redacted'}
(S/'PACKAGE_MANIFEST.json').write_text(json.dumps(pm,ensure_ascii=False,indent=2),encoding='utf-8')
for name in ['REPORT.md','FOR_WEB_REVIEWERS.md','BATCH_RECEIPT.json']:(S/name).write_bytes(payload['reports/'+name])
(S/'README.md').write_text('# CHARLS基期名册与缺失处理接续\n\n**四项调节完整推断、完整 H4 仍未完成。**\n\n[报告](REPORT.md) · [网页说明](FOR_WEB_REVIEWERS.md) · [回执](BATCH_RECEIPT.json) · [包清单](PACKAGE_MANIFEST.json)\n\n本包完成基期名册交叉核验及四份后续小试数据入口，新增Mplus为0。既有H4.1、CHARLS核心20MI和资源40MI继续引用前批437518b，不重复估计。\n\n解压后执行 `python code/verify_public_bundle.py` 可核验公开哈希与汇总一致性。独立原始数据复算在本机已完成，微观资料不公开；请勿声称云端重新拟合。代码中的个人路径已脱敏，实际本机重现需绑定自己的授权数据。初始原始槽位拼接代码保留为有记录的探索来源，不将其缺失计数用于推断；最终采用CONSTRUCTED前缀结果。\n\n技能经验见 [mplusautomation-guide PR25](https://github.com/lzhs1995/clauder-rstudio-workbench/pull/25)。\n',encoding='utf-8')
(R/'audit/PUBLIC_FILE_SELECTION.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(pm,ensure_ascii=False))
