"""从实际回执生成接续合同与交付记录；本脚本不启动统计模型。"""
from pathlib import Path
import csv,json,hashlib,datetime
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads((R/p).read_text(encoding='utf-8-sig'))
write=lambda p,x:(R/p).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
audit=read('results/CONSTRUCTED_AUDIT_RECEIPT.json')
verification=read('audit/INDEPENDENT_ROSTER_VERIFICATION.json')
assert verification['status']=='PASS'
entries=read('contracts/VERIFIED_CC_ENTRIES.json')
assert all(x['status']=='DATA_READY_NOT_ESTIMATED' for x in entries.values())
assert all(sha(Path(x['data_file']))==x['data_sha256'] for x in entries.values())
source_rows=list(csv.DictReader((R/'audit/CONSTRUCTED_SOURCE_HASHES.csv').open(encoding='utf-8-sig')))
assert all(sha(Path(x['file']))==x['sha256'] for x in source_rows)
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
write('audit/FINAL_SOURCE_AND_INPUT_CHECK.json',{'status':'PASS','utc':now,'source_files':len(source_rows),'isolated_input_files':len(entries),'sources_unchanged':True,'input_hashes_match':True})
next_contract={'created_utc':now,'scope':'Prospective admission and data scope after baseline source audit; exact numerical inputs must be frozen before first estimation',
 'previous_evidence':'437518be9ba2c55313ad91ff2fd079eec73df0d1','datasets':{k:{n:v[n] for n in ['N','communities','z_definition','z_mean','z_sd','data_sha256']} for k,v in entries.items()},
 'target':'SX times observed absolute baseline child contrast predicting SY, within explicitly verified baseline roster/complete-core-control scope',
 'sequence':['same-sample no-interaction parent for each contrast','if parent admissible, single interaction with all lower-order effects retained','second independent start only for admissible interaction','conditional slopes and full covariance readback; never combine starts as imputations'],
 'limits':{'max_parent_calls':4,'max_interaction_calls':8,'max_total_calls':12,'per_call_seconds':240,'total_engine_launcher_seconds':2880,'batch_wall_seconds':3600,'Mplus_processors':1,'engine_slots_initial':1},
 'stop_rules':['No unchanged failed CFPS input rerun','No fixing negative variances solely to force success','No p-value eligibility or selective reporting','No pooling incomplete MI families','No automatic new Bayes/window/shape branch'],
 'missingness':'Complete-case feasibility entry only; additive20/40MI cannot be relabeled interaction-compatible; structural contrasts remain undefined',
 'closed_manuscript':'preserved','auto_submitted':False,'preregistration_claim':False}
write('contracts/NEXT_BATCH_ADMISSION.json',next_contract)
write('reports/BATCH_RECEIPT.json',{'utc':now,'status':'CHARLS_BASELINE_ROSTER_AND_MISSINGNESS_ENTRY_COMPLETE','overall_status':'四项调节完整推断、完整 H4 仍未完成。','new_Mplus_calls':0,'new_MI':0,'new_NLM_rounds':0,
 'CFPS_reused':{'registered_H41_families':12,'complete_conditional_families':3,'other_new_families_adjudicated_previous_batch':9,'unchanged_failed_spec_reruns':0,'MI_interaction_compatibility_proven':False},
 'CHARLS_reused':{'core_MI':20,'income_MI':40,'consumption_MI':40,'additive_models_only':True},
 'CHARLS_new':{'cohort_N':audit['N_cohort'],'listed_children':audit['cohort_children'],'missing_child_contact':audit['cohort_missing_contact'],'parents_with_missing_child_contact':audit['cohort_any_missing_contact'],'source_discrepancy_parents':read('audit/LEGACY_KEY_DISPOSITION.json')['cohort_affected_parents'],'ready_CC_entries':{k:v['N'] for k,v in entries.items()},'entries_not_estimated':True},
 'independent_verification':verification,'raw_sources_unchanged':True,'skill':'mplusautomation-guide PR25 updated separately; no assertion that it completes scientific inference'})
print(json.dumps(read('reports/BATCH_RECEIPT.json'),ensure_ascii=False,indent=2))
