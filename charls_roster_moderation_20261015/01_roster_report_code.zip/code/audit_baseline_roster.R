# 从2011原始两个子女来源重建报告槽位，保留未报告接触及结构性不可定义，不改历史结果。
library(haven);library(dplyr);library(jsonlite);library(digest)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_roster_moderation_20261015'
OLD<-'<LOCAL_USER_HOME>/pp_lgcm_review/reopen_observed_charls_20261015'
CORE<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015'
RAW<-'<LOCAL_USER_HOME>/Desktop/20230505 毕业论文/开题报告/开题报告/CHARLS/CHARLS2011/Data'
LEGACY<-'<LOCAL_USER_HOME>/Desktop/开题报告/0_data_clo/contact_2011_long.dta'
wj<-function(a,p)write_json(a,file.path(ROOT,p),auto_unbox=TRUE,pretty=TRUE,digits=16,na='null',null='null')
csv<-function(a,p)write.csv(a,file.path(ROOT,p),row.names=FALSE,na='')
progress<-function(stage,message){cat(stage,message,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(stage,message)}
src<-c(file.path(RAW,c('family_information.dta','household_roster.dta')),LEGACY,file.path(OLD,'private/charls_cohort.rds'),file.path(CORE,'private/charls_core_mi_inputs.rds'))
before<-vapply(src,function(p)digest(file=p,algo='sha256'),'')
progress('metadata','Read only required baseline child columns')
fm<-read_dta(src[1],n_max=0);hm<-read_dta(src[2],n_max=0)
fc<-grep('^(ID$|householdID$|communityID$|cb048_[0-9]+_$|cb049_[0-9]+_$|cb050_[0-9]+_$|cb051_[12]_[0-9]+_$|cb053_[0-9]+_$|cd003_[0-9]+_$)',names(fm),value=TRUE)
hc<-grep('^(ID$|householdID$|a006_[0-9]+_$|a002_[0-9]+_$|a003_[12]_[0-9]+_$)',names(hm),value=TRUE)
f<-read_dta(src[1],col_select=all_of(fc));h<-read_dta(src[2],col_select=all_of(hc))
stopifnot(!anyDuplicated(f$ID),!anyDuplicated(h$ID))
getnum<-function(d,n){if(n%in%names(d))as.numeric(d[[n]]) else rep(NA_real_,nrow(d))}
normalpid<-function(id,fid)paste0(as.character(fid),'0',substr(as.character(id),nchar(as.character(id))-1,nchar(as.character(id))))
rows<-list();slots<-sort(as.integer(sub('^cb049_([0-9]+)_$','\\1',grep('^cb049_[0-9]+_$',names(f),value=TRUE))))
for(i in slots){
 vars<-c(paste0('cb048_',i,'_'),paste0('cb049_',i,'_'),paste0('cb050_',i,'_'),paste0('cb051_1_',i,'_'),paste0('cb051_2_',i,'_'),paste0('cb053_',i,'_'),paste0('cd003_',i,'_'));vars<-intersect(vars,names(f))
 reported<-Reduce(`|`,lapply(f[vars],function(v)!is.na(v)|haven::is_tagged_na(v)))
 d<-data.frame(pid=normalpid(f$ID,f$householdID),fid=paste0(f$householdID,'0'),slot=i,source='family_information',reported=reported,
 sex=getnum(f,paste0('cb049_',i,'_')),birth=getnum(f,paste0('cb051_1_',i,'_')),month=getnum(f,paste0('cb051_2_',i,'_')),residence=getnum(f,paste0('cb053_',i,'_')),meet_code=getnum(f,paste0('cd003_',i,'_')))
 rows[[length(rows)+1L]]<-d[d$reported,]
}
slots<-sort(as.integer(sub('^a006_([0-9]+)_$','\\1',grep('^a006_[0-9]+_$',names(h),value=TRUE))))
for(i in slots){
 d<-data.frame(pid=normalpid(h$ID,h$householdID),fid=paste0(h$householdID,'0'),slot=as.integer(paste0('11',i)),source='household_roster',reported=getnum(h,paste0('a006_',i,'_'))%in%7,
 sex=getnum(h,paste0('a002_',i,'_')),birth=getnum(h,paste0('a003_1_',i,'_')),month=getnum(h,paste0('a003_2_',i,'_')),residence=NA_real_,meet_code=1)
 rows[[length(rows)+1L]]<-d[d$reported,]
}
d<-bind_rows(rows);d$sex[!d$sex%in%1:2]<-NA_real_;d$birth[is.na(d$birth)|d$birth<1800|d$birth>2011]<-NA_real_
d$month[!d$month%in%1:12]<-NA_real_;d$meet<-ifelse(d$meet_code%in%1:9,10-d$meet_code,NA_real_)
d$meet[is.na(d$meet)&d$residence%in%1]<-9
stopifnot(!anyDuplicated(paste(d$pid,d$slot)))
saveRDS(d,file.path(ROOT,'private/BASELINE_REPORTED_CHILDREN.rds'))
progress('source_comparison','Compare raw source keys with historical filtered child-long')
l<-read_dta(LEGACY,col_select=all_of(c('pid','fid','ID_c2gc','cb049_','cb051_1_','cb053_','cd003_')))
lpid<-normalpid(l$pid,l$fid);key<-paste(lpid,l$ID_c2gc);dk<-paste(d$pid,d$slot);ix<-match(key,dk)
oldmeet<-ifelse(l$cd003_%in%1:9,10-as.numeric(l$cd003_),NA_real_);oldmeet[is.na(oldmeet)&l$cb053_%in%1]<-9
same<-function(a,b)sum((is.na(a)!=is.na(b))|(!is.na(a)&!is.na(b)&abs(a-b)>1e-10))
overlap<-list(raw_reported_slots=nrow(d),legacy_slots=nrow(l),legacy_key_missing_in_raw=sum(is.na(ix)),raw_slots_not_in_legacy=sum(!dk%in%key),contact_mismatches=same(oldmeet,d$meet[ix]),
 raw_missing_contact=sum(is.na(d$meet)),legacy_now_missing_contact=sum(is.na(oldmeet)))
stopifnot(!anyNA(ix),overlap$contact_mismatches==0)
cohort<-readRDS(src[4]);stopifnot(nrow(cohort)==3006)
sel<-d[d$pid%in%cohort$pid,];stopifnot(length(unique(sel$pid))==nrow(cohort))
gap<-function(v,g){if(anyNA(g)||!any(g)||all(g))return(NA_real_);mean(v[g])-mean(v[!g])}
rankgap<-function(v,b,s=NULL){if(anyNA(b)||(!is.null(s)&&anyNA(s)))return(NA_real_);eligible<-if(is.null(s))rep(TRUE,length(b))else s==1;if(!any(eligible))return(NA_real_);g<-eligible&b==min(b[eligible]);if(sum(g)!=1L)return(NA_real_);gap(v,g)}
measure<-function(z){v<-z$meet;data.frame(mean=if(length(v)>=2)mean(v)else NA_real_,sd=if(length(v)>=2)sd(v)else NA_real_,gender=gap(v,z$sex==1),oldest=rankgap(v,z$birth),son=rankgap(v,z$birth,z$sex))}
observed<-bind_rows(lapply(split(sel,sel$pid),function(z)cbind(pid=z$pid[1],n_reported=nrow(z),n_valid=sum(!is.na(z$meet)),measure(z[!is.na(z$meet),]))))
observed<-observed[match(cohort$pid,observed$pid),];stopifnot(identical(as.character(observed$pid),as.character(cohort$pid)))
cmp<-data.frame(variable=c('mean','sd','gender','oldest','son'),legacy_column=c('x1','sd1','gender1','oldest1','son1'))
cmp$unequal<-mapply(function(a,b)same(observed[[a]],cohort[[b]]),cmp$variable,cmp$legacy_column)
csv(cmp,'audit/AVAILABLE_CHILD_MEASUREMENT_COMPARISON.csv');stopifnot(all(cmp$unequal==0))
progress('missingness','Separate structural contrast absence, missing contact/demographics and birth-rank ties')
status<-function(z,type){
 if(nrow(z)<2)return('STRUCTURAL_FEWER_THAN_TWO')
 if(type%in%c('gender','son')){
  if(anyNA(z$sex))return('MISSING_CHILD_SEX')
  if(type=='gender'&&length(unique(z$sex))<2)return('STRUCTURAL_ONE_SEX_ONLY')
  if(type=='son'&&!any(z$sex==1))return('STRUCTURAL_NO_SON')
 }
 if(type%in%c('oldest','son')){
  if(anyNA(z$birth))return('MISSING_BIRTH_YEAR')
  eligible<-if(type=='son')z$sex==1 else rep(TRUE,nrow(z))
  if(sum(eligible&z$birth==min(z$birth[eligible]))!=1)return('AMBIGUOUS_EARLIEST_BIRTH_YEAR')
 }
 if(anyNA(z$meet))return('MISSING_REPORTED_CHILD_CONTACT')
 'DEFINED'
}
strict<-bind_rows(lapply(split(sel,sel$pid),function(z){
 a<-measure(z);ans<-data.frame(pid=z$pid[1],n_reported=nrow(z),n_valid=sum(!is.na(z$meet)))
 for(v in c('sd','gender','oldest','son')){st<-status(z,v);ans[[paste0(v,'_status')]]<-st;ans[[paste0(v,'_absolute')]]<-if(st=='DEFINED')a[[v]] else NA_real_;ans[[paste0(v,'_relative')]]<-ans[[paste0(v,'_absolute')]]/a$mean}
 ans
}))
strict<-strict[match(cohort$pid,strict$pid),];core<-readRDS(src[5]);stopifnot(identical(as.character(core$raw$pid),as.character(cohort$pid)))
missingness<-bind_rows(lapply(c('sd','gender','oldest','son'),function(v){t<-as.data.frame(table(strict[[paste0(v,'_status')]]),stringsAsFactors=FALSE);names(t)<-c('status','N');cbind(indicator=v,t)}))
csv(missingness,'results/BASELINE_CONTRAST_MISSINGNESS.csv')
readiness<-bind_rows(lapply(c('sd','gender','oldest','son'),function(v){idx<-strict[[paste0(v,'_status')]]=='DEFINED';data.frame(indicator=v,available_children_N=sum(!is.na(observed[[v]])),all_reported_children_N=sum(idx),core_complete_case_N=sum(idx&!is.na(core$data$adl)),mean_absolute=mean(strict[[paste0(v,'_absolute')]],na.rm=TRUE),sd_absolute=sd(strict[[paste0(v,'_absolute')]],na.rm=TRUE),mean_relative=mean(strict[[paste0(v,'_relative')]],na.rm=TRUE),sd_relative=sd(strict[[paste0(v,'_relative')]],na.rm=TRUE))}))
csv(readiness,'results/BASELINE_CONTRAST_READINESS.csv')
composition<-as.data.frame(table(reported=observed$n_reported,valid=observed$n_valid));composition<-subset(composition,Freq>0);csv(composition,'results/REPORTED_VS_VALID_CHILD_COUNTS.csv')
saveRDS(list(observed=observed,all_reported=strict,children=sel,source_hashes=before),file.path(ROOT,'private/BASELINE_CONTRASTS.rds'))
after<-vapply(src,function(p)digest(file=p,algo='sha256'),'');stopifnot(identical(before,after))
csv(data.frame(file=src,sha256=before,unchanged=before==after),'audit/BASELINE_SOURCE_HASHES.csv')
wj(c(overlap,list(status='BASELINE_SOURCE_AND_CONTRAST_AUDIT_COMPLETE',N_cohort=nrow(cohort),cohort_reported_slots=nrow(sel),cohort_missing_contact=sum(is.na(sel$meet)),cohort_any_unreported_contact=sum(observed$n_reported>observed$n_valid),legacy_measurement_unchanged=TRUE,
 scope='Identifiable child slots in raw2011 family_information plus household-roster Child relation; not proof every living child was reported',
 rule='No arbitrary birth-year tie breaking; no imputation of structural no-son/one-sex contrasts; both absolute and ratio descriptions, no Mplus yet',
 caveat='Ratio of ordinal1-9 contact scores depends on scale origin; same-household economically-independent family slots retained separately from household members; no automatic demographic-based deduplication')),'results/BASELINE_AUDIT_RECEIPT.json')
progress('BASELINE_AUDIT_TERMINAL','Raw-slot linkage, unchanged available-child scores, missingness and model readiness saved')
