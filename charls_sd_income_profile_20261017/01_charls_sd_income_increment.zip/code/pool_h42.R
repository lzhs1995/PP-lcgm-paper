# 只合并已完整结束的20/40成员；复用原始TECH3，不重复Mplus。
source('<LOCAL_USER_HOME>/pp_lgcm_review/charls_sd_income_profile_20261017/code/models.R',local=TRUE)
pool_h42<-function(phase='EDU_URBAN'){
 states<-rj(file.path(ROOT,'results/FAMILY_STATUS.json'))
 outroot<-file.path(ROOT,'results',paste0('pool_',phase));dir.create(outroot,showWarnings=FALSE)
 labs<-c('bii','bis','bss','bsyiy','gi0','gs0','gizg','gszg','dc','bxg','dcg')
 overview<-list();allpaths<-list();allcontrasts<-list();allslopes<-list();allfinite<-list()
 selected<-names(states)[vapply(states,function(s)if(phase=='ALL')TRUE else if(phase=='EDU_URBAN')s$group%in%c('EDU','URBAN')else s$group=='INC',TRUE)]
 for(f in selected){
  st<-states[[f]];row<-data.frame(family=f,z=st$z,resource=st$group,status=st$status,m=st$m,members=st$members,N=if(is.null(st$N))NA else st$N,estimate=NA_real_,se=NA_real_,lower=NA_real_,upper=NA_real_,p=NA_real_,max_MCSE_over_SE=NA_real_)
  if(st$status=='FULL_FAMILY_PENDING_POOLING'){
   stopifnot(st$members==st$m,isTRUE(rj(file.path(ROOT,'results',paste0(toupper(f),'_START_COMPARISON.json')))$passed))
   dest<-file.path(outroot,f);dir.create(dest,showWarnings=FALSE)
   Q<-matrix(NA_real_,st$m,length(labs),dimnames=list(NULL,labs));U<-list();sources<-list();supports<-list()
   for(k in seq_len(st$m)){
    d<-file.path(ROOT,'models',job_id(f,'E1',k,'A'));j<-rj(file.path(d,'job.json'));r<-rj(file.path(d,'receipt.json'))
    stopifnot(r$status=='USABLE_SINGLE_DATASET',r$N==st$N,j$member==k,j$start=='A',r$output_sha256==hashf(file.path(d,'model.out')),j$hashes$data.dat==hashf(file.path(d,'data.dat')),j$hashes$model.inp==hashf(file.path(d,'model.inp')))
    p<-read.csv(file.path(d,'key_paths.csv'));p<-p[match(labs,p$label),];stopifnot(!anyNA(p$parameter),!anyDuplicated(p$parameter))
    V<-as.matrix(read.csv(file.path(d,'parameter_covariance.csv'),header=FALSE));Q[k,]<-p$estimate;U[[k]]<-V[p$parameter,p$parameter,drop=FALSE];dimnames(U[[k]])<-list(labs,labs)
    stopifnot(all(is.finite(U[[k]])),max(abs(U[[k]]-t(U[[k]])))<1e-9,max(abs(diag(U[[k]])-p$se^2))<1e-6)
    sources[[k]]<-data.frame(member=k,model=j$id,output_sha256=r$output_sha256,data_sha256=j$hashes$data.dat,input_sha256=j$hashes$model.inp,results_sha256=hashf(file.path(d,'estimates.dat')),tech3_sha256=hashf(file.path(d,'tech3.dat')))
    supports[[k]]<-j$support
   }
   dfcom<-j$communities-1L;po<-rubin_pool(Q,U)
   path<-data.frame(family=f,label=labs,po$table,row.names=NULL);csv(path,file.path(dest,'POOLED_PATHS.csv'))
   csv(data.frame(label=labs,po$W,check.names=FALSE),file.path(dest,'WITHIN_COVARIANCE.csv'));csv(data.frame(label=labs,po$B,check.names=FALSE),file.path(dest,'BETWEEN_COVARIANCE.csv'));csv(data.frame(label=labs,po$T,check.names=FALSE),file.path(dest,'TOTAL_COVARIANCE.csv'))
   csv(data.frame(member=seq_len(st$m),Q),file.path(dest,'MEMBER_ESTIMATES.csv'))
   csv(do.call(rbind,lapply(seq_len(st$m),function(k)data.frame(member=k,expand.grid(row=labs,column=labs,stringsAsFactors=FALSE),covariance=as.vector(U[[k]])))),file.path(dest,'MEMBER_COVARIANCES.csv'))
   csv(do.call(rbind,sources),file.path(dest,'MEMBER_SOURCES.csv'))
   contrast<-function(coef,df=Inf){a<-setNames(rep(0,length(labs)),labs);a[names(coef)]<-coef;pool_contrast(Q,U,a,nu_com=df)}
   cs<-list(delta_G0=c(dc=1),delta_G1=c(dc=1,dcg=1),direct_difference=c(dcg=1))
   ct<-do.call(rbind,lapply(names(cs),function(n)data.frame(family=f,contrast=n,contrast(cs[[n]]),row.names=NULL)))
   finite<-do.call(rbind,lapply(names(cs),function(n)data.frame(family=f,contrast=n,df_complete=dfcom,contrast(cs[[n]],dfcom),row.names=NULL)))
   csv(ct,file.path(dest,'GROUP_MODERATION_CONTRASTS.csv'));csv(finite,file.path(dest,'CLUSTER_DF_SENSITIVITY.csv'))
   curves<-list()
   for(g in 0:1){
    group<-lapply(supports,function(s)s[[g+1L]])
    lo<-max(vapply(group,function(s)s$min,0));hi<-min(vapply(group,function(s)s$max,0));stopifnot(lo<=hi)
    # 收入插补会改变分组成员；只展示所有成员共同支持区间内的预定点。
    points<-sort(unique(c(lo,hi,unlist(group[[1]]$points))));points<-points[points>=lo&points<=hi]
    for(z in points)curves[[length(curves)+1L]]<-data.frame(family=f,G=g,z=z,support_min=lo,support_max=hi,contrast(c(bss=1,dc=z,bxg=g,dcg=z*g)),row.names=NULL)
   }
   curve<-do.call(rbind,curves);csv(curve,file.path(dest,'CONDITIONAL_SLOPES.csv'))
   primary<-ct[ct$contrast=='direct_difference',];row[names(primary)[names(primary)%in%names(row)]]<-primary[names(primary)%in%names(row)]
   row$max_MCSE_over_SE<-max(c(path$MCSE_over_SE,ct$MCSE_over_SE,curve$MCSE_over_SE));row$status<-if(row$max_MCSE_over_SE<.1)'FULL_CONDITIONAL_MI_POOLED'else'FULL_POOLED_MCSE_LIMIT_RETAINED'
   wj(list(status=row$status,family=f,m=st$m,N=st$N,communities=j$communities,max_MCSE_over_SE=row$max_MCSE_over_SE,compatibility=contract$compatibility,full_H4_complete=FALSE,original_CFPS_moderations_complete=FALSE),file.path(dest,'RECEIPT.json'))
   allpaths[[f]]<-path;allcontrasts[[f]]<-ct;allfinite[[f]]<-finite;allslopes[[f]]<-curve
  }
  overview[[f]]<-row
 }
 tab<-do.call(rbind,overview);ok<-which(is.finite(tab$p));tab$Holm_12<-tab$Bonferroni_12<-NA_real_
 if(length(ok)){tab$Holm_12[ok]<-p.adjust(tab$p[ok],'holm',n=12);tab$Bonferroni_12[ok]<-p.adjust(tab$p[ok],'bonferroni',n=12)}
 csv(tab,file.path(outroot,'H42_REGISTERED.csv'))
 for(n in c('allpaths','allcontrasts','allfinite','allslopes'))if(length(get(n)))csv(do.call(rbind,get(n)),file.path(outroot,paste0(toupper(n),'.csv')))
 wj(list(status='H42_MI_SAVED_RESULTS_POOLED',phase=phase,registered=length(selected),complete=length(allpaths),conditional_on_working_MI=TRUE,full_H4_complete=FALSE,original_CFPS_moderations_complete=FALSE,new_Mplus_calls=0),file.path(outroot,'RECEIPT.json'))
 cat('H42_MI_POOL_NATIVE_TERMINAL',phase,length(allpaths),'complete families\n')
}
