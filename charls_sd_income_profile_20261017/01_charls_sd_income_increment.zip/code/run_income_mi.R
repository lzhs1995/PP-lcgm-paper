# 从真实新输入开始40链，完整检查点恢复；接口小试的随机成员不得混入。
source('<LOCAL_USER_HOME>/pp_lgcm_review/charls_sd_income_profile_20261017/code/income_pilot.R',local=TRUE)
run_income_mi<-function(z){
 contract<-fromJSON(file.path(BATCH,'contracts/INCOME_MI_RUN.json'),simplifyVector=FALSE)
 ROOT<-file.path(BATCH,'mi_income',z);a<-readRDS(file.path(ROOT,'private/INPUTS.rds'));d<-a$data
 h<-digest(file=file.path(ROOT,'private/INPUTS.rds'),algo='sha256');pilot<-fromJSON(file.path(ROOT,contract$pilot_attempt[[z]],'audit/RECEIPT.json'),simplifyVector=FALSE)
 stopifnot(isTRUE(pilot$passed),pilot$input_sha256==h,!file.exists(file.path(ROOT,'audit/ADMISSION.json')))
 stopfile<-file.path(ROOT,'runtime/FORMAL_TERMINAL');stopifnot(!file.exists(stopfile));on.exit(writeLines('Actual formal MI terminal; inspect admission',stopfile),add=TRUE)
 owner<-ps::ps_handle();ps::ps_set_nice(owner,'above_normal');py<-'<LOCAL_USER_HOME>/AppData/Local/Programs/Python/Python314/python.exe'
 watch<-processx::process$new(py,c('-X','utf8',file.path(BATCH,'code/bounded_worker_watch.py'),'--pid',Sys.getpid(),'--created',as.numeric(ps::ps_create_time(owner)),'--seconds',contract$scope_wall_seconds,'--receipt',file.path(ROOT,'runtime/WATCH.json'),'--stop',stopfile,'--fit-dir',file.path(ROOT,'audit'),'--fit-seconds',contract$per_fit_seconds),stdout=file.path(ROOT,'runtime/watch.log'),stderr='2>&1',cleanup=FALSE)
 awake<-processx::process$new(py,c('-X','utf8',file.path(BATCH,'code/coordinator_awake.py'),'--owner-pid',Sys.getpid(),'--owner-created',as.numeric(ps::ps_create_time(owner)),'--receipt',file.path(ROOT,'runtime/AWAKE.json'),'--max-seconds','14400','--stop-file',stopfile),stdout=file.path(ROOT,'runtime/awake.log'),stderr='2>&1',cleanup=FALSE)
 # Windows负载下保护进程可能晚于10秒生成回执；先查真实身份和状态，不把路径当JSON文本。
 ar<-wr<-NULL;created<-as.numeric(ps::ps_create_time(owner))
 for(i in 1:360){
  read_receipt<-function(p)if(file.exists(p))tryCatch(fromJSON(p),error=function(e)NULL)else NULL
  ar<-read_receipt(file.path(ROOT,'runtime/AWAKE.json'));wr<-read_receipt(file.path(ROOT,'runtime/WATCH.json'))
  valid_awake<-!is.null(ar)&&identical(ar$status,'ACTIVE')&&ar$owner_pid==Sys.getpid()&&abs(ar$owner_created-created)<.02
  valid_watch<-!is.null(wr)&&identical(wr$state,'WATCHING')&&wr$owner_pid==Sys.getpid()&&abs(wr$owner_created-created)<.02
  if(valid_awake&&valid_watch)break
  if(!watch$is_alive()||!awake$is_alive())stop('Income startup helper exited before ACTIVE/WATCHING; inspect logs, no draws started')
  Sys.sleep(.25)
 }
 stopifnot(valid_awake,valid_watch,watch$is_alive(),awake$is_alive())
 progress<-function(stage,message){p<-file.path(ROOT,'runtime/progress.json');tmp<-paste0(p,'.tmp');write_json(list(stage=stage,message=paste(z,message),updated_at=format(Sys.time(),tz='UTC',usetz=TRUE),pid=Sys.getpid()),tmp,auto_unbox=TRUE,pretty=TRUE);fs::file_move(tmp,p);cat(stage,z,message,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(stage,paste(z,message))}
 source(file.path(BATCH,'code/income_imputers.R'),local=TRUE);fit_env$scope<-z;install_scaling()
 oldlog<-file.path(ROOT,'audit/FIT_LOG.jsonl');if(file.exists(oldlog)){oldfits<-lapply(readLines(oldlog),fromJSON);if(length(oldfits))fit_env$fit_n<-max(vapply(oldfits,function(x)x$fit_n,0))}
 warnings<-character();capture<-function(e)withCallingHandlers(e,warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')})
 checkpoint<-function(imp){p<-file.path(ROOT,'checkpoints',sprintf('ITER%02d.rds',imp$iteration));stopifnot(!file.exists(p));tmp<-paste0(p,'.tmp');saveRDS(imp,tmp);stopifnot(file.rename(tmp,p));write_json(list(iteration=imp$iteration,m=imp$m,sha256=digest(file=p,algo='sha256'),input_sha256=h),paste0(p,'.json'),auto_unbox=TRUE,pretty=TRUE);if(exists(z,fit_env$warm,inherits=FALSE))saveRDS(get(z,fit_env$warm),paste0(p,'.warm.rds'))}
 ready<-function(imp){if(imp$iteration<contract$minit)return(FALSE);cv<-mice::convergence(imp);write.csv(cv,file.path(ROOT,'audit/CONVERGENCE.csv'),row.names=FALSE);tt<-cv[cv$vrb%in%c('g','adl')&cv$.it>imp$iteration-5,];nrow(tt)==10&&all(is.finite(tt$psrf))&&all(tt$psrf<1.1)}
 result<-tryCatch({
  cps<-sort(list.files(file.path(ROOT,'checkpoints'),pattern='^ITER[0-9]{2}\\.rds$',full.names=TRUE));imp<-NULL
  if(length(cps)){p<-tail(cps,1);meta<-fromJSON(paste0(p,'.json'));stopifnot(digest(file=p,algo='sha256')==meta$sha256,h==meta$input_sha256);imp<-readRDS(p);stopifnot(imp$m==40,identical(imp$data,d));if(file.exists(paste0(p,'.warm.rds')))tryCatch({warm<-readRDS(paste0(p,'.warm.rds'));stopifnot(is.list(warm),all(is.finite(warm$beta)),all(is.finite(warm$theta)));assign(z,warm,fit_env$warm)},error=function(e)cat('OPTIONAL_WARM_IGNORED',conditionMessage(e),'\n'));progress('H42_INCOME_MI_RESUME',paste('saved iteration',imp$iteration))}
  if(is.null(imp)){fit_env$iteration<-1L;progress('H42_INCOME_MI_START','40 fresh chains; pilot draws excluded');imp<-capture(mice(d,m=40,maxit=1,method=a$method,predictorMatrix=a$predictors,visitSequence=a$visit,seed=contract$mi_seeds[[z]],data.init=a$initial,blots=a$blots,remove.collinear=FALSE,remove.constant=FALSE,printFlag=FALSE));checkpoint(imp)}
  mixed<-ready(imp)
  while(imp$iteration<contract$maxit&&!mixed){fit_env$iteration<-imp$iteration+1L;progress('H42_INCOME_MI_ITERATION',paste(fit_env$iteration,'of at most20'));imp<-capture(mice.mids(imp,maxit=1,printFlag=FALSE));checkpoint(imp);mixed<-ready(imp)}
  saveRDS(imp,file.path(ROOT,'private/MIDS.rds'));stopifnot(identical(unname(imp$predictorMatrix),unname(a$predictors)))
  checks<-list();summ<-list()
  for(k in 1:40){v<-complete(imp,k);for(n in names(d)){ok<-!is.na(d[[n]]);stopifnot(identical(as.numeric(v[[n]][ok]),as.numeric(d[[n]][ok])))}
   stopifnot(!anyNA(v),all(v$g%in%0:1),all(v$adl%in%0:6),all(v$adl[is.na(d$adl)]%in%d$adl[!is.na(d$adl)]),max(abs(v$zg-v$g*v$z0))<1e-12,max(abs(v$z_adl-v$z0*v$adl))<1e-12)
   for(n in a$aux)stopifnot(max(abs(v[[paste0('g_',n)]]-v$g*v[[n]]))<1e-12,max(abs(v[[paste0('gz_',n)]]-v$g*v$z0*v[[n]]))<1e-12)
   b<-a$analysis;b$c7<-v$adl;b$g<-v$g;b$zg<-v$zg;stopifnot(identical(b[setdiff(names(a$analysis),'c7')],a$analysis[setdiff(names(a$analysis),'c7')]))
   path<-file.path(ROOT,'private',sprintf('MI%02d.dat',k));write.table(b,path,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
   checks[[k]]<-data.frame(member=k,N=nrow(b),observed_preserved=TRUE,XY_masks_preserved=TRUE,passive_products=TRUE,sha256=digest(file=path,algo='sha256'));summ[[k]]<-data.frame(member=k,imputed_G_mean=mean(v$g[is.na(d$g)]),imputed_ADL_mean=mean(v$adl[is.na(d$adl)]))
  }
  fits<-lapply(readLines(file.path(ROOT,'audit/FIT_LOG.jsonl')),fromJSON);valid<-all(vapply(fits,function(x)isTRUE(x$valid),TRUE));stopifnot(digest(file=file.path(ROOT,'private/INPUTS.rds'),algo='sha256')==h,digest(file=a$source,algo='sha256')==a$source_sha256)
  write.csv(do.call(rbind,checks),file.path(ROOT,'audit/MEMBER_VALIDATION.csv'),row.names=FALSE);write.csv(do.call(rbind,summ),file.path(ROOT,'results/MI_SUMMARIES.csv'),row.names=FALSE);write.csv(data.frame(variable=rownames(imp$predictorMatrix),imp$predictorMatrix,check.names=FALSE),file.path(ROOT,'audit/PREDICTORS_ACTUAL.csv'),row.names=FALSE)
  pdf(file.path(ROOT,'results/MI_CHAINS.pdf'),width=10,height=7);print(plot(imp,c('g','adl')));dev.off()
  list(scope=z,passed=mixed&&valid,status=if(mixed&&valid)'COMPLETE40_WORKING_MI_ADMITTED'else'COMPLETE40_NOT_ADMITTED',m=40,iterations=imp$iteration,N=nrow(b),communities=length(unique(b$cluster)),columns=names(b),missing_income=sum(is.na(d$g)),missing_ADL=sum(is.na(d$adl)),mixing_passed=mixed,all_conditional_fits_valid=valid,conditional_calls=length(fits),input_sha256=h,compatibility=contract$compatibility,full_H4_complete=FALSE)
 },error=function(e)list(scope=z,passed=FALSE,status='IMPUTATION_ERROR_NO_MEMBER_REPLACEMENT',error=conditionMessage(e)))
 write_json(result,file.path(ROOT,'audit/ADMISSION.json'),auto_unbox=TRUE,pretty=TRUE,digits=16);write_json(as.list(warnings),file.path(ROOT,'audit/WARNINGS.json'),auto_unbox=TRUE,pretty=TRUE);writeLines(capture.output(sessionInfo()),file.path(ROOT,'audit/R_SESSION_INFO.txt'))
 progress('H42_INCOME_MI_TERMINAL',paste(result$status));cat('H42_INCOME_MI_NATIVE_TERMINAL',z,'\n')
}
