"""完整SD家族的原生任务登记；不启动其他任务。"""
from pathlib import Path
import contextlib,io,json,sys
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,'<LOCAL_USER_HOME>/.codex/skills/clauder-rstudio-workbench')
from clauder_workbench.cli import main
mode=sys.argv[1];args=['async-guard',mode,'--task-key','pp-lgcm-sd-income-profile-family-20261017']
if mode in ('pre-submit','register-job'):args+=['--session-name','default','--io-mode','durable_files']
if len(sys.argv)>2:args+=['--job-id',sys.argv[2]]
if mode in ('complete','cancel'):args+=['--reason','verified_actual_native_terminal']
b=io.StringIO()
with contextlib.redirect_stdout(b):rc=main(args)
(R/'audit'/('GUARD_'+mode+'.json')).write_text(b.getvalue(),encoding='utf-8');j=json.loads(b.getvalue());assert rc==0 and j['decision']=='PASS',b.getvalue()
print(json.dumps({'decision':j['decision'],'evidence_id':j['evidence_id'],'mode':mode}))
