# 完整40链独立入口复核，直接读取保存MIDS与实际DAT；未完成只登记，不补成员。
verify_income_admissions<-function(scopes=c('sd','gender','oldest','son'),tag=''){
 .libPaths(c('<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_mi_pilot_20261016/library',.libPaths()));library(mice);library(jsonlite);library(digest)
 root<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_sd_income_profile_20261017';records<-list()
 stopifnot(length(scopes)>0,all(scopes%in%c('sd','gender','oldest','son')))
 for(z in scopes){
  d<-file.path(root,'mi_income',z);ap<-file.path(d,'audit/ADMISSION.json')
  # 独立消费者等待经过身份核验的恢复owner，不因原worker退出而提前拒收未完成范围。
  begun<-Sys.time()
  while(!file.exists(ap)){
   lease<-file.path(root,'runtime/INCOME_RECOVERY_OWNER.json');live<-FALSE
   if(file.exists(lease)){
    ow<-fromJSON(lease);if(z%in%ow$scopes)live<-tryCatch({h<-ps::ps_handle(ow$pid);ps::ps_is_running(h)&&abs(as.numeric(ps::ps_create_time(h))-ow$created)<.02},error=function(e)FALSE)
   }
   if(!live)break
   if(as.numeric(difftime(Sys.time(),begun,units='secs'))>28800)stop('Income input owner wait bound reached; inspect actual checkpoint')
   if(exists('clauder_progress',mode='function'))try(clauder_progress('WAIT_OWNED_INCOME_INPUT',paste(z,'registered recovery still running; no duplicate job')),silent=TRUE)
   Sys.sleep(45)
  }
  if(!file.exists(ap)){records[[z]]<-list(status='NOT_ADMITTED_NO_COMPLETE_FAMILY',passed=FALSE);next}
  ad<-fromJSON(ap,simplifyVector=FALSE);if(!isTRUE(ad$passed)){records[[z]]<-list(status=ad$status,passed=FALSE);next}
  a<-readRDS(file.path(d,'private/INPUTS.rds'));imp<-readRDS(file.path(d,'private/MIDS.rds'));stopifnot(imp$m==40,imp$iteration>=10,imp$iteration<=20,identical(imp$data,a$data),digest(file=file.path(d,'private/INPUTS.rds'),algo='sha256')==ad$input_sha256)
  cv<-mice::convergence(imp);tailcv<-cv[cv$vrb%in%c('g','adl')&cv$.it>imp$iteration-5,];stopifnot(nrow(tailcv)==10,all(is.finite(tailcv$psrf)),all(tailcv$psrf<1.1))
  tab<-read.csv(file.path(d,'audit/MEMBER_VALIDATION.csv'));stopifnot(nrow(tab)==40,identical(tab$member,1:40))
  for(k in 1:40){
   v<-complete(imp,k);p<-file.path(d,'private',sprintf('MI%02d.dat',k));stopifnot(digest(file=p,algo='sha256')==tab$sha256[k]);b<-read.table(p,col.names=unlist(ad$columns),na.strings='-9999')
   for(n in names(a$data)){o<-!is.na(a$data[[n]]);stopifnot(identical(as.numeric(v[[n]][o]),as.numeric(a$data[[n]][o])))}
   stopifnot(all(v$g%in%0:1),all(v$adl%in%0:6),all(v$adl[is.na(a$data$adl)]%in%a$data$adl[!is.na(a$data$adl)]),max(abs(v$zg-v$g*v$z0))<1e-12)
   expected<-a$analysis;expected[expected==-9999]<-NA;expected$c7<-v$adl;expected$g<-v$g;expected$zg<-v$zg
   stopifnot(identical(dim(expected),dim(b)),identical(is.na(as.matrix(expected)),is.na(as.matrix(b))),max(abs(as.matrix(expected)-as.matrix(b)),na.rm=TRUE)<1e-11)
   for(n in a$aux)stopifnot(max(abs(v[[paste0('g_',n)]]-v$g*v[[n]]))<1e-12,max(abs(v[[paste0('gz_',n)]]-v$g*v$z0*v[[n]]))<1e-12)
  }
  fit<-lapply(readLines(file.path(d,'audit/FIT_LOG.jsonl')),fromJSON);stopifnot(all(vapply(fit,function(x)isTRUE(x$valid),TRUE)))
  records[[z]]<-list(status='PASS',passed=TRUE,m=40,iterations=imp$iteration,N=ad$N,communities=ad$communities,input_sha256=ad$input_sha256,all_actual_DAT_read=TRUE,original_observed_preserved=TRUE,exact_SMC_claim=FALSE)
  rm(a,imp,v,b,expected);gc(full=TRUE)
 }
 write_json(list(status='ALL_ADMITTED_INPUTS_VERIFIED',scopes=records,admitted=sum(vapply(records,function(x)isTRUE(x$passed),TRUE)),full_H4_complete=FALSE),file.path(root,'audit',paste0('INCOME_DAT_INDEPENDENT',tag,'.json')),pretty=TRUE,auto_unbox=TRUE,digits=16)
 cat('H42_INCOME_DAT_VERIFICATION_NATIVE_TERMINAL\n')
}
