# 只读已经逐家族验收的合并结果；新增SD收入高亮，旧11家族直接复用。
plot_combined_h42<-function(){
 root<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_sd_income_profile_20261017'
 stopifnot(jsonlite::fromJSON(file.path(root,'audit/COMBINED_SUMMARY.json'))$families==12)
 dest<-file.path(root,'results/combined');d<-read.csv(file.path(dest,'H42_REGISTERED.csv'))
 stopifnot(nrow(d)==12,!anyDuplicated(d$family),all(is.finite(d$estimate)),all(d$members==d$m))
 draw<-function(){
  old<-par(mar=c(6,11,4,2));on.exit(par(old));y<-rev(seq_len(nrow(d)))
  xr<-range(c(d$lower,d$upper,0));pad<-diff(xr)*.08;colour<-ifelse(d$family=='sd_INC','#1765a3','#424242')
  plot(d$estimate,y,xlim=xr+c(-pad,pad),ylim=c(.5,nrow(d)+.5),yaxt='n',ylab='',
       xlab='Direct group difference in moderation (dcg), 95% MI interval',pch=19,col=colour,
       main='CHARLS H4.2: 12 conditional working-MI families')
  axis(2,at=y,labels=paste(d$family,' m =',d$m),las=1,cex.axis=.85)
  abline(v=0,lty=2,col='gray50');segments(d$lower,y,d$upper,y,lwd=2,col=colour)
  points(d$estimate,y,pch=19,col=colour)
  mtext('Blue: new SD-income family. Other 11 families reused. Fixed multiplicity family: 12.',side=1,line=4,cex=.7)
  mtext('Conditional working-MI results do not complete the original CFPS moderation hypotheses or full H4.',side=1,line=5,cex=.7)
 }
 pdf(file.path(dest,'H42_GROUP_DIFFERENCES.pdf'),width=10,height=6.5);draw();dev.off()
 png(file.path(dest,'H42_GROUP_DIFFERENCES.png'),width=1800,height=1170,res=180);draw();dev.off()
 cat('COMBINED_H42_FIGURE_SAVED',nrow(d),'families\n')
}
plot_combined_h42()
