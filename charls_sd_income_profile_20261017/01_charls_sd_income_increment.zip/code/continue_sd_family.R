# 已冻结SD数值策略接续；先接口小试，再完整MI，最后单槽Mplus及保存结果复算。
continue_sd<-function(){
 BATCH<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_sd_income_profile_20261017'
 .libPaths(c('<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_mi_pilot_20261016/library',.libPaths()))
 library(jsonlite);library(ps);library(processx)
 owner<-ps_handle();schedule<-fromJSON(file.path(BATCH,'runtime/SCHEDULING.json'));ps_set_cpu_affinity(owner,schedule$cores);ps_set_nice(owner,'above_normal')
 stage<-function(s,m){write_json(list(stage=s,message=m,updated_at=format(Sys.time(),tz='UTC',usetz=TRUE),pid=Sys.getpid(),created=as.numeric(ps_create_time(owner))),file.path(BATCH,'runtime/CONTINUATION.json'),auto_unbox=TRUE,pretty=TRUE);cat(s,m,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(s,m)}
 terminal<-function(status,detail){write_json(list(status=status,detail=detail,full_H4_complete=FALSE),file.path(BATCH,'audit/CONTINUATION_TERMINAL.json'),auto_unbox=TRUE,pretty=TRUE);stage('SD_PROFILE_FAMILY_TERMINAL',status);cat('SD_PROFILE_FAMILY_NATIVE_TERMINAL\n')}
 stage('PROFILE_INTERFACE_PILOT','2 chains x2 rounds; pilot members excluded from formal inference')
 source(file.path(BATCH,'code/income_pilot.R'),local=TRUE)
 run_income_pilot('sd','pilot_profile')
 pilot<-fromJSON(file.path(BATCH,'mi_income/sd/pilot_profile/audit/RECEIPT.json'))
 if(!isTRUE(pilot$passed)){terminal('INTERFACE_PILOT_NOT_ADMITTED',pilot);return(invisible(NULL))}
 stage('PROFILE_FORMAL_MI','40 fresh chains, min10/max20 iterations, unchanged seed and observed data')
 source(file.path(BATCH,'code/run_income_mi.R'),local=TRUE);run_income_mi('sd')
 ad<-fromJSON(file.path(BATCH,'mi_income/sd/audit/ADMISSION.json'))
 if(!isTRUE(ad$passed)){terminal('FORMAL_MI_NOT_ADMITTED',ad);return(invisible(NULL))}
 stage('VERIFY_ACTUAL40_INPUTS','Independent read of all actual saved DAT and MIDS')
 source(file.path(BATCH,'code/verify_income_admissions.R'),local=TRUE);verify_income_admissions('sd')
 verification<-fromJSON(file.path(BATCH,'audit/INCOME_DAT_INDEPENDENT.json'));stopifnot(isTRUE(verification$scopes$sd$passed))
 stage('SD_ONLY_MPLUS','42 remaining calls maximum; prior11 families reused, not estimated')
 source(file.path(BATCH,'code/models.R'),local=TRUE);main_models('INC','sd_INC')
 fam<-rj(file.path(BATCH,'results/FAMILY_STATUS.json'))$sd_INC
 if(fam$status!='FULL_FAMILY_PENDING_POOLING'){terminal('MPLUS_FAMILY_NOT_COMPLETE',fam);return(invisible(NULL))}
 source(file.path(BATCH,'code/pool_h42.R'),local=TRUE);pool_h42('ALL')
 py<-'<LOCAL_USER_HOME>/AppData/Local/Programs/Python/Python314/python.exe'
 stage('INDEPENDENT_PARAMETER_REPLAY','Raw parameters, TECH3, full MI covariance and supported slopes')
 native_env<-Sys.getenv();native_env[c('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS')]<-'1'
 result<-processx::run(py,c('-X','utf8',file.path(BATCH,'verification/verify_pooled_h42.py'),'ALL'),error_on_status=FALSE,timeout=600000,env=native_env)
 writeLines(c(result$stdout,result$stderr),file.path(BATCH,'audit/POOL_REPLAY_LOG.txt'));stopifnot(result$status==0)
 terminal('SD_COMPLETE40_POOLED_INDEPENDENT_PASS',rj(file.path(BATCH,'audit/POOL_INDEPENDENT_ALL.json')))
}
continue_sd()
