# 新条件公式2链2轮接口检查；不计入正式40份，不根据显著性放行。
.libPaths(c('<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_mi_pilot_20261016/library','<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
library(mice);library(miceadds);library(lme4);library(glmmTMB);library(jsonlite);library(digest)
BATCH<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_sd_income_profile_20261017'
stopifnot(packageVersion('mice')=='3.19.10')
install_scaling<-function(){
 scale_x<-function(x,type){for(k in which(type==1))if(length(unique(x[,k]))>2){v<-sd(x[,k]);if(is.finite(v)&&v>0)x[,k]<-(x[,k]-mean(x[,k]))/v};x}
 binary<-get('mice.impute.2l.bin.logged',.GlobalEnv);pmm<-get('mice.impute.2l.pmm.logged',.GlobalEnv)
 assign('mice.impute.2l.bin.logged',function(y,ry,x,type,wy=NULL,...)binary(y,ry,scale_x(x,type),type,wy=wy,...),.GlobalEnv)
 assign('mice.impute.2l.pmm.logged',function(y,ry,x,type,wy=NULL,...)pmm(y,ry,scale_x(x,type),type,wy=wy,...),.GlobalEnv)
}
run_income_pilot<-function(scopes,attempt='pilot'){
 stopifnot(length(scopes)==1,scopes%in%c('sd','gender','oldest','son'))
 stopfile<-file.path(BATCH,'runtime',paste0('INCOME_PILOT_',scopes,'_',attempt,'_TERMINAL'));stopifnot(!file.exists(stopfile));on.exit(writeLines('Actual pilot terminal; inspect per-scope receipt',stopfile),add=TRUE)
 owner<-ps::ps_handle();ps::ps_set_nice(owner,'above_normal')
 watch<-processx::process$new('<LOCAL_USER_HOME>/AppData/Local/Programs/Python/Python314/python.exe',c('-X','utf8',file.path(BATCH,'code/bounded_worker_watch.py'),'--pid',Sys.getpid(),'--created',as.numeric(ps::ps_create_time(owner)),'--seconds','1200','--receipt',file.path(BATCH,'runtime',paste0('INCOME_PILOT_',scopes,'_',attempt,'_WATCH.json')),'--stop',stopfile,'--fit-dir',file.path(BATCH,'mi_income',scopes,attempt,'audit'),'--fit-seconds','120'),stdout=file.path(BATCH,'runtime',paste0('income_pilot_',scopes,'_',attempt,'_watch.log')),stderr='2>&1',cleanup=FALSE)
 ready<-FALSE
 for(ii in 1:360){
  p<-file.path(BATCH,'runtime',paste0('INCOME_PILOT_',scopes,'_',attempt,'_WATCH.json'))
  w<-if(file.exists(p))tryCatch(fromJSON(p),error=function(e)NULL)else NULL
  ready<-!is.null(w)&&w$state=='WATCHING'&&w$owner_pid==Sys.getpid()&&abs(w$owner_created-as.numeric(ps::ps_create_time(owner)))<.02
  if(ready)break
  if(!watch$is_alive())stop('Pilot watchdog exited before identity receipt')
  Sys.sleep(.25)
 }
 stopifnot(isTRUE(ready),watch$is_alive())
 results<-list()
 for(z in scopes){
  ROOT<-file.path(BATCH,'mi_income',z,attempt);for(n in c('audit','runtime','private'))dir.create(file.path(ROOT,n),recursive=TRUE,showWarnings=FALSE)
  receipt<-file.path(ROOT,'audit/RECEIPT.json');if(file.exists(receipt)){results[[z]]<-fromJSON(receipt,simplifyVector=FALSE);next}
  contract<-list(max_conditional_calls=8L)
  progress<-function(stage,message){write_json(list(stage=stage,message=message,utc=format(Sys.time(),tz='UTC',usetz=TRUE),pid=Sys.getpid()),file.path(ROOT,'runtime/progress.json'),pretty=TRUE,auto_unbox=TRUE);cat(stage,message,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(stage,message)}
  source(file.path(BATCH,'code/income_imputers.R'),local=TRUE);fit_env$scope<-z;install_scaling()
  src<-file.path(BATCH,'mi_income',z,'private/INPUTS.rds');a<-readRDS(src);h<-digest(file=src,algo='sha256');warns<-character()
  capture<-function(e)withCallingHandlers(e,warning=function(w){warns<<-c(warns,conditionMessage(w));invokeRestart('muffleWarning')})
  result<-tryCatch({
   fit_env$iteration<-1L;progress('H42_INCOME_PILOT_START',paste(z,'2 fresh chains; no Mplus'))
   imp<-capture(mice(a$data,m=2,maxit=1,method=a$method,predictorMatrix=a$predictors,visitSequence=a$visit,seed=26101761+match(z,c('sd','gender','oldest','son'))-1L,data.init=a$initial,blots=a$blots,remove.collinear=FALSE,remove.constant=FALSE,printFlag=FALSE))
   saveRDS(imp,file.path(ROOT,'private/ITER01.rds'));fit_env$iteration<-2L;imp<-capture(mice.mids(imp,maxit=1,printFlag=FALSE));saveRDS(imp,file.path(ROOT,'private/MIDS.rds'))
   stopifnot(identical(unname(imp$predictorMatrix),unname(a$predictors)),fit_env$fit_n==8)
   for(k in 1:2){v<-complete(imp,k);for(n in names(a$data)){ok<-!is.na(a$data[[n]]);stopifnot(identical(as.numeric(v[[n]][ok]),as.numeric(a$data[[n]][ok])))}
    stopifnot(!anyNA(v),all(v$g%in%0:1),all(v$adl%in%0:6),all(v$adl[is.na(a$data$adl)]%in%a$data$adl[!is.na(a$data$adl)]),max(abs(v$zg-v$g*v$z0))<1e-12,max(abs(v$z_adl-v$z0*v$adl))<1e-12)
    for(n in a$aux)stopifnot(max(abs(v[[paste0('g_',n)]]-v$g*v[[n]]))<1e-12,max(abs(v[[paste0('gz_',n)]]-v$g*v$z0*v[[n]]))<1e-12)
   }
   fits<-lapply(readLines(file.path(ROOT,'audit/FIT_LOG.jsonl')),fromJSON);stopifnot(length(fits)==8,all(vapply(fits,function(f)isTRUE(f$valid),TRUE)),digest(file=src,algo='sha256')==h)
   list(scope=z,status='INTERFACE_PILOT_PASS_NOT_FULL_MI',passed=TRUE,conditional_calls=8,m=2,iterations=2,N=nrow(a$data),input_sha256=h,warnings=warns,full_MI=FALSE,new_Mplus=0)
  },error=function(e)list(scope=z,status='INTERFACE_PILOT_FAILED',passed=FALSE,error=conditionMessage(e),conditional_calls=fit_env$fit_n,warnings=warns,full_MI=FALSE,new_Mplus=0))
  write_json(result,receipt,pretty=TRUE,auto_unbox=TRUE,digits=16);results[[z]]<-result
  write_json(results,file.path(BATCH,'audit',paste0('INCOME_PILOT_',z,'_',attempt,'_RESULTS.json')),pretty=TRUE,auto_unbox=TRUE,digits=16)
  progress('H42_INCOME_PILOT_SCOPE_DONE',paste(z,result$status));rm(a);gc()
 }
 cat('H42_INCOME_PILOT_NATIVE_TERMINAL',sum(vapply(results,function(x)isTRUE(x$passed),TRUE)),'of',length(results),'passed; no formal MI\n')
}
