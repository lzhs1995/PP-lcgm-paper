"""打包SD增量聚合证据；旧11家族只引用固定提交，不重复复制。"""
from pathlib import Path
import csv,hashlib,io,json,re,zipfile
R=Path(__file__).resolve().parents[1]
D=R.parent/'remaining_scope_diagnostic_20261017'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()

def main():
    assert read(R/'audit/CONTINUATION_TERMINAL.json')['status']=='SD_COMPLETE40_POOLED_INDEPENDENT_PASS'
    assert read(R/'audit/POOL_INDEPENDENT_ALL.json')['status']=='PASS'
    assert read(R/'audit/COMBINED_SUMMARY.json')['families']==12
    assert read(R/'audit/FIGURE_VISUAL_REVIEW.json')['status']=='PASS'
    stage=R/'public_stage';stage.mkdir(exist_ok=True)
    assert not list(stage.iterdir()),'Reuse existing release or explicitly version it'
    selected={}
    def add(p,rel=None):
        assert p.is_file() and p.suffix.lower() in {'.json','.csv','.txt','.log','.md','.r','.py','.inp','.out','.dat','.pdf','.png'}
        assert 'private' not in p.parts and 'checkpoints' not in p.parts
        if p.suffix.lower()=='.dat':assert p.name in {'estimates.dat','tech3.dat'}
        rel=rel or p.relative_to(R).as_posix();assert rel not in selected
        selected[rel]=p
    for folder in ['contracts','code']:
        for p in (R/folder).iterdir():
            if p.is_file():add(p)
    for n in ['raw_parameter_reader.py','verify_pooled_h42.py','combine_h42_summary.py','package_increment.py']:
        add(R/'verification'/n)
    for folder in ['results/pool_ALL','results/combined','reports']:
        for p in (R/folder).rglob('*'):
            if p.is_file():add(p)
    for n in ['FAMILY_STATUS.json','CALL_RESULTS.json','SD_INC_START_COMPARISON.json']:
        add(R/'results'/n)
    for n in ['POOL_INDEPENDENT_ALL.json','INCOME_DAT_INDEPENDENT.json','COMBINED_SUMMARY.json',
              'FIGURE_VISUAL_REVIEW.json','CONTINUATION_TERMINAL.json','INITIALIZATION.json']:
        add(R/'audit'/n)
    for n in ['ADMISSION.json','INPUT_DESIGN.json','MEMBER_VALIDATION.csv','CONVERGENCE.csv',
              'PREDICTORS_ACTUAL.csv','R_SESSION_INFO.txt','WARNINGS.json','IMPUTER_INSTRUMENTATION.json']:
        p=R/'mi_income/sd/audit'/n
        if p.exists():add(p)
    for p in (R/'mi_income/sd/results').glob('*'):
        if p.suffix.lower() in {'.csv','.pdf'}:add(p)
    add(R/'mi_income/sd/pilot_profile/audit/RECEIPT.json')
    for n in ['PROFILE_DIAGNOSTIC_RESULT.json','WATCH_TEST.json','WATCH_TEST_RECEIPT.json',
              'SD_DESIGN.json','SD_FIXED_EFFECT_SEPARATION.json','CFPS_H41_EXISTING_MEMBERS.csv']:
        p=D/'audit'/n
        if p.exists():add(p,'diagnostic/audit/'+n)
    for d in (R/'models').iterdir():
        if not d.is_dir():continue
        for n in ['model.inp','model.out','job.json','receipt.json','engine_receipt.json','not_run.json',
                  'validation.json','key_paths.csv','parameter_covariance.csv','parameters_high_precision.csv',
                  'tech1_parameter_map.csv','matrix_values.csv','start_mapping.csv','design_check.json',
                  'mplus_execution.log','estimates.dat','tech3.dat']:
            p=d/n
            if p.exists():add(p)
    add(R/'runtime/budget_status.json')
    payload={};manifest=[]
    for rel,p in sorted(selected.items()):
        raw=p.read_bytes()
        if p.suffix.lower() in {'.pdf','.png'}:data=raw
        else:
            text=raw.decode('utf-8-sig')
            for prefix in ['<LOCAL_USER_HOME>','<LOCAL_USER_HOME>','C:\\\\Users\\\\LZHS','<LOCAL_USER_HOME>','<LOCAL_USER_HOME>']:
                text=text.replace(prefix,'<LOCAL_USER_HOME>')
            assert not re.search(r'(?i)(?:api[_-]?key|access_token)\s*[:=]\s*["\x27]?[A-Za-z0-9_-]{20,}',text),rel
            if p.suffix.lower()=='.csv':
                header={x.lower() for x in next(csv.reader(io.StringIO(text)))}
                assert not header&{'pid','fid','childid','householdid','communityid'},rel
            data=text.encode('utf-8')
        payload[rel]=data
        manifest.append({'path':rel,'bytes':len(data),'sha256':sha(data),'local_source_sha256':sha(raw),
                         'role':'explicit_aggregate_code_or_parameter'})
    payload['PAYLOAD_MANIFEST.json']=json.dumps(manifest,indent=2).encode('utf-8')
    def compress(items):
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for name,data in items:z.writestr(name,data)
        return b.getvalue()
    groups=[sorted(payload.items())]
    while any(len(compress(g))>=25_000_000 for g in groups):
        replacement=[]
        for g in groups:
            if len(compress(g))<25_000_000:replacement.append(g)
            else:
                assert len(g)>1
                middle=len(g)//2;replacement.extend([g[:middle],g[middle:]])
        groups=replacement
    packs=[]
    for i,g in enumerate(groups,1):
        p=stage/f'{i:02d}_charls_sd_income_increment.zip';p.write_bytes(compress(g))
        with zipfile.ZipFile(p) as z:assert z.testzip() is None
        packs.append({'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'files':len(g)})
    for src,dst in [('reports/REPORT_INCREMENT.md','REPORT.md'),
                    ('results/combined/H42_REGISTERED.csv','H42_REGISTERED.csv'),
                    ('results/pool_ALL/ALLCONTRASTS.csv','SD_GROUP_CONTRASTS.csv'),
                    ('results/combined/H42_GROUP_DIFFERENCES.pdf','H42_GROUP_DIFFERENCES.pdf')]:
        assert src in payload,src
        (stage/dst).write_bytes(payload[src])
    public={'packages':packs,'new_complete_families':1,'new_MI_members':40,'combined_complete_families':12,
            'reestimated_old_families':0,'full_H4_complete':False,'original_CFPS_four_complete':False,
            'privacy':'No individual data DAT, RDS, MIDS or participant identifiers; parameter/TECH3 DAT only',
            'prior_commit':'99e03ea8e16da7ae95a2a28d6b52b5d88a942c53'}
    (stage/'PACKAGE_MANIFEST.json').write_text(json.dumps(public,indent=2),encoding='utf-8')
    readme='''# CHARLS SD收入：40份工作MI增量

**四项调节完整推断、完整 H4 仍未完成。**

[报告](REPORT.md) · [12家族汇总](H42_REGISTERED.csv) · [SD收入组内/组差](SD_GROUP_CONTRASTS.csv) · [区间图](H42_GROUP_DIFFERENCES.pdf) · [清单](PACKAGE_MANIFEST.json)

本包只增加SD收入家族。前11家族使用[已有固定提交](https://github.com/lzhs1995/PP-lcgm-paper/tree/99e03ea8e16da7ae95a2a28d6b52b5d88a942c53/charls_h42_mi_20261017)，不重复打包。

将本目录ZIP合并解压到同一目录，可用Python及numpy/pandas/scipy执行 `python verification/verify_pooled_h42.py ALL --public`，从保存参数和TECH3独立复算本批40成员；无需微观数据或Mplus。公开脱敏哈希和本机来源哈希分别保留。合并汇总的前11项沿用上述固定提交，完整模型不在本增量内。

完整工作插补并非潜交互精确相容性证明；CHARLS见面频率不是CFPS情感亲近度的同尺度复现。该研究增量不替换冻结论文，不启动新的NLM审阅，不以显著性选择成员。
'''
    (stage/'README.md').write_text(readme,encoding='utf-8')
    (stage/'FOR_WEB_REVIEWERS.md').write_text('请核对本批完整家族、原始参数/TECH3及固定12项校正，并保留研究边界。旧11家族直接引用固定提交。无个人数据，无需重新拟合。\n\n'+readme,encoding='utf-8')
    (R/'audit/PUBLIC_FILE_SELECTION.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(json.dumps(public))

if __name__=='__main__':main()
