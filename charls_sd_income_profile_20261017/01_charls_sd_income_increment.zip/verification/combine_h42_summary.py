"""只合并两批已验收的家族摘要，不混合MI成员，不重估前11家族。"""
from pathlib import Path
import csv, hashlib, io, json, math

R=Path(__file__).resolve().parents[1]
OLD=R.parent/'charls_h42_mi_20261017'
OLD_COMMIT='99e03ea8e16da7ae95a2a28d6b52b5d88a942c53'
OLD_URL=f'https://github.com/lzhs1995/PP-lcgm-paper/tree/{OLD_COMMIT}/{OLD.name}'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def csv_rows(p):
    with p.open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))

def put(p,text):
    data=text.encode('utf-8')
    if p.exists():
        assert p.read_bytes()==data,'Existing aggregate differs; do not overwrite'
    else:
        p.write_bytes(data)

def main():
    terminal=read(R/'audit/CONTINUATION_TERMINAL.json')
    assert terminal['status']=='SD_COMPLETE40_POOLED_INDEPENDENT_PASS'
    verification=read(R/'audit/POOL_INDEPENDENT_ALL.json')
    assert verification['status']=='PASS' and set(verification['complete_families'])=={'sd_INC'}
    assert verification['complete_families']['sd_INC']['m']==40
    previous=read(OLD/'audit/POOL_INDEPENDENT_ALL.json')
    assert previous['status']=='PASS' and len(previous['complete_families'])==11
    prior_path=OLD/'results/pool_ALL/H42_REGISTERED.csv'
    remote=read(OLD/'audit/REMOTE_VERIFICATION.json')
    assert remote['status']=='PASS' and remote['commit']==OLD_COMMIT
    published=next(x for x in remote['files'] if x['file']=='H42_REGISTERED.csv')
    assert published['sha256']==sha(prior_path)
    old=csv_rows(prior_path);new=csv_rows(R/'results/pool_ALL/H42_REGISTERED.csv')
    assert len(old)==12 and len(new)==1 and new[0]['family']=='sd_INC'
    assert next(x for x in old if x['family']=='sd_INC')['status']=='IMPUTATION_NOT_ADMITTED'
    assert int(new[0]['members'])==int(new[0]['m'])==40
    sources=[];rows=[]
    for x in old:
        fresh=x['family']=='sd_INC'
        p=R/'results/pool_ALL/H42_REGISTERED.csv' if fresh else prior_path
        item=dict(new[0] if fresh else x)
        assert int(item['members'])==int(item['m']) and math.isfinite(float(item['p']))
        item['source_batch']=R.name if fresh else OLD.name
        item['source_csv_sha256']=sha(p)
        rows.append(item)
        sources.append({'family':item['family'],'batch':item['source_batch'],'source_csv_sha256':sha(p),
                        'fixed_public_source':None if fresh else OLD_URL,'members':int(item['members'])})
    # 固定12项校正；已发布11家族的原始估计和P值不变。
    order=sorted(range(12),key=lambda i:float(rows[i]['p']))
    running=0.0
    for k,i in enumerate(order):
        p=float(rows[i]['p']);running=max(running,(12-k)*p)
        rows[i]['Holm_12']=format(min(1.0,running),'.17g')
        rows[i]['Bonferroni_12']=format(min(1.0,12*p),'.17g')
    dest=R/'results/combined';dest.mkdir(exist_ok=True)
    stream=io.StringIO(newline='');writer=csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator='\n')
    writer.writeheader();writer.writerows(rows);put(dest/'H42_REGISTERED.csv',stream.getvalue())
    put(dest/'FAMILY_SOURCE_MAP.json',json.dumps(sources,ensure_ascii=False,indent=2)+'\n')
    table=['| 家族 | MI成员 | 直接组差 | 95% MI区间 | P | Holm（12项） |',
           '|---|---:|---:|---|---:|---:|']
    num=lambda x:format(float(x),'.5g')
    for x in rows:
        table.append(f'| {x["family"]} | {x["members"]} | {num(x["estimate"])} | [{num(x["lower"])}, {num(x["upper"])}] | {num(x["p"])} | {num(x["Holm_12"])} |')
    ci_excluding=sum(float(x['lower'])*float(x['upper'])>0 for x in rows)
    mcse=max(float(x['max_MCSE_over_SE']) for x in rows)
    report=f'''# CHARLS H4.2：SD收入家族增量与12家族汇总

**四项调节完整推断、完整 H4 仍未完成。**

本增量完成SD收入的40份工作插补家族。此前11家族直接复用[已发布固定提交]({OLD_URL})，未重复估计或重打包；合计12个登记条件家族、{sum(int(x['members']) for x in rows)}个MI成员。这不是原稿全部H4或CFPS四项调节的完成证明。

## 本批结果

{chr(10).join(table)}

直接组差为三重交互dcg；12个95%区间中有{ci_excluding}个不跨零。保留效应值、区间及固定12项校正，不以两组星号差异替代直接检验。所报告路径/对比/支持点的最大MCSE/SE为{mcse:.5g}，具体状态以各家族回执为准。区间跨零不能解释为效应不存在。

## 新执行依据与缺失处理

本次只在有新数值诊断依据后重开SD收入插补：保持原数据、公式和随机规则，采用glmmTMB的profile数值选项；独立双起点诊断和两链两轮接口试验通过后，重新生成完整40链。接口试验成员没有进入正式推断。完整MIDS、混合诊断、每份实际DAT读回、双起点Mplus和原始参数/TECH3独立合并均保留。历史未完成首拟合并非受控计时基线，不能据此宣称固定倍数加速。

基期控制仍为年龄、性别、教育、城乡、伴侣、有效子女报告数、ADL和自评健康四列虚拟变量。收入为CHARLS家庭净收入高低组（观察队列固定中位数8730元），G与ADL缺失使用带社区随机截距的条件工作插补，观察值、结构性缺失和X/Y的FIML掩码保留。它不证明MAR或潜交互的精确实质模型相容性。

## 研究范围

CHARLS使用子女见面频率：SD是绝对标准差，其余三个指标是有符号差；它不是CFPS情感亲近度及相对差异指标的同尺度重复。四项CHARLS动态调节的工作MI、基期条件H4.1的12/12家族已另批保存。CFPS条件H4.1仍3/12，其余保存输出的负方差经核对后保留，不原样重跑。原稿关于差异轨迹及资源异质性的完整范围不能用这些条件家族数量替代。

这份增量没有覆盖原稿、冻结收缩稿或原始数据，也不启动新NLM轮次。公开包仅含聚合结果、模型参数及可复算代码；个人DAT、MIDS和逐人记录保持本地。

## 复核入口

- `results/pool_ALL/sd_INC/`：本批40成员的参数、完整协方差和来源映射。
- `audit/POOL_INDEPENDENT_ALL.json`：本批独立参数/TECH3复算。
- `results/combined/H42_REGISTERED.csv`：12家族展示和重新计算的固定12项校正。
- `results/combined/FAMILY_SOURCE_MAP.json`：旧11家族与本批SD的文件级来源；不混合不同家族成员。

旧11家族的完整原始参数包继续使用上方固定链接，不另复制一套。
'''
    (R/'reports').mkdir(exist_ok=True)
    put(R/'reports/REPORT_INCREMENT.md',report)
    receipt={'status':'COMBINED_SAVED_SUMMARIES','families':12,'members':sum(int(x['members']) for x in rows),
             'reestimated_old_families':0,'full_H4_complete':False,'original_CFPS_four_complete':False,
             'old_source_sha256':sha(prior_path),'new_source_sha256':sha(R/'results/pool_ALL/H42_REGISTERED.csv'),
             'combined_sha256':sha(dest/'H42_REGISTERED.csv')}
    put(R/'audit/COMBINED_SUMMARY.json',json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt))

if __name__=='__main__':main()
