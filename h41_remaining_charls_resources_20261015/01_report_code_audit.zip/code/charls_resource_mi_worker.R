# 两个20链子任务，各自独立种子/检查点；拟合输入改变时不沿用旧全量缓存。
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/h41_remaining_charls_resources_20261015'
PREV<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015'
.libPaths(c(file.path(PREV,'library'),.libPaths()));library(mice);library(miceadds);library(jsonlite);library(digest)
worker<-Sys.getenv('CHARLS_MI_WORKER');stopifnot(worker%in%c('A','B'));seed<-if(worker=='A')26101581L else 26101582L
wd<-file.path(ROOT,'private',paste0('MI_',worker));dir.create(wd,showWarnings=FALSE)
input<-readRDS(file.path(ROOT,'private/CHARLS_RESOURCE_INPUTS.rds'));run_start<-Sys.time();iteration<-0L;warns<-list()
update<-function(stage,message){x<-list(worker=worker,stage=stage,message=message,updated_at=format(Sys.time(),tz='UTC',usetz=TRUE));write_json(x,file.path(ROOT,'runtime',paste0('mi_',worker,'_progress.json')),auto_unbox=TRUE,pretty=TRUE);if(exists('clauder_progress',mode='function'))clauder_progress(stage,paste(worker,message))}
fe<-new.env(parent=asNamespace('miceadds'));fe$nfits<-0L;fe$target<-'';fe$worker<-worker;fe$ROOT<-ROOT;fe$update<-update
fe$mice_multilevel_doCall_suppressWarnings<-function(what,args,warnings=TRUE){
 nfits<<-nfits+1L;t<-Sys.time();update('conditional_fit',paste(target,'fit',nfits))
 ans<-if(warnings)do.call(what,args) else suppressWarnings(do.call(what,args))
 conv<-ans@optinfo$conv
 rec<-list(worker=worker,target=target,fit=nfits,seconds=as.numeric(difftime(Sys.time(),t,units='secs')),optimizer_code=conv$opt,messages=conv$lme4$messages,finished_at=format(Sys.time(),tz='UTC',usetz=TRUE))
 cat(jsonlite::toJSON(rec,auto_unbox=TRUE,null='null'),'\n',file=file.path(ROOT,'audit',paste0('MI_',worker,'_FIT_TIMINGS.jsonl')),append=TRUE)
 ans
}
environment(fe$mice_multilevel_doCall_suppressWarnings)<-fe
fe$mice_imputation_2l_lmer<-miceadds:::mice_imputation_2l_lmer;environment(fe$mice_imputation_2l_lmer)<-fe
imputer<-miceadds::mice.impute.2l.pmm;environment(imputer)<-fe
for(v in input$targets){fn<-local({target<-v;function(...){fe$target<-target;imputer(...)}});assign(paste0('mice.impute.2l.pmm.',v,'monitor'),fn,envir=.GlobalEnv)}
capture<-function(expr)withCallingHandlers(expr,warning=function(w){warns[[length(warns)+1L]]<<-data.frame(iteration=iteration,target=fe$target,fit=fe$nfits,type='warning',message=conditionMessage(w));invokeRestart('muffleWarning')},message=function(m){warns[[length(warns)+1L]]<<-data.frame(iteration=iteration,target=fe$target,fit=fe$nfits,type='message',message=conditionMessage(m));invokeRestart('muffleMessage')})
cp<-file.path(wd,'mids.rds')
if(file.exists(cp)){imp<-readRDS(cp);stopifnot(identical(imp$data,input$data))}else{
 iteration<-1L;update('MI_initializing','20 chains, first iteration, fit-level progress')
 imp<-capture(mice(input$data,m=20,maxit=1,method=input$method,predictorMatrix=input$predictorMatrix,seed=seed,donors=5,printFlag=FALSE,remove.collinear=TRUE));saveRDS(imp,cp)
}
while(imp$iteration<20){
 if(as.numeric(difftime(Sys.time(),run_start,units='secs'))>2700)stop('MI worker wall budget reached; checkpoint preserved, no partial pooling')
 iteration<-imp$iteration+1L;update('MI_iteration',paste(iteration,'of20'))
 imp<-capture(mice.mids(imp,maxit=1,donors=5,printFlag=FALSE));saveRDS(imp,cp)
 if(length(warns))write.csv(do.call(rbind,warns),file.path(ROOT,'audit',paste0('MI_',worker,'_WARNINGS.csv')),row.names=FALSE)
}
write.csv(mice::convergence(imp),file.path(ROOT,'audit',paste0('MI_',worker,'_CONVERGENCE.csv')),row.names=FALSE)
if(!is.null(imp$loggedEvents))write.csv(imp$loggedEvents,file.path(ROOT,'audit',paste0('MI_',worker,'_LOGGED_EVENTS.csv')),row.names=FALSE)
write_json(list(status='MI20_GENERATED_PENDING_COMBINED_ADMISSION',worker=worker,m=imp$m,iterations=imp$iteration,seed=seed,fit_calls=fe$nfits,seconds=as.numeric(difftime(Sys.time(),run_start,units='secs')),warnings=length(warns),mids_sha256=digest(file=cp,algo='sha256')),file.path(ROOT,'results',paste0('MI_',worker,'_RECEIPT.json')),auto_unbox=TRUE,pretty=TRUE)
update('MI_worker_complete','20 members saved; no Mplus admission until combined diagnostics')
