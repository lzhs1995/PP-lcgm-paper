# 已批准的小试；不运行完整MI，不改原稿或上游数据。
library(jsonlite);library(digest);library(processx);library(MplusAutomation)
ROOT <- '<LOCAL_USER_HOME>/pp_lgcm_review/reopen_observed_charls_20261015'
Sys.setenv(R2E_ROOT=ROOT)
source(file.path(ROOT,'code/r2e_local.R'),local=TRUE)
# 仅在当前沙盒修复旧检查器：完整剥离起点数值（含科学计数法），保留未知变量检查。
splice_check <- function(spliced,si) {
 missing<-setdiff(stmt_pairs(si$model),stmt_pairs(spliced))
 txt<-gsub('[*@]\\s*[+-]?(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)(?:[eE][+-]?[0-9]+)?',' ',tolower(spliced),perl=TRUE)
 txt<-gsub('\\([^)]*\\)',' ',txt)
 tok<-unique(unlist(regmatches(txt,gregexpr('[a-z][a-z0-9_]*',txt))))
 xw<-tolower(sub('^\\s*([A-Za-z0-9_]+)\\s*\\|.*$','\\1',grep('XWITH',spliced,value=TRUE,ignore.case=TRUE)))
 allowed<-c(tolower(expand_vars(unlist(strsplit(si$use,'\\s+')))),tolower(si$fac),xw,'on','with','by','xwith')
 foreign<-setdiff(tok,allowed)
 list(ok=!length(missing)&&!length(foreign),missing=missing,foreign=foreign)
}
E <- '<LOCAL_USER_HOME>/pp_lgcm_review/round2E_20261010'
F <- '<LOCAL_USER_HOME>/pp_lgcm_review/round2F_20261011'
custom_spec <- function(sp) {
 if(sp=='H41_EDU') {
  si<-spec_info_r2e('SD','H4_EDU','c1-c24')
  si$model<-si$model[!grepl('XWITH|ON sxz|ON sxg|ON sxzg',si$model)]
  si$kind<-'linear';si$key<-si$key[!si$key$label %in% c('dc','bxg','dcg'),];return(si)
 }
 spec_info_r2e('SD',sp,'c1-c24')
}
prepare <- function(id,sp,category,cap,old=NULL) {
 d<-file.path(ROOT,'models',id);dir.create(d,showWarnings=FALSE)
 if(file.exists(file.path(d,'job.json')))return(rj(file.path(d,'job.json')))
 si<-custom_spec(sp);data<-datpath('SD',1L)
 if(!is.null(old)) {
  lines<-readLines(file.path(old,'model.inp'),warn=FALSE)
  stopifnot(!any(grepl('MCONVERGENCE',lines)))
  j<-match('MODEL:',trimws(lines));stopifnot(!is.na(j));lines<-append(lines,'MCONVERGENCE=0.00001;',after=j-1L)
  stopifnot(identical(lines[-which(lines=='MCONVERGENCE=0.00001;')],readLines(file.path(old,'model.inp'),warn=FALSE)))
  data<-file.path(old,'data.dat')
 }else{
  mm<-make_model(si,file.path(E,'models/CFPS_SD_E0_01_base'))
  sc<-splice_check(mm$lines,si);wj(sc,file.path(d,'splice_check.json'))
  stopifnot(isTRUE(sc$ok))
  analysis<-if(si$kind=='linear')'TYPE=COMPLEX; ESTIMATOR=MLR; PROCESSORS=1; COVERAGE=.005; ITERATIONS=2000;' else c('TYPE=COMPLEX RANDOM; ESTIMATOR=MLR; PROCESSORS=1;','ALGORITHM=INTEGRATION; INTEGRATION=30; MCSEED=26101001;','COVERAGE=.005; ITERATIONS=2000; MITERATIONS=4000;','LOGCRITERION=0.00001; RLOGCRITERION=0.000000001; MCONVERGENCE=0.00001;')
  lines<-inp_text(paste('Reopened pilot',id),si$use,wrap90(analysis),mm$lines,define=si$define,kind=if(si$kind=='linear')'linear' else 'lms')
  csv(mm$mapping,file.path(d,'start_mapping.csv'))
 }
 stopifnot(file.copy(data,file.path(d,'data.dat'),overwrite=FALSE));writeLines(lines,file.path(d,'model.inp'))
 job<-list(id=id,root=ROOT,dest=d,spec=sp,category=category,cap_seconds=cap,
   rscript=file.path(R.home('bin'),'Rscript.exe'),mplus=MPLUS,source_input=old,source_data=data,
   hashes=list(model.inp=hashf(file.path(d,'model.inp')),data.dat=hashf(file.path(d,'data.dat'))))
 wj(job,file.path(d,'job.json'));job
}
review <- function(job) {
 d<-job$dest;er<-rj(file.path(d,'engine_receipt.json'))
 if(is.null(er))return(list(id=job$id,status='NOT_RUN_RESOURCE_OR_BUDGET'))
 res<-list(id=job$id,spec=job$spec,seconds=er$seconds,engine_status=er$status,status=er$status,full_MI=FALSE)
 if(er$status=='EXITED')tryCatch({
  # 原生读取与独立高精度读取并存，原始警告单独核对。
  native<-MplusAutomation::readModels(file.path(d,'model.out'),what='all',quiet=TRUE);saveRDS(native,file.path(d,'mplusautomation_readback.rds'))
  m<-read_mplus_raw(d);si<-custom_spec(job$spec)
  dd<-read_dat(file.path(d,'data.dat'),R2D_NAMES);sp<-range(dd$z0,na.rm=TRUE)
  gt<-gate_r2e(m,si,sp);res$status<-classify_local(m,si,gt);res$negative<-gt$negative;res$sy<-mval(m,'PSI','SY','SY')
  res$LL<-m$extra[['H0 Loglikelihood']];res$derivative_lines<-grep('Derivative|MCONVERGENCE',m$lines,value=TRUE)
  if(any(grepl('FIXED TO AVOID SINGULARITY',m$lines,fixed=TRUE)))res$status<-'AUTOFIX_REJECTED'
  csv(m$par,file.path(d,'parameters_high_precision.csv'));csv(key_paths_r2e(m,si$key),file.path(d,'key_paths.csv'))
  csv(m$values,file.path(d,'matrix_values.csv'));csv(m$spec,file.path(d,'tech1_parameter_map.csv'))
  write.table(m$V,file.path(d,'parameter_covariance.csv'),sep=',',row.names=FALSE,col.names=FALSE)
  wj(gt,file.path(d,'validation.json'))
 },error=function(e){res$status<<-'READBACK_OR_ESTIMATION_FAILURE';res$error<<-conditionMessage(e)})
 res$output_sha256<-if(file.exists(file.path(d,'model.out')))hashf(file.path(d,'model.out')) else NULL
 wj(res,file.path(d,'receipt.json'));res
}
run <- function(job) {
 if(file.exists(file.path(job$dest,'receipt.json')))return(rj(file.path(job$dest,'receipt.json')))
 progress('estimate_start',job$id)
 p<-processx::process$new(PY,c('-X','utf8',file.path(ROOT,'code/engine.py'),file.path(job$dest,'job.json')),
   stdout=file.path(job$dest,'supervisor.log'),stderr='2>&1',cleanup=TRUE)
 while(p$is_alive()) {
  p$wait(1000L)
  if(!exists('last')||as.numeric(Sys.time())-last>25){
   h<-rj(file.path(ROOT,'runtime/progress.json'));cat(job$id,if(is.null(h))'starting' else h$stage,'\n');flush.console()
   if(exists('clauder_progress',mode='function'))clauder_progress('estimating',paste(job$id,if(is.null(h))'' else h$elapsed_seconds))
   last<-as.numeric(Sys.time())
  }
 }
 res<-review(job);progress('estimate_end',paste(job$id,res$status));res
}
pilot_main<-function(){jobs<-list(
 prepare('CFPS_SD_E1_DERIV_A','E1','CFPS',300,file.path(F,'models/CFPS_SD_E1_01_F2_q30a')),
 prepare('CFPS_SD_E1_DERIV_B','E1','CFPS',300,file.path(F,'models/CFPS_SD_E1_01_F2_q30b')),
 prepare('CFPS_SD_H41_EDU_MI01','H41_EDU','H4',180),
 prepare('CFPS_SD_H42_EDU_MI01','H4_EDU','H4',600))
wj(jobs,file.path(ROOT,'contracts/PILOT_JOBS.json'))
results<-list()
for(job in jobs) {results[[job$id]]<-run(job);wj(results,file.path(ROOT,'results/CFPS_PILOTS.json'))}
writeLines(capture.output(sessionInfo()),file.path(ROOT,'audit/R_SESSION_INFO.txt'))
progress('CFPS_PILOT_TERMINAL','Four prespecified attempts adjudicated; no full MI launched')
cat('CFPS_PILOT_TERMINAL\n')
}
if(!identical(Sys.getenv('PP_PREPARE_ONLY'),'1'))pilot_main()
