"""核对冻结来源与实际使用的隔离副本；不读取或输出个人记录。"""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
checks=[]
zroot=root.parent/'round2D_20261008';zc=read(zroot/'audit/Z_CONTRACT.json')
for z in ['SEXGAP','OLDEST','SONGAP']:
    for k,h in enumerate(zc['samples'][z+'_Z0']['data_sha256'],1):
        p=zroot/'private'/z/f'Z0_member_{k:02d}.dat';actual=sha(p)
        assert actual==h,(z,k)
        checks.append({'source':z,'member':k,'sha256':actual,'unchanged':True})
rc=read(root/'contracts/CHARLS_RESOURCE_INPUT_CONTRACT.json')
p=root.parent/'charls_adjusted_h41_20261015/private/charls_core_mi_inputs.rds'
assert sha(p)==rc['source_sha256']
checks.append({'source':'CHARLS_core_input','sha256':sha(p),'unchanged':True})
for p in sorted((root/'models').glob('*/job.json')):
    j=read(p)
    for f,h in j['hashes'].items():assert sha(p.parent/f)==h,(p.parent.name,f)
    checks.append({'model':p.parent.name,'frozen_model_and_data_hashes_match':True})
out={'status':'PASS','source_checks':31,'isolated_jobs':len(checks)-31,'checks':checks}
(root/'audit/SOURCE_INTEGRITY.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k!='checks'}))
