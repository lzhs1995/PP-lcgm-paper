# 只合并完整十份家族；城乡/收入使用真实组间差异及联合D1。
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/h41_remaining_charls_resources_20261015'
Sys.setenv(R2E_ROOT=ROOT);source(file.path(ROOT,'code/r2e_local.R'),local=TRUE)
library(mitml)
families<-rj(file.path(ROOT,'results/H41_FAMILIES.json'))
labs<-c('bii','bis','bss','bsyiy','gi0','gs0','gizg','gszg')
summary<-list()
for(nm in names(families)){
 tokens<-strsplit(nm,'_',fixed=TRUE)[[1]];z<-tokens[1];g<-tokens[2]
 f<-families[[nm]];if(is.null(f)||f$status!='TEN_USABLE_PENDING_POOLING')next
 out<-file.path(ROOT,'results',paste0('H41_',nm));dir.create(out,showWarnings=FALSE)
 Q<-matrix(NA_real_,10,8,dimnames=list(NULL,labs));U<-list();sources<-list()
 for(k in 1:10){
  d<-f$members[[sprintf('MI%02d',k)]]$source_dir;r<-rj(file.path(d,'receipt.json'))
  stopifnot(r$status=='USABLE',identical(hashf(file.path(d,'model.out')),r$output_sha256))
  key<-read.csv(file.path(d,'key_paths.csv'));key<-key[match(labs,key$label),];stopifnot(!anyNA(key$parameter))
  V<-as.matrix(read.csv(file.path(d,'parameter_covariance.csv'),header=FALSE))
  Q[k,]<-key$estimate;U[[k]]<-V[key$parameter,key$parameter];dimnames(U[[k]])<-list(labs,labs)
  stopifnot(max(abs(diag(U[[k]])-key$se^2))<1e-6)
  sources[[k]]<-data.frame(member=k,source_dir=d,output_sha256=r$output_sha256,data_sha256=hashf(file.path(d,'data.dat')),SY_residual=r$sy)
 }
 csv(data.frame(label=labs,rubin_pool(Q,U)$table,row.names=NULL),file.path(out,'POOLED_PATHS.csv'))
 jt<-mitml::testConstraints(qhat=lapply(1:10,function(k)setNames(Q[k,],labs)),uhat=U,constraints=c('gizg','gszg'),method='D1')
 j<-data.frame(Z=z,G=g,F=jt$test[1,1],df1=jt$test[1,2],df2=jt$test[1,3],p=jt$test[1,4],RIV=jt$test[1,5],bonferroni_p_12=min(1,12*jt$test[1,4]))
 csv(j,file.path(out,'JOINT_D1.csv'));summary[[nm]]<-j
 cs<-list(IY_Z0_G0=c(gi0=1),IY_Z0_G1=c(gi0=1,gizg=1),IY_difference=c(gizg=1),SY_Z0_G0=c(gs0=1),SY_Z0_G1=c(gs0=1,gszg=1),SY_difference=c(gszg=1))
 ct<-do.call(rbind,lapply(names(cs),function(n){a<-setNames(rep(0,8),labs);a[names(cs[[n]])]<-cs[[n]];data.frame(contrast=n,pool_contrast(Q,U,a),row.names=NULL)}))
 csv(ct,file.path(out,'GROUP_CONTRASTS.csv'));csv(do.call(rbind,sources),file.path(out,'MEMBER_SOURCES.csv'))
 csv(data.frame(member=1:10,Q),file.path(out,'MEMBER_ESTIMATES.csv'))
 uu<-do.call(rbind,lapply(1:10,function(k)data.frame(member=k,expand.grid(row=labs,column=labs,stringsAsFactors=FALSE),covariance=as.vector(U[[k]]))))
 csv(uu,file.path(out,'MEMBER_COVARIANCES.csv'))
 wj(list(status='TEN_MI_POOLED',G=g,N=zc()$samples[[paste0(z,'_Z0')]]$N,households=zc()$samples[[paste0(z,'_Z0')]]$households,members=10,meaning=switch(g,EDU='G0=below junior high,G1=junior high or above',URBAN='G0=rural,G1=urban',INC='G0=no positive personal income,G1=positive personal income; NOT high/low income'),
 limitation='Conditional on frozen corrected FCS; compatibility with interactions not established. This H4.1 baseline Z0 by resource interaction is not dynamic SX by Z0 moderation or H4.2.',method='Rubin scalar and mitml D1; finite MI df, asymptotic complete-data df; fixed12 Bonferroni interim'),file.path(out,'RECEIPT.json'))
}
if(length(summary))csv(do.call(rbind,summary),file.path(ROOT,'results/H41_NEW_FAMILIES_JOINT.csv'))
cat('H41_POOLING_FINISHED',paste(names(summary),collapse=','),'\n')
