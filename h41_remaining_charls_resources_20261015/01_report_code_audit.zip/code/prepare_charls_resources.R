# 资源敏感性输入：家庭收入/消费保留真实负值与零值，只作数值线性缩放。
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/h41_remaining_charls_resources_20261015'
PREV<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015'
.libPaths(c(file.path(PREV,'library'),.libPaths()));library(mice);library(jsonlite);library(digest)
src<-file.path(PREV,'private/charls_core_mi_inputs.rds');a<-readRDS(src);cc<-a$data;d<-a$raw
stopifnot(!anyNA(cc$female),nrow(cc)==3006,!anyDuplicated(d$pid),!anyDuplicated(d$fid))
scale_info<-list()
for(v in c('income','consumption')){
 raw<-d[[paste0('hh_',v)]];mu<-mean(raw,na.rm=TRUE);sd<-sd(raw,na.rm=TRUE)
 stopifnot(is.finite(sd),sd>0);cc[[v]]<-(raw-mu)/sd;scale_info[[v]]<-list(mean=mu,sd=sd,raw_column=paste0('hh_',v))
}
targets<-c('adl','income','consumption');method<-mice::make.method(cc);method[]<-'';method[targets]<-paste0('2l.pmm.',targets,'monitor')
pm<-matrix(0,ncol(cc),ncol(cc),dimnames=list(names(cc),names(cc)))
for(v in targets){pm[v,setdiff(names(cc),c(v,'cluster'))]<-1;pm[v,'cluster']<--2}
stopifnot(identical(as.integer(colSums(is.na(cc[targets]))),c(20L,734L,451L)))
saveRDS(list(data=cc,raw=d,scale=scale_info,targets=targets,method=method,predictorMatrix=pm,source_sha256=digest(file=src,algo='sha256')),file.path(ROOT,'private/CHARLS_RESOURCE_INPUTS.rds'))
write_json(list(N=nrow(cc),communities=length(unique(cc$cluster)),source_sha256=digest(file=src,algo='sha256'),missing=as.list(colSums(is.na(cc[targets]))),scaling=scale_info,
 rule='PMM on linearly scaled raw money; donor mapping returns exact observed raw amounts; passive asinh(income/1000),log1p(consumption); no negative-income truncation',
 recovered_sex_record=file.path(PREV,'audit/SEX_SOURCE_RECOVERY.json'),MI_compatibility='Additive adjusted PP-LGCM sensitivity only; not automatically congenial to future interactions'),file.path(ROOT,'contracts/CHARLS_RESOURCE_INPUT_CONTRACT.json'),auto_unbox=TRUE,pretty=TRUE,digits=16)
write.csv(data.frame(variable=rownames(pm),pm,check.names=FALSE),file.path(ROOT,'audit/CHARLS_RESOURCE_PREDICTORS.csv'),row.names=FALSE)
cat('CHARLS_RESOURCE_INPUT_READY\n')
