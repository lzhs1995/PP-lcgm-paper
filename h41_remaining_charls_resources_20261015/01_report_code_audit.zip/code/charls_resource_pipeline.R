# 后续协调器只消费完整检查点，按阶段推进，不重复提交已有MI或Mplus作业。
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/h41_remaining_charls_resources_20261015'
t0<-Sys.time()
repeat{
 ready<-all(file.exists(file.path(ROOT,'results',paste0('MI_',c('A','B'),'_RECEIPT.json'))))
 if(ready)break
 if(as.numeric(difftime(Sys.time(),t0,units='secs'))>3000)stop('MI receipts unavailable; no model launched')
 if(exists('clauder_progress',mode='function'))clauder_progress('waiting_MI_workers','Waiting original A/B jobs; no duplicate imputations')
 Sys.sleep(20)
}
if(exists('clauder_progress',mode='function'))clauder_progress('MI_combined_admission','Checking40 members, observed cells, donors, optimizer and chains')
source(file.path(ROOT,'code/combine_charls_resource_mi.R'),local=TRUE)
source(file.path(ROOT,'code/charls_resource_models.R'),local=TRUE)
source(file.path(ROOT,'code/pool_charls_resources.R'),local=TRUE)
if(exists('clauder_progress',mode='function'))clauder_progress('CHARLS_RESOURCE_PIPELINE_TERMINAL','Model families and conditional pooling saved')
