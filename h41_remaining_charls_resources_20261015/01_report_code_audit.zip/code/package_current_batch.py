"""显式文件清单发布汇总证据；不打包真实DAT、RDS或个体标识。"""
from pathlib import Path
import json,csv,hashlib,zipfile,io,re
root=Path(__file__).resolve().parents[1];stage=root/'public_stage';stage.mkdir(exist_ok=True)
paths='reports/REPORT.md\nreports/FOR_WEB_REVIEWERS.md\nreports/BATCH_RECEIPT.json\ncontracts/RUN_CONTRACT.json\ncontracts/CHARLS_RESOURCE_INPUT_CONTRACT.json\nresults/CALLS.csv\nresults/H4_REGISTER_UPDATED.csv\nresults/H41_NEW_FAMILY_OVERVIEW.csv\nresults/H41_FAMILIES.json\nresults/MI_A_RECEIPT.json\nresults/MI_B_RECEIPT.json\nresults/CHARLS_RESOURCE_MI_SUMMARIES.csv\nresults/CHARLS_RESOURCE_MI_CHAINS.pdf\nresults/CHARLS_FAMILY_STATUS.json\nresults/CHARLS_POOLING_RECEIPT.json\nresults/CHARLS_RESOURCE_COMPARISON.csv\nresults/CHARLS_RESOURCE_COMPARISON.png\nresults/CHARLS_RESOURCE_COMPARISON.pdf\naudit/INDEPENDENT_POOLING.json\naudit/CHARLS_RESOURCE_MI_ADMISSION.json\naudit/CHARLS_RESOURCE_MEMBER_VALIDATION.csv\naudit/CHARLS_RESOURCE_PREDICTORS.csv\naudit/MI40_CONVERGENCE.csv\naudit/MI_A_FIT_TIMINGS.jsonl\naudit/MI_B_FIT_TIMINGS.jsonl\naudit/MI_A_CONVERGENCE.csv\naudit/MI_B_CONVERGENCE.csv\naudit/MI_FIT_TIMING_SUMMARY.csv\naudit/MI_VISUAL_REVIEW.json\naudit/SECOND_MI_WORKER_ADMISSION.json\naudit/SOURCE_INTEGRITY.json\naudit/CLAUDER_COMPLETION.json\ncode/prepare_charls_resources.R\ncode/charls_resource_mi_worker.R\ncode/combine_charls_resource_mi.R\ncode/charls_resource_models.R\ncode/charls_resource_pipeline.R\ncode/pool_charls_resources.R\ncode/h41_remaining_families.R\ncode/pool_h41_remaining.R\ncode/verify_current_pooling.py\ncode/plot_resource_results.py\ncode/build_batch_report.py\ncode/package_current_batch.py\ncode/engine.py\ncode/run_one.R\ncode/pilot.R\ncode/r2e_local.R\ncode/r2e_tools.R\ncode/r2e_upstream_math.R'.splitlines()
for sp in ['INC','CONS']:
 for f in ['POOLED_PATHS.csv','DF439_SENSITIVITY.csv','RECEIPT.json','MEMBER_SOURCES.csv','MEMBER_ESTIMATES.csv','MEMBER_COVARIANCES.csv','FIT_BY_MEMBER.csv']:
  name='results/CHARLS_'+sp+'/'+f
  if (root/name).exists(): paths.append(name)
for z in ['SEXGAP','OLDEST','SONGAP']:
 for g in ['EDU','URBAN','INC']:
  for f in ['POOLED_PATHS.csv','GROUP_CONTRASTS.csv','JOINT_D1.csv','RECEIPT.json','MEMBER_SOURCES.csv','MEMBER_ESTIMATES.csv','MEMBER_COVARIANCES.csv']:
   name='results/H41_'+z+'_'+g+'/'+f
   if (root/name).exists(): paths.append(name)
  for name in ['results/H41_'+z+'_'+g+'_START_CHECK.json','results/H41_'+z+'_'+g+'_start_check.json','results/'+z+'_'+g+'_START_CHECK.json']:
   if (root/name).exists(): paths.append(name)
paths.extend(['code/coordinator_awake.py','code/verify_source_integrity.py','audit/WINDOWS_SLEEP_EVENTS.json','audit/PHASE_TIMING_DIAGNOSTIC.json','audit/COORDINATOR_AWAKE_RELEASE.json','audit/AWAKE_GUARD_INVALID_OWNER.json'])
selected={n:root/n for n in paths}
model_files=['model.inp','model.out','engine_receipt.json','receipt.json','validation.json','parameters_high_precision.csv','key_paths.csv','matrix_values.csv','tech1_parameter_map.csv','parameter_covariance.csv','estimates.dat','tech3.dat','mplus_execution.log','supervisor_error.json','receipt_before_claim_recovery.json','SPECIFICATION_DELTA.json']
for row in csv.DictReader((root/'results/CALLS.csv').open(encoding='utf-8-sig')):
 d=root/'models'/row['model']
 for f in model_files:
  if (d/f).is_file():selected['models/'+d.name+'/'+f]=d/f
payload={};manifest=[];sha=lambda b:hashlib.sha256(b).hexdigest()
for n,p in selected.items():
 assert p.is_file(),n
 assert not n.startswith('private/') and p.name not in ['data.dat','job.json'] and p.suffix!='.rds'
 b=p.read_bytes();original_sha=sha(b);redacted=False
 if p.suffix.lower() not in ['.pdf','.png']:
  s=b.decode('utf-8-sig')
  for prefix in ['<LOCAL_USER_HOME>','<LOCAL_USER_HOME>','C:\\\\Users\\\\LZHS','<LOCAL_USER_HOME>','<LOCAL_USER_HOME>']:
   if prefix in s:s=s.replace(prefix,'<LOCAL_USER_HOME>');redacted=True
  assert not re.search(r'(?i)(?:api[_-]?key|access_token)\s*[:=]\s*["\']?[A-Za-z0-9_-]{20,}',s)
  if p.suffix=='.csv' and p.name!='parameter_covariance.csv':
   hdr=next(csv.reader(io.StringIO(s)),[]);assert not set(x.lower() for x in hdr)&{'pid','fid','householdid','communityid','id'},(n,hdr)
  b=s.encode('utf-8')
 payload[n]=b;manifest.append({'path':n,'bytes':len(b),'sha256':sha(b),'local_source_sha256':original_sha,'paths_redacted':redacted})
payload['PAYLOAD_MANIFEST.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
packages=[]
for models,fn in [(False,'01_report_code_audit.zip'),(True,'02_model_evidence.zip')]:
 names=[n for n in payload if n.startswith('models/')==models];p=stage/fn
 with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n in names:z.writestr(n,payload[n])
 assert p.stat().st_size<25_000_000
 with zipfile.ZipFile(p) as z:assert z.testzip() is None
 packages.append({'file':fn,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'files':len(names)})
for n in ['REPORT.md','FOR_WEB_REVIEWERS.md','BATCH_RECEIPT.json']:(stage/n).write_bytes(payload['reports/'+n])
pm={'packages':packages,'payload_files':len(payload),'privacy':'Explicit per-file allowlist; no personal DAT/RDS/MI/IDs; estimates.dat and tech3.dat contain aggregate parameters/covariance only'}
(stage/'PACKAGE_MANIFEST.json').write_text(json.dumps(pm,ensure_ascii=False,indent=2),encoding='utf-8')
(root/'audit/PUBLIC_FILE_SELECTION.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
(stage/'README.md').write_text('# H4.1剩余分支与CHARLS资源调整\n\n**四项调节完整推断、完整 H4 仍未完成。**\n\n[报告](REPORT.md) · [网页说明](FOR_WEB_REVIEWERS.md) · [回执](BATCH_RECEIPT.json) · [包清单](PACKAGE_MANIFEST.json)\n\n接续上一批SD三资源H4.1和CHARLS核心20MI，按新合同裁定其余H4.1，并形成收入/消费基期控制与40MI敏感性。没有原样重跑旧失败CFPS规格，没有替换收尾稿件。具体完成数以回执为准。\n\n每包小于25MB，解压到同一目录后运行 `python code/verify_current_pooling.py` 独立复算采用结果。包不含个人数据，不能据此声称云端重新拟合微观数据。原始历史结果仍在前批固定提交。\n\n技能增量见 [mplusautomation-guide PR25](https://github.com/lzhs1995/clauder-rstudio-workbench/pull/25)。\n',encoding='utf-8')
print(json.dumps(pm,ensure_ascii=False))
