"""独立读取保存参数和全协方差复算，不调用R合并器。"""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
from scipy.stats import t as student_t, f as f_dist
root=Path(__file__).resolve().parents[1]

def verify(source,table,labels,joint=None,contrasts=None):
    rows=pd.read_csv(source);qs=[];us=[]
    for row in rows.itertuples():
        d=Path(row.source_dir)
        if not d.exists():d=root/'models'/str(row.source_dir).replace('\\','/').split('/')[-1]
        assert hashlib.sha256((d/'model.out').read_bytes()).hexdigest()==row.output_sha256
        k=pd.read_csv(d/'key_paths.csv').set_index('label').loc[labels]
        p=pd.read_csv(d/'parameters_high_precision.csv').set_index('parameter')
        qs.append(p.loc[k.parameter,'estimate'].to_numpy())
        v=pd.read_csv(d/'parameter_covariance.csv',header=None).to_numpy();ix=k.parameter.to_numpy(dtype=int)-1
        us.append(v[np.ix_(ix,ix)])
    Q=np.array(qs);U=np.array(us);m=len(Q);W=U.mean(0);B=np.cov(Q,rowvar=False,ddof=1);T=W+(1+1/m)*B;e=Q.mean(0)
    def scalar(a):
        est=float(a@e);se=float(np.sqrt(a@T@a));r=(1+1/m)*(a@B@a)/(a@W@a)
        df=(m-1)*(1+1/r)**2 if r>0 else np.inf
        return np.array([est,se,est-student_t.ppf(.975,df)*se,est+student_t.ppf(.975,df)*se])
    ref=pd.read_csv(table).set_index('label').loc[labels];calc=np.array([scalar(a) for a in np.eye(len(labels))])
    assert np.allclose(calc,ref[['estimate','se','lower','upper']].to_numpy(),atol=1e-10,rtol=1e-8)
    result={'status':'PASS','members':m,'paths':len(labels),'maximum_absolute_difference':float(np.max(np.abs(calc-ref[['estimate','se','lower','upper']].to_numpy())))}
    if joint:
        ix=[labels.index('gizg'),labels.index('gszg')];w=W[np.ix_(ix,ix)];b=B[np.ix_(ix,ix)];q=e[ix];k=2
        r=(1+1/m)*np.trace(b@np.linalg.inv(w))/k;F=q@np.linalg.solve((1+r)*w,q)/k
        nu=4+(k*(m-1)-4)*(1+(1-2/(k*(m-1)))/r)**2;p=f_dist.sf(F,k,nu)
        refj=pd.read_csv(joint).iloc[0];assert np.allclose([F,nu,p,r],[refj.F,refj.df2,refj.p,refj.RIV],rtol=2e-6,atol=1e-8)
        result['joint']={'F':F,'p':p,'df1':2,'df2':nu}
    if contrasts:
        cs={'IY_Z0_G0':{'gi0':1},'IY_Z0_G1':{'gi0':1,'gizg':1},'IY_difference':{'gizg':1},'SY_Z0_G0':{'gs0':1},'SY_Z0_G1':{'gs0':1,'gszg':1},'SY_difference':{'gszg':1}}
        cr=pd.read_csv(contrasts).set_index('contrast')
        for name,co in cs.items():
            a=np.array([co.get(l,0) for l in labels]);assert np.allclose(scalar(a),cr.loc[name,['estimate','se','lower','upper']].to_numpy(dtype=float),atol=1e-10,rtol=1e-8)
        result['contrasts']=6
    return result

results={}
for d in sorted((root/'results').glob('H41_*_*')):
    if (d/'POOLED_PATHS.csv').exists():
        results[d.name]=verify(d/'MEMBER_SOURCES.csv',d/'POOLED_PATHS.csv',['bii','bis','bss','bsyiy','gi0','gs0','gizg','gszg'],d/'JOINT_D1.csv',d/'GROUP_CONTRASTS.csv')
for sp in ['INC','CONS']:
    d=root/'results'/('CHARLS_'+sp)
    if (d/'POOLED_PATHS.csv').exists():
        results[d.name]=verify(d/'MEMBER_SOURCES.csv',d/'POOLED_PATHS.csv',['bii','bis','bss','bsyiy'])
assert results, 'No complete family available for independent pooling'
(root/'audit/INDEPENDENT_POOLING.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print(json.dumps(results))
