# CHARLS资源敏感性：每个家族40份真实插补；失败家族停止，另一家族独立推进。
Sys.setenv(PP_PREPARE_ONLY='1')
source('<LOCAL_USER_HOME>/pp_lgcm_review/reopen_observed_charls_20261015/code/charls_pilot.R',local=TRUE)
Sys.unsetenv('PP_PREPARE_ONLY')
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/h41_remaining_charls_resources_20261015';Sys.setenv(R2E_ROOT=ROOT)
base_spec<-specs$PP
for(sp in c('INC','CONS')){specs[[sp]]<-base_spec;specs[[sp]]$model<-c(base_spec$model,'ix sx iy sy ON c1-c12;')}
base_check<-check
check<-function(j){
 jj<-j;jj$spec<-'PP';saved<-specs$PP;specs$PP<<-specs[[j$spec]]
 on.exit({specs$PP<<-saved},add=TRUE)
 r<-base_check(jj);r$spec<-j$spec;r$member<-j$member;r$N_expected<-j$N
 r$adjustment<-paste('11 frozen core columns plus',j$spec,'with community clustering')
 if(r$status=='USABLE_SINGLE_DATASET'&&!identical(as.integer(r[['N',exact=TRUE]]),as.integer(j$N)))r$status<-'SAMPLE_MISMATCH'
 wj(r,file.path(j$dest,'receipt.json'));r
}
prepare_model<-function(sp,k){
 id<-if(k==0L)paste0('CHARLS_',sp,'_CC_COMMUNITY') else sprintf('CHARLS_%s_MI%02d',sp,k)
 d<-file.path(ROOT,'models',id);dir.create(d,showWarnings=FALSE)
 if(file.exists(file.path(d,'job.json')))return(rj(file.path(d,'job.json')))
 nn<-unlist(rj(file.path(ROOT,'audit/CHARLS_RESOURCE_MI_ADMISSION.json'))$columns)
 if(k>0L){dat<-file.path(ROOT,'private',sprintf('CHARLS_%s_MI%02d.dat',sp,k));N<-3006L}
 else{
  original<-readRDS(file.path(ROOT,'private/CHARLS_RESOURCE_INPUTS.rds'));raw<-original$raw;cc<-original$data
  a<-data.frame(cluster=cc$cluster);for(v in c(paste0('x',1:5),paste0('y',1:5)))a[[v]]<-raw[[v]]
  a$c1<-cc$age;a$c2<-raw$female;a$c3<-cc$edu;a$c4<-cc$urban;a$c5<-cc$partner;a$c6<-cc$nchild;a$c7<-cc$adl
  for(i in 2:5)a[[paste0('c',i+6)]]<-cc[[paste0('health',i)]]
  a$c12<-if(sp=='INC')asinh(raw$hh_income/1000) else log1p(raw$hh_consumption)
  a<-a[complete.cases(a[paste0('c',1:12)]),];stopifnot(identical(names(a),nn))
  dat<-file.path(ROOT,'private',paste0(id,'.dat'));N<-nrow(a)
  write.table(a,dat,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
 }
 si<-specs[[sp]]
 lines<-c(paste0('TITLE: ',id,';'),'DATA: FILE=data.dat;','VARIABLE:',wrap90(paste('NAMES=',paste(nn,collapse=' '),';')),wrap90(paste0('USEVARIABLES=',paste(c(tolower(si$obs),'c1-c12'),collapse=' '),';')),'MISSING=ALL(-9999);','CLUSTER=cluster;','ANALYSIS: TYPE=COMPLEX; ESTIMATOR=MLR; PROCESSORS=1;','ITERATIONS=2000; COVERAGE=.005;','MODEL:',si$model,'OUTPUT: TECH1 TECH3 TECH4 TECH8 SVALUES CINTERVAL;','SAVEDATA: RESULTS=estimates.dat; TECH3=tech3.dat;')
 stopifnot(all(nchar(lines)<=90));writeLines(lines,file.path(d,'model.inp'));stopifnot(file.copy(dat,file.path(d,'data.dat')))
 j<-list(id=id,root=ROOT,dest=d,spec=sp,member=k,N=N,category='CHARLS',cap_seconds=180,rscript=file.path(R.home('bin'),'Rscript.exe'),mplus=MPLUS,hashes=list(model.inp=hashf(file.path(d,'model.inp')),data.dat=hashf(file.path(d,'data.dat'))));wj(j,file.path(d,'job.json'));j
}
run_model<-function(j){
 rp<-file.path(j$dest,'receipt.json')
 if(file.exists(rp)){
  prior<-rj(rp)
  if(prior$status=='NOT_RUN_RESOURCE_OR_BUDGET'&&!file.exists(file.path(j$dest,'engine_receipt.json'))&&!file.exists(file.path(j$dest,'model.out'))){stopifnot(file.rename(rp,file.path(j$dest,'receipt_before_claim_recovery.json')))}else return(prior)
 }
 progress('charls_resource_start',j$id)
 p<-processx::process$new(PY,c('-X','utf8',file.path(ROOT,'code/engine.py'),file.path(j$dest,'job.json')),stdout=file.path(j$dest,'supervisor.log'),stderr='2>&1',cleanup=TRUE)
 last<-0;while(p$is_alive()){p$wait(1000L);if(as.numeric(Sys.time())-last>25){if(exists('clauder_progress',mode='function'))clauder_progress('charls_estimating',j$id);last<-as.numeric(Sys.time())}}
 progress('charls_readback',j$id);r<-check(j);progress('charls_resource_end',paste(j$id,r$status));r
}
main<-function(){
 admission<-rj(file.path(ROOT,'audit/CHARLS_RESOURCE_MI_ADMISSION.json'));stopifnot(isTRUE(admission$passed),admission$m==40)
 # 只等登记的H41协调器和单引擎锁；不占用外部会话。
 t0<-Sys.time();repeat{
  hh<-rj(file.path(ROOT,'results/H41_FAMILIES.json'));owner<-rj(file.path(ROOT,'runtime/h41_coordinator.json'))
  live<-if(is.null(owner))FALSE else tryCatch({h<-ps::ps_handle(as.integer(owner$pid));ps::ps_is_running(h)&&abs(as.numeric(ps::ps_create_time(h))-as.numeric(owner$created))<.01},error=function(e)FALSE)
  if(!live&&length(hh)==9&&!any(vapply(hh,function(z)z$status=='RUNNING',logical(1)))&&!file.exists(file.path(ROOT,'runtime/engine.lock')))break
  if(as.numeric(difftime(Sys.time(),t0,units='secs'))>7200)stop('H41 still owns engine slot beyond waiting budget')
  if(exists('clauder_progress',mode='function'))clauder_progress('waiting_registered_engine','H41 owns slot; no duplicate Mplus launch');Sys.sleep(20)
 }
 results<-list();families<-list()
 for(sp in c('INC','CONS')){
  families[[sp]]<-list(status='RUNNING',members=0);wj(families,file.path(ROOT,'results/CHARLS_FAMILY_STATUS.json'))
  j<-prepare_model(sp,0L);cc<-run_model(j);results[[j$id]]<-cc;wj(results,file.path(ROOT,'results/CHARLS_MODELS.json'))
  members<-list()
  for(k in 1:40){j<-prepare_model(sp,k);r<-run_model(j);results[[j$id]]<-r;members[[as.character(k)]]<-r;wj(results,file.path(ROOT,'results/CHARLS_MODELS.json'));if(r$status!='USABLE_SINGLE_DATASET')break}
  families[[sp]]<-list(status=if(length(members)==40L&&all(vapply(members,function(r)r$status=='USABLE_SINGLE_DATASET',logical(1))))'FORTY_USABLE_PENDING_POOLING' else 'INCOMPLETE_STOPPED',members=length(members),complete_case_sensitivity=cc$status)
  wj(families,file.path(ROOT,'results/CHARLS_FAMILY_STATUS.json'))
 }
 progress('CHARLS_RESOURCE_TERMINAL','Both families adjudicated; pool only complete40')
}
main()
