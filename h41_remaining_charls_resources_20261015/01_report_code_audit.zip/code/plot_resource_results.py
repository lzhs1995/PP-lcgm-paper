"""汇总系数区间，不隐藏跨零路径；不同调整规格不当作独立重复。"""
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
root=Path(__file__).resolve().parents[1]
d=pd.read_csv(root/'results/CHARLS_RESOURCE_COMPARISON.csv')
order=['UNADJ','CC','CORE_MI20','INC_CC','INC_MI40','CONS_CC','CONS_MI40']
fig,axs=plt.subplots(1,4,figsize=(14,5.5),sharey=True)
for ax,lab in zip(axs,['bii','bis','bss','bsyiy']):
    z=d[d.label==lab].set_index('model').reindex(order).dropna()
    yy=[order.index(n) for n in z.index]
    ax.errorbar(z.estimate,yy,xerr=[z.estimate-z.lower,z.upper-z.estimate],fmt='o',capsize=3,color='#176b87')
    ax.axvline(0,color='gray',linewidth=.8);ax.set_title(lab);ax.grid(axis='x',alpha=.2)
    ax.xaxis.set_major_locator(MaxNLocator(4));ax.set_xlabel('Estimate and 95% interval')
axs[0].set_yticks(range(len(order)),order);axs[0].invert_yaxis()
fig.suptitle('CHARLS resource-adjusted growth associations: same cohort, different adjustment')
fig.tight_layout()
for ext in ['png','pdf']:fig.savefig(root/'results'/('CHARLS_RESOURCE_COMPARISON.'+ext),dpi=160)
plt.close(fig)
print('CHARLS_RESOURCE_COMPARISON_FIGURES_SAVED')
