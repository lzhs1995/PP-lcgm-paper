# 原始完整TECH3合并；每个家族必须40/40，不平均P值，不混合两个资源模型。
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/h41_remaining_charls_resources_20261015'
PREV<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015'
Sys.setenv(R2E_ROOT=ROOT);source(file.path(ROOT,'code/r2e_local.R'),local=TRUE)
families<-rj(file.path(ROOT,'results/CHARLS_FAMILY_STATUS.json'));labs<-c('bii','bis','bss','bsyiy')
compare<-list();complete<-list()
for(sp in c('INC','CONS')){
 if(families[[sp]]$status!='FORTY_USABLE_PENDING_POOLING')next
 out<-file.path(ROOT,'results',paste0('CHARLS_',sp));dir.create(out,showWarnings=FALSE)
 Q<-matrix(NA_real_,40,4,dimnames=list(NULL,labs));U<-list();src<-list();fit<-list()
 for(k in 1:40){
  d<-file.path(ROOT,'models',sprintf('CHARLS_%s_MI%02d',sp,k));r<-rj(file.path(d,'receipt.json'))
  stopifnot(r$status=='USABLE_SINGLE_DATASET',r[['N',exact=TRUE]]==3006,identical(r$output_sha256,hashf(file.path(d,'model.out'))))
  p<-read.csv(file.path(d,'key_paths.csv'));p<-p[match(labs,p$label),];v<-as.matrix(read.csv(file.path(d,'parameter_covariance.csv'),header=FALSE))
  Q[k,]<-p$estimate;U[[k]]<-v[p$parameter,p$parameter];dimnames(U[[k]])<-list(labs,labs)
  stopifnot(max(abs(diag(U[[k]])-p$se^2))<1e-6)
  src[[k]]<-data.frame(member=k,source_dir=d,output_sha256=r$output_sha256,data_sha256=hashf(file.path(d,'data.dat')))
  ff<-r$fit[[1L]];fit[[k]]<-data.frame(member=k,CFI=ff$CFI,TLI=ff$TLI,RMSEA=ff$RMSEA_Estimate,SRMR=ff$SRMR)
 }
 tab<-data.frame(label=labs,rubin_pool(Q,U)$table,row.names=NULL);stopifnot(max(tab$MCSE_over_SE)<.1)
 csv(tab,file.path(out,'POOLED_PATHS.csv'));csv(data.frame(label=labs,rubin_pool(Q,U,nu_com=439)$table,row.names=NULL),file.path(out,'DF439_SENSITIVITY.csv'))
 csv(do.call(rbind,src),file.path(out,'MEMBER_SOURCES.csv'));csv(do.call(rbind,fit),file.path(out,'FIT_BY_MEMBER.csv'))
 csv(data.frame(member=1:40,Q),file.path(out,'MEMBER_ESTIMATES.csv'))
 csv(do.call(rbind,lapply(1:40,function(k)data.frame(member=k,expand.grid(row=labs,column=labs,stringsAsFactors=FALSE),covariance=as.vector(U[[k]])))),file.path(out,'MEMBER_COVARIANCES.csv'))
 d<-file.path(ROOT,'models',paste0('CHARLS_',sp,'_CC_COMMUNITY'));r<-rj(file.path(d,'receipt.json'))
 if(r$status=='USABLE_SINGLE_DATASET'){
  p<-read.csv(file.path(d,'key_paths.csv'));p<-p[match(labs,p$label),]
  compare[[paste0(sp,'_CC')]]<-data.frame(model=paste0(sp,'_CC'),N=r[['N',exact=TRUE]],label=labs,estimate=p$estimate,se=p$se,lower=p$estimate-qnorm(.975)*p$se,upper=p$estimate+qnorm(.975)*p$se)
 }
 compare[[sp]]<-data.frame(model=paste0(sp,'_MI40'),N=3006,label=labs,tab[c('estimate','se','lower','upper')])
 complete[[sp]]<-list(status='FORTY_MI_POOLED',m=40,N=3006,communities=440,MCSE_over_SE_max=max(tab$MCSE_over_SE))
 wj(complete[[sp]],file.path(out,'RECEIPT.json'))
}
old<-read.csv(file.path(PREV,'results/CHARLS_CORE_COMPARISON.csv'));compare$prior<-old
csv(do.call(rbind,compare),file.path(ROOT,'results/CHARLS_RESOURCE_COMPARISON.csv'))
wj(list(status='RESOURCE_FAMILIES_ADJUDICATED',families=complete,
 scale='Baseline2011 standardized continuous X/Y; actual-year time0,2,4,7,9; community-cluster MLR',
 estimand='Additive resource-adjusted growth association; income and consumption separate sensitivity models; not dynamic moderation or H4',
 limitations='Unweighted selected cohort; MAR/PMM working imputation; no causal or cross-window claim; additive MI compatibility does not establish interaction compatibility',
 method='Rubin finite-MI df, full TECH3; complete-data df439 sensitivity separately reported'),file.path(ROOT,'results/CHARLS_POOLING_RECEIPT.json'))
cat('CHARLS_RESOURCE_POOLING_FINISHED',paste(names(complete),collapse=','),'\n')
