# 合并两个真实20链任务，核对原始观测和每个PMM供体，再派生两个资源尺度。
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/h41_remaining_charls_resources_20261015'
PREV<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015'
.libPaths(c(file.path(PREV,'library'),.libPaths()));library(mice);library(jsonlite);library(digest)
inputs<-readRDS(file.path(ROOT,'private/CHARLS_RESOURCE_INPUTS.rds'));cc<-inputs$data;raw<-inputs$raw
stopifnot(identical(digest(file=file.path(PREV,'private/charls_core_mi_inputs.rds'),algo='sha256'),inputs$source_sha256))
parts<-lapply(c('A','B'),function(w){r<-fromJSON(file.path(ROOT,'results',paste0('MI_',w,'_RECEIPT.json')));p<-file.path(ROOT,'private',paste0('MI_',w),'mids.rds');stopifnot(r$status=='MI20_GENERATED_PENDING_COMBINED_ADMISSION',r$m==20,r$iterations==20,identical(digest(file=p,algo='sha256'),r$mids_sha256));readRDS(p)})
stopifnot(identical(parts[[1]]$data,parts[[2]]$data));imp<-mice::ibind(parts[[1]],parts[[2]]);stopifnot(imp$m==40,imp$iteration==20)
saveRDS(imp,file.path(ROOT,'private/CHARLS_RESOURCE_MI40.rds'))
cv<-subset(mice::convergence(imp),vrb%in%inputs$targets);write.csv(cv,file.path(ROOT,'audit/MI40_CONVERGENCE.csv'),row.names=FALSE)
last<-subset(cv,.it==20);stopifnot(all(is.finite(last$psrf)),all(last$psrf<1.1))
fits<-unlist(lapply(c('A','B'),function(w)lapply(readLines(file.path(ROOT,'audit',paste0('MI_',w,'_FIT_TIMINGS.jsonl'))),fromJSON)),recursive=FALSE)
stopifnot(length(fits)==2400L)
badfit<-vapply(fits,function(z)is.null(z$optimizer_code)||any(unlist(z$optimizer_code)!=0),logical(1))
stopifnot(!any(badfit))
warnfiles<-file.path(ROOT,'audit',paste0('MI_',c('A','B'),'_WARNINGS.csv'));warnings<-lapply(warnfiles[file.exists(warnfiles)],read.csv)
# 非收敛不能因占比低而自动略过；留给诊断裁定，不发出模型准入。
if(length(warnings)){
 ww<-do.call(rbind,warnings);write.csv(ww,file.path(ROOT,'audit/MI40_WARNINGS.csv'),row.names=FALSE)
 if(any(grepl('failed to converge|degenerate|unable|unidentif|Hessian',ww$message,ignore.case=TRUE)))stop('Conditional-fit warnings require explicit diagnosis before admission')
}
valid<-list();summ<-list()
for(k in 1:40){
 z<-complete(imp,k);stopifnot(!anyNA(z[inputs$targets]))
 for(v in inputs$targets){idx<-!is.na(cc[[v]]);stopifnot(identical(z[[v]][idx],cc[[v]][idx]))}
 restored<-list()
 for(v in c('income','consumption')){
  original<-raw[[paste0('hh_',v)]];ix<-which(!is.na(original));out<-original;missing<-which(is.na(original));donor<-match(z[[v]][missing],cc[[v]][ix]);stopifnot(!anyNA(donor));out[missing]<-original[ix[donor]];restored[[v]]<-out
 }
 stopifnot(all(z$adl%in%0:6),all(restored$consumption>=0))
 a<-data.frame(cluster=cc$cluster);for(v in c(paste0('x',1:5),paste0('y',1:5)))a[[v]]<-raw[[v]]
 a$c1<-z$age;a$c2<-z$female;a$c3<-z$edu;a$c4<-z$urban;a$c5<-z$partner;a$c6<-z$nchild;a$c7<-z$adl
 for(i in 2:5)a[[paste0('c',i+6)]]<-z[[paste0('health',i)]]
 for(resource in c('INC','CONS')){
  b<-a;b$c12<-if(resource=='INC')asinh(restored$income/1000) else log1p(restored$consumption)
  stopifnot(all(complete.cases(b[paste0('c',1:12)])),identical(b[paste0('x',1:5)],raw[paste0('x',1:5)]),identical(b[paste0('y',1:5)],raw[paste0('y',1:5)]))
  p<-file.path(ROOT,'private',sprintf('CHARLS_%s_MI%02d.dat',resource,k));write.table(b,p,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
  valid[[length(valid)+1L]]<-data.frame(resource=resource,member=k,N=nrow(b),observed_preserved=TRUE,XY_masks_preserved=TRUE,raw_donors_verified=TRUE,data_sha256=digest(file=p,algo='sha256'))
 }
 summ[[k]]<-data.frame(member=k,mean_income=mean(restored$income),median_income=median(restored$income),negative_income=sum(restored$income<0),mean_consumption=mean(restored$consumption),median_consumption=median(restored$consumption),mean_adl=mean(z$adl))
}
write.csv(do.call(rbind,valid),file.path(ROOT,'audit/CHARLS_RESOURCE_MEMBER_VALIDATION.csv'),row.names=FALSE);write.csv(do.call(rbind,summ),file.path(ROOT,'results/CHARLS_RESOURCE_MI_SUMMARIES.csv'),row.names=FALSE)
pdf(file.path(ROOT,'results/CHARLS_RESOURCE_MI_CHAINS.pdf'),width=10,height=7);print(plot(imp,inputs$targets));dev.off()
write_json(list(passed=TRUE,status='FORTY_MI_ADMITTED',m=40,N=3006,communities=440,seeds=c(26101581,26101582),iterations=20,final_diagnostics=last,fit_warnings=if(length(warnings))nrow(ww) else 0,
 columns=names(b),source_sha256=inputs$source_sha256,original_observations_preserved=TRUE,raw_money_donor_mapping=TRUE,negative_income_preserved=TRUE,
 limitations='Additive core-plus-resource sensitivity FCS under MAR; not a guarantee of latent interaction compatibility; no population weighting'),file.path(ROOT,'audit/CHARLS_RESOURCE_MI_ADMISSION.json'),auto_unbox=TRUE,pretty=TRUE,digits=16)
cat('CHARLS_RESOURCE_MI40_ADMITTED\n');print(last)
