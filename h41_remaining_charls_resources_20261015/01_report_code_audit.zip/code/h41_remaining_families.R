# 新H4.1条件模型，不重跑历史失败E0/E1；使用合法SW输出提供起点。
NEW<-'<LOCAL_USER_HOME>/pp_lgcm_review/h41_remaining_charls_resources_20261015'
Sys.setenv(PP_PREPARE_ONLY='1');source(file.path(NEW,'code/pilot.R'),local=TRUE);Sys.unsetenv('PP_PREPARE_ONLY')
ROOT<-NEW;Sys.setenv(R2E_ROOT=ROOT)
custom_spec<-function(sp){
 p<-strsplit(sp,'_',fixed=TRUE)[[1]];stopifnot(length(p)==3,p[1]=='H41')
 z<-p[2];g<-p[3];si<-spec_info_r2e(z,paste0('H4_',g),controls(z))
 si$model<-si$model[!grepl('XWITH|ON sxz|ON sxg|ON sxzg',si$model)];si$kind<-'linear';si$key<-si$key[!si$key$label%in%c('dc','bxg','dcg'),];si$z<-z;si$group<-g;si
}
prepare_new<-function(z,g,k,second=FALSE){
 id<-sprintf('CFPS_%s_H41_%s_MI%02d%s',z,g,k,if(second)'_startB' else '');d<-file.path(ROOT,'models',id);dir.create(d,showWarnings=FALSE)
 if(file.exists(file.path(d,'job.json')))return(rj(file.path(d,'job.json')))
 si<-custom_spec(paste('H41',z,g,sep='_'));dd<-read_dat(datpath(z,k),R2D_NAMES);cfg<-zc()$samples[[paste0(z,'_Z0')]]
 stopifnot(identical(hashf(datpath(z,k)),cfg$data_sha256[[k]]),nrow(dd)==cfg$N)
 ctrl<-paste0('c',unlist(cfg$ctrl_index));a<-dd[c('z0',if(g=='INC')'ginc',ctrl)];a$zg<-dd$z0*dd[[si$g]]
 mat<-cbind(1,as.matrix(a));stopifnot(!anyNA(mat));rk<-qr(mat)$rank
 wj(list(N=nrow(mat),columns=ncol(mat),rank=rk,full_rank=rk==ncol(mat)),file.path(d,'design_rank.json'));stopifnot(rk==ncol(mat))
 mm<-make_model(si,swpath(k),perturb=second);sc<-splice_check(mm$lines,si);stopifnot(isTRUE(sc$ok));wj(sc,file.path(d,'splice_check.json'));csv(mm$mapping,file.path(d,'start_mapping.csv'))
 e0<-spec_info_r2e(z,'E0',controls(z));delta<-setdiff(stmt_pairs(si$model),stmt_pairs(e0$model));stopifnot(length(delta)>=4L)
 wj(list(new_specification=TRUE,new_paths=delta,unchanged_failed_E0_rerun=FALSE,legal_start_source=swpath(k),source_population_is_initialization_only=TRUE),file.path(d,'SPECIFICATION_DELTA.json'))
 lines<-inp_text(id,si$use,wrap90(analysis_r2e('linear')),mm$lines,define=si$define,kind='linear');writeLines(lines,file.path(d,'model.inp'));stopifnot(file.copy(datpath(z,k),file.path(d,'data.dat')))
 j<-list(id=id,root=ROOT,dest=d,spec=paste('H41',z,g,sep='_'),z=z,group=g,member=k,second_start=second,category='H41',cap_seconds=180,rscript=file.path(R.home('bin'),'Rscript.exe'),mplus=MPLUS,hashes=list(model.inp=hashf(file.path(d,'model.inp')),data.dat=hashf(file.path(d,'data.dat'))));wj(j,file.path(d,'job.json'));j
}
main<-function(){
 all<-rj(file.path(ROOT,'results/H41_FAMILIES.json'));if(is.null(all))all<-list()
 for(z in c('SEXGAP','OLDEST','SONGAP'))for(g in c('EDU','URBAN','INC')){
  nm<-paste(z,g,sep='_');if(!is.null(all[[nm]])&&all[[nm]]$status!='RUNNING')next
  all[[nm]]<-list(status='RUNNING',members=list());wj(all,file.path(ROOT,'results/H41_FAMILIES.json'))
  progress('new_H41_family',nm);a<-prepare_new(z,g,1);ra<-run(a);results<-list(MI01=c(ra,list(source_dir=a$dest)))
  if(ra$status!='USABLE'){all[[nm]]<-list(status='PILOT_NOT_USABLE',members=results);wj(all,file.path(ROOT,'results/H41_FAMILIES.json'));next}
  b<-prepare_new(z,g,1,TRUE);rb<-run(b);co<-if(rb$status=='USABLE')compare_numeric(list(key=read.csv(file.path(a$dest,'key_paths.csv')),receipt=ra),list(key=read.csv(file.path(b$dest,'key_paths.csv')),receipt=rb)) else list(passed=FALSE,reason=rb$status)
  wj(co,file.path(ROOT,'results',paste0(nm,'_START_CHECK.json')))
  if(!isTRUE(co$passed)){all[[nm]]<-list(status='START_CHECK_FAILED',members=results);wj(all,file.path(ROOT,'results/H41_FAMILIES.json'));next}
  for(k in 2:10){j<-prepare_new(z,g,k);r<-run(j);results[[sprintf('MI%02d',k)]]<-c(r,list(source_dir=j$dest));all[[nm]]<-list(status='RUNNING',members=results);wj(all,file.path(ROOT,'results/H41_FAMILIES.json'));if(r$status!='USABLE')break}
  all[[nm]]<-list(status=if(length(results)==10&&all(vapply(results,function(x)x$status=='USABLE',logical(1))))'TEN_USABLE_PENDING_POOLING' else 'INCOMPLETE_STOPPED',members=results);wj(all,file.path(ROOT,'results/H41_FAMILIES.json'))
 }
 progress('H41_REMAINING_TERMINAL','All nine new specifications adjudicated; no failed scientific specification retried')
}
main()
