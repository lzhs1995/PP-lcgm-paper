"""只根据真实终态、完整家族与既有证据更新台账。"""
from pathlib import Path
import json, datetime, hashlib
import pandas as pd
root=Path(__file__).resolve().parents[1]
prev=root.parent/'charls_adjusted_h41_20261015'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
families=read(root/'results/H41_FAMILIES.json')
assert len(families)==9 and all(f['status']!='RUNNING' for f in families.values())
budget=read(root/'runtime/budget_status.json');calls=[]
for a in budget['rows']:
    d=root/'models'/a['id'];r=read(d/'receipt.json');e=read(d/'engine_receipt.json')
    assert a['state'] not in ['RUNNING','RESERVED']
    calls.append({'model':a['id'],'category':a['category'],'seconds':a['seconds'],'engine_status':e['status'],'adjudication':r['status'],'output_sha256':r.get('output_sha256'),'source_dir':str(d)})
pd.DataFrame(calls).to_csv(root/'results/CALLS.csv',index=False)
register=pd.read_csv(prev/'results/H4_REGISTER_UPDATED.csv')
overview=[]
for name,f in families.items():
    z,g=name.split('_');members=f.get('members',{})
    last=list(members.values())[-1] if members else {}
    pooled=root/'results'/('H41_'+name)/'RECEIPT.json';complete=pooled.exists()
    select=(register.family=='H4.1')&(register.Z==z)&(register.G==g)
    register.loc[select,'pilot_this_batch']=True
    register.loc[select,'formal_MI']='TEN_ESTIMATES_POOLED_CONDITIONAL_ON_FROZEN_MI' if complete else f['status']
    register.loc[select,'inference']='Complete conditional10; original FCS interaction compatibility limitation remains' if complete else 'No full MI inference; '+last.get('status','no member')+'; not evidence of zero effect'
    overview.append({'family':name,'status':f['status'],'full_MI_pooled':complete,'members_attempted':len(members),'usable_members':sum(x['status']=='USABLE' for x in members.values()),'last_member_status':last.get('status'),'negative':str(last.get('negative',[])),'SY_residual':last.get('sy')})
register.to_csv(root/'results/H4_REGISTER_UPDATED.csv',index=False)
pd.DataFrame(overview).to_csv(root/'results/H41_NEW_FAMILY_OVERVIEW.csv',index=False)
charls=read(root/'results/CHARLS_POOLING_RECEIPT.json');mi=read(root/'audit/CHARLS_RESOURCE_MI_ADMISSION.json')
verification=read(root/'audit/INDEPENDENT_POOLING.json')
fits=[json.loads(line) for w in ['A','B'] for line in (root/'audit'/f'MI_{w}_FIT_TIMINGS.jsonl').read_text().splitlines() if line.strip()]
timing=pd.DataFrame(fits).groupby(['worker','target']).seconds.agg(['count','sum','mean','max']).reset_index()
timing.to_csv(root/'audit/MI_FIT_TIMING_SUMMARY.csv',index=False)
hcount=int((register.formal_MI=='TEN_ESTIMATES_POOLED_CONDITIONAL_ON_FROZEN_MI').sum())
receipt={'status':'BOUNDED_EXTENSION_COMPLETE','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'H41_complete_conditional_families':hcount,'H41_registered_total':12,'four_dynamic_moderations_complete':False,'full_H4_complete':False,'CHARLS_resource_families':charls['families'],'Mplus_calls':len(calls),'engine_launcher_seconds':sum(x['seconds'] for x in calls),'failed_old_CFPS_specifications_repeated':0,'new_manuscript':False,'new_NLM':0,'raw_data_published':False,'independent_verification':verification}
(root/'reports/BATCH_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
ht='\n'.join(f"| {r['family']} | {r['members_attempted']} | {r['usable_members']} | {r['status']} | {r['last_member_status']} |" for r in overview)
ct=[]
for sp in ['INC','CONS']:
    p=root/'results'/('CHARLS_'+sp)/'POOLED_PATHS.csv'
    if p.exists():
        for r in pd.read_csv(p).itertuples():ct.append(f'| {sp} | {r.label} | {r.estimate:.6f} | [{r.lower:.6f}, {r.upper:.6f}] |')
body=f'''# H4.1剩余分支与CHARLS资源调整增量

**四项调节完整推断、完整 H4 仍未完成。**

本批接续已公开的[SD资源分支及CHARLS核心20MI](https://github.com/lzhs1995/PP-lcgm-paper/tree/6808a4c4bae974235657b6cd6edc50330d7a38d9/charls_adjusted_h41_20261015)和[SD教育完整家族](https://github.com/lzhs1995/PP-lcgm-paper/tree/bb4225651978e8588b8c9eb3d1ca43193a5cbbaa/h41_mi_charls_covariates_20261015)。原稿、原始数据、已收尾的范围收缩稿保持原样。新增工作全部位于隔离目录；未原样重跑旧CFPS E0/E1失败规格。

## H4.1实际推进

本批新增性别差、排行差、长子差各三种资源分组，模型增加观测Z0×G对四个增长因子的路径，并保留相应主效应。它们与旧E0/E1并非相同规格。初值来自合法SW成员，不能把初值来源当作当前样本的推断。每个家族先核对MI01及独立扰动起点，合法稳定后接续其余九份；首个不可采用成员出现即停止该家族，原输出保留。

| 新家族 | 实际MI成员数 | 可采用成员数 | 家族终态 | 最后成员裁定 |
|---|---:|---:|---|---|
{ht}

起点检查是额外调用，不算新增插补成员。未形成完整十份的家族不合并，也不把失败解释为无效应。当前H4.1共有{hcount}/12个家族完成冻结插补条件下的合并；既有SD×教育/城乡/正个人收入三项联合D1 P分别为0.304077、0.610263、0.896602，直接复用前批，不新增估计。INC不是高低收入组。

H4.1此处是基期差异关联的资源异质性，不能替代SX×Z0动态调节或H4.2。冻结CFPS插补模型与这些交互的相容性仍未证明，合法估计、完整成员和小FMI均不能消除此限制。完整12项Holm尚不能报告；已报告固定12项Bonferroni仅为阶段界限。

## CHARLS基期资源控制与缺失处理

队列仍为3006人、3006家庭、440社区；2011基期60岁以上，见面频率有效子女报告构成暴露，不能等同CFPS情感亲近度。时间载荷0、2、4、7、9；X/Y基期标准化、原有缺失掩码保留给FIML。核心控制沿用前批；收入和消费分别增加，不作为互相独立的重复验证。

原始缺失ADL20例、家庭收入734例、家庭消费451例。社区随机截距PMM使用5供体，两个独立种子的20链任务各迭代20轮，合并为40份真实MI。收入/消费只先作线性缩放改善条件拟合，填充值映射回真实原始供体；随后派生asinh(收入/1000)与log1p(消费)。负收入与零消费保留，不截成正数。

每份核对原观测、供体支持及X/Y缺失掩码；2400次条件拟合逐次记录。其最终链诊断、优化器代码和实际警告见准入收据及原始日志。PSRF<1.1是本批项目诊断门槛，不是MAR成立的证明。链图随包；潜变量交互相容性不由本次加法资源敏感性得到保证。

完整案例保留原始2011性别缺失标记；MI沿用前批已记录的跨访谈来源恢复。完整案例与MI样本不同，因此其结果差异不能单独归因于插补方法。

| 调整资源 | 路径 | 合并估计 | 95%条件MI区间 |
|---|---|---:|---:|
{chr(10).join(ct)}

bii=IX→IY，bis=IX→SY，bss=SX→SY，bsyiy=IY→SY。每个采用家族要求40/40，按参数向量和全TECH3协方差Rubin合并，有限MI自由度；另列439完整数据自由度敏感性。单份拟合逐一列示，不平均P值或拟合指标。原核心20MI和社区未调整对照直接复用，以比较表展示。

两套资源调整模型的bii区间均低于零，bss及其余变化路径区间跨零；这支持本工作模型下的初始水平负关联，未给出明确变化关联证据。收入完整案例2260人、消费完整案例2545人；MI均3006人。MCSE/SE最大值分别0.01194和0.00898。

这些是未加人口权重的选定队列纵向关联，不能解释成因果收益，也未完成CHARLS动态调节、资源异质性或跨窗口/形状稳健性。

## 效率与证据

本批{len(calls)}次实际引擎/启动器调用，总计{sum(x['seconds'] for x in calls):.3f}秒。这个总和不含全部插补、排队和读回时间，不等于任务端到端时间。两个R插补worker并行，Mplus保持单槽；第二worker准入基于实测Windows可用内存和提交余量，未关闭其他任务。当前插补条件数据随轮次变化，所以没有复用前批单变量ADL的全拟合缓存，避免陈旧拟合和不断增长的缓存。

收入MI07引擎/启动器约23秒，之后回执间隔约1622秒。Windows Kernel-Power事件506/507显示13:43:39因Idle Timeout进入Modern Standby、14:10:39键盘唤醒，与该间隔吻合。因此此次延迟有系统休眠证据，不是该模型耗时27分钟，也不是已证明的内存不足。已增加绑定协调器PID/创建时间、最多两小时的临时系统与显示空闲保护，任务退出自动释放；不修改全局电源计划，不阻止用户主动睡眠或合盖。以前批次的未知间隔不据此自动归因。[微软执行状态说明](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-setthreadexecutionstate)明确CPU活动不一定阻止系统空闲睡眠。

全部采用结果经过独立Python从高精度参数及全协方差复算。公开包采用逐文件白名单，只含汇总、代码、模型语法和结果；真实DAT、MI/RDS和个人标识不公开。失败输入输出与其裁定保留，不为增加成功率改写历史。

## 下一步边界

本批完成的是已登记的新H4.1分支裁定及CHARLS基期资源调整。剩余动态调节和完整H4仍是开放研究目标；不能因本批失败而说效应不存在，也不自动原样重跑。下一步需基于当前可采用CHARLS父模型定义家内差异指标、结构性缺失与可比估计对象，再冻结小试。CFPS如需新方法，应先说明它如何解决已定位的边界/识别问题，不把追求显著性作为修改依据。

本批不替换论文、不新增NLM轮次。
'''
(root/'reports/REPORT.md').write_text(body,encoding='utf-8')
(root/'reports/FOR_WEB_REVIEWERS.md').write_text('''# 网页复核说明

先读REPORT.md及BATCH_RECEIPT.json。本批是收尾稿之后经授权的新研究增量。请区分H4.1条件MI、四项动态调节、H4.2和CHARLS加法资源调整；这些不是同一估计对象。

请重点复核新H4.1规格与旧失败规格的差别、停止家族是否遵循冻结规则、CHARLS两组真实20链合并、原观测和原始供体保留、合并协方差与缺失假设。未形成完整家族不等于零效应。不要用一项合法模型的小FMI推断另一未运行模型。

包不含个人数据，云端可复算保存参数/TECH3及合并，不能声称重新拟合了微观CFPS或CHARLS。解压两包到同一目录后运行python code/verify_current_pooling.py；所需Python包为numpy、pandas、scipy。每个ZIP小于25MB，校验值和逐文件清单随包。
''',encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
