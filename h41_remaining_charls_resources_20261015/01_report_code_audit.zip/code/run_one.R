# 只在已隔离目录执行一个确切输入；外层监督器负责预算和进程树超时。
args <- commandArgs(TRUE)
stopifnot(length(args)==2L, file.exists(args[1]), file.exists(args[2]))
.libPaths(c('<LOCAL_USER_HOME>/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
library(MplusAutomation)
setwd(dirname(normalizePath(args[1],winslash='/')))
cat('MPLUS_AUTOMATION_START',as.character(packageVersion('MplusAutomation')),'\n');flush.console()
MplusAutomation::runModels(target=basename(args[1]),recursive=FALSE,showOutput=FALSE,
                          replaceOutfile='never',Mplus_command=args[2])
cat('MPLUS_AUTOMATION_END\n');flush.console()
