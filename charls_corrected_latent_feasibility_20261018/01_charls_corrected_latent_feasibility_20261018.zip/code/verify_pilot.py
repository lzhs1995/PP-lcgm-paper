"""从实际 INP/OUT、保存参数和 TECH3 独立核验本批；不调用估计器。"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import csv,datetime,hashlib,json,re,sqlite3
import numpy as np
import pandas as pd
import psutil
from raw_parameter_reader import raw_model
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
psutil.Process().cpu_affinity([8,9,10,11])
contract=read(R/'contracts/RUN_CONTRACT.json')
calls=read(R/'results/CALL_RESULTS.json');branches=read(R/'results/BRANCH_STATUS.json')
assert (R/'runtime/PILOT_TERMINAL').exists()
assert not (R/'runtime/engine.lock').exists()
owner=read(R/'runtime/pilot_coordinator.json')['owner']
try: live=abs(psutil.Process(owner['pid']).create_time()-owner['created'])<.01
except psutil.NoSuchProcess:live=False
assert not live,'Original coordinator still active; wait, never resubmit'
assert set(branches)==set(contract['indicators'])
rows=[];parameter_count=0
for name,r in calls.items():
 d=R/'models'/name;j=read(d/'job.json')
 assert all(sha(d/f)==h for f,h in j['hashes'].items())
 out=(d/'model.out').read_text(encoding='latin1') if (d/'model.out').exists() else ''
 if 'output_sha256' in r:assert sha(d/'model.out')==r['output_sha256']
 er=read(d/'engine_receipt.json') if (d/'engine_receipt.json').exists() else None
 if er:assert er['hashes']==j['hashes']
 item=dict(id=name,indicator=j['z'],type=j['type'],shape=j['shape'],status=r['status'],N=j['N'],new_MI=0,
           engine_seconds=er['seconds'] if er else 0,engine_cpu_seconds=er.get('sampled_tree_cpu_seconds',0) if er else 0,
           peak_tree_rss_mib=er.get('peak_tree_rss',0)/2**20 if er else 0,normal_termination='THE MODEL ESTIMATION TERMINATED NORMALLY' in out,
           raw_parameters_verified=False,free_negative_variances='',output_sha256=sha(d/'model.out') if out else '')
 if (d/'parameters_high_precision.csv').exists():
  text,mapping,q,se,v,key,ll=raw_model(d);parameter_count+=len(q)
  p=pd.read_csv(d/'parameters_high_precision.csv')
  neg=p[p.matrix.str.lower().isin(['psi','theta'])&p.row.eq(p.column)&p.estimate.lt(0)]
  item['free_negative_variances']=';'.join(str(x.row)+':'+format(x.estimate,'.8g') for x in neg.itertuples())
  item['raw_parameters_verified']=True;item['free_parameters']=len(q)
  if r['status']=='USABLE_CC_DIAGNOSTIC':
   assert item['normal_termination'] and neg.empty and len(q)==j['expected_free']
   corr=v/np.outer(np.sqrt(np.diag(v)),np.sqrt(np.diag(v)))
   assert np.linalg.eigvalsh(corr).min()>1e-10
   assert not re.search(r'FIXED TO AVOID SINGULARITY|STANDARD ERRORS.*COULD NOT BE COMPUTED',text)
   assert r['N']==j['N'] and abs(ll-r['LL'])<1e-3
 elif r['status']=='USABLE_CC_DIAGNOSTIC':raise AssertionError('Accepted model lacks raw parameter exports')
 rows.append(item)
for z,b in branches.items():
 assert b['complete_MI'] is False
 choices=[r for r in calls.values() if r.get('z')==z and r.get('type')=='Z' and r['status']=='USABLE_CC_DIAGNOSTIC']
 path=R/'results'/f'{z.upper()}_SHAPE_CHOICE.json'
 if choices:
  choice=read(path);best=min(choices,key=lambda r:r['BIC'])
  assert choice['selected']==best['shape']
 else:assert not any(r.get('z')==z and r.get('type') in ('E0','E1') for r in calls.values())
with sqlite3.connect(R/'runtime/budget.sqlite') as db:budget=db.execute('select id,state,seconds from calls').fetchall()
assert len(budget)<=contract['max_mplus_calls'] and all(s is not None for _,_,s in budget)
assert set(i for i,_,_ in budget)=={x['id'] for x in rows if (R/'models'/x['id']/'engine_receipt.json').exists()}
seconds=sum(s for _,_,s in budget)
assert seconds<=contract['total_engine_seconds']+10
pd.DataFrame(rows).to_csv(R/'results/INDEPENDENT_MODEL_LEDGER.csv',index=False)
out=dict(status='PASS',verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),calls=len(budget),engine_seconds=seconds,
 raw_free_parameters_verified=parameter_count,accepted_diagnostics=sum(x['status']=='USABLE_CC_DIAGNOSTIC' for x in rows),
 branch_status={z:b['status'] for z,b in branches.items()},new_MI=0,original_four_complete=False,full_H4_complete=False,
 scope='Raw saved parameters, TECH1 identity, TECH3, hashes, branch ordering and frozen BIC selection; full-case feasibility only')
(R/'audit/INDEPENDENT_MODELS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False),flush=True)
