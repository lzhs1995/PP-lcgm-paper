"""公开包零估计复算：原始 TECH1/RESULTS/TECH3 与派生参数表一致性。"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import json
import numpy as np
from raw_parameter_reader import raw_model
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
rows=[]
for name,r in read(R/'results/CALL_RESULTS.json').items():
 d=R/'models'/name
 if not (d/'parameters_high_precision.csv').exists():
  assert r['status']!='USABLE_CC_DIAGNOSTIC'
  rows.append(dict(id=name,status=r['status'],verified=False,reason='No complete saved parameter/SE export; failure retained'))
  continue
 text,mapping,q,se,v,key,ll=raw_model(d)
 assert abs(ll-r['LL'])<.001
 if r['status']=='USABLE_CC_DIAGNOSTIC':
  assert 'THE MODEL ESTIMATION TERMINATED NORMALLY' in text
  assert len(q)==read(d/'job.json')['expected_free']
  assert np.linalg.eigvalsh(v/np.outer(np.sqrt(np.diag(v)),np.sqrt(np.diag(v)))).min()>1e-10
 rows.append(dict(id=name,status=r['status'],verified=True,parameters=len(q)))
out=dict(status='PASS',calls=len(rows),raw_parameters_verified=sum(x.get('parameters',0) for x in rows),rows=rows,
         scope='Saved-output verification only, no microdata or re-estimation',original_four_complete=False,full_H4_complete=False)
(R/'audit/PUBLIC_RAW_REPLAY.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k!='rows'}),flush=True)
