"""从严格名册CSV与锁定来源读回表独立核对样本和实际DAT；只输出汇总。"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
entries=read(R/'contracts/DATA_ENTRIES.json');sources=read(R/'contracts/SOURCES.json')
for s in sources.values():assert sha(Path(s['file']))==s['sha256']
strict=pd.read_csv(sources['strict_csv']['file'],dtype={'pid':str});results={}
for z,e in entries.items():
 src=pd.read_csv(R/'private'/f'{z}_SOURCE_REFERENCE.csv',dtype={'pid':str})
 sel=pd.read_csv(R/'private'/f'{z}_SELECTION.csv',dtype={'pid':str})
 assert src.pid.equals(sel.pid) and src.pid.is_unique
 d=strict.loc[strict.indicator.eq(z)&strict.pid.isin(src.pid)]
 states=d.pivot(index='pid',columns='year',values='status').reindex(src.pid)
 val=d.pivot(index='pid',columns='year',values='absolute').reindex(src.pid)
 assert states.shape==(len(src),5) and states[2011].eq('DEFINED').all()
 a=states.apply(lambda col:col.str.startswith('STRUCTURAL_')).any(axis=1).to_numpy()
 b=states.eq('AMBIGUOUS_EARLIEST_BIRTH_YEAR').any(axis=1).to_numpy()
 n=states.eq('DEFINED').sum(axis=1).to_numpy();cc=src[[f'c{k}' for k in range(1,12)]].notna().all(axis=1).to_numpy()
 keep=~a&~b&(n>=2)&cc
 for name,want in [('any_structural',a),('any_ambiguous',b),('defined_waves',n),('controls_complete',cc),('in_pilot',keep)]:assert np.array_equal(sel[name],want),name
 actual=pd.read_csv(e['file'],sep=r'\s+',header=None,names=e['columns'],na_values=-9999)
 assert len(actual)==int(keep.sum())==e['N'] and actual.cluster.nunique()==e['communities']
 assert sha(Path(e['file']))==e['sha256']
 keepcols=[c for c in e['columns'] if not c.startswith('z')]
 assert np.allclose(actual[keepcols],src.loc[keep,keepcols],atol=1e-10,rtol=1e-10,equal_nan=True)
 expected=(val.to_numpy()[keep]-e['z_mean'])/e['z_sd']
 assert np.allclose(actual[[f'z{k}' for k in range(1,6)]],expected,atol=1e-10,rtol=1e-10,equal_nan=True)
 assert np.array_equal(np.isnan(expected),states.loc[keep].ne('DEFINED').to_numpy())
 results[z]=dict(status='PASS',N=e['N'],communities=e['communities'],excluded_observed_structural=int(a.sum()),excluded_ambiguous=int(b.sum()),actual_data_sha256=e['sha256'])
out=dict(status='PASS',scopes=results,scope='Independent strict CSV derivation and original-source readback against actual DAT; no new raw-survey audit',new_models=0,new_MI=0,original_four_complete=False)
(R/'audit/INDEPENDENT_INPUTS.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out),flush=True)
