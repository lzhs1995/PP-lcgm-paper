# 严格名册五期Z：保留全部样本流程；可估计性小试不代替完整MI。
local({
 R<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_latent_feasibility_20261018'
 Q<-'<LOCAL_USER>/pp_lgcm_review/charls_latent_trajectory_readiness_20261018'
 Z<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_baseline_h41_20261018'
 library(jsonlite);library(digest)
 strictfile<-file.path(Q,'private/STRICT_FIVEWAVE_CONTRASTS.rds');csvfile<-file.path(Q,'private/STRICT_FIVEWAVE_CONTRASTS.csv')
 strict<-readRDS(strictfile);strictcsv<-read.csv(csvfile,colClasses=c(pid='character'))
 stopifnot(nrow(strict)==nrow(strictcsv),identical(as.character(strict$pid),strictcsv$pid),identical(strict$status,strictcsv$status),max(abs(strict$absolute-strictcsv$absolute),na.rm=TRUE)<1e-10)
 source_entries<-fromJSON(file.path(Z,'contracts/SOURCE_ENTRIES.json'),simplifyVector=FALSE)
 contract<-fromJSON(file.path(R,'contracts/RUN_CONTRACT.json'),simplifyVector=FALSE)
 entries<-list();flow<-list();miss<-list();desc<-list();yr<-c(2011,2013,2015,2018,2020)
 sources<-list(strict_rds=list(file=strictfile,sha256=digest(file=strictfile,algo='sha256')),strict_csv=list(file=csvfile,sha256=digest(file=csvfile,algo='sha256')))
 for(z in unlist(contract$indicators)){
  e<-source_entries[[z]];stopifnot(digest(file=e$file,algo='sha256')==e$sha256);a<-readRDS(e$file)
  states<-matrix('',nrow(a$analysis),5);values<-matrix(NA_real_,nrow(a$analysis),5)
  for(k in 1:5){d<-strict[strict$indicator==z&strict$year==yr[k],];ix<-match(a$pid,d$pid);stopifnot(!anyNA(ix));states[,k]<-d$status[ix];values[,k]<-(d$absolute[ix]-e$z_mean)/e$z_sd}
  stopifnot(all(states[,1]=='DEFINED'),max(abs(values[,1]-a$analysis$z0))<1e-10,identical(is.na(values),states!='DEFINED'))
  n<-rowSums(!is.na(values));struct<-apply(states,1,function(x)any(grepl('^STRUCTURAL_',x)));amb<-rowSums(states=='AMBIGUOUS_EARLIEST_BIRTH_YEAR')>0
  cfg<-!struct&!amb;n2<-n>=2;cc<-complete.cases(a$analysis[paste0('c',1:11)]);keep<-cfg&n2&cc
  d<-a$analysis[keep,setdiff(names(a$analysis),'z0'),drop=FALSE]
  for(k in 1:5)d[[paste0('z',k)]]<-values[keep,k]
  stopifnot(!anyNA(d[paste0('c',1:11)]),all(rowSums(!is.na(d[paste0('z',1:5)]))>=2),all(rowSums(!is.na(d[paste0('x',1:5)]))>=2),all(rowSums(!is.na(d[paste0('y',1:5)]))>=2))
  des<-cbind(1,as.matrix(d[paste0('c',1:11)]));stopifnot(qr(des)$rank==ncol(des))
  path<-file.path(R,'private',paste0(z,'_CC.dat'));stopifnot(!file.exists(path));write.table(d,path,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
  # 私有逐人来源对照只在本机核验，不公开。
  ref<-data.frame(pid=as.character(a$pid),baseline_source_eligible=TRUE,any_structural=struct,any_ambiguous=amb,defined_waves=n,controls_complete=cc,in_pilot=keep)
  write.csv(ref,file.path(R,'private',paste0(z,'_SELECTION.csv')),row.names=FALSE)
  write.csv(data.frame(pid=as.character(a$pid),a$analysis,check.names=FALSE),file.path(R,'private',paste0(z,'_SOURCE_REFERENCE.csv')),row.names=FALSE,na='')
  stages<-c('current_baseline_defined','no_observed_structural_or_ambiguous','plus_two_Z_waves','plus_complete_11_controls')
  flow[[z]]<-data.frame(indicator=z,stage=stages,N=c(nrow(ref),sum(cfg),sum(cfg&n2),sum(keep)))
  for(k in 1:5){tab<-table(states[keep,k]);miss[[paste(z,k)]]<-data.frame(indicator=z,year=yr[k],status=names(tab),N=as.integer(tab));v<-d[[paste0('z',k)]];desc[[paste(z,k)]]<-data.frame(indicator=z,year=yr[k],N=sum(!is.na(v)),mean=mean(v,na.rm=TRUE),sd=sd(v,na.rm=TRUE),min=min(v,na.rm=TRUE),max=max(v,na.rm=TRUE))}
  entries[[z]]<-list(file=path,sha256=digest(file=path,algo='sha256'),N=nrow(d),communities=length(unique(d$cluster)),columns=names(d),z_mean=e$z_mean,z_sd=e$z_sd,source_file=e$file,source_sha256=e$sha256,source_selection_csv=file.path(R,'private',paste0(z,'_SELECTION.csv')),X_Y_masks_preserved=TRUE,structural_or_ambiguous_filled=FALSE)
  sources[[z]]<-list(file=e$file,sha256=e$sha256)
  if(exists('clauder_progress',mode='function'))clauder_progress('latent_input',paste(z,'CC',nrow(d),'no imputation'))
 }
 write.csv(do.call(rbind,flow),file.path(R,'results/SAMPLE_FLOW.csv'),row.names=FALSE)
 write.csv(do.call(rbind,miss),file.path(R,'results/Z_MISSING_REASONS.csv'),row.names=FALSE)
 write.csv(do.call(rbind,desc),file.path(R,'results/Z_WAVE_DESCRIPTIVES.csv'),row.names=FALSE)
 write_json(entries,file.path(R,'contracts/DATA_ENTRIES.json'),auto_unbox=TRUE,pretty=TRUE,digits=NA)
 write_json(sources,file.path(R,'contracts/SOURCES.json'),auto_unbox=TRUE,pretty=TRUE)
 for(s in sources)stopifnot(digest(file=s$file,algo='sha256')==s$sha256)
 cat('LATENT_INPUTS_PREPARED_ZERO_MODELS\n')
})
