# 潜在家内差异轨迹可估计性：20次上限；CC不是完整MI；禁止方差归零修模。
local({
 .libPaths(c('<LOCAL_USER>/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
 library(jsonlite);library(digest);library(processx);library(ps);library(MplusAutomation)
 ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_corrected_latent_feasibility_20261018'
 Sys.setenv(R2E_ROOT=ROOT,OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1,MKL_NUM_THREADS=1)
 ps_set_cpu_affinity(ps_handle(),8:11)
 source(file.path(ROOT,'code/r2e_local.R'),local=TRUE)
 contract<-rj(file.path(ROOT,'contracts/RUN_CONTRACT.json'));entries<-rj(file.path(ROOT,'contracts/DATA_ENTRIES.json'))
 stopifnot(rj(file.path(ROOT,'audit/INDEPENDENT_INPUTS.json'))$status=='PASS')
 FAC_ALL<-c('IX','SX','IY','SY','IZ','SZ');OBS_ALL<-c(paste0('X',1:5),paste0('Y',1:5),paste0('Z',1:5))
 growth<-function(p,shape='linear')paste0('i',p,' s',p,' | ',p,'1@0 ',p,'2',if(shape=='linear')'@2 'else'*2 ',p,'3',if(shape=='linear')'@4 'else'*4 ',p,'4',if(shape=='linear')'@7 'else'*7 ',p,'5@9;')
 keyrow<-function(label,mat,row,col)data.frame(label=label,matrix=mat,row=row,column=col)
 si_for<-function(type,shape){
  if(type=='Z')return(list(kind='linear',fac=c('IZ','SZ'),obs=paste0('Z',1:5),fixed_zero=character(),model=c(growth('z',shape),'iz WITH sz;'),fixed_cov=character(),use='z1-z5',key=rbind(keyrow('mean_iz','ALPHA','1','IZ'),keyrow('mean_sz','ALPHA','1','SZ'),keyrow('var_iz','PSI','IZ','IZ'),keyrow('var_sz','PSI','SZ','SZ'))))
  base<-c(growth('x'),growth('y'),growth('z',shape),'iy ON ix (bii);','iy ON iz (bzi);','sy ON ix (bis);','sy ON sx (bss);','sy ON iy (bsyiy);','sy ON iz (biz);','sy ON sz (bsz);',
   'ix WITH sx iz sz;','sx WITH iz sz iy;','iz WITH sz;','sz WITH iy;',paste0('x',1:5,' WITH y',1:5,' z',1:5,';'),paste0('y',1:5,' WITH z',1:5,';'),'ix sx iy sy iz sz ON c1-c11;')
  key<-rbind(keyrow('bii','BETA','IY','IX'),keyrow('bzi','BETA','IY','IZ'),keyrow('bis','BETA','SY','IX'),keyrow('bss','BETA','SY','SX'),keyrow('bsyiy','BETA','SY','IY'),keyrow('biz','BETA','SY','IZ'),keyrow('bsz','BETA','SY','SZ'))
  if(type=='E1'){base<-c(base,'sxiz | sx XWITH iz;','sy ON sxiz (dc);');key<-rbind(key,keyrow('dc','BETA','SY','SXIZ'))}
  list(kind=if(type=='E1')'lms_latent'else'linear',fac=FAC_ALL,obs=OBS_ALL,fixed_zero=character(),model=base,fixed_cov=c('iy WITH ix@0 iz@0 sy@0;','sy WITH ix@0 sx@0 iz@0 sz@0;'),use='x1-x5 y1-y5 c1-c11 z1-z5',key=key)
 }
 slots_for<-function(si,shape){
  a<-list();add<-function(op,lhs,rhs='',value=0)a[[length(a)+1L]]<<-data.frame(op=op,lhs=toupper(lhs),rhs=toupper(rhs),value=value,source='new_start')
  if(shape=='latent_basis')for(k in 2:4)add('BY','SZ',paste0('Z',k),c(2,4,7)[k-1])
  for(f in si$fac)add('MEAN',f)
  for(o in si$obs)add('VAR',o,value=.5)
  for(f in si$fac)add('VAR',f,value=if(substr(f,1,1)=='S').01 else .5)
  for(k in stmt_pairs(si$model)){v<-strsplit(toupper(k),' ',fixed=TRUE)[[1]];add(v[2],v[1],v[3])}
  d<-do.call(rbind,a);d$key<-paste(d$op,d$lhs,d$rhs,sep=':');stopifnot(!anyDuplicated(d$key));d
 }
 source_object<-function(path,fac,obs){m<-read_mplus_raw(path);list(path=path,m=m,fac=fac,obs=obs,meas=canonical_measurement(m,fac,obs),sha=hashf(file.path(path,'model.out')))}
 source_value<-function(s,k){m<-s$m;has<-function(mat,r,c)any(.cell(m$values,mat,r,c));r<-k$lhs;c<-k$rhs
  if(k$op=='MEAN')return(if(has('ALPHA','1',r))mval(m,'ALPHA','1',r)else NA_real_)
  if(k$op=='BY')return(if(has('LAMBDA',c,r))mval(m,'LAMBDA',c,r)else NA_real_)
  if(k$op=='VAR')return(if(r%in%s$obs)s$meas$THETA[r,r]else if(has('PSI',r,r))mval(m,'PSI',r,r)else NA_real_)
  if(k$op=='WITH')return(if(r%in%s$obs&&c%in%s$obs)s$meas$THETA[r,c]else if(has('PSI',r,c))mval(m,'PSI',r,c)else NA_real_)
  if(k$op=='ON')return(if(has('BETA',r,c))mval(m,'BETA',r,c)else if(has('GAMMA',r,c))mval(m,'GAMMA',r,c)else NA_real_)
  NA_real_
 }
 compile<-function(si,shape,sources,start){d<-slots_for(si,shape)
  for(i in seq_len(nrow(d)))for(s in sources){v<-source_value(s,d[i,]);if(is.finite(v)){d$value[i]<-v;d$source[i]<-paste0(s$path,'#',s$sha);break}}
  if(start=='B'){j<-d$op%in%c('ON','MEAN','BY');d$value[j]<-d$value[j]+.02*ifelse(seq_len(sum(j))%%2,1,-1)}
  if(si$kind=='lms_latent')d$value[d$key=='ON:SY:SXIZ']<-if(start=='A').1 else -.1
  stopifnot(all(d$value[d$op=='VAR']>0))
  line<-vapply(seq_len(nrow(d)),function(i){k<-d[i,];v<-trimws(formatC(k$value,digits=12,format='g'));a<-tolower(k$lhs);b<-tolower(k$rhs);switch(k$op,MEAN=paste0('[',a,'*',v,'];'),VAR=paste0(a,'*',v,';'),paste(a,k$op,paste0(b,'*',v,';')))},'')
  list(lines=c(si$model,line,si$fixed_cov),mapping=d,expected_free=nrow(d))
 }
 prepare<-function(z,type,shape,start='A',chosen=NULL){
  e<-entries[[z]];id<-paste('CHARLS_LATENT',toupper(z),type,toupper(shape),start,sep='_');d<-file.path(ROOT,'models',id);dir.create(d,showWarnings=FALSE)
  if(file.exists(file.path(d,'job.json')))return(rj(file.path(d,'job.json')))
  stopifnot(hashf(e$file)==e$sha256);si<-si_for(type,shape);sources<-list()
  if(type=='E0'){
   parent<-file.path('<LOCAL_USER>/pp_lgcm_review/charls_corrected_baseline_h41_20261018/models',paste0('CHARLS_',toupper(z),'_H41_PARENT_MI01_A'))
   stopifnot(rj(file.path(parent,'receipt.json'))$status=='USABLE_SINGLE_DATASET')
   sources<-list(source_object(parent,c('IX','SX','IY','SY'),c(paste0('X',1:5),paste0('Y',1:5))),source_object(chosen,c('IZ','SZ'),paste0('Z',1:5)))
  }
  if(type=='E1')sources<-list(source_object(chosen,FAC_ALL,OBS_ALL))
  mm<-compile(si,shape,sources,start);csv(mm$mapping,file.path(d,'start_mapping.csv'))
  an<-if(type=='E1')c('TYPE=COMPLEX RANDOM; ESTIMATOR=MLR; PROCESSORS=1;','ALGORITHM=INTEGRATION; INTEGRATION=30; MCSEED=26101891;','ITERATIONS=2000; MITERATIONS=4000; COVERAGE=.005;','LOGCRITERION=.00001; RLOGCRITERION=.000000001; MCONVERGENCE=.00001;')else c('TYPE=COMPLEX; ESTIMATOR=MLR; PROCESSORS=1;','ITERATIONS=2000; COVERAGE=.005;')
  lines<-c(paste0('TITLE: ',id,' restricted CC feasibility;'),'DATA: FILE=data.dat;','VARIABLE:',wrap90(paste('NAMES=',paste(unlist(e$columns),collapse=' '),';')),paste0('USEVARIABLES=',si$use,';'),'CLUSTER=cluster; MISSING=ALL(-9999);','ANALYSIS:',an,'MODEL:',mm$lines,'OUTPUT: TECH1 TECH3 TECH4 TECH8 SVALUES CINTERVAL;','SAVEDATA: RESULTS=estimates.dat; TECH3=tech3.dat;')
  stopifnot(all(nchar(lines)<=90));writeLines(lines,file.path(d,'model.inp'));stopifnot(file.copy(e$file,file.path(d,'data.dat')))
  j<-list(id=id,root=ROOT,dest=d,z=z,type=type,shape=shape,start=start,N=e$N,communities=e$communities,expected_free=mm$expected_free,category='CHARLS_LATENT_CC',cap_seconds=if(type=='E1')contract$latent_interaction_seconds else contract$per_model_seconds,rscript=file.path(R.home('bin'),'Rscript.exe'),mplus=MPLUS,source_data=e$file,hashes=list(model.inp=hashf(file.path(d,'model.inp')),data.dat=hashf(file.path(d,'data.dat'))),new_MI=0)
  wj(j,file.path(d,'job.json'));j
 }
 review<-function(j){er<-rj(file.path(j$dest,'engine_receipt.json'));if(is.null(er))return(list(id=j$id,status='NOT_RUN_RESOURCE_OR_BUDGET',detail=rj(file.path(j$dest,'not_run.json'))))
  r<-list(id=j$id,z=j$z,type=j$type,shape=j$shape,start=j$start,status=er$status,seconds=er$seconds,N_expected=j$N,dest=j$dest)
  if(er$status=='EXITED')tryCatch({
   m<-read_mplus_raw(j$dest);si<-si_for(j$type,j$shape);v<-gate_r2e(m,si);native<-MplusAutomation::readModels(file.path(j$dest,'model.out'),what='summaries',quiet=TRUE)
   r$status<-if(isTRUE(v$passed))'USABLE_CC_DIAGNOSTIC'else'INADMISSIBLE';r$negative<-v$negative;r$N<-native$summaries$Observations;r$fit<-native$summaries;r$LL<-m$extra[['H0 Loglikelihood']];r$BIC<-native$summaries$BIC;r$free_parameters<-m$P
   if(any(grepl('FIXED TO AVOID SINGULARITY',m$lines,fixed=TRUE)))r$status<-'AUTOFIX_REJECTED'
   if(r$N!=j$N)r$status<-'SAMPLE_MISMATCH';if(m$P!=j$expected_free)r$status<-'PARAMETER_CONTRACT_MISMATCH'
   key<-do.call(rbind,lapply(seq_len(nrow(si$key)),function(i){k<-si$key[i,];id<-pnum(m,k$matrix,k$row,k$column);stopifnot(id>0);p<-m$par[m$par$parameter==id,];data.frame(k,parameter=id,estimate=p$estimate,se=p$se)}))
   wj(v,file.path(j$dest,'validation.json'));csv(m$par,file.path(j$dest,'parameters_high_precision.csv'));csv(m$spec,file.path(j$dest,'tech1_parameter_map.csv'));csv(m$values,file.path(j$dest,'matrix_values.csv'));csv(key,file.path(j$dest,'key_paths.csv'));write.table(m$V,file.path(j$dest,'parameter_covariance.csv'),sep=',',row.names=FALSE,col.names=FALSE)
  },error=function(e){r$status<<-'READBACK_OR_ESTIMATION_FAILURE';r$error<<-conditionMessage(e)})
  if(file.exists(file.path(j$dest,'model.out')))r$output_sha256<-hashf(file.path(j$dest,'model.out'))
  wj(r,file.path(j$dest,'receipt.json'));r
 }
 run<-function(j){
  if(file.exists(file.path(j$dest,'receipt.json')))return(rj(file.path(j$dest,'receipt.json')))
  if(file.exists(file.path(j$dest,'engine_receipt.json')))return(review(j))
  progress('latent_model_start',j$id);p<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/model_engine.py'),file.path(j$dest,'job.json')),stdout=file.path(j$dest,'supervisor.log'),stderr='2>&1',cleanup=TRUE)
  last<-0;while(p$is_alive()){p$wait(1000L);if(as.numeric(Sys.time())-last>25){clauder_progress('latent_estimating',j$id);last<-as.numeric(Sys.time())}}
  progress('latent_readback',j$id);r<-review(j);progress('latent_model_end',paste(j$id,r$status));r
 }
 main<-function(){
  stopifnot(!file.exists(file.path(ROOT,'runtime/PILOT_TERMINAL')),!file.exists(file.path(ROOT,'runtime/pilot_coordinator.json')))
  owner<-file.path(ROOT,'runtime/pilot_coordinator.json');wj(list(owner=list(pid=Sys.getpid(),created=as.numeric(ps_create_time(ps_handle())))),owner)
  aw<-file.path(ROOT,'runtime/awake_PILOT');a<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/windows_awake_guard.py'),'--owner-file',owner,'--output',aw,'--interval','5'),stdout=file.path(ROOT,'runtime/awake_PILOT.log'),stderr='2>&1',cleanup=FALSE)
  on.exit({if(dir.exists(aw))writeLines('release',file.path(aw,'stop.request'));a$wait(8000L)},add=TRUE)
  started<-Sys.time();calls<-list();branches<-list();saveall<-function(){wj(calls,file.path(ROOT,'results/CALL_RESULTS.json'));wj(branches,file.path(ROOT,'results/BRANCH_STATUS.json'))}
  for(z in unlist(contract$indicators)){
   if(as.numeric(difftime(Sys.time(),started,units='secs'))>contract$wall_seconds-240){branches[[z]]<-list(status='WALL_LIMIT_NOT_RUN',complete_MI=FALSE);saveall();next}
   candidates<-list()
   for(sh in unlist(contract$univariate_shapes)){j<-prepare(z,'Z',sh);r<-run(j);calls[[j$id]]<-r;candidates[[sh]]<-r;saveall()}
   usable<-names(candidates)[vapply(candidates,function(r)r$status=='USABLE_CC_DIAGNOSTIC',TRUE)]
   if(!length(usable)){branches[[z]]<-list(status='NO_ADMISSIBLE_Z_TRAJECTORY',complete_MI=FALSE);saveall();next}
   bic<-vapply(candidates[usable],function(r)r$BIC,0.0);stopifnot(all(is.finite(bic)));sh<-usable[which.min(bic)]
   wj(list(rule=contract$shape_choice,selected=sh,candidates=candidates),file.path(ROOT,'results',paste0(toupper(z),'_SHAPE_CHOICE.json')))
   j<-prepare(z,'E0',sh,chosen=candidates[[sh]]$dest);r<-run(j);calls[[j$id]]<-r;branches[[z]]<-list(status=if(r$status=='USABLE_CC_DIAGNOSTIC')'E0_READY'else'PARENT_NOT_ADMITTED',shape=sh,parent_status=r$status,complete_MI=FALSE);saveall()
   if(r$status!='USABLE_CC_DIAGNOSTIC')next
   parent<-j$dest;pair<-list()
   for(st in c('A','B')){j<-prepare(z,'E1',sh,st,parent);r<-run(j);calls[[j$id]]<-r;pair[[st]]<-r;saveall();if(r$status!='USABLE_CC_DIAGNOSTIC')break}
   if(length(pair)==2&&all(vapply(pair,function(r)r$status=='USABLE_CC_DIAGNOSTIC',TRUE))){
    get<-function(r)list(receipt=r,key=read.csv(file.path(r$dest,'key_paths.csv')))
    co<-compare_numeric(get(pair$A),get(pair$B),'start',list(start_LL=.01,start_path_abs=.001,start_path_se=.05,integration_path_se=.05,se_rel=.05))
    wj(co,file.path(ROOT,'results',paste0(toupper(z),'_START_COMPARISON.json')));status<-if(co$passed)'TWO_START_CC_FEASIBLE_NOT_MI'else'START_CHECK_FAILED'
   }else status<-'INTERACTION_NOT_ADMITTED'
   branches[[z]]<-list(status=status,shape=sh,complete_MI=FALSE,original_four_complete=FALSE);saveall()
  }
  writeLines('All four latent feasibility scopes adjudicated',file.path(ROOT,'runtime/PILOT_TERMINAL'))
  progress('LATENT_FEASIBILITY_TERMINAL','Read four branch dispositions; CC feasibility is not complete MI or full H4')
 }
 if(!identical(Sys.getenv('LATENT_READ_ONLY'),'1'))main()
})
