"""核对有界TIMEOUT，不把失败处置写成已获得统计估计。"""
from pathlib import Path
import csv,datetime,hashlib,json,sqlite3,psutil
R=Path(__file__).resolve().parents[1];P=R.parent/'charls_latent_compute_probe_20261018'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
c=read(R/'contracts/RUN_CONTRACT.json')
assert read(P/'audit/VERIFIED_PROBE.json')['status']=='PASS'
dirs=list((R/'models').iterdir());assert len(dirs)==1
d=dirs[0];j=read(d/'job.json');er=read(d/'engine_receipt.json');receipt=read(d/'receipt.json')
assert j['id']=='CHARLS_LATENT_SD_E1_Q15_A' and j['integration_points']==15
assert er['status']==receipt['status']=='TIMEOUT' and er['exitcode']==124
for n,h in er['hashes'].items():assert sha(d/n)==h
assert er['output_sha256']==sha(d/'model.out')
assert 240<=er['seconds']<250
source=Path(c['source_parent']);assert sha(source/'model.out')==c['source_parent_out_sha256']
original=source.parent/'CHARLS_LATENT_SD_E1_LATENT_BASIS_A'
assert sha(d/'data.dat')==sha(original/'data.dat')
inp=(d/'model.inp').read_text();old=(original/'model.inp').read_text()
assert inp.split('MODEL:',1)[1].split('OUTPUT:',1)[0]==old.split('MODEL:',1)[1].split('OUTPUT:',1)[0]
assert 'PROCESSORS=4;' in inp and 'INTEGRATION=15;' in inp and 'MITERATIONS=4000;' in inp
assert len(list(csv.DictReader((d/'start_mapping.csv').open(encoding='utf-8-sig'))))==127
out=(d/'model.out').read_text();assert 'THE MODEL ESTIMATION TERMINATED NORMALLY' not in out
rows=[json.loads(x) for x in (d/'resources.jsonl').read_text().splitlines() if x]
samples=[];rates=[]
for row in rows:
 mp=[p for p in row['processes'] if p['name'].lower()=='mplus.exe']
 for p in mp:
  assert p['affinity']==[8,9,10,11]
  samples.append({'active':row['elapsed_seconds'],**p})
for a,b in zip(samples,samples[1:]):
 if a['pid']==b['pid'] and a['created']==b['created'] and b['active']>a['active']:
  rates.append(100*(b['cpu']-a['cpu'])/(b['active']-a['active']))
assert samples and rates
owner=read(R/'runtime/coordinator.json')['owner']
try:assert abs(psutil.Process(owner['pid']).create_time()-owner['created'])>.001
except psutil.NoSuchProcess:pass
assert not (R/'runtime/engine.lock').exists()
assert read(R/'runtime/awake_CALIBRATION/completion.json')['released']
db=sqlite3.connect(R/'runtime/budget.sqlite');budget=db.execute('SELECT id,state,seconds FROM calls').fetchall();db.close()
assert len(budget)==1 and budget[0][1]=='TIMEOUT' and budget[0][2]<=c['total_engine_seconds']
assert read(R/'results/CALIBRATION_STATUS.json')['status']=='Q15_A_TIMEOUT'
assert (R/'runtime/CALIBRATION_TERMINAL').read_text().strip()=='Q15_A_TIMEOUT'
assert (R/'code/run_calibration.R').stat().st_mtime<=(R/'audit/NATIVE_SUBMIT.json').stat().st_mtime
summary={'id':j['id'],'disposition':'TIMEOUT_NO_INFERENCE','N':j['N'],'communities':j['communities'],
 'engine_active_seconds':er['seconds'],'peak_tree_mib':er['peak_tree_rss']/2**20,
 'sampled_tree_cpu_seconds':er['sampled_tree_cpu_seconds'],'last_mplus_cpu_seconds':samples[-1]['cpu'],
 'max_mplus_threads':max(p['threads'] for p in samples),'max_sampled_cpu_one_core_percent':max(rates),
 'mean_sampled_cpu_one_core_percent':sum(rates)/len(rates),'output_sha256':sha(d/'model.out')}
with (R/'results/INDEPENDENT_CALIBRATION_LEDGER.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(summary));w.writeheader();w.writerow(summary)
v={'status':'PASS','calls':1,'remaining_calls_not_executed':3,'source_data_and_model_equal':True,
 'terminal_job':'53448001','owned_worker_exited':True,'lock_released':True,'awake_released':True,
 'new_MI':0,'original_four_complete':False,'full_H4_complete':False,'row':summary,
 'executed_script_sha256':sha(R/'code/run_calibration.R'),
 'preparation_note':'Preparation hash precedes a pre-submit precision-status guard correction; final script mtime is before genuine native submit. Scientific inputs unchanged.'}
(R/'audit/INDEPENDENT_CALIBRATION.json').write_text(json.dumps(v,indent=2),encoding='utf-8')
print(json.dumps(v))
