# 离线仅检查实际worker库函数；不执行模型，也不代表原生MCP就绪。
.libPaths(c('C:/Users/LZHS/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
library(jsonlite)
f <- get('runModels',asNamespace('MplusAutomation'))
x <- deparse(f)
p <- 'C:/Users/LZHS/pp_lgcm_review/charls_latent_integration_calibration_20261018/audit'
writeLines(x,file.path(p,'RUNMODELS_ACTUAL_WORKER_SOURCE.R'))
ids <- grep('intern = TRUE|cat\\(the_output|the_output <- system|if \\(showOutput',x)
write_json(list(version=as.character(packageVersion('MplusAutomation')),
 package_path=find.package('MplusAutomation'),R=as.character(getRversion()),
 selected_source_lines=x[sort(unique(unlist(lapply(ids,function(i)seq(max(1,i-1),min(length(x),i+2))))))],
 new_model_calls=0,inspection='Offline source inspection only'),
 file.path(p,'RUNMODELS_SOURCE_CHECK.json'),auto_unbox=TRUE,pretty=TRUE)
cat('RUNMODELS_SOURCE_CHECK_SAVED\n')
