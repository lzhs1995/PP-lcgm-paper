"""用实测一次EM成本开启有限积分精度校准；旧来源和失败记录只读。"""
from pathlib import Path
import datetime,hashlib,json,shutil
R=Path(__file__).resolve().parents[1]
S=R.parent/'charls_corrected_latent_feasibility_20261018'
P=R.parent/'charls_latent_compute_probe_20261018'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def w(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
for k in ['contracts','audit','models','runtime','results','reports']:(R/k).mkdir(exist_ok=True)
assert not (R/'contracts/RUN_CONTRACT.json').exists()
v=json.loads((P/'audit/VERIFIED_PROBE.json').read_text());assert v['status']=='PASS'
shutil.copyfile(P/'audit/VERIFIED_PROBE.json',R/'audit/COST_BASIS.json')
files=['r2e_local.R','r2e_tools.R','r2e_upstream_math.R','raw_parameter_reader.py','windows_awake_guard.py']
manifest={}
for n in files:
 shutil.copyfile(S/'code'/n,R/'code'/n)
 manifest[n]={'source':str(S/'code'/n),'sha256':sha(R/'code'/n)}
for n in ['model_engine.py','active_clock.py','run_one.R']:
 shutil.copyfile(P/'code'/n,R/'code'/n)
 manifest[n]={'source':str(P/'code'/n),'sha256':sha(R/'code'/n)}
for n in ['NATIVE_PROOF.json','INDEPENDENT_INPUTS.json']:shutil.copyfile(S/'audit'/n,R/'audit'/n)
shutil.copyfile(S/'contracts/DATA_ENTRIES.json',R/'contracts/DATA_ENTRIES.json')
contract={
 'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'purpose':'SD latent interaction restricted CC feasibility with bounded integration calibration, not complete MI',
 'max_mplus_calls':4,'total_engine_seconds':1080,'wall_seconds':1800,
 'maximum_owned_slots':1,'processors':4,'affinity':[8,9,10,11],
 'resource_admission':{'minimum_available_gib':1.2,'minimum_commit_available_gib':2,'max_cpu_percent':85},
 'sequence':[{'points':15,'start':'A','cap':240},{'points':15,'start':'B','cap':240},
             {'points':30,'start':'A_refined','cap':300},{'points':30,'start':'B_refined','cap':300}],
 'stop_rules':['Any time limit, nontermination or inadmissibility stops dependent fits.',
   '15-point dual-start check must pass before 30-point refinement.',
   '30-point refinement preserves each 15-point terminal estimate as start; it is not a fresh independent-start test.',
   'Check final 30-point pair and integration differences for both paths; no inference before validation.',
   'No variance fixing, no new estimator, no source data changes, no CFPS retries, no additional MI.'],
 'project_tolerances':{'start_LL':.01,'start_path_abs':.001,'start_path_se':.05,'integration_path_se':.05,'se_rel':.05},
 'source_parent':str(S/'models/CHARLS_LATENT_SD_E0_LATENT_BASIS_A'),
 'source_parent_out_sha256':sha(S/'models/CHARLS_LATENT_SD_E0_LATENT_BASIS_A/model.out'),
 'cost_basis_sha256':sha(P/'audit/VERIFIED_PROBE.json')}
w(R/'contracts/RUN_CONTRACT.json',contract);w(R/'audit/RUNTIME_REUSE.json',manifest)
text=(S/'code/run_pilot.R').read_text(encoding='utf-8')
def replace(a,b):
 global text
 assert a in text,a
 text=text.replace(a,b)
replace("ROOT<-'C:/Users/LZHS/pp_lgcm_review/charls_corrected_latent_feasibility_20261018'",f"ROOT<-'{R.as_posix()}'")
replace('OMP_NUM_THREADS=1','OMP_NUM_THREADS=4')
replace("compile<-function(si,shape,sources,start)","compile<-function(si,shape,sources,start,refine=FALSE)")
replace("if(start=='B'){", "if(start=='B' && !refine){")
replace("if(si$kind=='lms_latent')d$value", "if(si$kind=='lms_latent' && !refine)d$value")
replace("prepare<-function(z,type,shape,start='A',chosen=NULL)","prepare<-function(z,type,shape,start='A',chosen=NULL,q=15L,refine=FALSE)")
replace("id<-paste('CHARLS_LATENT',toupper(z),type,toupper(shape),start,sep='_')", "id<-paste('CHARLS_LATENT',toupper(z),type,paste0('Q',q),start,sep='_')")
replace('mm<-compile(si,shape,sources,start)', 'mm<-compile(si,shape,sources,start,refine)')
replace("'TYPE=COMPLEX RANDOM; ESTIMATOR=MLR; PROCESSORS=1;'", "'TYPE=COMPLEX RANDOM; ESTIMATOR=MLR; PROCESSORS=4;'")
replace("'ALGORITHM=INTEGRATION; INTEGRATION=30; MCSEED=26101891;'", "paste0('ALGORITHM=INTEGRATION; INTEGRATION=',q,'; MCSEED=26101891;')")
replace("cap_seconds=if(type=='E1')contract$latent_interaction_seconds else contract$per_model_seconds", "cap_seconds=if(q==15L)240 else 300")
replace("category='CHARLS_LATENT_CC'", "category='CHARLS_SD_INTEGRATION_CC',integration_points=q,refined_start=refine")
start=text.index(' main<-function(){')
text=text[:start]+(R/'code/calibration_main.R.fragment').read_text(encoding='utf-8')
(R/'code/run_calibration.R').write_text(text,encoding='utf-8')
h=(P/'code/harness.py').read_text(encoding='utf-8').replace('pp-lgcm-charls-one-em-cost-20261018','pp-lgcm-charls-integration-calibration-20261018').replace('three bounded diagnostic receipts','bounded calibration receipts')
(R/'code/harness.py').write_text(h,encoding='utf-8')
w(R/'audit/PREPARATION.json',{'status':'PASS','parent_sha256':contract['source_parent_out_sha256'],'new_MI':0,'max_calls':4,'run_script_sha256':sha(R/'code/run_calibration.R')})
print(json.dumps({'status':'PREPARED','root':str(R),'max_calls':4,'max_engine_seconds':1080}))
