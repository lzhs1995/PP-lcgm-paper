# 单槽诊断；每次最多一次EM；不把计划内不收敛当成实质分析。
local({
 library(jsonlite);library(processx);library(ps)
 ROOT <- 'C:/Users/LZHS/pp_lgcm_review/charls_latent_compute_probe_20261018'
 PY <- 'C:/Users/LZHS/AppData/Local/Programs/Python/Python314/python.exe'
 ps::ps_set_cpu_affinity(ps::ps_handle(),8:11)
 Sys.setenv(OPENBLAS_NUM_THREADS=1,MKL_NUM_THREADS=1,OMP_NUM_THREADS=4)
 progress <- function(stage,message) {
  if(exists('clauder_progress',mode='function',inherits=TRUE)) clauder_progress(stage,message)
  cat(format(Sys.time(),tz='UTC'),stage,message,'\n');flush.console()
 }
 stopifnot(jsonlite::fromJSON(file.path(ROOT,'audit/PREPARATION.json'))$status=='PASS')
 jobs <- jsonlite::fromJSON(file.path(ROOT,'contracts/JOBS.json'))
 for(f in jobs) {
  j <- jsonlite::fromJSON(f); er <- file.path(j$dest,'engine_receipt.json')
  if(file.exists(er)) stop('Existing model receipt: reconcile, do not rerun')
  progress('one_em_cost',j$id)
  p <- processx::process$new(PY,c('-X','utf8',file.path(ROOT,'code/model_engine.py'),f),
       stdout=file.path(j$dest,'supervisor.log'),stderr='2>&1',cleanup_tree=TRUE)
  while(p$is_alive()) { Sys.sleep(5); progress('one_em_running',j$id) }
  if(p$get_exit_status()!=0L) stop('Supervisor failed: ',j$id)
  if(!file.exists(er)) stop('Not admitted: inspect not_run.json before resuming')
  r <- jsonlite::fromJSON(er)
  progress('one_em_done',paste(j$id,r$status,round(r$seconds,2),'seconds'))
 }
 writeLines('Three bounded diagnostic calls terminal; not scientific estimates',file.path(ROOT,'runtime/TERMINAL'))
 progress('ONE_EM_PROBE_TERMINAL','Inspect actual TECH8 cost; no inference or automatic full fit')
})
