"""在隔离副本中冻结一次EM成本诊断；不改原数据或历史模型。"""
from pathlib import Path
import datetime, hashlib, json, shutil

R = Path(__file__).resolve().parents[1]
S = R.parent / 'charls_corrected_latent_feasibility_20261018'
D = S / 'models/CHARLS_LATENT_SD_E1_LATENT_BASIS_A'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p, value): p.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
for sub in ['contracts','audit','models','runtime','results','reports']:
    (R/sub).mkdir(exist_ok=True)
assert not (R/'contracts/RUN_CONTRACT.json').exists(), 'Prepare once; do not overwrite contract'
old = json.loads((D/'job.json').read_text())
for n,h in old['hashes'].items(): assert sha(D/n)==h, n
assert json.loads((D/'engine_receipt.json').read_text())['status']=='TIMEOUT'
runtime={}
for n in ['model_engine.py','active_clock.py','run_one.R']:
    text=(S/'code'/n).read_text(encoding='utf-8')
    if n=='run_one.R': text=text.replace('showOutput=FALSE','showOutput=TRUE')
    if n=='model_engine.py':
        # 记录线程与亲和性；只扩大观测字段，不改变原监督器准入和停止规则。
        text=text.replace("'cpu':ct.user+ct.system}","'cpu':ct.user+ct.system,'threads':p.num_threads(),'affinity':p.cpu_affinity()}")
    (R/'code'/n).write_text(text,encoding='utf-8')
    runtime[n]={'source':str(S/'code'/n),'source_sha256':sha(S/'code'/n),'local_sha256':sha(R/'code'/n)}
shutil.copyfile(S/'audit/NATIVE_PROOF.json',R/'audit/NATIVE_PROOF.json')
contract={
 'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'purpose':'Cost diagnostic only: one EM iteration, not scientific estimation or MI',
 'official_basis':'https://www.statmodel.com/HTML_UG/chapter14V8.htm#practical-aspects (MITERATIONS=1, STARTS=0, TECH1/TECH8)',
 'max_mplus_calls':3,'total_engine_seconds':360,'per_model_seconds':120,
 'maximum_owned_slots':1,'affinity':[8,9,10,11],
 'resource_admission':{'minimum_available_gib':1.2,'minimum_commit_available_gib':2,'max_cpu_percent':85},
 'sequence':[{'id':'SD_Q30_P1','points':30,'processors':1},{'id':'SD_Q30_P4','points':30,'processors':4},{'id':'SD_Q15_P4','points':15,'processors':4}],
 'decision_rules':[
  'Identical data, MODEL block, starting values and seed across probes.',
  'q30 p1/p4 comparison changes PROCESSORS only; both cap EM at one iteration.',
  'q15 is integration-cost exploration, never a precision-equivalent accepted result.',
  'Planned one-iteration nonconvergence is diagnostic; retain errors and timeouts.',
  'No full model, other branch, new MI, original CFPS retry or manuscript change in this batch.',
  'Do not infer p-values, factor significance, absence of moderation or complete H4 from probes.'
 ],'source':str(D),'source_hashes':old['hashes'],'source_output_sha256':sha(D/'model.out')}
write(R/'contracts/RUN_CONTRACT.json',contract)
write(R/'audit/RUNTIME_REUSE.json',runtime)
jobs=[];source=(D/'model.inp').read_text(encoding='utf-8')
model_block=source.split('MODEL:',1)[1].split('OUTPUT:',1)[0]
for v in contract['sequence']:
    d=R/'models'/v['id'];d.mkdir()
    text=source.replace(source.splitlines()[0],f"TITLE: {v['id']} ONE EM ITERATION COST ONLY;")
    text=text.replace('PROCESSORS=1;',f"PROCESSORS={v['processors']};")
    text=text.replace('INTEGRATION=30;',f"INTEGRATION={v['points']};")
    text=text.replace('MITERATIONS=4000;','MITERATIONS=1; STARTS=0;')
    assert text.split('MODEL:',1)[1].split('OUTPUT:',1)[0]==model_block
    assert all(len(line)<=90 for line in text.splitlines())
    (d/'model.inp').write_text(text,encoding='utf-8')
    shutil.copyfile(D/'data.dat',d/'data.dat')
    shutil.copyfile(D/'start_mapping.csv',d/'start_mapping.csv')
    j={**old,'id':v['id'],'root':str(R),'dest':str(d),'cap_seconds':120,
       'category':'ONE_EM_COST','points':v['points'],'processors':v['processors'],
       'diagnostic_only':True,'source':str(D),
       'hashes':{n:sha(d/n) for n in ['model.inp','data.dat']}}
    assert j['hashes']['data.dat']==old['hashes']['data.dat']
    write(d/'job.json',j);jobs.append(str(d/'job.json'))
write(R/'contracts/JOBS.json',jobs)
write(R/'audit/PREPARATION.json',{'status':'PASS','model_block_equal':True,'data_equal':True,'starts_equal':True,'jobs':3,'runtime':runtime})
print(json.dumps({'status':'PREPARED','root':str(R),'calls':3,'new_MI':0}))
