"""从实际输入、TECH8屏幕日志、输出和进程采样独立核验三次成本诊断。"""
from pathlib import Path
import csv,hashlib,json,re,sqlite3
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
c=read(R/'contracts/RUN_CONTRACT.json');source=Path(c['source'])
original=(source/'model.inp').read_text(encoding='utf-8')
extract=lambda t:t.split('MODEL:',1)[1].split('OUTPUT:',1)[0]
rows=[]
for spec in c['sequence']:
 d=R/'models'/spec['id'];j=read(d/'job.json');er=read(d/'engine_receipt.json')
 for n,h in j['hashes'].items():assert sha(d/n)==h,n
 assert sha(d/'data.dat')==c['source_hashes']['data.dat']
 assert sha(d/'start_mapping.csv')==sha(source/'start_mapping.csv')
 inp=(d/'model.inp').read_text();assert extract(inp)==extract(original)
 assert 'MITERATIONS=1; STARTS=0;' in inp
 assert f"PROCESSORS={spec['processors']};" in inp
 assert f"INTEGRATION={spec['points']};" in inp
 assert er['status']=='EXITED' and er['exitcode']==0
 assert er['output_sha256']==sha(d/'model.out')
 out=(d/'model.out').read_text();log=(d/'mplus_execution.log').read_text()
 assert 'Mplus VERSION 9' in out
 assert 'THE MODEL ESTIMATION DID NOT TERMINATE NORMALLY DUE TO AN INSUFFICIENT' in out
 assert 'NUMBER OF E STEPS.  INCREASE THE NUMBER OF MITERATIONS.' in out
 assert re.search(r'Number of observations\s+2672\b',out)
 dimensions=int(re.search(r'Dimensions of integration:\s+(\d+)',log)[1])
 nodes=int(re.search(r'Total number of integration points:\s+(\d+)',log)[1])
 its=re.findall(r'^\s*(\d+)\s+([-+.0-9DE]+)\s+([-+.0-9DE]+)\s+([-+.0-9DE]+)\s+EM\s+([.0-9]+)\s+([.0-9]+)\s*$',log,re.M)
 assert len(its)==1 and its[0][0]=='1',its
 assert dimensions==2 and nodes==spec['points']**dimensions
 hh,mm,ss=map(int,re.search(r'Elapsed Time:\s+(\d+):(\d+):(\d+)',log).groups())
 samples=[readline for readline in (d/'resources.jsonl').read_text().splitlines() if readline]
 processes=[p for l in samples for p in json.loads(l)['processes'] if p['name'].lower()=='mplus.exe']
 assert processes and all(p['affinity']==c['affinity'] for p in processes)
 rows.append(dict(id=spec['id'],points_per_dimension=spec['points'],processors_requested=spec['processors'],
  dimensions=dimensions,total_nodes=nodes,em_rows=1,first_LL_printed=float(its[0][1].replace('D','E')),
  tech8_TIME_seconds=float(its[0][4]),mplus_elapsed_whole_seconds=hh*3600+mm*60+ss,
  wrapper_awake_seconds=er['seconds'],sampled_tree_cpu_seconds=er['sampled_tree_cpu_seconds'],
  sampled_mplus_cpu_seconds=max(p['cpu'] for p in processes),
  max_mplus_threads=max(p['threads'] for p in processes),peak_tree_mib=er['peak_tree_rss']/2**20,
  disposition='PLANNED_ONE_EM_NONCONVERGENCE_NOT_AN_ESTIMATE',output_sha256=sha(d/'model.out')))
assert rows[0]['first_LL_printed']==rows[1]['first_LL_printed']
db=sqlite3.connect(R/'runtime/budget.sqlite');ledger=db.execute('SELECT id,state,seconds FROM calls').fetchall();db.close()
assert len(ledger)==3 and all(x[1]=='EXITED' for x in ledger)
assert sum(x[2] for x in ledger)<=c['total_engine_seconds']
assert not (R/'runtime/engine.lock').exists() and (R/'runtime/TERMINAL').exists()
with (R/'results/COMPUTE_PROBE.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
v={'status':'PASS','calls':3,'diagnostic_only':True,'new_MI':0,'original_four_complete':False,'full_H4_complete':False,
 'active_engine_seconds':sum(x[2] for x in ledger),'rows':rows,
 'limits':'One observation per setting; TECH8 TIME is a reported field, not assumed CPU or wall. Whole-second Mplus elapsed and sampled CPU retained separately. No general causal speedup claim.'}
(R/'audit/VERIFIED_PROBE.json').write_text(json.dumps(v,indent=2),encoding='utf-8')
print(json.dumps(v,ensure_ascii=False))
