"""只恢复已租用CC Switch的精确主窗口，核验两R与自有引擎终态。"""
from pathlib import Path
from datetime import datetime,timezone
from ctypes import wintypes as w
import ctypes,json,sys,psutil
r=Path(__file__).resolve().parents[1];y=r.parent/'cfps_h41_yshape_pilot_20261019'
sys.path.insert(0,'C:/Users/RESEARCH_USER/Desktop/cnm/tasks/01_R_analysis/work/ch4_archived_replay_20261016')
from windows_process_terminal import process_state
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
restore=read(y/'audit/cc_memory_lease/RESTORED.json')
assert process_state(restore['pid'],restore['created'])['state']=='active'
protected=[process_state(8764,1792308599.6514845),process_state(18112,1792308603.0035183)]
owned=[]
for root in [y,r]:
 assert read(root/'results/BATCH_RECEIPT.json')['terminal']
 runtime=read(root/'audit/EXECUTION_RUNTIME.json')
 owned.append(process_state(runtime['pid']))
 for p in (root/'models').glob('*/LAUNCH_RECEIPT.json'):
  launch=read(p)
  if launch.get('actual_engine_calls',0):owned.append(process_state(launch['pid']))
user=ctypes.WinDLL('user32',use_last_error=True);cbtype=ctypes.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
user.EnumWindows.argtypes=[cbtype,w.LPARAM];user.GetWindowThreadProcessId.argtypes=[w.HWND,ctypes.POINTER(w.DWORD)]
user.GetWindowTextW.argtypes=[w.HWND,w.LPWSTR,ctypes.c_int];user.IsWindowVisible.argtypes=[w.HWND];user.ShowWindow.argtypes=[w.HWND,ctypes.c_int]
windows=[]
@cbtype
def cb(hwnd,_):
 pid=w.DWORD();user.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
 if pid.value==restore['pid']:
  buf=ctypes.create_unicode_buffer(512);user.GetWindowTextW(hwnd,buf,512)
  if buf.value=='CC Switch':
   before=bool(user.IsWindowVisible(hwnd))
   if not before:user.ShowWindow(hwnd,5)
   windows.append(dict(title=buf.value,visible_before=before,visible_after=bool(user.IsWindowVisible(hwnd))))
 return True
user.EnumWindows(cb,0)
mplus=[dict(pid=p.pid,created=p.create_time()) for p in psutil.process_iter(['name']) if (p.info['name'] or '').lower()=='mplus.exe' and process_state(p.pid)['state']=='active']
out=dict(at=datetime.now(timezone.utc).isoformat(),protected=protected,owned=owned,restored_manager=restore,restored_windows=windows,active_mplus=mplus,available_gib=psutil.virtual_memory().available/2**30)
out['passed']=all(x['state']=='active' for x in protected) and all(x['state'] in ['exited','absent','reused'] for x in owned) and not mplus and any(x['visible_after'] for x in windows)
p=r/'audit/FINAL_PROCESS_HEALTH.json';assert not p.exists();p.write_text(json.dumps(out,indent=2));print(json.dumps(out));assert out['passed']
