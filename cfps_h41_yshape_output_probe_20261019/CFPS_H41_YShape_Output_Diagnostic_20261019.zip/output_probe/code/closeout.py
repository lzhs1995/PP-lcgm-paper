"""有限敏感性批次的事实报告；无新模型、无新插补、不改论文。"""
from pathlib import Path
import csv,json,re
r=Path(__file__).resolve().parents[1];y=r.parent/'cfps_h41_yshape_pilot_20261019'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
v=read(r/'audit/INDEPENDENT_READBACK.json');assert v['status']=='PASS_INDEPENDENT_AGGREGATE_READBACK'
assert read(r/'audit/FINAL_PROCESS_HEALTH.json')['passed']
calls=[]
for root in [y,r]:
 e=read(root/'models/PARENT_MI02/LAUNCH_RECEIPT.json')
 s=(root/'models/PARENT_MI02/execution/stdout.log').read_text(errors='replace')
 trace=[x for x in s.splitlines() if re.match(r'^\s+\d+\s+\d+\s+[+-]?\d*\.\d+[DE][+-]?\d+',x)]
 calls.append(dict(batch=root.name,state=e['state'],cap=e['configured_seconds'],launch_seconds=e['launch_seconds'],cutoff_detected=e['detected_seconds'],confirmed_exit=e['exit_confirmed_seconds'],exited=e['process_exited'],H1_warning='221445 PARAMETERS' in s,printed_numeric_rows=len(trace)))
with (r/'results/COMPARISON.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(calls[0]));w.writeheader();w.writerows(calls)
text='''# CFPS H4.1：Y形状有限诊断与输出对照

**四项调节完整推断、完整 H4 仍未完成。** 本批不是论文收尾的重开，也不是原失败规格原样重跑。新自由载荷敏感性未在限定时间内形成可采用父模型，故未启动H4.1成员或合并。CFPS原观测Z₀ H4.1仍为3/12个完整十份家族。

## 本次新增工作及依据

首先复用九个未完成家族的原始输出，匹配同样本父模型，核对DAT及输出哈希。SEXGAP与SONGAP父模型已经有负方差；OLDEST的MI02父模型SY残差为0.0011844289，EDU H4.1对应值为−0.0016272205，MI06父模型也已有负SY。问题不能统一归因于交互或接口。

原审阅要求检查Y形状，且指定历史Round2目录未发现已执行YFREE目录。结合原MI02均值残差的探索性信号，冻结一个事后敏感性：N=3159，原十份插补，原控制、聚类和MLR不动，只把Y2—Y4时间载荷释放，保持Y1=0、Y5=1。没有按P值选规格，没有固定任何负方差，也没有产生新MI。该估计对象的时间锚点不变，但轨迹形状改变，不能用新结果冒充原规格已修复。

原合同最多12次调用，父模型合法、MI02双起点通过后才允许完整家族。实际第一项超时，余下11个准备项均未执行。另一次单独登记的输出对照最多1次，仅改变OUTPUT选项；DATA/VARIABLE/ANALYSIS/MODEL及初值、SAVEDATA逐字一致。

## 实际执行

| 调用 | 截止秒数 | Popen返回耗时 | 触发截止 | 确认退出 | 迭代数值行 | 结果 |
|---|---:|---:|---:|---:|---:|---|
'''
for x in calls:text+=f"| {x['batch']} | {x['cap']} | {x['launch_seconds']:.3f} | {x['cutoff_detected']:.3f} | {x['confirmed_exit']:.3f} | {x['printed_numeric_rows']} | 超时，无可采用估计 |\n"
text+='''
共2次真实CFPS调用；新MI=0，完整新家族=0，新NLM=0，CHARLS本批新增=0。两次合计从启动计时到确认退出约370.262秒。180秒是触发截止的阈值，不能把进程退出延迟抹去后声称严格180秒总墙钟。

两次stdout都提示标准化系数涉及很大的H1标准误计算，原文打印“221445 PARAMETERS”。原输入未直接请求STANDARDIZED；精简TECH4/SAMPSTAT/RESIDUAL后警告仍然出现。该提示不是已证实的唯一瓶颈，也不能据此断言估计器缺陷或模型不可识别。输出精简没有在本次上限内取得成功，不能宣传为已验证提速。

原来的TECH8在TYPE=COMPLEX、无数值积分配置下被明确忽略。输出对照改用TECH5，保留了准牛顿迭代。迭代行不能当作已收敛参数，未打印阶段也不能凭空归因。两次均没有可用于合并的高精度参数/TECH3文件；保留空文件及部分输出是超时证据，不是损坏包。

官方文档区分TECH5的优化历史与TECH8支持的分析类型，见 [Mplus Output](https://www.statmodel.com/HTML_UG/chapter18V8.htm)。本地输出是本次适用性和超时事实的直接证据。

## RStudio接口、资源和恢复

原生8787绑定PID8764。作业9c7a29bc、b1ffb424各提交一次，均通过原生get_async_result消费终态，guard已关闭；最终原生短调用成功，后台注册表为空。未重启RStudio或改ClaudeR包/config，保留8789的另一会话。

前台已加载MplusAutomation1.2，新后台从隔离库加载1.3，实际路径及加载时间在EXECUTION_RUNTIME.json中。加载等待不计作引擎估计；不能把修改libPaths描述为替换前台已经加载的namespace。

按现有授权，仅正常退出经过PID+创建时间核实的任务自有闲置CC Switch，并设置恢复租约。保留R会话，不强杀安全程序或其他工作。模型启动仍通过1.2 GiB可用物理内存、2 GiB可用提交量及CPU门槛，未因等待降低标准。Windows退出状态用同句柄核验，避免把可查询的已退出PID误当存活。两任务终态后租约已恢复普通CC Switch，并且只显示精确名称的主窗口，不操作IME辅助窗口。

当前没有本批Mplus或R worker遗留；两RStudio保留。进程退出与模型可采用分别验收。接口恢复的完整历史继续保存在guide recovery-runbook及前批固定报告，不能把本次原生通道正常等同于统计任务完成。

## 可复核资产与后续边界

公开包只含聚合原始输出、输入、脚本、合同、哈希及终态记录，不含个人DAT、MI对象或个人得分。两次调用的输出与启动回执、输入和数据哈希由独立Python复核；解压包再次执行相同读取，不调用Mplus。

冻结正文与补充材料保持原版。CHARLS已完成的31个条件工作MI家族/800成员继续复用；它们基于观测基期Z₀，不能替代原潜在IZ/SZ机制。其数据与缺失处理已有记录，本批没有重新清洗或再次估计。

本合同已终止自动估计。后续科学推进需先从已有聚合输出定位可解释的识别、增长形状或信息不足问题，再制定单一有限检验；不得原样重跑两个超时输入，或把任意延长上限、改门槛作为默认恢复。当前没有新增正式H4推断。
'''
(r/'reports/REPORT.md').write_text(text,encoding='utf-8')
lesson='''## Output diagnostics and bounded exit are separate from interface health

In the 2026-10-19 CFPS Y-shape pilot, native jobs `9c7a29bc` and `b1ffb424` each submitted once, exposed progress, and returned their original terminal result. Both Mplus attempts timed out. Do not call a responsive RStudio bridge a successful model, or resubmit a live job while diagnosing slow estimation.

- Match the optimizer trace to the actual analysis. Mplus explicitly ignored TECH8 for this non-integration TYPE=COMPLEX model; TECH5 exposed quasi-Newton history. A warning is not automatically an estimation failure, and printed iterations are not a converged result.
- Preserve failed optimization hypotheses. Both stdout logs printed a large H1 standard-error warning even without an explicit STANDARDIZED request. A single bounded removal of optional TECH4/SAMPSTAT/RESIDUAL output did not remove that warning or obtain an estimate. Do not claim this output change fixed the bottleneck, identify the warning as the unique cause, or standardize data simply to silence it.
- Report timeout detection and confirmed exit separately. The first direct-child attempt detected its 180-second deadline at 179.998 seconds but confirmed exit at 190.130; the second confirmed exit at 180.132. Popen launch itself took measurable time. An owned-handle deadline avoids broad process killing but cannot guarantee zero operating-system scheduling/termination latency.
- Reclamation remains reversible and identity bound. An owned idle UI was closed under a restoration lease; both R sessions survived. Verify Windows process terminal state, and restore only the exact main window. Reuse native preflight only with the same bound session and unchanged transport/configuration, while giving each real job its own guard and terminal receipt.

The optional-output comparison preserved DATA/VARIABLE/ANALYSIS/MODEL, starts and SAVEDATA byte-for-byte. Two real calls yielded no admissible parent and no new MI; dependent family members were not launched. This is a negative diagnostic result, not a repaired H4 family or evidence of a null effect. Original sources and failed outputs remain intact.
'''
(r/'reports/GUIDE_RECOVERY.md').write_text(lesson,encoding='utf-8')
validation=dict(status='PASS_BOUNDED_COMPARISON_READBACK',actual_engine_calls=v['actual_engine_calls'],models=calls,independent_readback='PASS',formal_estimates_available=False,full_H4_complete=False,original_four_complete=False)
(r/'audit/VALIDATION.json').write_text(json.dumps(validation,indent=2))
print(json.dumps(validation))
