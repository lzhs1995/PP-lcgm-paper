from pathlib import Path
import csv,hashlib,json,os,sys
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
import numpy as np
from raw_tech1 import tech1
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read_model(d):
 text=(d/'model.out').read_text(encoding='latin1');mapping=tech1(text);n=max(v[3] for v in mapping)
 assert set(v[3] for v in mapping if v[3])==set(range(1,n+1))
 a=np.fromstring((d/'estimates.dat').read_text(),sep=' ');t=np.fromstring((d/'tech3.dat').read_text(),sep=' ')
 assert len(a)>=2*n and len(t)==n*(n+1)//2
 V=np.zeros((n,n));V[np.tril_indices(n)]=t;V=V+V.T-np.diag(V.diagonal())
 assert np.allclose(np.sqrt(V.diagonal()),a[n:2*n],rtol=1e-6,atol=1e-8)
 p=list(csv.DictReader((d/'parameters_high_precision.csv').open()));assert len(p)==n
 assert np.allclose([float(x['estimate']) for x in p],a[:n],rtol=0,atol=1e-12)
 assert np.allclose([float(x['se']) for x in p],a[n:2*n],rtol=0,atol=1e-12)
 assert np.allclose(np.loadtxt(d/'parameter_covariance.csv',delimiter=','),V,rtol=1e-12,atol=1e-12)
 def canon(mat,row,col):
  if mat.lower() in ['theta','psi']:row,col=sorted([row.upper(),col.upper()])
  return (mat.lower(),row.upper(),col.upper())
 keys=[canon(x['matrix'],x['row'],x['column']) for x in p];assert len(set(keys))==n
 for i,k in enumerate(keys):assert {z[3] for z in mapping if z[3] and canon(*z[:3])==k}=={i+1}
 assert 'THE MODEL ESTIMATION TERMINATED NORMALLY' in text and '*** ERROR' not in text
 return keys,a[:n],a[n:2*n],V,a[2*n+1]

r=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
roots=[r/'original',r/'output_probe'] if (r/'original').exists() else [r.parent/'cfps_h41_yshape_pilot_20261019',r]
checks=[]
for root in roots:
 c=read(root/'contracts/RUN_CONTRACT.json');terminal=read(root/'results/BATCH_RECEIPT.json');assert terminal['terminal']
 count=0
 for d in sorted((root/'models').iterdir()):
  if not (d/'receipt.json').exists():continue
  rec=read(d/'receipt.json');launch=read(d/'LAUNCH_RECEIPT.json');j=read(d/'job.json')
  count+=launch.get('actual_engine_calls',0)
  # 发布包对本机路径做了匿名化，使用清单保留的本机原始哈希核对启动回执。
  expected=sha(d/'model.inp')
  if (r/'MANIFEST.json').exists():
   entry=next(x for x in read(r/'MANIFEST.json')['files'] if x['path']==(d/'model.inp').relative_to(r).as_posix())
   expected=entry['original_local_sha256']
  if launch.get('actual_engine_calls',0):
   assert launch['input_sha256']==expected==j['input_sha256']
   assert launch['data_sha256']==j['data_sha256']==c['data_hashes'][str(j['member'])]
   assert launch['process_exited']
   for stream in ['stdout','stderr']:
    path=d/'execution'/f'{stream}.log';h=sha(path)
    if (r/'MANIFEST.json').exists():h=next(x for x in read(r/'MANIFEST.json')['files'] if x['path']==path.relative_to(r).as_posix())['original_local_sha256']
    assert h==launch[stream+'_sha256']
  if (d/'data.dat').exists():assert sha(d/'data.dat')==j['data_sha256']
  item=dict(batch=root.name,model=d.name,status=rec['status'],accepted=rec['accepted'],engine_calls=launch.get('actual_engine_calls',0),engine_elapsed=launch.get('exit_confirmed_seconds'))
  if (d/'parameters_high_precision.csv').exists():
   keys,q,se,V,ll=read_model(d);assert len(keys)==j['expected_free'];assert abs(ll-rec['LL'])<1e-8
   sy=q[keys.index(('psi','SY','SY'))];item.update(parameters=len(q),SY=float(sy),LL=float(ll))
   neg=[str(k) for k,v in zip(keys,q) if k[0] in ['psi','theta'] and k[1]==k[2] and v<0]
   item['negative_free_variances']=neg
   assert bool(neg)==bool(rec['negative'])
   if rec['accepted']:assert not neg and read(d/'validation.json')['passed']
  else:assert not rec['accepted']
  checks.append(item)
 assert count<=c['max_mplus_calls']
a=(roots[0]/'models/PARENT_MI02/model.inp').read_text();b=(roots[1]/'models/PARENT_MI02/model.inp').read_text()
assert a.split('OUTPUT:')[0]==b.split('OUTPUT:')[0]
assert a.split('SAVEDATA:')[1]==b.split('SAVEDATA:')[1]
assert 'TECH1 TECH3 TECH5 CINTERVAL SVALUES;' in b
out=dict(status='PASS_INDEPENDENT_AGGREGATE_READBACK',models=checks,output_only_change_verified=True,actual_engine_calls=sum(x['engine_calls'] for x in checks),new_MI=0,original_four_complete=False,full_H4_complete=False)
print(json.dumps(out))
