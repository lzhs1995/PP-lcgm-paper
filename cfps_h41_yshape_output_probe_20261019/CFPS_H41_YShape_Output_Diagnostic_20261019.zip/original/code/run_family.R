# 独立后台环境：复用原始MI，仅测试已登记Y自由载荷敏感性。
local({
 ROOT <- 'C:/Users/RESEARCH_USER/pp_lgcm_review/cfps_h41_yshape_pilot_20261019'
 .libPaths(c('C:/Users/RESEARCH_USER/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
 library(jsonlite)
 wj<-function(x,p)write_json(x,p,auto_unbox=TRUE,pretty=TRUE,digits=NA,null='null')
 say<-function(stage,message){cat(format(Sys.time(),tz='UTC'),stage,message,'\n');flush.console();if(exists('clauder_progress',mode='function',inherits=TRUE))clauder_progress(stage,message);wj(list(stage=stage,message=message,at=format(Sys.time(),tz='UTC')),file.path(ROOT,'runtime/PROGRESS.json'))}
 begin<-Sys.time();say('LOADING','One worker; MplusAutomation and verified raw-output reader')
 Sys.setenv(OPENBLAS_NUM_THREADS=1,MKL_NUM_THREADS=1,OMP_NUM_THREADS=1,R2E_ROOT=ROOT)
 library(MplusAutomation);library(ps);library(digest)
 ps_set_cpu_affinity(ps_handle(),8:11)
 source(file.path(ROOT,'code/r2e_tools.R'),local=TRUE)
 wj(list(pid=Sys.getpid(),created=ps_create_time(ps_handle()),version=as.character(getNamespaceVersion('MplusAutomation')),package_path=getNamespaceInfo(asNamespace('MplusAutomation'),'path'),loading_seconds=as.numeric(difftime(Sys.time(),begin,units='secs'))),file.path(ROOT,'audit/EXECUTION_RUNTIME.json'))
 con<-fromJSON(file.path(ROOT,'contracts/RUN_CONTRACT.json'));stopifnot(!file.exists(file.path(ROOT,'runtime/ATTEMPT_RESERVED')))
 writeLines('one native coordinator',file.path(ROOT,'runtime/ATTEMPT_RESERVED'))
 labs<-c('bii','bis','bss','bsyiy','gi0','gs0','gizg','gszg')
 key<-data.frame(label=labs,row=c('IY','SY','SY','SY','IY','SY','IY','SY'),column=c('IX','IX','SX','IY','Z0','Z0','ZG','ZG'))
 keys<-function(p)paste(p$matrix,p$row,p$column,sep=':')
 run_one<-function(id){
  d<-file.path(ROOT,'models',id);j<-fromJSON(file.path(d,'job.json'));say('RUNMODELS',id)
  warn<-character();err<-NULL;at<-Sys.time()
  withCallingHandlers(tryCatch(MplusAutomation::runModels(target=file.path(d,'model.inp'),recursive=FALSE,showOutput=TRUE,replaceOutfile='never',Mplus_command=file.path(d,'launch.cmd'),killOnFail=FALSE,logFile=file.path(d,'MplusAutomation.log')),error=function(e)err<<-conditionMessage(e)),warning=function(w){warn<<-c(warn,conditionMessage(w));invokeRestart('muffleWarning')})
  wj(list(error=err,warnings=warn,seconds=as.numeric(difftime(Sys.time(),at,units='secs'))),file.path(d,'R_WRAPPER_RETURN.json'))
  if(!file.exists(file.path(d,'LAUNCH_RECEIPT.json')))stop('Missing launch receipt: acceptance unknown, do not resubmit')
  e<-fromJSON(file.path(d,'LAUNCH_RECEIPT.json'));ans<-list(id=id,member=j$member,phase=j$phase,accepted=FALSE,complete_MI=FALSE,engine=e)
  if(identical(e$status,'NOT_RUN_RESOURCE_HOLD')){ans$status<-e$status;wj(ans,file.path(d,'receipt.json'));return(ans)}
  if(e$state!='EXITED'||e$exitcode!=0||!isTRUE(e$process_exited)){ans$status<-paste0('ENGINE_',e$state);wj(ans,file.path(d,'receipt.json'));return(ans)}
  say('READBACK',id)
  tryCatch({
   m<-read_mplus_raw(d);stopifnot(identical(as.integer(m$par$parameter),seq_len(m$P)))
   si<-list(kind='linear',fac=c('IX','SX','IY','SY'),obs=c(paste0('X',1:5),paste0('Y',1:5)),fixed_zero=character())
   gate<-gate_r2e(m,si);native<-MplusAutomation::readModels(file.path(d,'model.out'),what='summaries',quiet=TRUE)
   write.csv(m$par,file.path(d,'parameters_high_precision.csv'),row.names=FALSE);write.csv(m$spec,file.path(d,'tech1_parameter_map.csv'),row.names=FALSE)
   write.csv(m$values,file.path(d,'matrix_values.csv'),row.names=FALSE);write.table(m$V,file.path(d,'parameter_covariance.csv'),sep=',',row.names=FALSE,col.names=FALSE)
   wj(gate,file.path(d,'validation.json'));wj(native$summaries,file.path(d,'fit.json'))
   ans$LL<-m$extra[['H0 Loglikelihood']];ans$N<-native$summaries$Observations;ans$free_parameters<-m$P;ans$negative<-gate$negative;ans$SY<-mval(m,'PSI','SY','SY')
   ans$accepted<-isTRUE(gate$passed)&&ans$N==j$N&&m$P==j$expected_free&&!any(grepl('FIXED TO AVOID SINGULARITY',m$lines,fixed=TRUE))
   ans$status<-if(ans$accepted)'USABLE_SINGLE_SENSITIVITY'else'INADMISSIBLE_OR_CONTRACT_FAILURE'
   if(ans$accepted){kp<-key_paths_r2e(m,if(j$phase=='parent')key[1:6,]else key);write.csv(kp,file.path(d,'key_paths.csv'),row.names=FALSE)}
  },error=function(x){ans$status<<-'READBACK_FAILURE';ans$error<<-conditionMessage(x);ans$accepted<<-FALSE})
  if(file.exists(file.path(d,'model.out')))ans$output_sha256<-digest::digest(file=file.path(d,'model.out'),algo='sha256')
  wj(ans,file.path(d,'receipt.json'));ans
 }
 compare_starts<-function(){
  ds<-file.path(ROOT,'models',c('H41_EDU_MI02_A','H41_EDU_MI02_B'));a<-read.csv(file.path(ds[1],'parameters_high_precision.csv'));b<-read.csv(file.path(ds[2],'parameters_high_precision.csv'))
  ix<-match(keys(a),keys(b));stopifnot(!anyNA(ix),!anyDuplicated(keys(a)),!anyDuplicated(keys(b)),nrow(a)==nrow(b))
  va<-as.matrix(read.csv(file.path(ds[1],'parameter_covariance.csv'),header=FALSE));vb<-as.matrix(read.csv(file.path(ds[2],'parameter_covariance.csv'),header=FALSE))[ix,ix]
  ra<-fromJSON(file.path(ds[1],'receipt.json'));rb<-fromJSON(file.path(ds[2],'receipt.json'))
  checks<-list(LL=abs(ra$LL-rb$LL),all_parameters_over_reference_SE=max(abs(a$estimate-b$estimate[ix])/a$se),SE_relative=max(abs(a$se-b$se[ix])/a$se),normalized_vcov=max(abs(va-vb)/sqrt(outer(diag(va),diag(va)))))
  t<-con$start_tolerances;pass<-checks$LL<=t$LL_absolute&&checks$all_parameters_over_reference_SE<=t$all_parameters_over_reference_SE&&checks$SE_relative<=t$SE_relative&&checks$normalized_vcov<=t$normalized_vcov
  wj(list(passed=pass,checks=checks,tolerances=t,all_parameters=nrow(a)),file.path(ROOT,'results/START_COMPARISON.json'));pass
 }
 results<-list();stop_reason<-NULL
 for(id in con$sequence){
  a<-run_one(id);results[[id]]<-a;wj(results,file.path(ROOT,'results/CALL_RESULTS.json'));say('MODEL_TERMINAL',paste(id,a$status))
  if(!a$accepted){stop_reason<-a$status;break}
  if(id=='H41_EDU_MI02_B'&&!compare_starts()){stop_reason<-'START_COMPARISON_FAILED';break}
 }
 members<-sprintf('H41_EDU_MI%02d_A',1:10)
 full<-all(members%in%names(results))&&all(vapply(results[members],function(x)isTRUE(x$accepted),logical(1)))
 if(full){
  say('POOLING','Ten complete sensitivity members; Rubin and two-path joint D1')
  library(mitml);Q<-matrix(NA_real_,10,8,dimnames=list(NULL,labs));U<-list();sources<-list()
  for(k in 1:10){d<-file.path(ROOT,'models',members[k]);kp<-read.csv(file.path(d,'key_paths.csv'));kp<-kp[match(labs,kp$label),];stopifnot(!anyNA(kp$parameter));V<-as.matrix(read.csv(file.path(d,'parameter_covariance.csv'),header=FALSE));Q[k,]<-kp$estimate;U[[k]]<-V[kp$parameter,kp$parameter];dimnames(U[[k]])<-list(labs,labs);sources[[k]]<-data.frame(member=k,source_dir=d,output_sha256=results[[members[k]]]$output_sha256,data_sha256=digest(file=file.path(d,'data.dat'),algo='sha256'),SY=results[[members[k]]]$SY)}
  out<-file.path(ROOT,'results/OLDEST_EDU_YFREE');dir.create(out)
  write.csv(data.frame(label=labs,rubin_pool(Q,U)$table,row.names=NULL),file.path(out,'POOLED_PATHS.csv'),row.names=FALSE)
  jt<-mitml::testConstraints(qhat=lapply(1:10,function(k)setNames(Q[k,],labs)),uhat=U,constraints=c('gizg','gszg'),method='D1')
  write.csv(data.frame(F=jt$test[1,1],df1=jt$test[1,2],df2=jt$test[1,3],p=jt$test[1,4],RIV=jt$test[1,5]),file.path(out,'JOINT_D1.csv'),row.names=FALSE)
  cs<-list(IY_Z0_G0=c(gi0=1),IY_Z0_G1=c(gi0=1,gizg=1),IY_difference=c(gizg=1),SY_Z0_G0=c(gs0=1),SY_Z0_G1=c(gs0=1,gszg=1),SY_difference=c(gszg=1))
  ct<-do.call(rbind,lapply(names(cs),function(n){a<-setNames(rep(0,8),labs);a[names(cs[[n]])]<-cs[[n]];data.frame(contrast=n,pool_contrast(Q,U,a),row.names=NULL)}))
  write.csv(ct,file.path(out,'GROUP_CONTRASTS.csv'),row.names=FALSE);write.csv(do.call(rbind,sources),file.path(out,'MEMBER_SOURCES.csv'),row.names=FALSE)
  write.csv(data.frame(member=1:10,Q),file.path(out,'MEMBER_ESTIMATES.csv'),row.names=FALSE)
  wj(list(status='TEN_MI_POOLED_SENSITIVITY',members=10,N=3159,new_MI=FALSE,changed_Y_shape=TRUE,original_H41_repaired=FALSE,limitation=con$inference),file.path(out,'RECEIPT.json'))
 }
 wj(list(terminal=TRUE,calls=results,full_sensitivity_MI=full,stop_reason=stop_reason,original_H41_count_changed=FALSE,original_four_complete=FALSE,full_H4_complete=FALSE),file.path(ROOT,'results/BATCH_RECEIPT.json'))
 say('YSHAPE_BATCH_TERMINAL',paste('Full conditional sensitivity MI:',full,'Stop:',stop_reason));cat('YSHAPE_BATCH_DONE\n')
})
