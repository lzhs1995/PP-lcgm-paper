"""登记真实预检，并复用经过修正的限时资源租约。"""
from pathlib import Path
import ast,hashlib,json,shutil,subprocess,sys
r=Path(__file__).resolve().parents[1];c=r.parent/'charls_latent_em_recovery_20261019'
source=r.parent/'charls_latent_scaling_calibration_20261019/code/record_preflight.py'
s=source.read_text().replace("task='pp-lgcm-charls-scaled-20261019'","task='pp-lgcm-cfps-yshape-20261019'").replace('0eacf96c','fc83c082')
(r/'code/record_preflight.py').write_text(s)
s=(c/'code/cc_memory_lease.py').read_text()
s=s.replace('import psutil','import psutil, sys\nsys.path.insert(0,"C:/Users/RESEARCH_USER/Desktop/cnm/tasks/01_R_analysis/work/ch4_archived_replay_20261016")\nfrom windows_process_terminal import process_state')
s=s.replace('C:/Users/RESEARCH_USER/Desktop/cnm/tasks/01_R_analysis/work/pp_lgcm_managed_pr52_20261019_retry04/NORMAL_UI_RESTORED.json',str(c/'audit/cc_memory_lease/RESTORED.json').replace('\\','/'))
s=s.replace("    try: return abs(psutil.Process(pid).create_time()-created)<.001\n    except psutil.NoSuchProcess: return False","    return process_state(pid, created)['state']=='active'")
s=s.replace('lease_seconds=600','lease_seconds=3600').replace('time.monotonic()+600','time.monotonic()+3600')
s=s.replace("ui_visibility_unverified=True","ui_visibility_unverified=True")
ast.parse(s);(r/'code/cc_memory_lease.py').write_text(s)
for f in (r/'code').glob('*.py'):ast.parse(f.read_text())
(r/'audit/CODE_MANIFEST.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'code').glob('*') if p.is_file()},indent=2))
print('RUNTIME_PREPARED bounded lease; Windows same-handle terminal state; execution manifest frozen')
