"""一次仅改变可选输出的对照；旧超时证据和原始模型保持不动。"""
from pathlib import Path
import hashlib,json,shutil,datetime,difflib
r=Path(__file__).resolve().parents[1]
o=r.parent/'cfps_h41_yshape_output_probe_20261019'
assert not o.exists()
for d in ['audit','code','contracts','runtime','results','models','reports']:(o/d).mkdir(parents=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert read(r/'results/BATCH_RECEIPT.json')['stop_reason']=='ENGINE_TIMEOUT'
contract=read(r/'contracts/RUN_CONTRACT.json')
contract.update(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),purpose='One output-only diagnostic after archived H1 overhead timeout; not a scientific specification search',max_mplus_calls=1,total_engine_seconds=180,sequence=['PARENT_MI02'],family_condition='Only parent diagnostic. Do not extend into H4 or MI in this output comparison.',basis='The original stdout warns about H1 standard-error work despite no explicit STANDARDIZED request. Remove optional TECH4/SAMPSTAT/RESIDUAL together, replace ignored TECH8 by TECH5; attribution to one output option remains unproven.',stop_rules=['One new engine only; no automatic retry','No statistical model/data/starts changes','Do not call this complete MI or restored H4'])
(o/'contracts/RUN_CONTRACT.json').write_text(json.dumps(contract,indent=2))
for name in ['adapter.py','bounded_child.py','r2e_tools.R','r2e_upstream_math.R','harness.py']:
 shutil.copyfile(r/'code'/name,o/'code'/name)
s=(r/'code/run_family.R').read_text().replace(r.name,o.name)
(o/'code/run_family.R').write_text(s)
src=r/'models/PARENT_MI02';dst=o/'models/PARENT_MI02';dst.mkdir()
before=(src/'model.inp').read_text()
old='TECH1 TECH3 TECH4 TECH8 SAMPSTAT RESIDUAL CINTERVAL SVALUES;'
new='TECH1 TECH3 TECH5 CINTERVAL SVALUES;'
assert before.count(old)==1
after=before.replace(old,new)
assert before.split('OUTPUT:')[0]==after.split('OUTPUT:')[0]
assert before.split('SAVEDATA:')[1]==after.split('SAVEDATA:')[1]
(dst/'model.inp').write_text(after)
shutil.copyfile(src/'data.dat',dst/'data.dat')
j=read(src/'job.json');j['input_sha256']=sha(dst/'model.inp');j['output_only_probe']=True
(dst/'job.json').write_text(json.dumps(j,indent=2))
(dst/'launch.cmd').write_text((src/'launch.cmd').read_text().replace(r.name,o.name))
(dst/'SPECIFICATION_DIFF.txt').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='prior_timeout',tofile='output_only_probe')))
proof=dict(status='PASS_OUTPUT_ONLY_CHANGE',source=str(src),source_input_sha256=sha(src/'model.inp'),new_input_sha256=sha(dst/'model.inp'),data_sha256=sha(dst/'data.dat'),model_data_analysis_and_starts_unchanged=True,save_parameters_and_TECH3_unchanged=True,additional_calls_maximum=1,source_task='pp-lgcm-cfps-yshape-20261019',native_proof_reused='Current same session, same transport, no server/config/package changes',resource_lease=str(r/'audit/cc_memory_lease'))
(o/'audit/PREPARATION.json').write_text(json.dumps(proof,indent=2))
(o/'audit/CODE_MANIFEST.json').write_text(json.dumps({p.name:sha(p) for p in (o/'code').iterdir() if p.is_file()},indent=2))
print(json.dumps(proof))
