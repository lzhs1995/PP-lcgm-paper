"""仅准备自由Y载荷敏感性；父模型和双起点通过后才准入完整十份家族。"""
from pathlib import Path
from datetime import datetime,timezone
import csv,difflib,hashlib,json,re,shutil
r=Path(__file__).resolve().parents[1];b=r.parent;c=b/'charls_latent_em_recovery_20261019';e=b/'round2E_20261010';old=b/'h41_remaining_charls_resources_20261015'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['audit','contracts','models','results','runtime','reports']:(r/n).mkdir(exist_ok=True)
assert not (r/'contracts/RUN_CONTRACT.json').exists()
source_rows=[]
for name,f in read(old/'results/H41_FAMILIES.json').items():
    member,rr=list(f['members'].items())[-1];z,g=name.split('_');d=Path(rr['source_dir']);k=int(member[2:]);parent=e/'models'/f'CFPS_{z}_E0_{k:02d}_base'
    pr=read(parent/'receipt.json');pj=read(parent/'input_contract.json');hj=read(d/'job.json')
    assert sha(d/'model.out')==rr['output_sha256'] and sha(parent/'model.out')==pr['output_sha256']
    assert sha(parent/'data.dat')==sha(d/'data.dat')==pj['data_sha256']==hj['hashes']['data.dat']
    source_rows.append(dict(family=name,member=k,N=pj['N'],data_sha256=pj['data_sha256'],parent=str(parent),parent_status=pr['status'],parent_SY=pr['sy'],H41_status=rr['status'],H41_SY=rr['sy'],parent_output_sha256=pr['output_sha256'],H41_output_sha256=rr['output_sha256'],income_adds_G_main_effects=g=='INC'))
with (r/'audit/PARENT_H41_MATCH.csv').open('x',newline='') as f:w=csv.DictWriter(f,fieldnames=source_rows[0]);w.writeheader();w.writerows(source_rows)
sources={'parent':e/'models/CFPS_OLDEST_E0_02_base','H41':old/'models/CFPS_OLDEST_H41_EDU_MI02'}
assert read(sources['parent']/'receipt.json')['usable'] and read(sources['H41']/'receipt.json')['status']=='INADMISSIBLE_SY_ONLY'
zc=read(b/'round2D_20261008/audit/Z_CONTRACT.json')['samples']['OLDEST_Z0'];assert zc['N']==3159
datafiles={k:b/'round2D_20261008/private/OLDEST'/f'Z0_member_{k:02d}.dat' for k in range(1,11)}
hashes={str(k):sha(p) for k,p in datafiles.items()}
assert [hashes[str(k)] for k in range(1,11)]==zc['data_sha256']
for f in ['bounded_child.py','harness.py','r2e_tools.R','r2e_upstream_math.R','raw_tech1.py','parse_trace.py']:shutil.copyfile(c/'code'/f,r/'code'/f)
s=(c/'code/adapter.py').read_text()
s=s.replace("sha(d/'data.dat')==j['data_sha256']==c['source_data_sha256']","sha(d/'data.dat')==j['data_sha256']==c['data_hashes'][str(j['member'])]")
s=s.replace(" if d.name.startswith('E1'):assert json.loads((ROOT/'results/E0_CALIBRATION.json').read_text())['passed']", " if d.name!='PARENT_MI02':\n  assert json.loads((ROOT/'models/PARENT_MI02/receipt.json').read_text())['accepted']\n if j['phase']=='family':\n  assert json.loads((ROOT/'results/START_COMPARISON.json').read_text())['passed']\n calls=[json.loads(x.read_text()) for x in (ROOT/'models').glob('*/LAUNCH_RECEIPT.json')]\n assert sum(x.get('actual_engine_calls',0) for x in calls)<c['max_mplus_calls']\n assert sum(x.get('exit_confirmed_seconds',0) for x in calls)<c['total_engine_seconds']")
(r/'code/adapter.py').write_text(s)
sequence=[('PARENT_MI02',2,'parent',False),('H41_EDU_MI02_A',2,'pilot',False),('H41_EDU_MI02_B',2,'start_check',True)]+[(f'H41_EDU_MI{k:02d}_A',k,'family',False) for k in [1,3,4,5,6,7,8,9,10]]
oldline='iy sy | y1@0 y2@0.4 y3@0.6 y4@0.8 y5@1 ;';newline='iy sy | y1@0 y2*0.4 y3*0.6 y4*0.8 y5@1 ;'
for name,k,phase,second in sequence:
    d=r/'models'/name;d.mkdir();source=sources['parent' if phase=='parent' else 'H41'];before=(source/'model.inp').read_text();assert before.count(oldline)==1
    after=before.replace(oldline,newline);lines=after.splitlines();assert lines[0]=='TITLE:';lines[1]=name;after='\n'.join(lines)+'\n'
    if second:
        index=[0]
        def perturb(m):
            index[0]+=1;v=float(m.group(1));v=v*(1.1 if index[0]%2 else .9) if v else (.01 if index[0]%2 else -.01)
            return '*'+format(v,'.12g')
        after=re.sub(r'\*([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][+-]?\d+)?)',perturb,after)
    after=after.replace('TECH1 TECH3 TECH4 SAMPSTAT','TECH1 TECH3 TECH4 TECH8 SAMPSTAT')
    assert max(map(len,after.splitlines()))<=90 and 'XWITH' not in after and 'sy@0' not in after.lower()
    (d/'model.inp').write_text(after);shutil.copyfile(datafiles[k],d/'data.dat')
    j=dict(id=name,member=k,phase=phase,kind='licensed_mplus',cap_seconds=180,N=3159,expected_free=137 if phase=='parent' else 141,input_sha256=sha(d/'model.inp'),data_sha256=hashes[str(k)],complete_MI=False,source_input=str(source/'model.inp'))
    (d/'job.json').write_text(json.dumps(j,indent=2))
    (d/'launch.cmd').write_text('@echo off\n"C:/Users/RESEARCH_USER/AppData/Local/Programs/Python/Python314/python.exe" -X utf8 "'+r.as_posix()+'/code/adapter.py" "%~dp0job.json" "%~1"\nexit /b %ERRORLEVEL%\n')
    (d/'SPECIFICATION_DIFF.txt').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='historical/model.inp',tofile=name+'/model.inp')))
prior=read(c/'contracts/RUN_CONTRACT.json')
contract=dict(created_at=datetime.now(timezone.utc).isoformat(),purpose='Prespecified post hoc Y-shape sensitivity for OLDEST education H4.1; no significance-based admission',
 max_mplus_calls=12,total_engine_seconds=2160,maximum_owned_engines=1,per_engine_seconds=180,sequence=[x[0] for x in sequence],new_MI=0,data_hashes=hashes,
 minimum_available_gib=1.2,minimum_commit_available_gib=2,max_cpu_percent=85,resource_wait_seconds=30,executable=prior['executable'],executable_sha256=prior['executable_sha256'],
 estimand='Observed 2012 relative oldest-child difference by education association with latent depression intercept and total endpoint change, conditional on X growth and original controls',
 scientific_change='Free Y2-Y4 growth loadings with unchanged Y1=0/Y5=1 anchors. Retain X shape, data/MI, control set, all variance/covariance restrictions, MLR and household cluster.',
 basis='Prior review requested Y-shape sensitivity. Exact same-data MI02 E0 was legal (SY 0.0011844289) while H41 became inadmissible (SY -0.0016272205); E0 Y3/Y4 mean residual z printed 2.024/-2.330, only exploratory diagnostics, not proof of causation. Historical Round2 roots show no executed YFREE model directory.',
 start_tolerances=dict(LL_absolute=.01,all_parameters_over_reference_SE=.05,SE_relative=.05,normalized_vcov=.05),
 family_condition='Parent legal then MI02 A/B all-parameter comparison; only then MI01,MI03-MI10. Stop at first inadmissible/timeout/hold; never pool a subset.',
 inference='Ten members required. Conditional on historical corrected FCS; interaction congeniality unresolved. Single post hoc sensitivity is not confirmation of original four moderations or full H4.',
 stop_rules=['No variance fixing or silent boundary tolerance','No automatic repeat of any completed attempt','No other indicators, groups or Y shapes in this batch','No manuscript overwrite or new NLM'])
(r/'contracts/RUN_CONTRACT.json').write_text(json.dumps(contract,ensure_ascii=False,indent=2))
(r/'audit/PREPARATION.json').write_text(json.dumps(dict(status='PASS_FROZEN_NEW_Y_SHAPE',matched_existing_pairs=len(source_rows),source_inputs={k:sha(v/'model.inp') for k,v in sources.items()},data_unchanged=True,prepared_calls=len(sequence)),indent=2))
print('PREPARED parent + conditional H41 family; max12 calls, 180s each; no unchanged failed specification queued')
