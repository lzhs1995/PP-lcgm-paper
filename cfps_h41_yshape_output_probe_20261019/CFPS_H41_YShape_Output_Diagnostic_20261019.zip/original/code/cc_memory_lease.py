"""限时回收本任务启动的闲置 CC Switch 界面；退出或到期后恢复普通窗口。"""
from pathlib import Path
from datetime import datetime, timezone
from ctypes import wintypes as w
import ctypes, json, os, subprocess, time
import psutil, sys
sys.path.insert(0,"C:/Users/RESEARCH_USER/Desktop/cnm/tasks/01_R_analysis/work/ch4_archived_replay_20261016")
from windows_process_terminal import process_state

ROOT = Path(__file__).resolve().parents[1]
D = ROOT / 'audit/cc_memory_lease'
D.mkdir(parents=True, exist_ok=False)
SOURCE = Path('C:/Users/RESEARCH_USER/pp_lgcm_review/charls_latent_em_recovery_20261019/audit/cc_memory_lease/RESTORED.json')
record = json.loads(SOURCE.read_text())
protected = {8764: 1792308599.6514845, 18112: 1792308603.0035183}
stamp = lambda: datetime.now(timezone.utc).isoformat()
def save(name, value):
    with (D / name).open('x', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
def alive(pid, created):
    return process_state(pid, created)['state']=='active'
def check_r():
    assert all(alive(p,c) for p,c in protected.items())
def host(): return dict(available_gib=psutil.virtual_memory().available/2**30)

cc = psutil.Process(record['pid'])
assert alive(cc.pid, record['created']) and Path(cc.exe()) == Path(record['exe'])
assert len([p for p in psutil.process_iter(['name']) if (p.info['name'] or '').lower()=='cc-switch.exe']) == 1
check_r()
children = [dict(pid=p.pid, created=p.create_time(), name=p.name()) for p in cc.children(recursive=True)]
assert all(p['name'].lower() == 'msedgewebview2.exe' for p in children)
before = dict(cpu=sum(cc.cpu_times()[:2]), write_bytes=cc.io_counters().write_bytes)
time.sleep(5)
after = dict(cpu=sum(cc.cpu_times()[:2]), write_bytes=cc.io_counters().write_bytes)
save('IDLE_CHECK.json',dict(before=before,after=after))
assert after['cpu']-before['cpu']<.5 and after['write_bytes']-before['write_bytes']<=65536
user=ctypes.WinDLL('user32',use_last_error=True)
cbtype=ctypes.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
user.EnumWindows.argtypes=[cbtype,w.LPARAM]
user.GetWindowThreadProcessId.argtypes=[w.HWND,ctypes.POINTER(w.DWORD)]
user.GetWindowTextW.argtypes=[w.HWND,w.LPWSTR,ctypes.c_int]
user.PostThreadMessageW.argtypes=[w.DWORD,w.UINT,w.WPARAM,w.LPARAM]
windows=[]
@cbtype
def callback(hwnd, _):
    pid=w.DWORD();thread=user.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
    if pid.value==cc.pid:
        title=ctypes.create_unicode_buffer(512);user.GetWindowTextW(hwnd,title,512)
        if title.value: windows.append(dict(hwnd=int(hwnd),thread=thread,title=title.value))
    return True
user.EnumWindows(callback,0)
assert windows, 'No verified CC Switch top-level window'
save('INTENT.json',dict(at=stamp(),owner=dict(pid=os.getpid(),created=psutil.Process().create_time()),source=str(SOURCE),manager=record,children=children,protected=protected,host_before=host(),lease_seconds=3600,force_termination=False))
closed=False
try:
    sent=[dict(thread=t,ok=bool(user.PostThreadMessageW(t,0x0012,0,0)),last_error=ctypes.get_last_error()) for t in sorted({x['thread'] for x in windows})]
    save('QUIT_REQUEST.json',dict(at=stamp(),requests=sent))
    until=time.monotonic()+15
    while alive(cc.pid,record['created']) and time.monotonic()<until: time.sleep(.5)
    closed=not alive(cc.pid,record['created'])
    assert closed, 'Graceful quit did not exit; no forced termination'
    until=time.monotonic()+15
    while any(alive(x['pid'],x['created']) for x in children) and time.monotonic()<until: time.sleep(.5)
    remaining=[x for x in children if alive(x['pid'],x['created'])]
    check_r();save('CLOSED.json',dict(at=stamp(),host_after=host(),remaining_children=remaining,protected_unchanged=True))
    print('CC_MEMORY_LEASE_ACTIVE',json.dumps(host()),flush=True)
    deadline=time.monotonic()+3600
    while time.monotonic()<deadline and not (D/'restore.request').exists(): time.sleep(2)
finally:
    if closed or not alive(cc.pid,record['created']):
        other=[p for p in psutil.process_iter(['name']) if (p.info['name'] or '').lower()=='cc-switch.exe']
        assert not other, 'A new manager appeared; preserve it and reconcile manually'
        child=subprocess.Popen([record['exe']],cwd=str(Path(record['exe']).parent),stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        p=psutil.Process(child.pid)
        save('RESTORE_STARTED.json',dict(at=stamp(),pid=p.pid,created=p.create_time(),exe=record['exe'],ordinary_mode=True))
        time.sleep(3);check_r();assert p.is_running()
        save('RESTORED.json',dict(at=stamp(),status='PASS_NORMAL_PROCESS_RESTORED',pid=p.pid,created=p.create_time(),exe=p.exe(),protected_unchanged=True,ui_visibility_unverified=True,host_after=host()))
        print('CC_MEMORY_LEASE_RESTORED',p.pid,flush=True)
