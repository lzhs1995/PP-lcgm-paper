# 从完整家族保存值提取预定参照点的资源组差；不重新估计。
local({
 root<-'<LOCAL_USER>/pp_lgcm_review/research_scope_synthesis_20261017'
 registry<-read.csv(file.path(root,'source/CHARLS_H42.csv'))
 out<-list();validation<-list()
 for(i in seq_len(nrow(registry))){
  f<-registry$family[i];d<-file.path(root,'source/h42',f)
  Q<-read.csv(file.path(d,'MEMBER_ESTIMATES.csv'));U<-read.csv(file.path(d,'MEMBER_COVARIANCES.csv'))
  P<-read.csv(file.path(d,'POOLED_PATHS.csv'));S<-read.csv(file.path(d,'CONDITIONAL_SLOPES.csv'))
  stopifnot(nrow(Q)==registry$m[i],identical(Q$member,seq_len(nrow(Q))))
  u<-U[U$row=='bxg'&U$column=='bxg',];u<-u[match(Q$member,u$member),]
  stopifnot(nrow(u)==nrow(Q),!anyNA(u$covariance),all(u$covariance>0))
  lo<-max(S$support_min);hi<-min(S$support_max);stopifnot(setequal(S$G,0:1))
  m<-nrow(Q);est<-mean(Q$bxg);W<-mean(u$covariance);B<-var(Q$bxg);T<-W+(1+1/m)*B
  lambda<-(1+1/m)*B/T;df<-if(lambda>0)(m-1)/lambda^2 else Inf
  se<-sqrt(T);low<-est-qt(.975,df)*se;high<-est+qt(.975,df)*se;p<-2*pt(-abs(est/se),df)
  old<-P[P$label=='bxg',];stopifnot(nrow(old)==1,max(abs(c(est,se,low,high,p)-unlist(old[c('estimate','se','lower','upper','p')])))<1e-9)
  admitted<-lo<=0&&hi>=0
  out[[i]]<-data.frame(family=f,resource=registry$resource[i],z=registry$z[i],N=registry$N[i],m=m,Z0_reference=0,common_min=lo,common_max=hi,support_admitted=admitted,estimate=if(admitted)est else NA,se=if(admitted)se else NA,df=df,lower=if(admitted)low else NA,upper=if(admitted)high else NA,p=if(admitted)p else NA,MCSE_over_SE=sqrt(B/m)/se,interpretation='Conditional resource difference in SX-to-SY slope at existing centered Z0=0')
  validation[[i]]<-data.frame(family=f,m=m,W=W,B=B,T=T,saved_bxg_match=TRUE,support_admitted=admitted)
 }
 ans<-do.call(rbind,out);ans$Holm_12<-p.adjust(ans$p,'holm',n=12)
 write.csv(ans,file.path(root,'results/MEAN_CHANGE_RESOURCE_AT_Z0.csv'),row.names=FALSE)
 write.csv(do.call(rbind,validation),file.path(root,'audit/R_CONTRAST_VALIDATION.csv'),row.names=FALSE)
 draw<-function(){
  o<-order(match(ans$z,c('sd','gender','oldest','son')),match(ans$resource,c('EDU','URBAN','INC')));a<-ans[o,];y<-rev(seq_len(nrow(a)))
  labs<-paste(c(sd='SD',gender='Son - daughter',oldest='Oldest - others',son='Eldest son - others')[a$z],a$resource,sep=' / ')
  cols<-c(EDU='#0072B2',URBAN='#009E73',INC='#D55E00')[a$resource]
  par(mar=c(6,12,4,2));plot(a$estimate,y,xlim=range(c(a$lower,a$upper),na.rm=TRUE),ylim=c(.5,12.5),yaxt='n',pch=19,col=cols,xlab='Resource group 1 minus group 0: conditional SX -> SY association',ylab='',main='CHARLS: mean-change association by resources at Z0 = 0')
  abline(v=0,col='grey55',lty=2);segments(a$lower,y,a$upper,y,col=cols,lwd=2);axis(2,at=y,labels=labs,las=1,cex.axis=.85)
  mtext('Existing complete working MI; pointwise 95% intervals; exploratory, not a replacement for H4 tests.',side=1,line=4,cex=.72)
 }
 pdf(file.path(root,'results/MEAN_CHANGE_RESOURCE_AT_Z0.pdf'),width=11.5,height=7);draw();dev.off()
 png(file.path(root,'results/MEAN_CHANGE_RESOURCE_AT_Z0.png'),width=1840,height=1120,res=160);draw();dev.off()
 cat('SAVED_CONTRAST_EXTRACTION_COMPLETE families=',nrow(ans),' supported=',sum(ans$support_admitted),' nominal_p_lt_05=',sum(ans$p<.05,na.rm=TRUE),' Holm12_lt_05=',sum(ans$Holm_12<.05,na.rm=TRUE),' new_Mplus=0\n')
})
