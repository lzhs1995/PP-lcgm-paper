"""独立复算已保存参数的12个参照点对比，并更新原假设覆盖清单。"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import csv,hashlib,json,math,statistics,sys
from scipy.stats import t
R=Path(__file__).resolve().parents[1];B=R.parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
rows=lambda p:list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
public='--public' in sys.argv
def write_csv(p,records):
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
def holm(ps):
 ix=sorted(range(len(ps)),key=lambda i:ps[i]);out=[0]*len(ps);last=0
 for k,i in enumerate(ix):last=max(last,min(1,ps[i]*(len(ps)-k)));out[i]=last
 return out
if not public:
 for item in read(R/'audit/SOURCE_MANIFEST.json'):
  assert sha(B/item['source'])==sha(R/item['path'])==item['sha256'],item['path']
 mrows=[]
 for reg in rows(R/'source/CHARLS_H42.csv'):
  f=reg['family'];d=R/'source/h42'/f
  q=rows(d/'MEMBER_ESTIMATES.csv');u=rows(d/'MEMBER_COVARIANCES.csv');s=rows(d/'MEMBER_SOURCES.csv')
  vv={int(x['member']):float(x['covariance']) for x in u if x['row']==x['column']=='bxg'}
  src={int(x['member']):x for x in s};assert len(src)==len(q)==int(reg['m'])
  support=rows(d/'CONDITIONAL_SLOPES.csv');assert {x['G'] for x in support}=={'0','1'}
  lo=max(float(x['support_min']) for x in support);hi=min(float(x['support_max']) for x in support)
  for x in q:
   k=int(x['member']);p=src[k]
   mrows.append(dict(family=f,member=k,bxg=float(x['bxg']),within_variance=vv[k],common_min=lo,common_max=hi,source_model=p['model'],output_sha256=p['output_sha256'],tech3_sha256=p['tech3_sha256'],member_estimates_sha256=sha(d/'MEMBER_ESTIMATES.csv'),member_covariances_sha256=sha(d/'MEMBER_COVARIANCES.csv')))
 write_csv(R/'results/BXG_PARAMETER_MEMBERS.csv',mrows)
else:mrows=rows(R/'results/BXG_PARAMETER_MEMBERS.csv')
table=rows(R/'results/MEAN_CHANGE_RESOURCE_AT_Z0.csv');assert len(table)==12 and len(mrows)==320
ps=[];checks=[]
for row in table:
 f=row['family'];a=[x for x in mrows if x['family']==f];m=len(a);assert m==int(row['m'])
 assert sorted(int(x['member']) for x in a)==list(range(1,m+1))
 q=[float(x['bxg']) for x in a];v=[float(x['within_variance']) for x in a]
 est=statistics.mean(q);W=statistics.mean(v);between=statistics.variance(q);total=W+(1+1/m)*between
 se=math.sqrt(total);lam=(1+1/m)*between/total;df=(m-1)/lam**2 if lam else math.inf
 p=2*t.sf(abs(est/se),df);lo=est-t.ppf(.975,df)*se;hi=est+t.ppf(.975,df)*se
 assert all(float(x['common_min'])<=0<=float(x['common_max']) for x in a)
 for k,value in dict(estimate=est,se=se,p=p,lower=lo,upper=hi,MCSE_over_SE=math.sqrt(between/m)/se).items():
  assert math.isclose(value,float(row[k]),rel_tol=1e-8,abs_tol=1e-10),(f,k,value,row[k])
 ps.append(float(p));checks.append(dict(family=f,m=m,status='PASS',support='both groups/all members',source='saved per-member coefficients and covariance diagonals; prior full TECH3 validation reused'))
adjusted=holm(ps)
assert all(abs(a-float(x['Holm_12']))<1e-10 for a,x in zip(adjusted,table))
verification=dict(status='PASS',families=12,parameter_records=len(mrows),nominal_p_lt_05=sum(p<.05 for p in ps),Holm12_p_lt_05=sum(p<.05 for p in adjusted),new_Mplus_calls=0,new_MI=0,public_mode=public,checks=checks)
(R/'audit/INDEPENDENT_CONTRASTS.json').write_text(json.dumps(verification,indent=2),encoding='utf-8')
if public:
 print(json.dumps({k:v for k,v in verification.items() if k!='checks'}));sys.exit(0)

coverage=[]
def add(cohort,family,scope,resource,status,m,source,record,target,original_gap):
 p=R/source
 coverage.append(dict(cohort=cohort,family=family,scope=scope,resource=resource,status=status,complete_members=m,target=target,source_file=source,source_sha256=sha(p),source_record=record,original_scope_complete=False,original_gap=original_gap))
for x in read(R/'source/CFPS_DYNAMIC_REGISTER.json'):
 add('CFPS','DYNAMIC',x['branch'],'NONE','NO_COMPLETE_USABLE_MI_FAMILY',0,'source/CFPS_DYNAMIC_REGISTER.json',x['branch'],'SY ON SX*observed_Z0','No full valid family; observed baseline Z0 differs from latent IZ')
for x in rows(R/'source/CFPS_H4_REGISTER.csv'):
 status=x['formal_MI'];m=10 if status=='TEN_ESTIMATES_POOLED_CONDITIONAL_ON_FROZEN_MI' else 0
 if x['family']=='H4.2':
  status='TIMEOUT_NO_INFERENCE' if x['Z']=='SD' and x['G']=='EDU' else 'INADMISSIBLE_SY_NO_INFERENCE' if x['Z']=='SD' else 'NO_VALID_PARENT_CHAIN'
 add('CFPS',x['family'],x['Z'],x['G'],status,m,'source/CFPS_H4_REGISTER.csv',x['family']+'/'+x['Z']+'/'+x['G'],x['target'],'Original latent-difference trajectory and full mean-association heterogeneity not covered')
for x in rows(R/'source/CHARLS_H41.csv'):
 add('CHARLS','H4.1',x['scope'],x['resource'],x['status'],int(x['members']),'source/CHARLS_H41.csv',x['family'],'IY/SY ON observed_Z0*G','Adjacent contact-frequency construct; baseline conditional contrasts, not difference trajectories or full mean heterogeneity')
for x in rows(R/'source/CHARLS_H42.csv'):
 add('CHARLS','H4.2',x['z'],x['resource'],x['status'],int(x['members']),'source/CHARLS_H42.csv',x['family'],'SY ON SX*observed_Z0*G','Adjacent contact-frequency construct; working MI; original latent IZ not used')
for x in rows(R/'source/CHARLS_DYNAMIC.csv'):
 add('CHARLS','DYNAMIC',x['scope'],'NONE','TWENTY_CONDITIONAL_MI_POOLED',20,'source/CHARLS_DYNAMIC.csv',x['scope'],'SY ON SX*observed_Z0','Adjacent construct and observed baseline moderator, not original latent trajectory mechanism')
assert len(coverage)==56
# 对H4.2最新失败记录补绑实际证据；不让旧登记表冒充新失败来源。
for row in coverage:
 if row['cohort']=='CFPS' and row['family']=='H4.2' and row['scope']=='SD' and row['resource'] in ('URBAN','INC'):
  actual=next(x for x in read(R/'source/CFPS_H42_FIRST_ATTEMPTS.json')['models'] if x['group']==row['resource'])
  assert actual['status']=='INADMISSIBLE_SY_ONLY';row.update(source_file='source/CFPS_H42_FIRST_ATTEMPTS.json',source_sha256=sha(R/'source/CFPS_H42_FIRST_ATTEMPTS.json'),source_record=row['resource'])
 if row['cohort']=='CFPS' and row['family']=='H4.2' and row['scope']=='SD' and row['resource']=='EDU':
  original=B/'cfps_h42_unrun_sd_20261017/audit/HISTORICAL_EDU_TIMEOUT.json'
  # 本机路径只留在本机证据，公开表引用原文件哈希和既有公开批次。
  row.update(source_file='cfps_h42_unrun_sd_20261017/audit/HISTORICAL_EDU_TIMEOUT.json',source_sha256=sha(original),source_record='historical SD EDU')
write_csv(R/'results/EVIDENCE_COVERAGE_56.csv',coverage)
h41=rows(R/'source/CHARLS_H41.csv');h42=rows(R/'source/CHARLS_H42.csv');dyn=rows(R/'source/CHARLS_DYNAMIC.csv')
son=next(x for x in h41 if x['family']=='SON_INC')
summary=dict(CFPS_H41_complete_registered_families=3,CFPS_H41_registered=12,CHARLS_H41_complete_registered_families=12,CHARLS_H42_complete_registered_families=12,CHARLS_H42_members=sum(int(x['members']) for x in h42),CHARLS_dynamic_families=4,CHARLS_dynamic_members=80,CHARLS_H41_min_joint_p=min(float(x['joint_p']) for x in h41),CHARLS_H41_son_income_joint_p=float(son['joint_p']),CHARLS_H41_son_income_Holm4=float(son['holm_p_income4']),CHARLS_H41_son_income_Holm12=float(son['holm_p_combined12']),CHARLS_H42_intervals_excluding_zero=sum(not(float(x['lower'])<=0<=float(x['upper'])) for x in h42),new_secondary_contrasts=12,new_Mplus_calls=0,new_MI=0,original_four_complete=False,original_full_H4_complete=False)
(R/'results/SYNTHESIS_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(dict(status='PASS',coverage_rows=len(coverage),**summary)))
