"""独立复读TECH1/RESULTS/TECH3，核对全部低阶项、R表与组差协方差。"""
from pathlib import Path
import hashlib,json,re,sys
import numpy as np
import pandas as pd
from scipy.stats import norm
from raw_parameter_reader import raw_model
R=Path(__file__).resolve().parents[1];read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
labs=['bss','dc','bxg','dcg'];fields=['estimate','se','lower','upper','p']
def main(public=False):
 jobs=read(R/'contracts/JOBS.json');calls=read(R/'results/CALL_RESULTS.json');entries=read(R/'contracts/DATA_ENTRIES.json');families=read(R/'results/FAMILY_STATUS.json')
 assert read(R/'audit/TERMINAL.json')['status']=='H42_PILOT_TERMINAL'
 table=pd.read_csv(R/'results/H42_REGISTERED_12.csv').set_index('family');assert set(table.index)==set(entries) and len(table)==12
 parsed={};checks={}
 for name,j in jobs.items():
  d=R/'models'/name;e=entries[j['family']]
  if not public:
   assert sha(d/'model.inp')==j['hashes']['model.inp'];assert sha(d/'data.dat')==j['hashes']['data.dat']==e['parent_hashes']['data.dat']
   for n,h in e['parent_hashes'].items():assert sha(Path(e['parent_dir'])/n)==h
  c=calls.get(name)
  if c is None:checks[name]={'status':'NOT_RUN'};continue
  if c['status']!='USABLE_SINGLE_DATASET':checks[name]={'status':c['status']};continue
  assert sha(d/'model.out')==c['output_sha256']
  out,mapping,q,se,V,key,ll=raw_model(d)
  assert 'THE MODEL ESTIMATION TERMINATED NORMALLY' in out and 'FIXED TO AVOID SINGULARITY' not in out
  assert len(q)==j['expected_free']==e['parent_free']+3 and int(re.search(r'Number of observations\s+(\d+)',out,re.I).group(1))==e['N']
  assert not any(q[p-1]<0 for mat,a,b,p in mapping if mat in ('PSI','THETA') and a==b and p>0)
  assert np.linalg.eigvalsh(V/np.outer(np.sqrt(V.diagonal()),np.sqrt(V.diagonal()))).min()>1e-10
  # 原始TECH1须包含三重交互及所有低阶路径，不以标签存在代替路径核验。
  for lhs,rhs in [('SY','SX'),('SY','Z0'),('SY',e['g_column'].upper()),('SY','ZG'),('SY','SXZ'),('SY','SXG'),('SY','SXZG')]:
   assert any(mat in ('BETA','GAMMA') and a==lhs and b==rhs and p>0 for mat,a,b,p in mapping),(name,lhs,rhs)
  key=key.set_index('label');ix=key.loc[labs].parameter.to_numpy(dtype=int)-1
  parsed[name]=(q[ix],V[np.ix_(ix,ix)],se[ix],ll,key)
  checks[name]={'status':'PASS','parameters':len(q),'N':e['N']}
 def scalar(q,V,a):
  a=np.asarray(a);est=float(a@q);se=float(np.sqrt(a@V@a));return [est,se,est-norm.ppf(.975)*se,est+norm.ppf(.975)*se,2*norm.sf(abs(est/se))]
 cs=pd.read_csv(R/'results/GROUP_MODERATION_CONTRASTS.csv') if (R/'results/GROUP_MODERATION_CONTRASTS.csv').exists() else pd.DataFrame()
 curves=pd.read_csv(R/'results/CONDITIONAL_SLOPES.csv') if (R/'results/CONDITIONAL_SLOPES.csv').exists() else pd.DataFrame()
 for f,state in families.items():
  e=entries[f];prefix=f'CHARLS_{e["z"].upper()}_H42_{e["group"]}_CC_';a=parsed.get(prefix+'A');b=parsed.get(prefix+'B')
  if a is not None and b is not None:
   ak=a[4].sort_index();bk=b[4].loc[ak.index];aq=ak.estimate.to_numpy();bq=bk.estimate.to_numpy();ase=ak.se.to_numpy();bse=bk.se.to_numpy()
   passed=abs(a[3]-b[3])<=.01 and np.all(abs(aq-bq)<=np.maximum(.001,.05*np.maximum(ase,bse))) and np.all(abs(ase-bse)/np.maximum(ase,bse)<=.05)
   assert bool(passed)==read(R/'results'/f'{f.upper()}_START_COMPARISON.json')['passed']
   assert (state['status']=='TWO_STARTS_USABLE_CC')==bool(passed)
  if state['status']!='TWO_STARTS_USABLE_CC':assert pd.isna(table.loc[f,'estimate']);continue
  q,V,_,_,_=a;assert np.allclose(scalar(q,V,[0,0,0,1]),table.loc[f,fields].to_numpy(dtype=float),rtol=1e-10,atol=1e-12)
  for name,w in [('delta_G0',[0,1,0,0]),('delta_G1',[0,1,0,1]),('direct_difference',[0,0,0,1])]:
   row=cs[(cs.family==f)&(cs.contrast==name)];assert len(row)==1
   assert np.allclose(scalar(q,V,w),row[fields].to_numpy()[0],rtol=1e-10,atol=1e-12)
  for r in curves[curves.family==f].itertuples():
   assert r.support_min<=r.z<=r.support_max
   assert np.allclose(scalar(q,V,[1,r.z,r.G,r.z*r.G]),[getattr(r,k) for k in fields],rtol=1e-10,atol=1e-12)
 valid=table.p.dropna().sort_values();holm=np.minimum(1,np.maximum.accumulate(valid.to_numpy()*(12-np.arange(len(valid)))))
 assert np.allclose(holm,table.loc[valid.index,'Holm_12']) and np.allclose(np.minimum(1,valid*12),table.loc[valid.index,'Bonferroni_12'])
 out={'status':'PASS','mode':'PUBLIC_RAW_PARAMETER_REPLAY' if public else 'INPUTS_RAW_PARAMETERS_AND_R_SUMMARY','registered':12,'usable':len(valid),'models':checks,'full_H4_complete':False,'MI_complete':False}
 (R/'audit'/('PUBLIC_PARAMETER_REPLAY.json' if public else 'INDEPENDENT_VERIFICATION.json')).write_text(json.dumps(out,indent=2),encoding='utf-8')
 print(json.dumps({'status':'PASS','registered':12,'usable':len(valid),'actual_calls':len(calls)}))
if __name__=='__main__':main('--public' in sys.argv)
