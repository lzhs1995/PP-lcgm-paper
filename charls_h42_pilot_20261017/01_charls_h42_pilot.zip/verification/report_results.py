"""按12个已登记H4.2范围生成完整表图和诚实的完成边界。"""
from pathlib import Path
import json,os
os.environ.setdefault('OMP_NUM_THREADS','1')
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def main():
 assert read(R/'audit/INDEPENDENT_VERIFICATION.json')['status']=='PASS'
 table=pd.read_csv(R/'results/H42_REGISTERED_12.csv');receipt=read(R/'results/SUMMARY_RECEIPT.json');budget=read(R/'runtime/budget_status.json')
 rows=[]
 for r in table.itertuples():
  numbers=f'{r.estimate:.6f} | [{r.lower:.6f}, {r.upper:.6f}] | {r.p:.6f} | {r.Holm_12:.6f}' if pd.notna(r.estimate) else '— | — | — | —'
  rows.append(f'| {r.family} | {r.N} | {numbers} | {r.status} |')
 fig,ax=plt.subplots(figsize=(10,8));labels=[]
 for i,r in enumerate(table.itertuples()):
  labels.append(r.family.replace('_',' / '))
  if pd.notna(r.estimate):ax.errorbar(r.estimate,i,xerr=[[r.estimate-r.lower],[r.upper-r.estimate]],fmt='o',capsize=3,color='#2369a1')
  else:ax.text(.02,i,'No adopted estimate',transform=ax.get_yaxis_transform(),fontsize=8,color='#666666')
 ax.set_yticks(range(len(labels)),labels);ax.invert_yaxis();ax.axvline(0,color='black',linewidth=.8)
 ax.set_title('CHARLS H4.2: direct difference in dynamic moderation')
 ax.set_xlabel('SX × baseline Z × resource: complete-case estimate and pointwise 95% interval')
 fig.text(.5,.01,'Different scope samples; fixed 12-test multiplicity. Complete-case feasibility does not complete MI or full H4.',ha='center',fontsize=9)
 fig.tight_layout(rect=[0,.035,1,1]);fig.savefig(R/'results/H42_TRIPLE_INTERACTIONS.pdf');fig.savefig(R/'results/H42_TRIPLE_INTERACTIONS.png',dpi=160);plt.close(fig)
 text='''# CHARLS H4.2：十二规格完整案例可行性小试

**四项调节完整推断、完整 H4 仍未完成。**

本批推进SX×观测基期Z0×资源→SY。它不同于H4.1基期路径异质性，也不同于不含资源的SX×Z0调节。CHARLS见面频率是相邻构念，不能改称CFPS情感亲近度。

## 实际结果

'''+f'预定12个规格，{receipt["usable"]}个通过两套独立起点及合法性核验。新增{len(budget["rows"])}次调用，启动器/引擎墙钟合计{budget["engine_seconds"]:.3f}秒；12个精确同样本H4.1父模型直接复用。名义P<.05有{receipt["nominal_significant"]}项，固定12项Holm后有{receipt["Holm_significant"]}项。新增MI为0，CFPS调用为0。\n\n'+'''| 差异×资源 | N | 三重交互 | 95%完整案例区间 | P | Holm(12) | 状态 |
|---|---:|---:|---|---:|---:|---|
'''+ '\n'.join(rows)+'''

没有采用估计的规格仍保留在分母及运行台账中。原始输出、失败和起点差异均保留，不通过放宽门槛、清零方差或换成员追求星号。

## 估计对象与解释

教育G=1为初中及以上，城乡G=1为城市；收入G=1为基期家庭净收入超过此前冻结的8730元。该家庭收入定义不等于CFPS个人收入。四个Z依次为绝对SD、儿子减女儿、最年长子女减其他、长子减所有其他的见面频率差，尺度和子女来源规则不变。

低阶项SX、Z0、G、Z0×G、SX×Z0、SX×G全部保留，同时保留原H4.1的增长因子及基期观测直接路径。主检验是三重交互dcg，而不是比较两组星号。两组调节为dc、dc+dcg；条件变化关联为bss+dc×Z+bxg×G+dcg×Z×G，区间使用完整参数协方差。各组曲线仅在本组真实Z支持范围报告。区间为点态，不是同时置信带。

父模型与新模型的逐字节数据哈希一致，父模型结构语句集合逐项核对。每规格两个交互起点分别从同一无交互父模型产生，不能当成两份MI。原始TECH1、RESULTS、TECH3独立核对参数身份、标准误、协方差、低阶项、组差和条件斜率。30点积分，原EM导数和似然停止准则不变；项目起点一致性容差不是全局最优证明。

Mplus官方支持潜变量与观测变量用XWITH、观测乘积用DEFINE；本批显式构造Z0×G，再由SX XWITH ZG定义三重交互：[官方MODEL语法](https://www.statmodel.com/HTML_UG/chapter17V8.htm)。

## 缺失与后续

本批沿用各资源范围完整案例和后续X/Y的FIML掩码。完整案例选择性仍存在；本批不作全体无偏或完整MI推断。上一批四项20份工作插补已经包含Z与各波辅助值，但没有为本三重交互额外建立全部G×Z×波次的缺失模型；旧收入FCS也不能自动升级为潜三重交互相容MI。因此下一步必须按资源范围核对插补相容性，再决定有限完整家族，而非直接重命名旧MI。

H4.2a/b的理论方向须结合直接组差及两组调节方向共同判断，不能仅凭一项正负或P值。未能取得采用估计不等于假设被否证；不显著不等于证明无效应。已完成的CHARLS条件H4.1十二家族、CFPS三家族和此前四项敏感性保持原裁定。冻结正文及补充材料未修改，不新增NLM或全量CI。

## Windows执行记录

准备任务9f3178da的异步提交回执丢失，按RStudio后台实际job代码和PID找回并读取终态，没有重复提交。短连接核查fc046633也保留原错误与真实终态。源桥post_to_r_addin采用10秒HTTP超时，说明提交回执超时不能判断后台未启动；没有在其他活跃任务期间修改桥或重启RStudio。正式模型job09ba2b72的原生提交回执正常。Windows ps接口须用ps_get_cpu_affinity/ps_set_cpu_affinity；未执行主函数里的错误API在估计前修复，24个模型输入未改。

所有新输入和输出位于独立本机目录；原始数据、原R脚本及既有成功输出保持。只按核实归属调整自有进程，资源准入保留原1GiB物理可用、2GiB commit和单引擎限制；不关闭外部RStudio/研究任务。
'''
 (R/'reports/REPORT.md').write_text(text,encoding='utf-8')
 (R/'reports/RECEIPT.json').write_text(json.dumps({**receipt,'status':'H42_CC_PILOT_REPORTED','calls':len(budget['rows']),'engine_seconds':budget['engine_seconds']},indent=2),encoding='utf-8')
 print(json.dumps({'reported':12,'usable':receipt['usable'],'calls':len(budget['rows'])}))
if __name__=='__main__':main()
