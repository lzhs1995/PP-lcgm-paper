"""估计前逐个核对24个输入、源数据哈希与全部低阶项；仅修正未执行的调度API绑定。"""
import ctypes
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
assert k.SetProcessAffinityMask(k.GetCurrentProcess(),15)
from pathlib import Path
import hashlib,json,re,shutil,datetime
R=Path(__file__).resolve().parents[1];read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
jobs=read(R/'contracts/JOBS.json');entries=read(R/'contracts/DATA_ENTRIES.json');assert len(jobs)==24
checks=[]
for name,j in jobs.items():
 d=Path(j['dest']);e=entries[j['family']]
 assert not (d/'model.out').exists()
 for n,h in j['hashes'].items():assert sha(d/n)==h
 assert sha(d/'data.dat')==e['parent_hashes']['data.dat']
 text=(d/'model.inp').read_text();parent=(Path(e['parent_dir'])/'model.inp').read_text()
 for syntax in ('sxz | sx XWITH z0;',f'sxg | sx XWITH {e["g_column"]};','sxzg | sx XWITH zg;','sy ON sxz (dc);','sy ON sxg (bxg);','sy ON sxzg (dcg);','sy ON sx (bss);','iy ON zg (gizg);','sy ON zg (gszg);','ix sx iy sy ON c1-c11;'):
  assert syntax in text,(name,syntax)
 if e['group']=='INC':assert 'ix sx iy sy ON g;' in text and 'x1 y1 ON g;' in text
 else:assert f'DEFINE: zg=z0*{e["g_column"]};' in text
 assert 'sy@0' not in text.lower() and j['expected_free']==e['parent_free']+3
 checks.append({'model':name,'N':j['N'],'expected_free':j['expected_free'],'same_parent_data':True})
old=read(R/'audit/FROZEN_CODE.json');shutil.copyfile(R/'audit/FROZEN_CODE.json',R/'audit/PREPARED_CODE_HASHES.json')
new={p.name:sha(p) for p in (R/'code').iterdir() if p.is_file()}
assert set(n for n in old if old[n]!=new[n])=={'worker.R'}
(R/'audit/PRE_EXECUTION_API_REPAIR.json').write_text(json.dumps({'reason':'Foreground diagnostic showed ps_cpu_affinity is not exported. Replace unexecuted main() call with documented already-used ps_get_cpu_affinity/ps_set_cpu_affinity. No model/input/data changed; all24 prepared inputs reused.','old_worker':old['worker.R'],'new_worker':new['worker.R'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2),encoding='utf-8')
(R/'audit/FROZEN_CODE.json').write_text(json.dumps(new,indent=2),encoding='utf-8')
out={'status':'PASS','models':checks,'new_Mplus':0,'reused_parent_models':12}
(R/'audit/INPUT_VERIFICATION.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({'status':'PASS','models':24,'new_Mplus':0}))
