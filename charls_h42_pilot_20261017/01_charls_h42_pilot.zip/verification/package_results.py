"""发布H4.2汇总和参数证据，不公开逐人数据，不复制旧H4.1模型。"""
from pathlib import Path
import csv,hashlib,io,json,re,zipfile
R=Path(__file__).resolve().parents[1];read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
def main():
 assert read(R/'audit/INDEPENDENT_VERIFICATION.json')['status']=='PASS'
 assert read(R/'audit/CLAUDER_COMPLETION.json')['decision']=='PASS'
 assert read(R/'audit/FIGURE_REVIEW.json')['status']=='PASS'
 S=R/'public_stage';S.mkdir(exist_ok=True);assert not list(S.glob('*.zip'))
 selected={}
 def add(rel,required=True):
  p=R/rel
  if not p.exists():assert not required,p;return
  assert p.is_file() and p.suffix.lower() not in ('.rds','.dta','.rdata') and 'private' not in p.parts
  if p.suffix=='.dat':assert p.name in ('estimates.dat','tech3.dat')
  selected[rel]=p
 for p in sorted((R/'contracts').iterdir()):add('contracts/'+p.name)
 for p in sorted((R/'code').iterdir()):
  if p.suffix in ('.R','.py'):add('code/'+p.name)
 for n in ('raw_parameter_reader.py','verify_inputs.py','verify_results.py','report_results.py','package_results.py','verify_package.py','harness_control.py'):add('verification/'+n)
 for n in ('REUSED_CODE.json','PREPARED_CODE_HASHES.json','FROZEN_CODE.json','PRE_EXECUTION_API_REPAIR.json','INPUT_VERIFICATION.json','TERMINAL.json','INDEPENDENT_VERIFICATION.json','FIGURE_REVIEW.json','CLAUDER_COMPLETION.json','FINAL_RUNTIME.json','NATIVE_PREP_SUBMIT.json','NATIVE_PREP_RESULT.json','CONNECTION_PROBE.json','PREP_SCHEDULING.json','NATIVE_SMOKE_SUBMIT.json','NATIVE_SMOKE_RECOVERED_RESULT.json','NATIVE_RUN_SUBMIT.json','NATIVE_RUN_RESULT.json','NATIVE_SUMMARY_RESULT.json','RUN_LOADING_SCHEDULING.json','R_SESSION_INFO.txt','DOCTOR.json','GUARD_PRE_SUBMIT.json','GUARD_REGISTER.json','GUARD_FINAL.json','NATIVE_SMOKE_RECOVERY_ARCHIVE.json','POSTPROCESS.json','UTILITY_RECLAMATION.json'):add('audit/'+n)
 for n in ('REPORT.md','RECEIPT.json'):add('reports/'+n)
 for p in (R/'results').iterdir():
  if p.suffix in ('.json','.csv','.pdf'):add('results/'+p.name)
 for id,j in read(R/'contracts/JOBS.json').items():
  for n in ('model.inp','job.json','start_mapping.csv','design_check.json'):add(f'models/{id}/{n}')
  for n in ('model.out','engine_receipt.json','receipt.json','not_run.json','mplus_execution.log','validation.json','parameters_high_precision.csv','tech1_parameter_map.csv','matrix_values.csv','key_paths.csv','parameter_covariance.csv','estimates.dat','tech3.dat'):add(f'models/{id}/{n}',False)
 add('runtime/budget_status.json');payload={};manifest=[]
 for name,p in selected.items():
  raw=p.read_bytes()
  if p.suffix=='.pdf':data=raw
  else:
   text=raw.decode('utf-8-sig')
   for prefix in ('<LOCAL_USER_HOME>','<LOCAL_USER_HOME>','C:\\\\Users\\\\LZHS','<LOCAL_USER_HOME>','<LOCAL_USER_HOME>'):text=text.replace(prefix,'<LOCAL_USER_HOME>')
   assert not re.search(r'(?i)(?:api[_-]?key|access_token)\s*[:=]\s*["\x27]?[A-Za-z0-9_-]{20,}',text),name
   if p.suffix=='.csv' and p.name!='parameter_covariance.csv':
    head={x.lower() for x in next(csv.reader(io.StringIO(text)))};assert not head&{'pid','fid','childid','householdid','communityid'},name
   data=text.encode('utf-8')
  payload[name]=data;manifest.append({'path':name,'bytes':len(data),'sha256':sha(data),'local_source_sha256':sha(raw),'role':'explicit_aggregate_code_or_model_parameter'})
 payload['PAYLOAD_MANIFEST.json']=json.dumps(manifest,indent=2).encode()
 groups=[sorted(payload.items())]
 while True:
  revised=[];split=False
  for group in groups:
   stream=io.BytesIO()
   with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,b in group:z.writestr(n,b)
   if len(stream.getvalue())>=25_000_000:mid=len(group)//2;assert mid;revised.extend((group[:mid],group[mid:]));split=True
   else:revised.append(group)
  groups=revised
  if not split:break
 packs=[]
 for i,group in enumerate(groups,1):
  p=S/f'{i:02d}_charls_h42_pilot.zip'
  with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
   for n,b in group:z.writestr(n,b)
  with zipfile.ZipFile(p) as z:assert z.testzip() is None
  assert p.stat().st_size<25_000_000;packs.append({'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'files':len(group)})
 pm={'packages':packs,'privacy':'No individual records; parameter DAT and TECH3 only','full_H4_complete':False,'MI_complete':False}
 (S/'PACKAGE_MANIFEST.json').write_text(json.dumps(pm,indent=2),encoding='utf-8')
 for a,b in [('reports/REPORT.md','REPORT.md'),('results/H42_REGISTERED_12.csv','H42_REGISTERED_12.csv'),('results/GROUP_MODERATION_CONTRASTS.csv','GROUP_MODERATION_CONTRASTS.csv'),('results/H42_TRIPLE_INTERACTIONS.pdf','H42_TRIPLE_INTERACTIONS.pdf')]:
  if a in payload:(S/b).write_bytes(payload[a])
 text='''# CHARLS H4.2 十二范围完整案例小试

**四项调节完整推断、完整 H4 仍未完成。**

[报告](REPORT.md) · [十二项结果](H42_REGISTERED_12.csv) · [直接组差与组内调节](GROUP_MODERATION_CONTRASTS.csv) · [区间图](H42_TRIPLE_INTERACTIONS.pdf) · [包清单](PACKAGE_MANIFEST.json)

本批只报告已登记完整案例可行性，保留失败，不将两套起点当MI。全部源H4.1父模型复用，不再次上传其个人数据。新模型原始参数可复算：合并解压ZIP后运行 `python verification/verify_results.py --public`，需numpy、pandas、scipy；无需Mplus或微观数据。

已有H4.1十二家族：https://github.com/lzhs1995/PP-lcgm-paper/tree/87941423437c589809a2c95833c220e387fc0f5d/charls_son_income_resume_20261016
已有四项动态MI工作敏感性：https://github.com/lzhs1995/PP-lcgm-paper/tree/6ea7d570be09492927eac64315f7655cad55d66d/charls_dynamic_mi_sensitivity_20261016

不重新开启已冻结稿件/NLM，不公开个人级数据。后续完整MI需三重交互的缺失处理合同，不能直接改名旧加法MI。
'''
 (S/'README.md').write_text(text,encoding='utf-8');(S/'FOR_WEB_REVIEWERS.md').write_text('请先阅读报告中的12个登记范围及失败、完整案例选择和MI未完成边界，再复算参数/协方差。不要比较两组星号判断H4.2；不得将CHARLS见面频率称为CFPS情感亲近度。无需重新拟合或增加NLM轮次。\n\n'+text,encoding='utf-8')
 (R/'audit/PUBLIC_FILE_SELECTION.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');print(json.dumps(pm))
if __name__=='__main__':main()
