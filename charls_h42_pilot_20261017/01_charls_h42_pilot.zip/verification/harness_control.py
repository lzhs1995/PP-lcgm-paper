"""真实原生工具回执登记与执行门；不伪造回调，不调用统计引擎。"""
import ctypes
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
assert k.SetProcessAffinityMask(k.GetCurrentProcess(),15),ctypes.get_last_error()
from pathlib import Path
import contextlib,io,json,sys
sys.path.insert(0,'<LOCAL_USER_HOME>/.codex/skills/clauder-rstudio-workbench')
from clauder_workbench.cli import main as cli
R=Path(__file__).resolve().parents[1];KEY='pp-lgcm-charls-h42-20261017'
def run(args,name):
 b=io.StringIO()
 with contextlib.redirect_stdout(b):rc=cli(args)
 (R/'audit'/name).write_text(b.getvalue(),encoding='utf-8');j=json.loads(b.getvalue())
 assert rc==0 and j['decision']=='PASS',j
 print(json.dumps({'step':args[:2],'decision':j['decision'],'id':j['evidence_id']}),flush=True);return j
if sys.argv[1]=='setup':
 run(['doctor','--expect-client','codex','--check-toml-parse'],'DOCTOR.json')
 run(['native-smoke','start','--task-key',KEY,'--session-name','default','--agent','codex','--require-raw-file'],'NATIVE_START.json')
 run(['native-smoke','record','--task-key',KEY,'--step','list_sessions','--ok','--session-name','default','--session-count','2','--raw-file',str(R/'audit/NATIVE_LIST.json')],'NATIVE_LIST_RECORD.json')
 run(['native-smoke','record','--task-key',KEY,'--step','execute_r','--ok','--marker','H42_NATIVE_EXECUTE_OK','--pid','26032','--raw-file',str(R/'audit/NATIVE_EXECUTE.json')],'NATIVE_EXECUTE_RECORD.json')
elif sys.argv[1]=='prepared':
 job=sys.argv[2]
 run(['native-smoke','record','--task-key',KEY,'--step','execute_r_async','--ok','--job-id',job,'--raw-file',str(R/'audit/NATIVE_PREP_SUBMIT.json')],'NATIVE_PREP_SUBMIT_RECORD.json')
 run(['native-smoke','record','--task-key',KEY,'--step','get_async_result','--ok','--job-id',job,'--marker','H42_PREPARE_NATIVE_TERMINAL','--raw-file',str(R/'audit/NATIVE_PREP_RESULT.json')],'NATIVE_PREP_RESULT_RECORD.json')
 run(['native-smoke','complete','--task-key',KEY,'--max-age-min','60'],'NATIVE_PROOF.json')
 run(['async-guard','pre-submit','--task-key',KEY,'--session-name','default','--io-mode','durable_files'],'GUARD_PRE_SUBMIT.json')
elif sys.argv[1]=='register':
 run(['async-guard','register-job','--task-key',KEY,'--job-id',sys.argv[2],'--session-name','default','--io-mode','durable_files'],'GUARD_REGISTER.json')
elif sys.argv[1]=='recover_pre_submit':
 run(['native-smoke','cancel','--task-key',KEY,'--reason','submit_ack_lost_jobs_recovered'],'NATIVE_SMOKE_RECOVERY_ARCHIVE.json')
 run(['async-guard','pre-submit','--task-key',KEY,'--session-name','default','--io-mode','durable_files'],'GUARD_PRE_SUBMIT.json')
