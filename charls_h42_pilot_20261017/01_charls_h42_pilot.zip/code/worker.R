# CHARLS H4.2：同样本父模型复用、完整低阶项、两套独立起点；不扩大估计合同。
.libPaths(c('<LOCAL_USER_HOME>/pp_lgcm_runs/20260908/library_mplusautomation_20260926',.libPaths()))
library(jsonlite);library(digest);library(processx);library(ps);library(MplusAutomation)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_h42_pilot_20261017'
Sys.setenv(R2E_ROOT=ROOT);source(file.path(ROOT,'code/r2e_local.R'),local=TRUE)
contract<-rj(file.path(ROOT,'contracts/RUN_CONTRACT.json'));entries<-rj(file.path(ROOT,'contracts/DATA_ENTRIES.json'))
growth<-function(p)paste0('i',p,' s',p,' | ',p,'1@0 ',p,'2@2 ',p,'3@4 ',p,'4@7 ',p,'5@9;')
specification<-function(e){
 b<-c(growth('x'),growth('y'),'iy ON ix (bii);','sy ON ix (bis);','sy ON sx (bss);','sy ON iy (bsyiy);','ix WITH sx;','sx WITH iy;',paste0('x',1:5,' WITH y',1:5,';'),'ix sx iy sy ON c1-c11;',
      'ix sx ON z0;','iy ON z0 (gi0);','sy ON z0 (gs0);','x1 y1 ON z0;','ix sx ON zg;','iy ON zg (gizg);','sy ON zg (gszg);','x1 y1 ON zg;')
 if(e$group=='INC')b<-c(b,'ix sx iy sy ON g;','x1 y1 ON g;')
 list(kind='lms_observed',fac=FAC_XY,obs=OBS_XY,fixed_zero=character(),g=e$g_column,
      parent=b,model=c(b,'sxz | sx XWITH z0;',paste0('sxg | sx XWITH ',e$g_column,';'),'sxzg | sx XWITH zg;','sy ON sxz (dc);','sy ON sxg (bxg);','sy ON sxzg (dcg);'),
      key=rbind(KEY_XY,key_add(c('gi0','gs0','gizg','gszg','dc','bxg','dcg'),c('IY','SY','IY','SY','SY','SY','SY'),c('Z0','Z0','ZG','ZG','SXZ','SXG','SXZG'))))
}
slots<-function(si){
 a<-list();add<-function(op,lhs,rhs='',init=0){a[[length(a)+1L]]<<-data.frame(op=op,lhs=toupper(lhs),rhs=toupper(rhs),init=init)}
 for(f in FAC_XY)add('MEAN',f)
 for(o in OBS_XY)add('VAR',o,init=.5)
 for(f in FAC_XY)add('VAR',f,init=.1)
 for(key in stmt_pairs(si$model)){t<-strsplit(toupper(key),' ',fixed=TRUE)[[1]];add(t[2],t[1],t[3])}
 x<-do.call(rbind,a);x$key<-paste(x$op,x$lhs,x$rhs,sep=':');stopifnot(!anyDuplicated(x$key));x
}
extract<-function(m,key){do.call(rbind,lapply(seq_len(nrow(key)),function(i){
 k<-key[i,];id<-pnum(m,'BETA',k$row,k$column);if(id==0)id<-pnum(m,'GAMMA',k$row,k$column)
 stopifnot(id>0);p<-m$par[m$par$parameter==id,];stopifnot(nrow(p)==1)
 data.frame(k,parameter=id,estimate=p$estimate,se=p$se)
}))}
prepare<-function(fam,start){
 e<-entries[[fam]];id<-paste('CHARLS',toupper(e$z),'H42',e$group,'CC',start,sep='_');d<-file.path(ROOT,'models',id);dir.create(d,showWarnings=FALSE)
 if(file.exists(file.path(d,'job.json')))return(rj(file.path(d,'job.json')))
 for(n in names(e$parent_hashes))stopifnot(identical(hashf(file.path(e$parent_dir,n)),e$parent_hashes[[n]]))
 src<-readLines(file.path(e$parent_dir,'model.inp'),warn=FALSE);beg<-grep('^MODEL:',src);end<-grep('^OUTPUT:',src);stopifnot(length(beg)==1,length(end)==1)
 si<-specification(e);old<-src[(beg+1):(end-1)]
 stopifnot(setequal(stmt_pairs(old),stmt_pairs(si$parent)),!any(grepl('XWITH',old)))
 a<-read.table(file.path(e$parent_dir,'data.dat'),col.names=unlist(e$columns),na.strings='-9999')
 stopifnot(nrow(a)==e$N,all(a[[e$g_column]]%in%0:1),length(unique(a$cluster))==e$communities)
 product<-a$z0*a[[e$g_column]]
 if('zg'%in%names(a))stopifnot(identical(a$zg,product))else a$zg<-product
 design<-cbind(1,as.matrix(a[c(paste0('c',1:11),'z0',if(e$group=='INC')'g','zg')]))
 stopifnot(!anyNA(design),qr(design)$rank==ncol(design))
 mm<-make_model(si,e$parent_dir,perturb=start=='B')
 for(rhs in c('SXZ','SXG','SXZG')){
  hit<-which(mm$mapping$key==paste0('ON:SY:',rhs));stopifnot(length(hit)==1)
  mm$mapping$value[hit]<-if(start=='A').1 else -.1
  mm$mapping$action[hit]<-'registered_new_interaction_start'
  mm$lines[length(si$model)+hit]<-paste0('sy ON ',tolower(rhs),'*',mm$mapping$value[hit],';')
 }
 stopifnot(mm$expected_free==e$parent_free+3L)
 csv(mm$mapping,file.path(d,'start_mapping.csv'))
 u<-paste('USEVARIABLES=x1-x5 y1-y5 c1-c11 z0',if(e$group=='INC')'g'else'', 'zg;')
 lines<-c(paste0('TITLE: ',id,' registered observed-baseline triple interaction;'),'DATA: FILE=data.dat;','VARIABLE:',wrap90(paste('NAMES=',paste(unlist(e$columns),collapse=' '),';')),u,'MISSING=ALL(-9999);','CLUSTER=cluster;',
   if(!'zg'%in%unlist(e$columns))paste0('DEFINE: zg=z0*',e$g_column,';'),
   'ANALYSIS: TYPE=COMPLEX RANDOM; ESTIMATOR=MLR; PROCESSORS=1;','ALGORITHM=INTEGRATION; INTEGRATION=30; MCSEED=26101701;',
   'ITERATIONS=2000; MITERATIONS=4000; COVERAGE=.005;','LOGCRITERION=.00001; RLOGCRITERION=.000000001; MCONVERGENCE=.00001;',
   'MODEL:',mm$lines,'OUTPUT: TECH1 TECH3 TECH4 TECH8 SVALUES CINTERVAL;','SAVEDATA: RESULTS=estimates.dat; TECH3=tech3.dat;')
 stopifnot(all(nchar(lines)<=90),setequal(stmt_pairs(si$model),stmt_pairs(mm$lines)),!any(grepl('BY.*\\*',mm$lines)))
 writeLines(lines,file.path(d,'model.inp'));stopifnot(file.copy(file.path(e$parent_dir,'data.dat'),file.path(d,'data.dat')))
 support<-lapply(0:1,function(g){v<-a$z0[a[[e$g_column]]==g];list(g=g,N=length(v),min=min(v),max=max(v),points=sort(unique(c(range(v),quantile(v,c(.1,.5,.9),names=FALSE)))))})
 zpoints<-sort(unique(unlist(lapply(support,function(x)x$points))))
 j<-list(id=id,root=ROOT,dest=d,family=fam,z=e$z,group=e$group,start=start,N=e$N,communities=e$communities,columns=e$columns,expected_free=mm$expected_free,category='CHARLS_H42',cap_seconds=contract$per_call_seconds,
   rscript=file.path(R.home('bin'),'Rscript.exe'),mplus=MPLUS,source_start=e$parent_dir,zpoints=zpoints,support=support,
   hashes=list(model.inp=hashf(file.path(d,'model.inp')),data.dat=hashf(file.path(d,'data.dat'))))
 stopifnot(identical(j$hashes$data.dat,e$parent_hashes$data.dat))
 wj(list(rank=qr(design)$rank,columns=ncol(design),same_sample_parent=TRUE,parent_free=e$parent_free,expected_free=mm$expected_free,groups=support),file.path(d,'design_check.json'))
 wj(j,file.path(d,'job.json'));j
}
review<-function(j){
 er<-rj(file.path(j$dest,'engine_receipt.json'));if(is.null(er))return(list(id=j$id,status='NOT_RUN_RESOURCE_OR_BUDGET',detail=rj(file.path(j$dest,'not_run.json'))))
 r<-list(id=j$id,family=j$family,z=j$z,group=j$group,start=j$start,N_expected=j$N,status=er$status,engine_status=er$status,seconds=er$seconds)
 if(er$status=='EXITED')tryCatch({
  n<-MplusAutomation::readModels(file.path(j$dest,'model.out'),what='summaries',quiet=TRUE);m<-read_mplus_raw(j$dest);si<-specification(entries[[j$family]])
  v<-gate_r2e(m,si,unlist(j$zpoints));r$status<-if(isTRUE(v$passed))'USABLE_SINGLE_DATASET'else'INADMISSIBLE';r$negative<-v$negative;r$N<-n$summaries$Observations;r$LL<-m$extra[['H0 Loglikelihood']];r$parameters<-m$P
  if(any(grepl('FIXED TO AVOID SINGULARITY',m$lines,fixed=TRUE)))r$status<-'AUTOFIX_REJECTED'
  if(r$N!=j$N)r$status<-'SAMPLE_MISMATCH'
  if(m$P!=j$expected_free)r$status<-'PARAMETER_CONTRACT_MISMATCH'
  wj(v,file.path(j$dest,'validation.json'));csv(m$par,file.path(j$dest,'parameters_high_precision.csv'));csv(m$values,file.path(j$dest,'matrix_values.csv'));csv(m$spec,file.path(j$dest,'tech1_parameter_map.csv'));csv(extract(m,si$key),file.path(j$dest,'key_paths.csv'));write.table(m$V,file.path(j$dest,'parameter_covariance.csv'),sep=',',row.names=FALSE,col.names=FALSE)
 },error=function(e){r$status<<-'READBACK_OR_ESTIMATION_FAILURE';r$error<<-conditionMessage(e)})
 r$output_sha256<-if(file.exists(file.path(j$dest,'model.out')))hashf(file.path(j$dest,'model.out'))else NULL
 wj(r,file.path(j$dest,'receipt.json'));r
}
run<-function(j){
 if(file.exists(file.path(j$dest,'receipt.json')))return(rj(file.path(j$dest,'receipt.json')))
 gc(full=TRUE);progress('H42_start',j$id)
 p<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/engine.py'),file.path(j$dest,'job.json')),stdout=file.path(j$dest,'supervisor.log'),stderr='2>&1',cleanup=TRUE)
 last<-0;while(p$is_alive()){
  p$wait(1000L)
  if(as.numeric(Sys.time())-last>25){h<-rj(file.path(ROOT,'runtime/progress.json'));if(exists('clauder_progress',mode='function'))clauder_progress(if(is.null(h))'H42_starting'else h$stage,paste(j$id,if(is.null(h))''else h$elapsed_seconds));last<-as.numeric(Sys.time())}
 }
 r<-review(j);progress('H42_readback',paste(j$id,r$status));r
}
prepare_all<-function(){
 jobs<-list();for(f in names(entries))for(s in c('A','B')){j<-prepare(f,s);jobs[[j$id]]<-j;progress('H42_preparing',j$id)}
 wj(jobs,file.path(ROOT,'contracts/JOBS.json'));writeLines(capture.output(sessionInfo()),file.path(ROOT,'audit/R_SESSION_INFO.txt'))
 code<-list.files(file.path(ROOT,'code'),full.names=TRUE);wj(setNames(as.list(vapply(code,hashf,'')),basename(code)),file.path(ROOT,'audit/FROZEN_CODE.json'))
 cat('H42_PREPARE_NATIVE_TERMINAL',length(jobs),'inputs; zero Mplus calls\n')
}
main<-function(){
 stopifnot(!file.exists(file.path(ROOT,'runtime/OWNER.json')),!file.exists(file.path(ROOT,'audit/TERMINAL.json')))
 frozen<-rj(file.path(ROOT,'audit/FROZEN_CODE.json'));for(n in names(frozen))stopifnot(identical(hashf(file.path(ROOT,'code',n)),frozen[[n]]))
 owner<-ps_handle();ps_set_cpu_affinity(owner,intersect(ps_get_cpu_affinity(owner),0:3));ps_set_nice(owner,'above_normal');wj(list(pid=Sys.getpid(),created=as.numeric(ps_create_time(owner)),affinity=ps_get_cpu_affinity(owner)),file.path(ROOT,'runtime/OWNER.json'))
 stopfile<-file.path(ROOT,'runtime/TERMINAL');on.exit(writeLines('Actual coordinator terminal; inspect audit',stopfile),add=TRUE)
 guard<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/coordinator_awake.py'),'--owner-pid',Sys.getpid(),'--owner-created',as.numeric(ps_create_time(owner)),'--receipt',file.path(ROOT,'runtime/AWAKE.json'),'--max-seconds','7200','--stop-file',stopfile),stdout=file.path(ROOT,'runtime/awake.log'),stderr='2>&1',cleanup=FALSE)
 calls<-list();families<-list();started<-Sys.time();jobs<-rj(file.path(ROOT,'contracts/JOBS.json'))
 for(pass in 1:2)for(f in names(entries)){
  if(!is.null(families[[f]])&&!families[[f]]$status%in%c('RESOURCE_DEFERRED'))next
  pair<-list();state<-'RUNNING'
  for(s in c('A','B')){
   if(as.numeric(difftime(Sys.time(),started,units='secs'))>contract$wall_seconds-240){state<-'WALL_LIMIT_NOT_RUN';break}
   id<-paste('CHARLS',toupper(entries[[f]]$z),'H42',entries[[f]]$group,'CC',s,sep='_');j<-jobs[[id]];r<-run(j);calls[[id]]<-r;pair[[s]]<-r
   wj(calls,file.path(ROOT,'results/CALL_RESULTS.json'))
   if(r$status=='NOT_RUN_RESOURCE_OR_BUDGET'){state<-if(identical(r$detail$status,'RESOURCE_HOLD'))'RESOURCE_DEFERRED'else'BUDGET_NOT_RUN';break}
  }
  if(length(pair)==2&&!identical(state,'RESOURCE_DEFERRED')&&!identical(state,'BUDGET_NOT_RUN')){
   if(all(vapply(pair,function(x)x$status=='USABLE_SINGLE_DATASET',TRUE))){
    prep<-function(s)list(receipt=pair[[s]],key=read.csv(file.path(jobs[[pair[[s]]$id]]$dest,'key_paths.csv')))
    comparison<-compare_numeric(prep('A'),prep('B'),'start',list(start_LL=.01,start_path_abs=.001,start_path_se=.05,integration_path_se=.05,se_rel=.05))
    wj(comparison,file.path(ROOT,'results',paste0(toupper(f),'_START_COMPARISON.json')))
    state<-if(isTRUE(comparison$passed))'TWO_STARTS_USABLE_CC'else'START_DIFFERENCE_NO_RETRY'
   }else state<-'INADMISSIBLE_OR_FAILED_CC'
  }
  families[[f]]<-list(status=state,starts=pair,N=entries[[f]]$N,MI_complete=FALSE);wj(families,file.path(ROOT,'results/FAMILY_STATUS.json'))
 }
 terminal<-list(status='H42_PILOT_TERMINAL',families=length(families),usable=sum(vapply(families,function(x)x$status=='TWO_STARTS_USABLE_CC',TRUE)),utc=format(Sys.time(),tz='UTC',usetz=TRUE),CFPS_calls=0,MI_complete=FALSE,full_H4_complete=FALSE)
 wj(terminal,file.path(ROOT,'audit/TERMINAL.json'));progress('H42_TERMINAL',paste(terminal$usable,'of',terminal$families,'complete-case scopes usable'));cat('H42_PILOT_NATIVE_TERMINAL\n')
}
