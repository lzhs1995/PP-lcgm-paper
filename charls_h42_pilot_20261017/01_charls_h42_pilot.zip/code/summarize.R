# 只读已保存估计，报告三重交互、组内调节及条件斜率；失败规格保留。
library(jsonlite)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_h42_pilot_20261017'
readj<-function(p)fromJSON(p,simplifyVector=FALSE)
terminal<-readj(file.path(ROOT,'audit/TERMINAL.json'));stopifnot(terminal$status=='H42_PILOT_TERMINAL')
families<-readj(file.path(ROOT,'results/FAMILY_STATUS.json'));jobs<-readj(file.path(ROOT,'contracts/JOBS.json'));entries<-readj(file.path(ROOT,'contracts/DATA_ENTRIES.json'))
labs<-c('bss','dc','bxg','dcg');mainrows<-list();contrastrows<-list();curves<-list();fits<-list()
for(f in names(entries)){
 e<-entries[[f]];state<-families[[f]]$status
 row<-data.frame(family=f,z=e$z,resource=e$group,N=e$N,status=state,estimate=NA_real_,se=NA_real_,lower=NA_real_,upper=NA_real_,p=NA_real_)
 if(identical(state,'TWO_STARTS_USABLE_CC')){
  id<-paste('CHARLS',toupper(e$z),'H42',e$group,'CC','A',sep='_');j<-jobs[[id]]
  key<-read.csv(file.path(j$dest,'key_paths.csv'));key<-key[match(labs,key$label),];stopifnot(!anyNA(key$parameter))
  V<-as.matrix(read.csv(file.path(j$dest,'parameter_covariance.csv'),header=FALSE));q<-key$estimate;V<-V[key$parameter,key$parameter,drop=FALSE]
  scalar<-function(a){est<-sum(a*q);se<-sqrt(drop(t(a)%*%V%*%a));data.frame(estimate=est,se=se,lower=est-qnorm(.975)*se,upper=est+qnorm(.975)*se,p=2*pnorm(-abs(est/se)))}
  primary<-scalar(c(0,0,0,1));row[names(primary)]<-primary
  C<-rbind(delta_G0=c(0,1,0,0),delta_G1=c(0,1,0,1),direct_difference=c(0,0,0,1))
  for(n in rownames(C))contrastrows[[length(contrastrows)+1L]]<-cbind(data.frame(family=f,contrast=n),scalar(C[n,]))
  for(s in j$support)for(z in unlist(s$points))curves[[length(curves)+1L]]<-cbind(data.frame(family=f,G=s$g,z=z,support_min=s$min,support_max=s$max),scalar(c(1,z,s$g,z*s$g)))
  fits[[f]]<-list(model=id,parameter_order=labs,parameters=key$parameter,estimate=q,vcov=unname(V),source_output_sha256=readj(file.path(j$dest,'receipt.json'))$output_sha256)
 }
 mainrows[[f]]<-row
}
tab<-do.call(rbind,mainrows);stopifnot(nrow(tab)==12)
tab$Holm_12<-tab$Bonferroni_12<-NA_real_;valid<-which(!is.na(tab$p))
tab$Holm_12[valid]<-p.adjust(tab$p[valid],method='holm',n=12);tab$Bonferroni_12[valid]<-p.adjust(tab$p[valid],method='bonferroni',n=12)
write.csv(tab,file.path(ROOT,'results/H42_REGISTERED_12.csv'),row.names=FALSE,na='')
if(length(contrastrows))write.csv(do.call(rbind,contrastrows),file.path(ROOT,'results/GROUP_MODERATION_CONTRASTS.csv'),row.names=FALSE)
if(length(curves))write.csv(do.call(rbind,curves),file.path(ROOT,'results/CONDITIONAL_SLOPES.csv'),row.names=FALSE)
write_json(fits,file.path(ROOT,'results/SELECTED_PARAMETERS.json'),auto_unbox=TRUE,pretty=TRUE,digits=NA)
receipt<-list(status='H42_CC_SUMMARY_COMPLETE',registered=12,usable=length(fits),nominal_significant=sum(tab$p<.05,na.rm=TRUE),Holm_significant=sum(tab$Holm_12<.05,na.rm=TRUE),MI_complete=FALSE,full_H4_complete=FALSE)
write_json(receipt,file.path(ROOT,'results/SUMMARY_RECEIPT.json'),auto_unbox=TRUE,pretty=TRUE)
cat('H42_SUMMARY_NATIVE_TERMINAL',length(fits),'of12 usable CC; MI not complete\n')
