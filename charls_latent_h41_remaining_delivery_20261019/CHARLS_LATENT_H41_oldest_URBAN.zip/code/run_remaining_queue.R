# 同一个原生后台任务：先新ADL插补及独立读回，再逐个完整MI家族。
local({
 ROOT<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_h41_remaining_mi_20261019'
 PILOT<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_h41_remaining_20261019'
 PY<-'C:/Users/LZHS/AppData/Local/Programs/Python/Python314/python.exe'
 library(jsonlite);library(ps);library(processx)
 Sys.setenv(OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1,MKL_NUM_THREADS=1)
 rj<-function(p)fromJSON(p,simplifyVector=FALSE)
 wj<-function(x,p)write_json(x,p,auto_unbox=TRUE,pretty=TRUE,digits=NA,null='null')
 report<-function(s,m,fam=NULL){cat(format(Sys.time(),tz='UTC'),s,m,'\n');flush.console();clauder_progress(s,m);wj(list(stage=s,message=m,family=fam,updated_at=format(Sys.time(),tz='UTC')),file.path(ROOT,'runtime/QUEUE_PROGRESS.json'))}
 terminal<-rj(file.path(PILOT,'results/BATCH_RECEIPT.json'));stopifnot(isTRUE(terminal$terminal),!isTRUE(terminal$resource_hold))
 stopifnot(rj(file.path(PILOT,'audit/INDEPENDENT_PARAMETER_CHECK.json'))$status=='PASS')
 owner<-rj(file.path(PILOT,'audit/EXECUTION_RUNTIME.json'))
 h<-tryCatch(ps_handle(owner$pid,as.POSIXct(as.numeric(owner$created_exact),origin='1970-01-01',tz='UTC')),error=function(e){if(inherits(e,'no_such_process'))return(NULL);stop(e)})
 stopifnot(is.null(h)||!ps_is_running(h))
 lock<-file.path(ROOT,'runtime/QUEUE_RESERVED.json');stopifnot(!file.exists(lock))
 cr<-as.numeric(ps_create_time(ps_handle()));wj(list(pid=Sys.getpid(),created=cr,created_exact=sprintf('%.17g',cr)),lock)
 choose_cpu<-function(tag){
  v<-processx::run(PY,c('-X','utf8','-c',"import psutil,json;v=psutil.cpu_percent(2,percpu=True);assert len(v)==16;g=min([list(range(8)),list(range(8,16))],key=lambda q:sum(v[i] for i in q)/len(q));print(json.dumps({'per_cpu':v,'chosen':g}))"),timeout=30,error_on_status=TRUE)
  x<-fromJSON(v$stdout);wj(x,file.path(ROOT,'audit',paste0(tag,'_CPU_ADMISSION.json')));ps_set_cpu_affinity(ps_handle(),x$chosen);x$chosen
 }
 env<-new.env(parent=environment());env$CPU_CORES<-choose_cpu('MI_PREPARE')
 report('PREPARING_ADL_MI','Fresh 20-draw working MI for individually admitted oldest/son indicators')
 source(file.path(ROOT,'code/prepare_mi.R'),local=env)
 report('VALIDATING_ADL_MI','Read every exported DAT and unchanged source/missingness masks')
 source(file.path(ROOT,'code/verify_mi_files.R'),local=env);rm(env);gc(FALSE)
 pilot<-rj(file.path(PILOT,'results/FAMILY_STATUS.json'));all<-list()
 for(fam in c('oldest_EDU','oldest_URBAN','son_EDU','son_URBAN')){
  if(!identical(pilot[[fam]]$status,'TWO_START_CC_FEASIBLE_NOT_MI')){all[[fam]]<-list(status='NOT_ADMITTED_FROM_CC',pilot=pilot[[fam]]);next}
  report('QUEUE_FAMILY_START',fam,fam);env<-new.env(parent=environment());env$FAMILY<-fam;env$CPU_CORES<-choose_cpu(fam)
  source(file.path(ROOT,'code/run_family.R'),local=env);fs<-rj(file.path(ROOT,'results',fam,'FAMILY_STATUS.json'));all[[fam]]<-fs
  if(identical(fs$status,'TWENTY_USABLE_PENDING_POOLING')){
   report('QUEUE_POOLING',fam,fam);source(file.path(ROOT,'code/pool_family.R'),local=env)
   report('QUEUE_INDEPENDENT_READBACK',fam,fam)
   p<-processx::run(PY,c('-X','utf8',file.path(ROOT,'code/run_readback_awake.py'),fam),timeout=Inf,error_on_status=FALSE)
   writeLines(c(p$stdout,p$stderr),file.path(ROOT,'results',fam,'INDEPENDENT_PROCESS_LOG.txt'));stopifnot(p$status==0)
   all[[fam]]$independent<-rj(file.path(ROOT,'results',fam,'INDEPENDENT_VERIFICATION.json'))
  }
  wj(all,file.path(ROOT,'results/QUEUE_STATUS.json'));rm(env);gc(FALSE)
 }
 wj(list(terminal=TRUE,families=all,original_four_complete=FALSE,full_H4_complete=FALSE),file.path(ROOT,'results/QUEUE_TERMINAL.json'))
 report('QUEUE_TERMINAL','All admitted remaining latent H4.1 families reached explicit dispositions');cat('REMAINING_MI_QUEUE_DONE\n')
})
