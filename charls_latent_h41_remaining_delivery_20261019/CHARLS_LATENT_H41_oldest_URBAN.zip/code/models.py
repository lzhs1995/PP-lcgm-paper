"""仅向已通过CC家族提供完整MI数据；只改变数据及起点，不改变规格。"""
from pathlib import Path
import json,re,hashlib,shutil
import numpy as np
import pandas as pd
import validated_models as base
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def prepare(z,g,k,start='A'):
 k=int(k);contract=read(R/'contracts/MODEL_CONTRACT.json');P=Path(contract['pilot_root'])
 assert z in contract['indicators'] and g in contract['groups'] and 1<=k<=20 and start in ('A','B') and (start=='A' or k==1)
 assert read(P/'results/FAMILY_STATUS.json')[f'{z}_{g}']['status']=='TWO_START_CC_FEASIBLE_NOT_MI'
 admission=read(R/'mi'/z/'audit/MI_ADMISSION.json');assert admission['status']=='ADMITTED_WORKING_MI' and g in admission['eligible_groups']
 source=P/'models'/f'CHARLS_{z.upper()}_LATENT_H41_{g}_A';rec=read(source/'receipt.json')
 assert rec['status']=='USABLE' and sha(source/'model.out')==rec['output_sha256']
 par=pd.read_csv(source/'parameters_high_precision.csv');slots=read(source/'normalized_slots.json');assert len(par)==len(slots)==132
 q=par.estimate.to_numpy().copy();se=par.se.to_numpy()
 if start=='B':
  for i,s in enumerate(slots):
   if s['op'] in ('ON','MEAN','BY'):q[i]+=(1 if i%2 else -1)*.02*se[i]
 val={s['key']:float(v) for s,v in zip(slots,q)};job0=read(source/'job.json');gcol=job0['g'];starts={}
 for s,v in zip(slots,q):
  op=s['op'];a=s['lhs'];b=s['rhs']
  if b in ('IXG','SXG','IZG','SZG') or (op=='ON' and b==gcol):continue
  if op=='MEAN':
   starts[a.lower()+'0']=float(v);starts[a.lower()+'1']=float(v)+val['ON:'+a+':'+gcol]
  elif op=='ON' and (a,b) in base.targets:
   # OVERALL还保留六个默认标签；类内两套参数覆盖它们，不增加自由参数。
   starts[s['label']]=float(v)
   starts[s['label']+'0']=float(v);starts[s['label']+'1']=float(v)+val['ON:'+a+':'+b+'G']
  else:starts[s['label']]=float(v)
 assert len(starts)==138
 inp=(source/'model.inp').read_text();seen=set()
 def repl(m):
  label=m.group(3);assert label in starts;seen.add(label)
  return '*'+format(starts[label],'.12g')+m.group(2)+' ('+label+')'
 new=re.sub(r'\*([-+0-9.eE]+)(\]?) \((\w+)\)',repl,inp);assert seen==set(starts),(set(starts)-seen)
 modelid=f'CHARLS_{z.upper()}_LATENT_H41_{g}_MI{k:02d}_{start}';new=new.replace('TITLE: '+source.name+';','TITLE: '+modelid+';')
 # 除TITLE和自由参数起点外，模型语法必须逐字节等同。
 scrub=lambda s:re.sub(r'TITLE:[^;]*;','TITLE:;',re.sub(r'\*[-+0-9.eE]+(?=\]? \()','*START',s))
 assert scrub(new)==scrub(inp)
 d=R/'models'/modelid;d.mkdir(exist_ok=False)
 data=R/'mi'/z/'private'/f'MI{k:02d}.dat';members=pd.read_csv(R/'mi'/z/'audit/MI_MEMBERS.csv');assert sha(data)==members.loc[members.member==k,'sha256'].iloc[0]
 shutil.copyfile(data,d/'data.dat');(d/'model.inp').write_text(new,encoding='ascii');(d/'normalized_slots.json').write_text(json.dumps(slots,indent=2))
 j={**job0,'id':modelid,'root':str(R),'dest':str(d),'member':k,'start':start,'N':admission['N'],'cap_seconds':180,'source_CC':str(source),'source_CC_output_sha256':rec['output_sha256'],'hashes':{n:sha(d/n) for n in ('model.inp','data.dat')}}
 (d/'job.json').write_text(json.dumps(j,indent=2));(d/'STRUCTURE_IDENTITY.json').write_text(json.dumps(dict(passed=True,only_title_starts_data_differ=True,source=str(source),source_input_sha256=sha(source/'model.inp'),source_output_sha256=sha(source/'model.out')),indent=2))
 return str(d)
def normalize(d):return base.normalize(Path(d))
def agree(a,b,target):
 # 复用全参数/完整TECH3比较，单独写入本批同阈值合同供验证器读取。
 return base.agree_full(a,b,target)
