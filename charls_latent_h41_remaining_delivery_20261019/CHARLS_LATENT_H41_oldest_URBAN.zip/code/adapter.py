"""身份与依赖核实后的单次引擎启动；计时使用已验证的自有进程句柄。"""
from pathlib import Path
import ctypes,datetime,hashlib,json,os,sys,time,psutil
from bounded_child_awake import run_child
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,j):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(j,indent=2));os.replace(t,p)
class Memory(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(k,ctypes.c_ulonglong) for k in ['total','avail','commit_limit','commit_avail','virtual','virtual_avail','extended']]
def resource():
 m=Memory();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
 return dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),available_gib=m.avail/2**30,commit_available_gib=m.commit_avail/2**30,cpu_percent=psutil.cpu_percent(interval=.3),mplus_pids=[p.pid for p in psutil.process_iter(['name']) if (p.info['name'] or '').lower()=='mplus.exe'])
def main():
 d=Path(sys.argv[1]).resolve().parent;j=read(d/'job.json');c=read(R/'contracts/RUN_CONTRACT.json')
 assert d.parent==R/'models' and Path(sys.argv[2]).name=='model.inp'
 assert not (d/'execution').exists() and not (d/'engine_receipt.json').exists()
 for n,h in j['hashes'].items():assert sha(d/n)==h
 assert sha(c['executable'])==c['executable_sha256']
 assert read(R/'mi'/j['indicator']/'audit/MI_ADMISSION.json')['status']=='ADMITTED_WORKING_MI'
 if j['member']>1:assert read(R/'results'/(j['indicator']+'_'+j['group']+'_MI01_START_COMPARISON.json'))['passed']
 if j['start']=='B':assert read(d.with_name(d.name[:-1]+'A')/'receipt.json')['status']=='USABLE'
 calls=[read(p) for root in [R,Path(c['prior_root'])] for p in (root/'models').glob('*/engine_receipt.json')]
 assert sum(x.get('actual_engine_calls',0) for x in calls)<c['max_mplus_calls']
 assert sum(x.get('active_seconds',x.get('exit_confirmed_seconds',0)) for x in calls)+j['cap_seconds']<=c['total_engine_seconds']+10
 with (d/'RESERVATION.json').open('x') as f:json.dump(dict(pid=os.getpid(),created=psutil.Process().create_time()),f)
 started=time.monotonic();pf=resource()
 while pf['available_gib']<c['minimum_available_gib'] or pf['commit_available_gib']<c['minimum_commit_available_gib'] or pf['cpu_percent']>c['max_cpu_percent'] or pf['mplus_pids']:
  if time.monotonic()-started>=c['resource_wait_seconds']:
   save(d/'engine_receipt.json',dict(status='NOT_RUN_RESOURCE_HOLD',actual_engine_calls=0,resource=pf));return 75
  time.sleep(2);pf=resource()
 save(d/'RESOURCE_ADMITTED.json',pf)
 awake=bool(ctypes.windll.kernel32.SetThreadExecutionState(0x80000001))
 try:
  out=run_child([c['executable'],'model.inp'],d/'execution',j['cap_seconds'],working_directory=d)
  out.update(status=out['state'],actual_engine_calls=1,input_sha256=j['hashes']['model.inp'],data_sha256=j['hashes']['data.dat'],stdout_sha256=sha(d/'execution/stdout.log'),stderr_sha256=sha(d/'execution/stderr.log'))
  save(d/'engine_receipt.json',out);return 124 if out['state']=='TIMEOUT' else out['exitcode']
 finally:
  if awake:ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
if __name__=='__main__':raise SystemExit(main())
