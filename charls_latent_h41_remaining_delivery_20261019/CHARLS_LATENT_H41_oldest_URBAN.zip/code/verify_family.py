"""独立从原始TECH1/RESULTS/TECH3验证完整家族与Rubin/D1；不启动引擎。"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import argparse,hashlib,json,sys
import numpy as np
import pandas as pd
from scipy.stats import t as student_t,f as f_dist
from calibrated_reader import matrices,pid
R=Path(__file__).resolve().parents[1];read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
ap=argparse.ArgumentParser();ap.add_argument('family');ap.add_argument('--public',action='store_true');ap.add_argument('--report-dir',type=Path);args=ap.parse_args()
fam=args.family;z,g=fam.split('_');D=R/'results'/fam
dest=args.report_dir or D;dest.mkdir(parents=True,exist_ok=True)
assert read(D/'FAMILY_STATUS.json')['status']=='TWENTY_USABLE_PENDING_POOLING'
assert read(D/'POOLING_RECEIPT.json')['m']==20
labs=['bii','bis','bss','bsyiy','bzi','biz','bsz','dii','dis','dss','dzi','diz','dsz']
records=[];values=[];covs=[]
for k,st in [(k,'A') for k in range(1,21)]+[(1,'B')]:
 d=R/'models'/f'CHARLS_{z.upper()}_LATENT_H41_{g}_MI{k:02d}_{st}'
 rec=read(d/'receipt.json');job=read(d/'job.json');assert rec['status']=='USABLE'
 txt,mp,q,se,V,ll=matrices(d);par=pd.read_csv(d/'parameters_high_precision.csv');P=len(q);assert P==132
 J=np.zeros((P,P))
 for i,p in enumerate(par.itertuples()):
  mat=p.matrix.upper();row=p.row;col=p.column
  if mat in ('BETA','GAMMA') and col==job['g']:
   J[i,pid(mp[2],'ALPHA','1',row)]=1;J[i,pid(mp[1],'ALPHA','1',row)]=-1
  elif mat in ('BETA','GAMMA') and col in ('IXG','SXG','IZG','SZG'):
   J[i,pid(mp[2],'BETA',row,col[:2])]=1;J[i,pid(mp[1],'BETA',row,col[:2])]=-1
  else:J[i,pid(mp[1],mat,row,col)]=1
 est=J@q;vc=J@V@J.T
 assert np.array_equal(J,np.loadtxt(d/'parameter_transform.csv',delimiter=',')) and np.linalg.matrix_rank(J)==P
 assert np.allclose(est,par.estimate,rtol=1e-10,atol=1e-11)
 assert np.allclose(np.sqrt(vc.diagonal()),par.se,rtol=1e-9,atol=1e-11)
 assert np.allclose(vc,np.loadtxt(d/'parameter_covariance.csv',delimiter=','),rtol=1e-9,atol=1e-11)
 assert hashlib.sha256((d/'model.out').read_bytes()).hexdigest()==rec['output_sha256']
 for name,sha in job['hashes'].items():
  if args.public and name=='data.dat':assert not (d/name).exists();continue
  assert hashlib.sha256((d/name).read_bytes()).hexdigest()==sha
 assert abs(ll+job['N']*np.log(2)-rec['LL'])<1e-7
 key=pd.read_csv(d/'key_paths.csv').set_index('label').loc[labs];ix=key.parameter.to_numpy(dtype=int)-1
 # Mplus参数编号从1开始；同时核对原始语义，避免仅靠位置。
 for label,p in zip(labs,ix):
  for field in ('parameter','matrix','row','column'):assert par.iloc[p][field]==key.loc[label,field]
 if st=='A':values.append(est[ix]);covs.append(vc[np.ix_(ix,ix)])
 records.append(dict(model=d.name,parameters=P,max_estimate_difference=float(np.max(abs(est-par.estimate))),max_covariance_difference=float(np.max(abs(vc-np.loadtxt(d/'parameter_covariance.csv',delimiter=','))))))
Q=np.array(values);U=np.array(covs);m=len(Q);assert m==20
W=U.mean(0);B=np.cov(Q,rowvar=False,ddof=1);T=W+(1+1/m)*B;e=Q.mean(0)
def scalar(a,dfcom=np.inf):
 est=float(a@e);se=float(np.sqrt(a@T@a));r=(1+1/m)*(a@B@a)/(a@W@a);lam=(1+1/m)*(a@B@a)/(a@T@a)
 df=(m-1)*(1+1/r)**2 if r>0 else np.inf
 if np.isfinite(dfcom):df=1/(1/df+1/((dfcom+1)/(dfcom+3)*dfcom*(1-lam)))
 return [est,se,df,est-student_t.ppf(.975,df)*se,est+student_t.ppf(.975,df)*se,2*student_t.sf(abs(est/se),df),lam,np.sqrt(a@B@a/m)/se]
fields=['estimate','se','df','lower','upper','p','lambda','MCSE_over_SE']
calc=np.array([scalar(a) for a in np.eye(len(labs))]);saved=pd.read_csv(D/'POOLED_PATHS.csv').set_index('label').loc[labs]
assert np.allclose(calc,saved[fields],rtol=1e-8,atol=1e-10)
admission=read(R/'mi'/z/'audit/MI_ADMISSION.json');finite=pd.read_csv(D/'CLUSTER_DF_SENSITIVITY.csv').set_index('label').loc[labs]
assert np.allclose([scalar(a,admission['communities']-1) for a in np.eye(len(labs))],finite[fields],rtol=1e-8,atol=1e-10)
sets={'primary_Z':['dzi','diz','dsz'],'secondary_X':['dii','dis','dss'],'diagnostic_all_six':['dii','dis','dss','dzi','diz','dsz']}
joints={};jref=pd.read_csv(D/'JOINT_D1.csv').set_index('test_set')
for name,ls in sets.items():
 ix=[labs.index(l) for l in ls];w=W[np.ix_(ix,ix)];b=B[np.ix_(ix,ix)];q=e[ix];k=len(ix);r=(1+1/m)*np.trace(b@np.linalg.inv(w))/k
 F=q@np.linalg.solve((1+r)*w,q)/k;nu=4+(k*(m-1)-4)*(1+(1-2/(k*(m-1)))/r)**2;p=f_dist.sf(F,k,nu)
 row=jref.loc[name];assert np.allclose([F,nu,p,r],[row.F,row.df2,row.p,row.RIV],rtol=2e-6,atol=1e-8)
 joints[name]=dict(F=float(F),df1=k,df2=float(nu),p=float(p))
paths={'IX_IY':('bii','dii'),'IX_SY':('bis','dis'),'SX_SY':('bss','dss'),'IZ_IY':('bzi','dzi'),'IZ_SY':('biz','diz'),'SZ_SY':('bsz','dsz')}
cs=pd.read_csv(D/'GROUP_CONTRASTS.csv').set_index(['path','contrast'])
for name,pair in paths.items():
 for group in ('G0','G1','difference'):
  a=np.zeros(len(labs))
  if group!='difference':a[labs.index(pair[0])]=1
  if group!='G0':a[labs.index(pair[1])]=1
  assert np.allclose(scalar(a),cs.loc[(name,group),fields].to_numpy(dtype=float),rtol=1e-8,atol=1e-10)
allj=pd.read_csv(R/'results/JOINT_D1_ALL_COMPLETE_FAMILIES.csv')
for name in sets:
 sub=allj[allj.test_set==name];p=sub.p.to_numpy();order=np.argsort(p);adj=np.empty(len(p));adj[order]=np.minimum(1,np.maximum.accumulate(p[order]*(12-np.arange(len(p)))))
 assert np.allclose(adj,sub.holm_p_planned12,rtol=1e-8,atol=1e-10)
pd.DataFrame(records).to_csv(dest/'INDEPENDENT_PARAMETER_CHECK.csv',index=False)
out=dict(status='PASS',family=fam,m=20,models=21,free_parameters=21*132,paths=len(labs),group_contrasts=18,joints=joints,max_MCSE_over_SE=float(calc[:,-1].max()),basis='Independent raw TECH1/RESULTS/TECH3 transformation, scalar Rubin, D1 and contrasts',private_data_hashes_checked=not args.public,new_engine_calls=0,original_four_complete=False,full_H4_complete=False)
(dest/'INDEPENDENT_VERIFICATION.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
