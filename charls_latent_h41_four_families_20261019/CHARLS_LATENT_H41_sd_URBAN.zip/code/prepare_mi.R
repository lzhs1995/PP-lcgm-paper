# 三过程H4.1：重新构造ADL条件插补；不复用仅基期Z的旧MI。
local({
 BATCH<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_h41_mi_20261019'
 Sys.setenv(OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1,MKL_NUM_THREADS=1)
 .libPaths(c('C:/Users/LZHS/pp_lgcm_review/charls_income_mi_pilot_20261016/library','C:/Users/LZHS/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
 library(jsonlite);library(digest);library(mice);library(miceadds);library(lme4);library(ps)
 ps_set_cpu_affinity(ps_handle(),8:11);stopifnot(packageVersion('mice')=='3.19.10')
 progress<-function(s,m){cat(format(Sys.time(),tz='UTC'),s,m,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(s,m);write_json(list(stage=s,message=m,updated_at=format(Sys.time(),tz='UTC')),file.path(BATCH,'runtime/MI_PROGRESS.json'),auto_unbox=TRUE)}
 c<-fromJSON(file.path(BATCH,'contracts/MI_CONTRACT.json'),simplifyVector=FALSE)
 audit<-fromJSON(file.path(BATCH,'contracts/COHORT_AUDIT.json'),simplifyVector=FALSE)
 pilot<-fromJSON(file.path(c$pilot_root,'results/FAMILY_STATUS.json'),simplifyVector=FALSE)
 stopifnot(!file.exists(file.path(BATCH,'runtime/MI_ATTEMPT_RESERVED')))
 writeLines('single MI worker',file.path(BATCH,'runtime/MI_ATTEMPT_RESERVED'))
 write_json(list(pid=Sys.getpid(),created=as.numeric(ps_create_time(ps_handle()))),file.path(BATCH,'audit/MI_RUNTIME.json'),auto_unbox=TRUE)
 strictfile<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_trajectory_readiness_20261018/private/STRICT_FIVEWAVE_CONTRASTS.rds'
 stopifnot(digest(file=strictfile,algo='sha256')==audit$strict_source_sha256)
 strict<-readRDS(strictfile);yr<-c(2011,2013,2015,2018,2020);admissions<-list()
 for(z in unlist(c$indicators)){
  feasible<-vapply(unlist(c$groups),function(g)identical(pilot[[paste(z,g,sep='_')]]$status,'TWO_START_CC_FEASIBLE_NOT_MI'),TRUE)
  if(!any(feasible)){admissions[[z]]<-list(status='NO_FEASIBLE_FAMILY_NO_MI');next}
  ROOT<-file.path(BATCH,'mi',z)
  for(d in c('private','audit','runtime','results'))dir.create(file.path(ROOT,d),recursive=TRUE,showWarnings=FALSE)
  stopifnot(!file.exists(file.path(ROOT,'private/MIDS.rds')))
  e<-audit$indicators[[z]]$source;stopifnot(digest(file=e$file,algo='sha256')==e$sha256)
  a<-readRDS(e$file);states<-matrix('',nrow(a$analysis),5);values<-matrix(NA_real_,nrow(a$analysis),5)
  for(k in 1:5){s<-strict[strict$indicator==z&strict$year==yr[k],];ix<-match(as.character(a$pid),as.character(s$pid));stopifnot(!anyNA(ix));states[,k]<-s$status[ix];values[,k]<-(s$absolute[ix]-a$z_mean)/a$z_sd}
  stopifnot(identical(is.na(values),states!='DEFINED'))
  keep<-!apply(states,1,function(s)any(grepl('^STRUCTURAL_',s)))&rowSums(states=='AMBIGUOUS_EARLIEST_BIRTH_YEAR')==0&rowSums(!is.na(values))>=2
  cc<-a$data[keep,,drop=FALSE];original<-a$analysis[keep,setdiff(names(a$analysis),'z0'),drop=FALSE]
  for(k in 1:5)original[[paste0('z',k)]]<-values[keep,k]
  stopifnot(nrow(cc)==audit$indicators[[z]]$N_two_Z_waves,identical(names(which(colSums(is.na(cc))>0)),'adl'),sum(is.na(cc$adl))==audit$indicators[[z]]$N_recovered_by_covariate_MI)
  for(k in 2:5){v<-values[keep,k];cc[[paste0('obs_z',k)]]<-ifelse(is.na(v),0,v);cc[[paste0('missing_z',k)]]<-as.numeric(is.na(v))}
  aux<-grep('^(obs_|missing_)',names(cc),value=TRUE)
  for(g in c('edu','urban'))for(v in aux)cc[[paste0(g,'_',v)]]<-cc[[g]]*cc[[v]]
  stopifnot(!anyNA(cc[setdiff(names(cc),'adl')]))
  method<-make.method(cc);method[]<-'';method['adl']<-'2l.pmm.cached'
  pm<-matrix(0,ncol(cc),ncol(cc),dimnames=list(names(cc),names(cc)));pm['adl',setdiff(names(cc),c('adl','cluster'))]<-1;pm['adl','cluster']<--2
  saveRDS(list(data=cc,analysis=original,methods=method,predictors=pm,source=e,strict_source_sha256=audit$strict_source_sha256),file.path(ROOT,'private/MI_INPUTS.rds'))
  source(file.path(BATCH,'code/mi_exact_fit_cache.R'),local=TRUE)
  progress('LATENT_H41_ADL_MI',paste(z,'20 fresh draws including Z waves and resource products'))
  warnings<-character();imp<-withCallingHandlers(mice(cc,m=c$m,maxit=c$maxit,method=method,predictorMatrix=pm,seed=c$seeds[[z]],donors=5,remove.collinear=TRUE,printFlag=FALSE),warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')})
  saveRDS(imp,file.path(ROOT,'private/MIDS.rds'));saveRDS(.Random.seed,file.path(ROOT,'private/RNG_FINAL.rds'))
  fit<-readRDS(file.path(ROOT,'private/MI_ADL_CONDITIONAL_LMER.rds'));observed<-!is.na(cc$adl);members<-list();summ<-list()
  for(k in seq_len(c$m)){
   v<-complete(imp,k);stopifnot(identical(v$adl[observed],cc$adl[observed]),all(v$adl%in%0:6),all(v$adl[!observed]%in%cc$adl[observed]))
   for(n in setdiff(names(v),'adl'))stopifnot(identical(v[[n]],cc[[n]]))
   d<-original;d$c7<-v$adl;stopifnot(identical(d[setdiff(names(d),'c7')],original[setdiff(names(original),'c7')]))
   p<-file.path(ROOT,'private',sprintf('MI%02d.dat',k));write.table(d,p,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999')
   got<-as.matrix(read.table(p,na.strings='-9999'));want<-as.matrix(d);stopifnot(identical(unname(is.na(got)),unname(is.na(want))),max(abs(got-want),na.rm=TRUE)<1e-10)
   members[[k]]<-data.frame(member=k,N=nrow(d),sha256=digest(file=p,algo='sha256'),observed_preserved=TRUE,XYZ_masks_preserved=TRUE)
   summ[[k]]<-data.frame(member=k,ADL_imputed_mean=mean(v$adl[!observed]),ADL_imputed_min=min(v$adl[!observed]),ADL_imputed_max=max(v$adl[!observed]))
  }
  write.csv(do.call(rbind,members),file.path(ROOT,'audit/MI_MEMBERS.csv'),row.names=FALSE)
  write.csv(do.call(rbind,summ),file.path(ROOT,'results/MI_SUMMARY.csv'),row.names=FALSE)
  write.csv(data.frame(variable=rownames(imp$predictorMatrix),imp$predictorMatrix,check.names=FALSE),file.path(ROOT,'audit/PREDICTORS_ACTUAL.csv'),row.names=FALSE)
  if(!is.null(imp$loggedEvents))write.csv(imp$loggedEvents,file.path(ROOT,'audit/LOGGED_EVENTS.csv'),row.names=FALSE)
  writeLines(warnings,file.path(ROOT,'audit/MI_WARNINGS.txt'))
  fit_ok<-is.null(fit@optinfo$conv$lme4$messages)&&fit@optinfo$conv$opt==0
  required<-c('z0','zg_edu','zg_urban',paste0('obs_z',2:5),paste0('edu_obs_z',2:5),paste0('urban_obs_z',2:5))
  retained<-required[imp$predictorMatrix['adl',required]!=0]
  passed<-isTRUE(fit_ok)&&cache_env$misses==1&&cache_env$hits==(c$m-1)&&length(retained)==length(required)&&imp$predictorMatrix['adl','cluster']==-2
  rec<-list(status=if(passed)'ADMITTED_WORKING_MI'else'NOT_ADMITTED',indicator=z,N=nrow(cc),communities=length(unique(cc$cluster)),m=imp$m,missing_ADL=sum(!observed),conditional_fit_ok=fit_ok,random_intercept_boundary=isSingular(fit),cache_misses=cache_env$misses,fresh_draws=cache_env$misses+cache_env$hits,required_Z_products_retained=retained,dropped_required=setdiff(required,retained),logged_events=imp$loggedEvents,compatible_claim=c$compatibility,eligible_groups=unlist(c$groups)[feasible],source_sha256=e$sha256,XYZ_masks_preserved=TRUE)
  write_json(rec,file.path(ROOT,'audit/MI_ADMISSION.json'),auto_unbox=TRUE,pretty=TRUE,digits=NA,na='null');admissions[[z]]<-rec
  stopifnot(digest(file=e$file,algo='sha256')==e$sha256)
  progress('LATENT_H41_MI_SCOPE_DONE',paste(z,rec$status));rm(imp,fit,cc,a,original,cache_env);gc(FALSE)
 }
 stopifnot(digest(file=strictfile,algo='sha256')==audit$strict_source_sha256)
 write_json(admissions,file.path(BATCH,'audit/MI_ADMISSIONS.json'),auto_unbox=TRUE,pretty=TRUE,digits=NA,na='null')
 writeLines(capture.output(sessionInfo()),file.path(BATCH,'audit/MI_R_SESSION_INFO.txt'))
 progress('LATENT_H41_MI_TERMINAL','Fresh ADL MI audited; no Mplus engines launched');cat('LATENT_H41_MI_DONE\n')
})
