# 从落盘DAT及源对象独立读回；不重新执行插补，不向前台返回逐人数据。
local({
 R<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_h41_mi_20261019'
 library(jsonlite);library(digest)
 admissions<-fromJSON(file.path(R,'audit/MI_ADMISSIONS.json'),simplifyVector=FALSE);rows<-list();checks<-list()
 for(z in names(admissions)){
  a<-admissions[[z]];if(a$status!='ADMITTED_WORKING_MI')next
  root<-file.path(R,'mi',z);inputs<-readRDS(file.path(root,'private/MI_INPUTS.rds'));src<-readRDS(inputs$source$file)
  stopifnot(digest(file=inputs$source$file,algo='sha256')==inputs$source$sha256)
  x<-as.matrix(inputs$analysis);cc<-inputs$data;observed<-!is.na(x[,'c7']);missing<-!observed
  # 矩阵列附带源行名而data.frame列无names；已证实两样本掩码值逐项相同。
  stopifnot(nrow(x)==a$N,ncol(x)==27L,sum(missing)==a$missing_ADL,identical(unname(is.na(x[,'c7'])),unname(is.na(cc$adl))))
  members<-read.csv(file.path(root,'audit/MI_MEMBERS.csv'));stopifnot(identical(members$member,1:20))
  for(k in 1:20){
   path<-file.path(root,'private',sprintf('MI%02d.dat',k));h<-digest(file=path,algo='sha256');stopifnot(h==members$sha256[k])
   d<-as.matrix(read.table(path,na.strings='-9999'));dimnames(d)<-dimnames(x)
   other<-setdiff(colnames(x),'c7');stopifnot(identical(is.na(d[,other]),is.na(x[,other])),max(abs(d[,other]-x[,other]),na.rm=TRUE)<1e-10)
   stopifnot(max(abs(d[observed,'c7']-x[observed,'c7']))<1e-10,all(d[missing,'c7']%in%0:6),all(d[missing,'c7']%in%cc$adl[!is.na(cc$adl)]),!anyNA(d[,paste0('c',1:11)]))
   rows[[paste(z,k)]]<-data.frame(indicator=z,member=k,N=nrow(d),data_sha256=h,observed_preserved=TRUE,XYZ_masks_preserved=TRUE,ADL_support_and_donors_valid=TRUE)
  }
  checks[[z]]<-list(passed=TRUE,members=20,N=nrow(x),communities=length(unique(x[,'cluster'])),only_missing_ADL_changed=TRUE,all_original_source_hashes_unchanged=TRUE)
 }
 stopifnot(length(rows)>0L)
 write.csv(do.call(rbind,rows),file.path(R,'audit/MI_INDEPENDENT_MEMBERS.csv'),row.names=FALSE)
 write_json(list(status='PASS',members=length(rows),scopes=checks,new_imputations=0,new_engines=0),file.path(R,'audit/MI_INDEPENDENT_VALIDATION.json'),auto_unbox=TRUE,pretty=TRUE)
 cat('INDEPENDENT_MI_FILES_PASS',length(rows),'members\n')
})
