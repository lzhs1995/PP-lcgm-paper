"""编译同一二元交互模型、按原目标参数变换高精度估计及完整协方差。"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import csv,hashlib,json,shutil,sys
import numpy as np
import pandas as pd
from scipy.linalg import cho_factor,cho_solve
from calibrated_reader import matrices,pid
R=Path(__file__).resolve().parents[1];P=R.parent/'cfps_mean_h41_20261017'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
fac=['IX','SX','IY','SY','IZ','SZ'];obs=[f'{p}{i}' for p in ['X','Y','Z'] for i in range(1,6)]
targets={('IY','IX'):'dii',('SY','IX'):'dis',('SY','SX'):'dss',('IY','IZ'):'dzi',('SY','IZ'):'diz',('SY','SZ'):'dsz'}
def parent_cell(df,mat,r,c):
 s=df[(df.matrix.str.upper()==mat)&(df.row==r)&(df.column.fillna('')==c)]
 if s.empty and mat in ('BETA','GAMMA'):s=df[df.matrix.str.upper().isin(['BETA','GAMMA'])&(df.row==r)&(df.column==c)]
 if s.empty and mat in ('THETA','PSI'):s=df[(df.matrix.str.upper()==mat)&(df.row==c)&(df.column==r)]
 assert len(s)==1,(mat,r,c);return float(s.estimate.iloc[0])
def stmt(r,v=None,lab=None):
 v=r['value'] if v is None else v;lab=r['label'] if lab is None else lab;a=r['lhs'].lower();b=r['rhs'].lower();v=f'{v:.12g}'
 if r['op']=='MEAN':return f'[{a}*{v}] ({lab});'
 if r['op']=='VAR':return f'{a}*{v} ({lab});'
 return f'{a} {r["op"]} {b}*{v} ({lab});'
def prepare(z,group,start):
 assert z in read(R/'contracts/SOURCES.json') and group in ('PARENT','EDU','URBAN') and start in ('A','B')
 interaction=group!='PARENT';g='C4' if group=='URBAN' else 'C3';entry=read(R/'contracts/SOURCES.json')[z];source=Path(entry['parent'])
 for name,h in entry['hashes'].items():assert sha(source/name)==h
 df=pd.read_csv(source/'parameters_high_precision.csv');rows=[]
 for i,r in enumerate(df.itertuples()):
  mat=r.matrix.upper();a=r.row;b=r.column
  if mat=='ALPHA':op='MEAN';a=b;b=''
  elif mat=='LAMBDA':op='BY';a,b=b,a
  elif mat in ('THETA','PSI'):op='VAR' if a==b else 'WITH'
  elif mat in ('BETA','GAMMA'):op='ON'
  else:raise ValueError(mat)
  v=float(r.estimate)
  if op=='VAR':assert v>0
  if start=='B' and op in ('MEAN','ON','BY'):v+=.02*float(r.se)*(1 if i%2 else -1)
  rows.append(dict(op=op,lhs=a,rhs=b,key=op+':'+a+':'+b,label=f'p{i+1:03d}',value=v))
 assert len(rows)==126
 d=R/'models'/f'CHARLS_{z.upper()}_LATENT_H41_{group}_{start}';d.mkdir(exist_ok=False)
 shutil.copyfile(source/'data.dat',d/'data.dat')
 common=[r for r in rows if r['op']!='MEAN' and not(r['op']=='ON' and r['rhs']==g)]
 means=[r for r in rows if r['op']=='MEAN'];gm={r['lhs']:r['value'] for r in rows if r['op']=='ON' and r['rhs']==g}
 assert len(means)==len(gm)==6
 controls=[f'c{i}' for i in range(1,12) if f'C{i}'!=g]
 fixed=[]
 for i,a in enumerate(fac):
  for b in fac[:i]:
   if not any(r['op']=='WITH' and {r['lhs'],r['rhs']}=={a,b} for r in rows):fixed.append(f'{a.lower()} WITH {b.lower()}@0;')
 lines=['TITLE: '+d.name+';','DATA: FILE=data.dat;','VARIABLE: NAMES=cluster x1-x5 y1-y5 c1-c11 z1-z5;',
  'USEVARIABLES=x1-x5 y1-y5 z1-z5 '+' '.join(controls)+';',
  'MISSING=ALL(-9999); CLUSTER=cluster; CLASSES=cg(2);',f'KNOWNCLASS=cg({g.lower()}=0 {g.lower()}=1);',
  'ANALYSIS: TYPE=COMPLEX MIXTURE; ESTIMATOR=MLR; STARTS=0;',
  'PROCESSORS=1; COVERAGE=.005; ITERATIONS=2000; MITERATIONS=2000;',
  'MODEL:','%OVERALL%','ix sx | x1@0 x2@2 x3@4 x4@7 x5@9;',
  'iy sy | y1@0 y2@2 y3@4 y4@7 y5@9;','iz sz | z1@0 z2*2 z3*4 z4*7 z5@9;',
  '[cg#1@0];','[x1-x5@0 y1-y5@0 z1-z5@0];',*fixed,*[stmt(r) for r in common]]
 for cls in (0,1):
  lines += [f'%cg#{cls+1}%','[x1-x5@0 y1-y5@0 z1-z5@0];',*fixed]
  for r in common:
   target=targets.get((r['lhs'],r['rhs'])) if interaction and r['op']=='ON' else None
   lines.append(stmt(r,r['value']+cls*(.005 if start=='A' else -.005),r['label']+str(cls)) if target else stmt(r))
  for r in means:lines.append(stmt(r,r['value']+cls*gm[r['lhs']],r['lhs'].lower()+str(cls)))
 lines+=['OUTPUT: TECH1 TECH3 TECH8 CINTERVAL SVALUES;','SAVEDATA: RESULTS=estimates.dat; TECH3=tech3.dat;']
 assert max(map(len,lines))<=90
 (d/'model.inp').write_text('\n'.join(lines)+'\n',encoding='ascii')
 normalized=rows.copy()
 if interaction:normalized += [dict(op='ON',lhs=a,rhs=b+'G',key='ON:'+a+':'+b+'G',label=lab,value=.005 if start=='A' else -.005) for (a,b),lab in targets.items()]
 (d/'normalized_slots.json').write_text(json.dumps(normalized,indent=2))
 job=dict(id=d.name,root=str(R),dest=str(d),indicator=z,group=group,member=0,start=start,category=group,cap_seconds=180 if interaction else 120,expected_free=len(normalized),g=g,interaction=interaction,source_parent=str(source),N=entry['N'],hashes={n:sha(d/n) for n in ['model.inp','data.dat']})
 (d/'job.json').write_text(json.dumps(job,indent=2));return d

def checks_moments(q,slots,data,gcol):
 L=np.zeros((15,6))
 for j in range(3):L[j*5:(j+1)*5,j*2]=1;L[j*5:(j+1)*5,j*2+1]=[0,2,4,7,9]
 TH=np.zeros((15,15));PSI=np.zeros((6,6));B=np.zeros((6,6));D=np.zeros((6,6));Gamma=np.zeros((6,11));alpha=np.zeros(6)
 for r,value in zip(slots,q):
  op=r['op'];a=r['lhs'];b=r['rhs']
  if op=='BY':L[obs.index(b),fac.index(a)]=value
  elif op=='MEAN':alpha[fac.index(a)]=value
  elif op in ('VAR','WITH'):
   b=a if op=='VAR' else b;m=PSI if a in fac else TH;ns=fac if a in fac else obs;i=ns.index(a);j=ns.index(b);m[i,j]=m[j,i]=value
  elif b in ('IXG','SXG','IZG','SZG'):D[fac.index(a),fac.index(b[:2])]=value
  elif b in fac:B[fac.index(a),fac.index(b)]=value
  else:Gamma[fac.index(a),int(b[1:])-1]=value
 def mineig(m):
  if np.any(np.diag(m)<=0):return float(np.linalg.eigvalsh(m).min())
  return float(np.linalg.eigvalsh(m/np.sqrt(np.outer(m.diagonal(),m.diagonal()))).min())
 geometry={'PSI':mineig(PSI),'THETA':mineig(TH)};ll=0.
 for g in (0,1):
  A=np.linalg.inv(np.eye(6)-B-g*D);G=A@PSI@A.T;S=L@G@L.T+TH
  geometry['G'+str(g)]=mineig(G);geometry['SIGMA'+str(g)]=mineig(S)
  if min(geometry.values())<=1e-7:return geometry,None
  dd=data[data[:,gcol]==g];mu=(alpha+dd[:,11:22]@Gamma.T)@A.T@L.T;y=dd[:,list(range(1,11))+list(range(22,27))];mask=np.isfinite(y)
  for pattern in np.unique(mask,axis=0):
   ids=np.all(mask==pattern,axis=1);j=np.flatnonzero(pattern)
   if not len(j):continue
   ch=cho_factor(S[np.ix_(j,j)],lower=True);e=y[ids][:,j]-mu[ids][:,j]
   ll-=.5*(len(e)*(len(j)*np.log(2*np.pi)+2*np.log(np.diag(ch[0])).sum())+np.sum(e*cho_solve(ch,e.T).T))
 return geometry,float(ll)
def normalize(d):
 d=Path(d);job=read(d/'job.json');er=read(d/'engine_receipt.json');rr=dict(id=d.name,dest=str(d),group=job['group'],member=job['member'],start=job['start'],engine=er,status=er['status'])
 if (d/'model.out').exists():rr['output_sha256']=sha(d/'model.out')
 if er['status']!='EXITED':(d/'receipt.json').write_text(json.dumps(rr,indent=2),encoding='utf-8');return
 try:
  txt,mp,q,se,V,ll=matrices(d);slots=read(d/'normalized_slots.json');n=len(slots);assert len(q)==n==job['expected_free'] and len(mp)==2
  J=np.zeros((n,n));normmeta=[]
  for i,r in enumerate(slots):
   op=r['op'];a=r['lhs'];b=r['rhs'];mat=None;row=a;col=b
   if op=='ON' and b==job['g']:
    J[i,pid(mp[2],'ALPHA','1',a)]=1;J[i,pid(mp[1],'ALPHA','1',a)]=-1;mat='BETA'
   elif op=='ON' and b in ('IXG','SXG','IZG','SZG'):
    base=b[:2];J[i,pid(mp[2],'BETA',a,base)]=1;J[i,pid(mp[1],'BETA',a,base)]=-1;mat='BETA'
   else:
    if op=='BY':mat='LAMBDA';row=b;col=a
    elif op=='MEAN':mat='ALPHA';row='1';col=a
    elif op in ('VAR','WITH'):mat='PSI' if a in fac else 'THETA';col=a if op=='VAR' else b
    elif op=='ON':mat='BETA'
    j=pid(mp[1],mat,row,col);J[i,j]=1
    if op!='MEAN':
     if job['interaction'] and op=='ON' and (a,b) in targets:assert j!=pid(mp[2],mat,row,col)
     else:assert j==pid(mp[2],mat,row,col)
   normmeta.append(dict(parameter=i+1,matrix=mat.lower(),row=row,column=col))
  assert np.linalg.matrix_rank(J)==n
  nq=J@q;NV=J@V@J.T;nse=np.sqrt(NV.diagonal());scale=np.sqrt(np.outer(NV.diagonal(),NV.diagonal()))
  eig=float(np.linalg.eigvalsh(NV/scale).min());data=np.genfromtxt(d/'data.dat',missing_values='-9999',filling_values=np.nan);data[data==-9999]=np.nan
  geometry,alll=checks_moments(nq,slots,data,{'C3':13,'C4':14}[job['g']])
  negative=[r['lhs'] for r,v in zip(slots,nq) if r['op']=='VAR' and v<0]
  normal='THE MODEL ESTIMATION TERMINATED NORMALLY' in txt
  no_autofix='FIXED TO AVOID SINGULARITY' not in txt
  ll_ok=alll is not None and abs(ll+len(data)*np.log(2)-alll)<.02
  fatal=any(t in ' '.join(txt.split()) for t in ['STANDARD ERRORS COULD NOT BE COMPUTED','MAY NOT BE TRUSTWORTHY','THE MODEL ESTIMATION DID NOT TERMINATE NORMALLY','SADDLE POINT','*** ERROR'])
  passed=normal and not fatal and no_autofix and len(data)==job['N'] and eig>1e-10 and min(geometry.values())>1e-7 and not negative and ll_ok
  rr.update(status='USABLE' if passed else 'INADMISSIBLE',parameters=n,negative=negative,geometry=geometry,vcov_min_correlation_eigenvalue=eig,normal=normal,no_autofix=no_autofix,LL=ll+len(data)*np.log(2),analytic_LL=alll,likelihood_identity=bool(ll_ok),normalized_parameters=True,N=len(data),communities=len(np.unique(data[:,0])))
  par=pd.DataFrame(normmeta);par['estimate']=nq;par['se']=nse;par.to_csv(d/'parameters_high_precision.csv',index=False)
  pd.DataFrame(NV).to_csv(d/'parameter_covariance.csv',header=False,index=False);pd.DataFrame(J).to_csv(d/'parameter_transform.csv',header=False,index=False)
  keys=[('bii','IY','IX'),('bis','SY','IX'),('bss','SY','SX'),('bsyiy','SY','IY'),('bzi','IY','IZ'),('biz','SY','IZ'),('bsz','SY','SZ'),('dii','IY','IXG'),('dis','SY','IXG'),('dss','SY','SXG'),('dzi','IY','IZG'),('diz','SY','IZG'),('dsz','SY','SZG')]
  rows=[]
  for lab,a,b in (keys if job['interaction'] else keys[:7]):
   match=par[(par.matrix=='beta')&(par.row==a)&(par.column==b)];assert len(match)==1;r=match.iloc[0].to_dict();r['label']=lab;rows.append(r)
  pd.DataFrame(rows).to_csv(d/'key_paths.csv',index=False)
  (d/'validation.json').write_text(json.dumps(dict(passed=bool(passed),geometry=geometry,vcov_min=eig,negative=negative,likelihood_identity=bool(ll_ok)),indent=2),encoding='utf-8')
 except Exception as exc:rr['status']='READBACK_FAILED';rr['error']=repr(exc)
 (d/'receipt.json').write_text(json.dumps(rr,indent=2),encoding='utf-8');print(json.dumps({k:rr[k] for k in ('id','status','negative','error') if k in rr}))
def agree(a,b,target):
 a=Path(a);b=Path(b);ra=read(a/'receipt.json');rb=read(b/'receipt.json');assert ra['status']==rb['status']=='USABLE'
 pa=pd.read_csv(a/'parameters_high_precision.csv');pb=pd.read_csv(b/'parameters_high_precision.csv');assert pa[['matrix','row','column']].equals(pb[['matrix','row','column']])
 diff=np.abs(pa.estimate-pb.estimate);sd=np.abs(pa.se-pb.se)/pa.se
 ok=np.all(diff<=np.maximum(.001,.05*pa.se)) and np.all(sd<=.05) and abs(ra['LL']-rb['LL'])<=.02
 result=dict(passed=bool(ok),all_parameters=len(pa),max_difference_over_SE=float(np.max(diff/pa.se)),max_SE_relative=float(sd.max()),LL_difference=abs(ra['LL']-rb['LL']))
 Path(target).write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare(sys.argv[2],sys.argv[3],sys.argv[4])
 elif sys.argv[1]=='normalize':normalize(sys.argv[2])
 elif sys.argv[1]=='agree':agree(*sys.argv[2:5])

def compare_full(a,b):
 a=Path(a);b=Path(b);pa=pd.read_csv(a/'parameters_high_precision.csv');pb=pd.read_csv(b/'parameters_high_precision.csv')
 def key(row):
  m=row.matrix.lower();r=row.row;c=row.column
  if m=='gamma':m='beta'
  if m in ('psi','theta'):r,c=sorted((r,c))
  return m,r,c
 ka=[key(x) for x in pa.itertuples()];kb=[key(x) for x in pb.itertuples()];assert len(ka)==len(set(ka))==len(kb)==len(set(kb)) and set(ka)==set(kb)
 ix=[kb.index(k) for k in ka];bq=pb.estimate.to_numpy()[ix];bs=pb.se.to_numpy()[ix];aq=pa.estimate.to_numpy();ase=pa.se.to_numpy()
 av=np.loadtxt(a/'parameter_covariance.csv',delimiter=',');bv=np.loadtxt(b/'parameter_covariance.csv',delimiter=',')[np.ix_(ix,ix)]
 ra=read(a/'receipt.json');rb=read(b/'receipt.json');checks=dict(LL_absolute=abs(ra['LL']-rb['LL']),parameter_over_reference_SE=float(np.max(abs(aq-bq)/ase)),SE_relative=float(np.max(abs(ase-bs)/ase)),normalized_vcov=float(np.max(abs(av-bv)/np.outer(ase,ase))))
 limits=read(R/'contracts/RUN_CONTRACT.json')['tolerances'];passed=all(checks[k]<=limits[k] for k in limits)
 return dict(passed=bool(passed),parameters=len(ka),checks=checks,tolerances=limits)
def calibrate(z):
 src=Path(read(R/'contracts/SOURCES.json')[z]['parent']);d=R/'models'/f'CHARLS_{z.upper()}_LATENT_H41_PARENT_A'
 assert read(d/'receipt.json')['status']=='USABLE'
 # 源参数顺序由语义键匹配；源与重参数化模型只差固定组概率常数。
 result=compare_full(src,d);result['source_parent']=str(src);result['class_constant']='fixed -N*log(2), removed in normalized LL'
 (R/'results'/f'{z}_CALIBRATION.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
def agree_full(a,b,target):
 assert read(Path(a)/'receipt.json')['status']==read(Path(b)/'receipt.json')['status']=='USABLE'
 result=compare_full(a,b);Path(target).write_text(json.dumps(result,indent=2));print(json.dumps(result))
