# 一个原生ClaudeR排队任务；只在SD城乡原worker真实退出后依次推进既定性别差家族。
# 无新插补、无CFPS重估；只复用CC已通过与原20份MI，单引擎执行。
local({
 ROOT<-'C:/Users/LZHS/pp_lgcm_review/charls_latent_h41_mi_20261019'
 PY<-'C:/Users/LZHS/AppData/Local/Programs/Python/Python314/python.exe'
 library(jsonlite);library(ps);library(processx)
 wj<-function(x,p)write_json(x,p,auto_unbox=TRUE,pretty=TRUE,digits=NA)
 rj<-function(p)fromJSON(p,simplifyVector=FALSE)
 marker<-file.path(ROOT,'runtime/GENDER_QUEUE_RESERVED.json');stopifnot(!file.exists(marker))
 created<-as.numeric(ps_create_time(ps_handle()));wj(list(pid=Sys.getpid(),created_exact=sprintf('%.17g',created),families=c('gender_EDU','gender_URBAN')),marker)
 dep<-rj(file.path(ROOT,'runtime/sd_URBAN_RESERVED.json'));deadline<-Sys.time()+24*3600
 repeat {
  h<-tryCatch(ps_handle(dep$pid,as.POSIXct(as.numeric(dep$created_exact),origin='1970-01-01',tz='UTC')),error=function(e){if(inherits(e,'no_such_process'))return(NULL);stop(e)})
  alive<-if(is.null(h))FALSE else ps_is_running(h)
  if(!alive)break
  clauder_progress('QUEUE_WAIT','Waiting for existing SD urban worker exit; no competing engine');Sys.sleep(30)
  if(Sys.time()>deadline)stop('Queue wall lease expired; original worker not touched')
 }
 statusfile<-file.path(ROOT,'results/sd_URBAN/FAMILY_STATUS.json');stopifnot(file.exists(statusfile))
 depstatus<-rj(statusfile);stopifnot(depstatus$status!='RUNNING')
 wj(list(dependency=dep,terminal=depstatus,at=format(Sys.time(),tz='UTC')),file.path(ROOT,'audit/GENDER_QUEUE_DEPENDENCY_EXIT.json'))
 all<-list()
 for(fam in c('gender_EDU','gender_URBAN')){
  clauder_progress('QUEUE_FAMILY_START',fam)
  env<-new.env(parent=environment());env$FAMILY<-fam
  # 对实际当前负载取样，选择两个预定义逻辑核集合中较空闲者；不是固定核号建议。
  rr<-processx::run(PY,c('-X','utf8','-c',"import psutil,json;v=psutil.cpu_percent(2,percpu=True);assert len(v)==16;g=min([list(range(8)),list(range(8,16))],key=lambda q:sum(v[i] for i in q)/len(q));print(json.dumps({'per_cpu':v,'chosen':g}))"),timeout=30,error_on_status=TRUE)
  cp<-fromJSON(rr$stdout);env$CPU_CORES<-cp$chosen;wj(cp,file.path(ROOT,'audit',paste0(fam,'_CPU_ADMISSION.json')))
  source(file.path(ROOT,'code/run_family.R'),local=env)
  fs<-rj(file.path(ROOT,'results',fam,'FAMILY_STATUS.json'))
  all[[fam]]<-fs
  if(identical(fs$status,'TWENTY_USABLE_PENDING_POOLING')){
   clauder_progress('QUEUE_POOLING',fam);source(file.path(ROOT,'code/pool_family.R'),local=env)
   clauder_progress('QUEUE_INDEPENDENT_READBACK',fam)
   x<-processx::run(PY,c('-X','utf8',file.path(ROOT,'code/verify_family.py'),fam),timeout=600,error_on_status=FALSE)
   writeLines(c(x$stdout,x$stderr),file.path(ROOT,'results',fam,'INDEPENDENT_PROCESS_LOG.txt'));stopifnot(x$status==0)
   all[[fam]]$independent<-rj(file.path(ROOT,'results',fam,'INDEPENDENT_VERIFICATION.json'))
  }
  wj(all,file.path(ROOT,'results/GENDER_QUEUE_STATUS.json'))
 }
 clauder_progress('GENDER_QUEUE_TERMINAL','Both originally registered gender families reached recorded terminal; inspect full-family receipts')
 cat('GENDER_QUEUE_DONE\n')
})
