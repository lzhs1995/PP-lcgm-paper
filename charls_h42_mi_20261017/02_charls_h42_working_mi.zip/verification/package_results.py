"""仅完整验收后的聚合证据白名单打包；不含个人数据；单ZIP<25MB。"""
from pathlib import Path
import csv,hashlib,io,json,re,sys,zipfile
R=Path(__file__).resolve().parents[1];read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
def main():
 assert read(R/'audit/POOL_INDEPENDENT_ALL.json')['status']=='PASS'
 assert read(R/'audit/FIGURE_VISUAL_REVIEW.json')['status']=='PASS'
 assert read(R/'audit/TERMINAL_EDU_URBAN.json')['status']=='H42_MI_PHASE_TERMINAL'
 assert read(R/'audit/TERMINAL_INC.json')['status']=='H42_MI_PHASE_TERMINAL'
 S=R/'public_stage';S.mkdir(exist_ok=True);assert not list(S.iterdir()),'Existing delivery; reuse or explicitly version'
 selected={}
 def add(p):
  assert p.is_file() and p.suffix.lower() in {'.json','.csv','.txt','.log','.md','.r','.py','.inp','.out','.dat','.pdf','.png'}
  assert 'private' not in p.parts and 'checkpoints' not in p.parts
  if p.suffix=='.dat':assert p.name in {'estimates.dat','tech3.dat'}
  selected[p.relative_to(R).as_posix()]=p
 for folder in ['contracts','code']:
  for p in (R/folder).iterdir():
   if p.is_file():add(p)
 for n in ['raw_parameter_reader.py','verify_pooled_h42.py','report_phase.py','package_results.py']:add(R/'verification'/n)
 for folder in ['results/pool_ALL']:
  for p in (R/folder).rglob('*'):
   if p.is_file():add(p)
 for n in ['FAMILY_STATUS.json','CALL_RESULTS.json']:add(R/'results'/n)
 for p in (R/'results').glob('*_START_COMPARISON.json'):add(p)
 for n in ['REPORT_ALL.md']:add(R/'reports'/n)
 for n in ['POOL_INDEPENDENT_ALL.json','INCOME_DAT_INDEPENDENT.json','FIGURE_VISUAL_REVIEW.json','ADL_INPUT_VERIFICATION.json','ADL_DESIGNS.json','ADL_ADMISSIONS.json','ADL_SESSION_INFO.txt','INCOME_INPUT_DESIGNS.json','INCOME_PILOT_SUMMARY.json','REBOOT_R_VALIDATION.json','CONNECTION_RECOVERY_R_VALIDATION.json','POSTBOOT_HOST_CONCURRENCY.json','INCOME_WORKER_SCHEDULING.json','TERMINAL_EDU_URBAN.json','TERMINAL_INC.json']:
  p=R/'audit'/n
  if p.exists():add(p)
 for z in ['sd','gender','oldest','son']:
  for family in ['mi','mi_income']:
   d=R/family/z
   for n in ['ADMISSION.json','INPUT_DESIGN.json','MEMBER_VALIDATION.csv','CONVERGENCE.csv','FIT_LOG.jsonl','PREDICTORS_ACTUAL.csv','R_SESSION_INFO.txt','WARNINGS.json','IMPUTER_INSTRUMENTATION.json']:
    p=d/'audit'/n
    if p.exists() and p.suffix!='.jsonl':add(p)
   for p in (d/'results').glob('*'):
    if p.suffix in {'.csv','.pdf'}:add(p)
  for attempt in ['pilot','pilot_interface2']:
   p=R/'mi_income'/z/attempt/'audit/RECEIPT.json'
   if p.exists():add(p)
 for rel in ['audit/income_startup_20261017/DISPOSITION.json','audit/streaming_dispatch_20261017/PRECHECK.json','audit/PUBLIC_HASH_TARGETED_TEST.json','audit/GUIDE_STREAMING_UPDATE.json','audit/RECOVERY_MI_SCHEDULING.json']:
  p=R/rel
  if p.exists():add(p)
 for d in (R/'models').iterdir():
  if not d.is_dir():continue
  for n in ['model.inp','model.out','job.json','receipt.json','engine_receipt.json','not_run.json','validation.json','key_paths.csv','parameter_covariance.csv','parameters_high_precision.csv','tech1_parameter_map.csv','matrix_values.csv','start_mapping.csv','design_check.json','mplus_execution.log','estimates.dat','tech3.dat']:
   p=d/n
   if p.exists():add(p)
 add(R/'runtime/budget_status.json')
 payload={};manifest=[]
 for rel,p in sorted(selected.items()):
  raw=p.read_bytes()
  if p.suffix in {'.pdf','.png'}:data=raw
  else:
   text=raw.decode('utf-8-sig')
   for prefix in ['<LOCAL_USER_HOME>','<LOCAL_USER_HOME>','C:\\\\Users\\\\LZHS','<LOCAL_USER_HOME>','<LOCAL_USER_HOME>']:text=text.replace(prefix,'<LOCAL_USER_HOME>')
   assert not re.search(r'(?i)(?:api[_-]?key|access_token)\s*[:=]\s*["\x27]?[A-Za-z0-9_-]{20,}',text),rel
   if p.suffix=='.csv':
    head={x.lower() for x in next(csv.reader(io.StringIO(text)))};assert not head&{'pid','fid','childid','householdid','communityid'},rel
   data=text.encode('utf-8')
  payload[rel]=data;manifest.append({'path':rel,'bytes':len(data),'sha256':sha(data),'local_source_sha256':sha(raw),'role':'explicit_aggregate_code_or_parameter'})
 payload['PAYLOAD_MANIFEST.json']=json.dumps(manifest,indent=2).encode()
 def zipped(group):
  s=io.BytesIO()
  with zipfile.ZipFile(s,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
   for n,b in group:z.writestr(n,b)
  return s.getvalue()
 groups=[sorted(payload.items())]
 while any(len(zipped(g))>=25_000_000 for g in groups):
  new=[]
  for g in groups:
   if len(zipped(g))>=25_000_000:assert len(g)>1;h=len(g)//2;new.extend([g[:h],g[h:]])
   else:new.append(g)
  groups=new
 packs=[]
 for i,g in enumerate(groups,1):
  p=S/f'{i:02d}_charls_h42_working_mi.zip';p.write_bytes(zipped(g))
  with zipfile.ZipFile(p) as z:assert z.testzip() is None
  packs.append({'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'files':len(g)})
 for src,dst in [('reports/REPORT_ALL.md','REPORT.md'),('results/pool_ALL/H42_REGISTERED.csv','H42_REGISTERED.csv'),('results/pool_ALL/ALLCONTRASTS.csv','GROUP_CONTRASTS.csv'),('results/pool_ALL/H42_GROUP_DIFFERENCES.pdf','H42_GROUP_DIFFERENCES.pdf')]:
  if src in payload:(S/dst).write_bytes(payload[src])
 manifest_out={'packages':packs,'privacy':'No individual DAT/RDS, identifiers or participant records. Parameter RESULTS and TECH3 DAT only.','complete_families':read(R/'results/pool_ALL/RECEIPT.json')['complete'],'full_H4_complete':False,'original_CFPS_four_complete':False}
 (S/'PACKAGE_MANIFEST.json').write_text(json.dumps(manifest_out,indent=2),encoding='utf-8')
 readme='''# CHARLS H4.2 完整家族工作插补敏感性

**四项调节完整推断、完整 H4 仍未完成。**

[报告](REPORT.md) · [全部登记家族](H42_REGISTERED.csv) · [组间直接差异与组内调节](GROUP_CONTRASTS.csv) · [区间图](H42_GROUP_DIFFERENCES.pdf) · [包清单](PACKAGE_MANIFEST.json)

请将所有ZIP合并解压到同一目录，运行 `python verification/verify_pooled_h42.py ALL --public`，需要numpy、pandas、scipy；无需微观数据或Mplus。程序直接读原始保存参数与TECH3，复算完整家族。代码中的本机路径已脱敏；公开验证器使用相对路径，同时核对公开字节哈希和保存的本机来源哈希。脱敏文件不宣称与本机原件逐字节相同。

工作插补完整不等于潜交互精确相容性。失败/未放行家族保留，固定12项多重比较；未按显著性选模型。本文档不是冻结论文的新版本，不要求新NLM轮次。CHARLS见面频率/家庭净收入与CFPS情感亲近度/个人收入含义不同。

前批固定证据：[H4.1十二条件家族](https://github.com/lzhs1995/PP-lcgm-paper/tree/87941423437c589809a2c95833c220e387fc0f5d/charls_son_income_resume_20261016)、[四项动态调节工作MI](https://github.com/lzhs1995/PP-lcgm-paper/tree/6ea7d570be09492927eac64315f7655cad55d66d/charls_dynamic_mi_sensitivity_20261016)、[本批H4.2完整案例父模型](https://github.com/lzhs1995/PP-lcgm-paper/tree/030bdcd548892df1876161b7e4637a02415bad56/charls_h42_pilot_20261017)。这些是同一研究资料上的不同条件分析，不是独立样本的重复验证。
'''
 (S/'README.md').write_text(readme,encoding='utf-8');(S/'FOR_WEB_REVIEWERS.md').write_text('请先读本报告的完成范围和失败记录，再复算原始参数/完整协方差。不要把MI成员数、合法输出或skill进展当成原完整H4完成。无个人级数据，无需重新拟合。\n\n'+readme,encoding='utf-8')
 (R/'audit/PUBLIC_FILE_SELECTION.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');print(json.dumps(manifest_out))
if __name__=='__main__':main()
