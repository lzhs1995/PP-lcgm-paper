"""独立原始参数/TECH3合并与直接组差复算；不估计模型。"""
from pathlib import Path
import json,sys,re,hashlib
import numpy as np
import pandas as pd
from scipy.stats import t
from raw_parameter_reader import raw_model
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
labs=['bii','bis','bss','bsyiy','gi0','gs0','gizg','gszg','dc','bxg','dcg']
fields=['estimate','se','df','lower','upper','p','lambda','MCSE_over_SE']
def verify_source(path,original_sha,manifest=None):
 if manifest is None:assert sha(path)==original_sha;return
 # 公开脱敏可能改变文本字节；同时核对公开字节和本机原文件哈希，不冒充原始字节相同。
 entry=manifest[path.relative_to(R).as_posix()]
 assert sha(path)==entry['sha256'] and original_sha==entry['local_source_sha256']
def main(phase):
 manifest=None
 if '--public' in sys.argv:
  entries=read(R/'PAYLOAD_MANIFEST.json');manifest={e['path']:e for e in entries};assert len(entries)==len(manifest)
  for rel,e in manifest.items():
   p=R/rel;assert p.resolve().is_relative_to(R.resolve()) and p.is_file() and sha(p)==e['sha256']
 root=R/'results'/f'pool_{phase}';summary=pd.read_csv(root/'H42_REGISTERED.csv');checked={}
 for row in summary.itertuples():
  if row.status not in ('FULL_CONDITIONAL_MI_POOLED','FULL_POOLED_MCSE_LIMIT_RETAINED'):continue
  dest=root/row.family;src=pd.read_csv(dest/'MEMBER_SOURCES.csv');assert len(src)==row.m and list(src.member)==list(range(1,row.m+1))
  pairs=[];starts=[]
  for s in src.itertuples():
   d=R/'models'/s.model;j=read(d/'job.json');assert j['member']==s.member and j['start']=='A' and j['family']==row.family
   for file,h in [('model.out',s.output_sha256),('model.inp',s.input_sha256),('estimates.dat',s.results_sha256),('tech3.dat',s.tech3_sha256)]:verify_source(d/file,h,manifest)
   out,mapping,q,se,v,key,ll=raw_model(d);assert 'THE MODEL ESTIMATION TERMINATED NORMALLY' in out and 'FIXED TO AVOID SINGULARITY' not in out
   assert int(re.search(r'Number of observations\s+(\d+)',out).group(1))==row.N
   assert all(q[k-1]>=0 for mat,a,b,k in mapping if mat in ('PSI','THETA') and a==b and k)
   assert np.linalg.eigvalsh(v/np.outer(np.sqrt(v.diagonal()),np.sqrt(v.diagonal()))).min()>0
   ix=key.set_index('label').loc[labs].parameter.to_numpy(dtype=int)-1;pairs.append((q[ix],v[np.ix_(ix,ix)]))
   if s.member==1:
    b=R/'models'/(s.model[:-1]+'B')
    ob,mb,qb,seb,vb,kb,llb=raw_model(b);idx=kb.set_index('label').loc[labs].parameter.to_numpy(dtype=int)-1
    assert abs(ll-llb)<=.01 and np.all(abs(q[ix]-qb[idx])<=np.maximum(.001,.05*np.maximum(se[ix],seb[idx]))) and np.all(abs(se[ix]-seb[idx])/np.maximum(se[ix],seb[idx])<=.05)
  Q=np.array([x[0] for x in pairs]);U=np.array([x[1] for x in pairs]);m=len(Q);W=U.mean(0);B=np.cov(Q,rowvar=False,ddof=1);T=W+(1+1/m)*B;est=Q.mean(0)
  def scalar(a,dfcom=np.inf):
   e=float(a@est);se=np.sqrt(a@T@a);rv=(1+1/m)*(a@B@a)/(a@W@a);lam=(1+1/m)*(a@B@a)/(a@T@a);df=(m-1)*(1+1/rv)**2 if rv>0 else np.inf
   if np.isfinite(dfcom):df=1/(1/df+1/((dfcom+1)/(dfcom+3)*dfcom*(1-lam)))
   return np.array([e,se,df,e-t.ppf(.975,df)*se,e+t.ppf(.975,df)*se,2*t.sf(abs(e/se),df),lam,np.sqrt(a@B@a/m)/se])
  def a(**kv):
   x=np.zeros(len(labs))
   for k,v in kv.items():x[labs.index(k)]=v
   return x
  path=pd.read_csv(dest/'POOLED_PATHS.csv').set_index('label').loc[labs]
  assert np.allclose([scalar(v) for v in np.eye(len(labs))],path[fields],rtol=1e-8,atol=1e-10)
  for name,mat in [('WITHIN',W),('BETWEEN',B),('TOTAL',T)]:assert np.allclose(pd.read_csv(dest/f'{name}_COVARIANCE.csv').set_index('label').loc[labs,labs],mat,rtol=1e-8,atol=1e-12)
  cs={'delta_G0':a(dc=1),'delta_G1':a(dc=1,dcg=1),'direct_difference':a(dcg=1)}
  for file in ['GROUP_MODERATION_CONTRASTS.csv','CLUSTER_DF_SENSITIVITY.csv']:
   for _,v in pd.read_csv(dest/file).iterrows():assert np.allclose(scalar(cs[v.contrast],v.get('df_complete',np.inf)),v[fields].to_numpy(dtype=float),rtol=1e-8,atol=1e-10)
  curves=pd.read_csv(dest/'CONDITIONAL_SLOPES.csv')
  for _,v in curves.iterrows():
   assert v.support_min<=v.z<=v.support_max
   assert np.allclose(scalar(a(bss=1,dc=v.z,bxg=v.G,dcg=v.z*v.G)),v[fields].to_numpy(dtype=float),rtol=1e-8,atol=1e-10)
  primary=scalar(a(dcg=1));assert np.allclose(primary[[0,1,3,4,5]],[row.estimate,row.se,row.lower,row.upper,row.p],rtol=1e-8,atol=1e-10)
  checked[row.family]={'m':m,'N':int(row.N),'conditional_points':len(curves),'p':float(primary[5])}
 valid=summary.p.notna();p=summary.loc[valid,'p'].to_numpy();order=np.argsort(p);holm=np.empty(len(p));holm[order]=np.minimum(1,np.maximum.accumulate((12-np.arange(len(p)))*p[order]))
 assert np.allclose(holm,summary.loc[valid,'Holm_12']) and np.allclose(np.minimum(1,12*p),summary.loc[valid,'Bonferroni_12'])
 receipt={'status':'PASS','phase':phase,'complete_families':checked,'new_Mplus_calls':0,'full_H4_complete':False,'original_CFPS_four_complete':False}
 target=R/'audit'/f'POOL_INDEPENDENT_{phase}.json';target.write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(receipt))
if __name__=='__main__':main(sys.argv[1] if len(sys.argv)>1 else 'EDU_URBAN')
