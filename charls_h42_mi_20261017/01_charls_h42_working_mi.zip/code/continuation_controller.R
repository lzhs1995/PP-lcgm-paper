# 低开销接续：完整家族独立放行，下一范围MI与本范围Mplus重叠；只有一个本任务引擎。
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_h42_mi_20261017'
library(jsonlite);library(ps);library(processx)
continuation_controller<-function(){
 record<-file.path(ROOT,'runtime/CONTINUATION.json');stopifnot(!file.exists(record))
 started<-Sys.time();me<-ps_handle();ps_set_cpu_affinity(me,c(0L,1L,3L,5L))
 state<-function(stage,message){x<-list(stage=stage,message=message,updated_at=format(Sys.time(),tz='UTC',usetz=TRUE),pid=Sys.getpid(),created=as.numeric(ps_create_time(me)));tmp<-paste0(record,'.tmp');write_json(x,tmp,pretty=TRUE,auto_unbox=TRUE);fs::file_move(tmp,record);if(exists('clauder_progress',mode='function'))try(clauder_progress(stage,message),silent=TRUE);cat(stage,message,'\n');flush.console()}
 alive<-function(pid,created)tryCatch({p<-ps_handle(pid);ps_is_running(p)&&abs(as.numeric(ps_create_time(p))-created)<.02},error=function(e)FALSE)
 wait_owner<-function(pid,created,name){while(alive(pid,created)){if(as.numeric(difftime(Sys.time(),started,units='secs'))>43200)stop('Controller12hour waiting bound reached');state('WAIT_EXISTING_OWNER',name);Sys.sleep(45)}}
 run_py<-function(script,args=character()){
  id<-paste0(tools::file_path_sans_ext(basename(script)),'_',paste(args,collapse='_'));log<-file.path(ROOT,'runtime',paste0(id,'.log'))
  p<-process$new('<LOCAL_USER_HOME>/AppData/Local/Programs/Python/Python314/python.exe',c('-X','utf8',script,args),stdout=log,stderr='2>&1',env=c('OPENBLAS_NUM_THREADS'='1','MKL_NUM_THREADS'='1'),cleanup=TRUE)
  beg<-Sys.time();while(p$is_alive()){p$wait(1000L);if(as.numeric(difftime(Sys.time(),beg,units='secs'))>600){p$kill();stop(paste('Verification timeout',id))}}
  stopifnot(p$get_exit_status()==0);state('VERIFICATION_DONE',id)
 }
 postprocess<-function(phase){
  source(file.path(ROOT,'code/pool_h42.R'),local=TRUE);pool_h42(phase)
  run_py(file.path(ROOT,'verification/verify_pooled_h42.py'),phase)
  source(file.path(ROOT,'code/plot_h42.R'),local=TRUE);plot_h42(phase)
  run_py(file.path(ROOT,'verification/report_phase.py'),phase)
 }
 wait_owner(24880,1792222847.45019,'EDU_URBAN job8294d45d')
 tpath<-file.path(ROOT,'audit/TERMINAL_EDU_URBAN.json');stopifnot(file.exists(tpath),fromJSON(tpath)$status=='H42_MI_PHASE_TERMINAL',!file.exists(file.path(ROOT,'runtime/engine.lock')))
 state('EDU_URBAN_POSTPROCESS','Only complete families; no new estimates');postprocess('EDU_URBAN')
 pending<-c('sd','gender','oldest','son')
 while(length(pending)){
  if(as.numeric(difftime(Sys.time(),started,units='secs'))>43200)stop('Controller12hour bound reached')
  workers_alive<-alive(16672,1792222451.3053129)||alive(5440,1792223718.0852)
  ready<-pending[vapply(pending,function(z)file.exists(file.path(ROOT,'mi_income',z,'audit/ADMISSION.json')),TRUE)]
  if(!workers_alive)ready<-pending
  if(!length(ready)){state('WAIT_INDEPENDENT_INCOME_ADMISSION',paste(pending,collapse=','));Sys.sleep(45);next}
  for(z in ready){
   # 仅对已完整放行家族验收数据；终态未放行范围由main_models记为排除，不估计。
   state('INCOME_INPUT_VERIFICATION',paste(z,'read actual40 DAT before this family'))
   source(file.path(ROOT,'code/verify_income_admissions.R'),local=TRUE);verify_income_admissions(z,paste0('_',toupper(z)))
   source(file.path(ROOT,'code/models.R'),local=TRUE);main_models(paste0('INC_',toupper(z)),paste0(z,'_INC'))
   pending<-setdiff(pending,z)
  }
 }
 source(file.path(ROOT,'code/verify_income_admissions.R'),local=TRUE);verify_income_admissions()
 fs<-fromJSON(file.path(ROOT,'results/FAMILY_STATUS.json'),simplifyVector=FALSE);inc<-fs[vapply(fs,function(s)s$group=='INC',TRUE)]
 stopifnot(length(inc)==4,all(vapply(inc,function(s)!s$status%in%c('RUNNING','REGISTERED_NOT_STARTED'),TRUE)))
 write_json(list(status='H42_MI_PHASE_TERMINAL',phase='INC',registered=4,full_families=sum(vapply(inc,function(s)s$status=='FULL_FAMILY_PENDING_POOLING',TRUE)),streamed_independent_families=TRUE,CFPS_calls=0,full_H4_complete=FALSE,utc=format(Sys.time(),tz='UTC',usetz=TRUE)),file.path(ROOT,'audit/TERMINAL_INC.json'),pretty=TRUE,auto_unbox=TRUE)
 state('ALL_AVAILABLE_FAMILIES_POSTPROCESS','Preserve nonadmitted/failed families; fixed12 multiplicity');postprocess('ALL')
 state('READY_FOR_FINAL_VISUAL_AND_PUBLIC_DELIVERY','Numerical work done within registered attempts; full original H4 still incomplete')
 cat('H42_CONTINUATION_NATIVE_TERMINAL\n')
}
