# 只缓存确定性lmer拟合；参数、随机效应和供体抽样每次仍执行。
# 隔离子进程内的函数副本，不修改安装包或前台R命名空间。
cache_env<-new.env(parent=asNamespace('miceadds'))
cache_env$fits<-new.env(parent=emptyenv());cache_env$hits<-0L;cache_env$misses<-0L
cache_env$ROOT<-ROOT
cache_env$mice_multilevel_doCall_suppressWarnings<-function(what,args,warnings=TRUE){
 stopifnot(identical(what,lme4::lmer))
 key<-digest::digest(args,algo='sha256')
 if(exists(key,envir=fits,inherits=FALSE)){hits<<-hits+1L;return(get(key,envir=fits))}
 misses<<-misses+1L;t0<-Sys.time();rng0<-get('.Random.seed',envir=.GlobalEnv)
 jsonlite::write_json(list(stage='lmer_fit_start',key=key,misses=misses,time=format(t0,tz='UTC')),file.path(ROOT,'runtime/mi_fit_cache.json'),auto_unbox=TRUE)
 ans<-if(warnings)do.call(what,args) else suppressWarnings(do.call(what,args))
 stopifnot(identical(rng0,get('.Random.seed',envir=.GlobalEnv)))
 assign(key,ans,envir=fits)
 saveRDS(ans,file.path(ROOT,'private/MI_ADL_CONDITIONAL_LMER.rds'))
 jsonlite::write_json(list(stage='lmer_fit_complete',key=key,seconds=as.numeric(difftime(Sys.time(),t0,units='secs')),random_state_unchanged=TRUE),file.path(ROOT,'audit/MI_FIT_CACHE_FIRST.json'),auto_unbox=TRUE)
 ans
}
environment(cache_env$mice_multilevel_doCall_suppressWarnings)<-cache_env
cache_env$mice_imputation_2l_lmer<-miceadds:::mice_imputation_2l_lmer
environment(cache_env$mice_imputation_2l_lmer)<-cache_env
cached_pmm<-miceadds::mice.impute.2l.pmm;environment(cached_pmm)<-cache_env
assign('mice.impute.2l.pmm.cached',cached_pmm,envir=.GlobalEnv)
