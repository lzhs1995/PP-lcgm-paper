# 只准备四份新的收入条件输入；不抽样、不调用Mplus。
.libPaths(c('<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_mi_pilot_20261016/library','<LOCAL_USER_HOME>/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
library(mice);library(jsonlite);library(digest)
BATCH<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_h42_mi_20261017'
prepare_income_inputs<-function(){
 records<-list()
 for(z in c('sd','gender','oldest','son')){
  root<-file.path(BATCH,'mi_income',z);for(x in c('private','audit','checkpoints','runtime','results','pilot'))dir.create(file.path(root,x),recursive=TRUE,showWarnings=FALSE)
  target<-file.path(root,'private/INPUTS.rds');stopifnot(!file.exists(target))
  src<-file.path('<LOCAL_USER_HOME>/pp_lgcm_review/charls_income_mi_pilot_20261016/attempt3/private',paste0(z,'_INPUTS.rds'));h<-digest(file=src,algo='sha256');a<-readRDS(src);d<-a$data;original_names<-names(d)
  aux<-grep('^(obs_|missing_)',names(d),value=TRUE);gproducts<-c('zg')
  for(v in aux){for(prefix in c('g_','gz_')){n<-paste0(prefix,v);d[[n]]<-d$g*d[[v]]*if(prefix=='gz_')d$z0 else 1;gproducts<-c(gproducts,n)}}
  proxy<-function(p){A<-as.matrix(a$analysis[paste0(p,1:5)]);A[A==-9999]<-NA_real_;tt<-c(0,2,4,7,9);s<-apply(A,1,function(y){o<-is.finite(y);if(sum(o)<2L)return(NA_real_);sum((tt[o]-mean(tt[o]))*(y[o]-mean(y[o])))/sum((tt[o]-mean(tt[o]))^2)});list(value=ifelse(is.na(s),0,s),missing=as.integer(is.na(s)))}
  x<-proxy('x');y<-proxy('y');d$sxp<-x$value;d$syp<-y$value;d$sxp_missing<-x$missing;d$syp_missing<-y$missing
  d$sxpsy<-d$sxp*d$syp;d$z_sxp<-d$z0*d$sxp;d$z_syp<-d$z0*d$syp;d$z_sxpsy<-d$z0*d$sxpsy
  proxynames<-c('sxp','syp','sxp_missing','syp_missing','sxpsy','z_sxp','z_syp','z_sxpsy')
  method<-make.method(d);method[]<-'';method['g']<-'2l.bin.logged';method['adl']<-'2l.pmm.logged';method['zg']<-'~I(z0*g)';method['z_adl']<-'~I(z0*adl)'
  for(v in aux){method[paste0('g_',v)]<-paste0('~I(g*',v,')');method[paste0('gz_',v)]<-paste0('~I(g*z0*',v,')')}
  initial<-d;initial$g[is.na(initial$g)]<-0;initial$adl[is.na(initial$adl)]<-median(initial$adl,na.rm=TRUE);initial$zg<-initial$z0*initial$g;initial$z_adl<-initial$z0*initial$adl
  update_g<-function(q,g){q$g<-g;q$zg<-q$z0*q$g;for(v in aux){q[[paste0('g_',v)]]<-q$g*q[[v]];q[[paste0('gz_',v)]]<-q$g*q$z0*q[[v]]};q}
  initial<-update_g(initial,initial$g);stopifnot(!anyNA(initial))
  requested<-list(g=unique(c(names(which(a$predictors['g',]==1)),proxynames)),adl=unique(c(names(which(a$predictors['adl',]==1)),paste0('z_',aux),gproducts)))
  pm<-matrix(0,ncol(d),ncol(d),dimnames=list(names(d),names(d)));ranks<-list()
  for(t in c('g','adl')){
   cand<-requested[[t]];stopifnot(!t%in%cand,!any(gproducts%in%requested$g),!'z_adl'%in%requested$adl)
   X<-cbind(Intercept=1,as.matrix(initial[cand]));cen<-colMeans(X);sc<-apply(X,2,sd);sc[!is.finite(sc)|sc==0]<-1;cen[1]<-0;sc[1]<-1
   scaleX<-function(q)sweep(sweep(cbind(Intercept=1,as.matrix(q[cand])),2,cen,'-'),2,sc,'/')
   X<-scaleX(initial);obs<-!is.na(d[[t]]);q<-qr(X[obs,,drop=FALSE],tol=1e-9);keep<-sort(q$pivot[seq_len(q$rank)]);stopifnot(1%in%keep)
   map<-qr.coef(qr(X[obs,keep,drop=FALSE],tol=1e-10),X[obs,,drop=FALSE])
   cases<-list(initial,update_g(initial,rep(0,nrow(d))),update_g(initial,rep(1,nrow(d))))
   # ADL预测值也会变；G条件的冗余列必须在合法ADL端点仍可重建。
   for(ad in c(0,6)){qq<-initial;qq$adl<-ad;qq$z_adl<-qq$z0*ad;cases[[length(cases)+1L]]<-qq}
   err<-max(vapply(cases,function(q){xx<-scaleX(q);max(abs(xx[,keep,drop=FALSE]%*%map-xx))},0));stopifnot(is.finite(err),err<1e-8)
   retained<-colnames(X)[setdiff(keep,1)];pm[t,retained]<-1;pm[t,'cluster']<--2
   ranks[[t]]<-list(candidate_columns=ncol(X),rank=q$rank,retained=retained,exact_redundant=setdiff(cand,retained),all_prediction_reconstruction_error=err)
  }
  essential<-all(pm['g',c('z0','z2','z_adl')]==1)&&all(pm['adl',c('g','z0','zg')]==1);stopifnot(essential)
  visit<-c('g',gproducts,'adl','z_adl');blots<-make.blots(d);blots$adl<-alist(donors=5)
  b<-list(data=d,analysis=a$analysis,method=method,predictors=pm,visit=visit,initial=initial,blots=blots,source=src,source_sha256=h,original_names=original_names,aux=aux,gproducts=gproducts,proxy_names=proxynames)
  saveRDS(b,target);stopifnot(digest(file=src,algo='sha256')==h)
  rec<-list(scope=z,status='INPUTS_ONLY_NOT_IMPUTED',N=nrow(d),income_missing=sum(is.na(d$g)),ADL_missing=sum(is.na(d$adl)),communities=length(unique(d$cluster)),source=src,source_sha256=h,input_sha256=digest(file=target,algo='sha256'),ranks=ranks,missing_slope_proxy_X=sum(x$missing),missing_slope_proxy_Y=sum(y$missing),exact_SMC_claim=FALSE)
  write_json(rec,file.path(root,'audit/INPUT_DESIGN.json'),pretty=TRUE,auto_unbox=TRUE,digits=16);records[[z]]<-rec
  cat('H42_INCOME_INPUT',z,'N',nrow(d),'G rank',ranks$g$rank,'ADL rank',ranks$adl$rank,'\n');flush.console()
 }
 write_json(records,file.path(BATCH,'audit/INCOME_INPUT_DESIGNS.json'),pretty=TRUE,auto_unbox=TRUE,digits=16)
 cat('H42_INCOME_INPUT_NATIVE_TERMINAL; zero imputations; zero Mplus\n')
}
