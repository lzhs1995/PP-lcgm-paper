"""只看本次指定worker身份；达到事先墙钟上限才停止，不触及其他会话。"""
import argparse,datetime,json,time,os
from pathlib import Path
import psutil
p=argparse.ArgumentParser();p.add_argument('--pid',type=int,required=True);p.add_argument('--created',type=float,required=True);p.add_argument('--seconds',type=int,required=True);p.add_argument('--receipt',type=Path,required=True);p.add_argument('--stop',type=Path,required=True);p.add_argument('--fit-dir',type=Path);p.add_argument('--fit-seconds',type=int,default=120);a=p.parse_args()
assert 0<a.seconds<=28800
start=time.monotonic()
def live():
 try:return psutil.Process(a.pid).is_running() and abs(psutil.Process(a.pid).create_time()-a.created)<.02
 except psutil.NoSuchProcess:return False
def save(state):
 d={'state':state,'owner_pid':a.pid,'owner_created':a.created,'watch_pid':os.getpid(),'elapsed_seconds':time.monotonic()-start,'limit_seconds':a.seconds,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};tmp=a.receipt.with_suffix('.tmp');tmp.write_text(json.dumps(d,indent=2),encoding='utf-8');os.replace(tmp,a.receipt)
def fit_expired():
 if not a.fit_dir:return False
 begin=a.fit_dir/'FIT_BEGIN.jsonl';end=a.fit_dir/'FIT_LOG.jsonl'
 if not begin.exists():return False
 try:
  b=json.loads(begin.read_text(encoding='utf-8').strip().splitlines()[-1]);finished=[json.loads(x)['fit_n'] for x in end.read_text(encoding='utf-8').splitlines() if x.strip()] if end.exists() else []
  if b['fit_n'] in finished:return False
  when=datetime.datetime.strptime(b['utc'],'%Y-%m-%d %H:%M:%S UTC').replace(tzinfo=datetime.timezone.utc)
  return (datetime.datetime.now(datetime.timezone.utc)-when).total_seconds()>a.fit_seconds
 except (ValueError,KeyError):return False
assert live();save('WATCHING')
while live() and not a.stop.exists() and time.monotonic()-start<a.seconds and not fit_expired():time.sleep(5);save('WATCHING')
if live() and not a.stop.exists():
 save('TIME_LIMIT_REACHED');owner=psutil.Process(a.pid);children=owner.children(recursive=True)
 for c in children:
  try:c.terminate()
  except psutil.NoSuchProcess:pass
 if live():owner.terminate()
 save('OWNED_WORKER_STOPPED_AT_LIMIT')
else:save('RELEASED')
