# 单链自动接续剩余两个独立收入范围；等待现有gender任务结束，不重复它。
BATCH<-'<LOCAL_USER_HOME>/pp_lgcm_review/charls_h42_mi_20261017'
run_remaining_income<-function(){
 library(ps);library(jsonlite);library(processx)
 root<-file.path(BATCH,'runtime');path<-file.path(root,'INCOME_REMAINING_PIPELINE.json');stopifnot(!file.exists(path))
 status<-function(stage,message){write_json(list(stage=stage,message=message,pid=Sys.getpid(),created=as.numeric(ps_create_time(ps_handle())),utc=format(Sys.time(),tz='UTC',usetz=TRUE)),path,auto_unbox=TRUE,pretty=TRUE);if(exists('clauder_progress',mode='function'))try(clauder_progress(stage,message),silent=TRUE);cat(stage,message,'\n');flush.console()}
 same_gender<-function(){tryCatch({h<-ps_handle(16672);abs(as.numeric(ps_create_time(h))-1792222451.3053129)<.02&&ps_is_running(h)},error=function(e)FALSE)}
 begun<-Sys.time();status('WAITING_EXISTING_GENDER','Keep real job94bfbb50; no duplicate40-chain submission')
 while(same_gender()){
  if(as.numeric(difftime(Sys.time(),begun,units='secs'))>15000)stop('Preceding gender worker exceeded its bounded contract; inspect without resubmitting')
  Sys.sleep(45);status('WAITING_EXISTING_GENDER','Existing worker still alive; queued oldest and son only')
 }
 source(file.path(BATCH,'code/run_income_mi.R'),local=TRUE)
 for(z in c('oldest','son')){
  ad<-file.path(BATCH,'mi_income',z,'audit/ADMISSION.json');if(file.exists(ad)){status('REUSE_INCOME_ADJUDICATION',z);next}
  startwait<-Sys.time()
  repeat{
   q<-processx::run('<LOCAL_USER_HOME>/AppData/Local/Programs/Python/Python314/python.exe',c('-c','import ctypes,json,psutil; class_dummy=None; print(json.dumps(dict(available=psutil.virtual_memory().available/2**30,cpu=psutil.cpu_percent(interval=1))))'),error_on_status=TRUE,timeout=15000)
   m<-fromJSON(q$stdout);if(m$available>=1.5&&m$cpu<85)break
   if(as.numeric(difftime(Sys.time(),startwait,units='secs'))>3600)stop('Resource wait limit; no imputation failure inferred')
   status('INCOME_RESOURCE_WAIT',paste(z,'availableGiB',round(m$available,2)));Sys.sleep(30)
  }
  status('H42_INCOME_FORMAL_START',z);run_income_mi(z);gc(full=TRUE);status('H42_INCOME_FORMAL_SCOPE_TERMINAL',z)
 }
 status('H42_INCOME_REMAINING_TERMINAL','Inspect each admission; no Mplus models submitted by this worker');cat('H42_INCOME_REMAINING_NATIVE_TERMINAL\n')
}
