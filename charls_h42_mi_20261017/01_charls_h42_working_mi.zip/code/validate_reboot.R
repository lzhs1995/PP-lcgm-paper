# 原生新会话重载检查点与已有解；不调用Mplus、不改源数据或旧结果。
source('<LOCAL_USER_HOME>/pp_lgcm_review/charls_h42_mi_20261017/code/models.R',local=TRUE)
test<-file.path(ROOT,'runtime/ATOMIC_PUBLICATION_TEST.json');wj(list(value=1),test);wj(list(value=2),test);stopifnot(rj(test)$value==2)
checkpoints<-list()
for(z in unlist(contract$indicators)){
 p<-file.path(ROOT,'mi',z,'private/MIDS.rds');imp<-readRDS(p);a<-readRDS(file.path(ROOT,'mi',z,'private/INPUTS.rds'))
 stopifnot(imp$m==20L,imp$iteration==1L,identical(imp$data,a$data),nrow(imp$imp$adl)==sum(is.na(a$data$adl)),all(is.finite(as.matrix(imp$imp$adl))))
 checkpoints[[z]]<-list(m=imp$m,iteration=imp$iteration,N=nrow(imp$data),missing_ADL=nrow(imp$imp$adl),sha256=hashf(p));rm(imp,a);gc()
}
checks<-list();paths<-list.files(file.path(ROOT,'models'),pattern='^receipt.json$',recursive=TRUE,full.names=TRUE)
for(p in paths){
 old<-rj(p);if(!identical(old$status,'USABLE_SINGLE_DATASET'))next
 d<-dirname(p);j<-rj(file.path(d,'job.json'));stopifnot(hashf(file.path(d,'model.out'))==old$output_sha256)
 for(n in names(j$hashes))stopifnot(hashf(file.path(d,n))==j$hashes[[n]])
 m<-read_mplus_raw(d);si<-specification(parents[[j$family]],j$type);g<-gate_r2e(m,si,unlist(j$zpoints))
 stopifnot(isTRUE(g$passed),m$P==j$expected_free,number_observations(m$lines)==j$N)
 checks[[j$id]]<-list(passed=TRUE,parameters=m$P,N=j$N,output_sha256=old$output_sha256)
 if(length(checks)%%8==0)progress('REBOOT_CHECKPOINT_VALIDATION',paste(length(checks),'existing legal models reused; zero new estimates'))
}
stopifnot(length(checks)==37)
wj(list(status='PASS',RStudio_parent_pid=Sys.getenv('CALLR_PARENT_PID'),checkpoints=checkpoints,models=checks,atomic_replacement_test=TRUE,models_reused=length(checks),new_estimates=0,utc=format(Sys.time(),tz='UTC',usetz=TRUE)),file.path(ROOT,'audit/REBOOT_R_VALIDATION.json'))
progress('REBOOT_VALIDATION_TERMINAL','Four MIDS and37 legal models reloaded; no estimate rerun');cat('H42_REBOOT_VALIDATION_NATIVE_TERMINAL\n')
