# 收入与教育/城乡均已独立验收后，按原固定12项范围统一多重检验。
local({
 ROOT<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_h42_income_models_20261018'
 H<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_h42_models_20261018'
 library(jsonlite)
 stopifnot(fromJSON(file.path(H,'audit/POOL_INDEPENDENT_EDU_URBAN.json'))$status=='PASS',fromJSON(file.path(ROOT,'audit/POOL_INDEPENDENT_INC.json'))$status=='PASS')
 a<-read.csv(file.path(H,'results/pool_EDU_URBAN/H42_REGISTERED.csv'))
 b<-read.csv(file.path(ROOT,'results/pool_INC/H42_REGISTERED.csv'))
 stopifnot(nrow(a)==8,nrow(b)==4,identical(names(a),names(b)))
 x<-rbind(a,b);expected<-as.vector(outer(c('sd','gender','oldest','son'),c('EDU','URBAN','INC'),paste,sep='_'))
 stopifnot(!anyDuplicated(x$family),setequal(x$family,expected))
 x<-x[match(expected,x$family),];ok<-which(is.finite(x$p))
 x$Holm_12<-x$Bonferroni_12<-NA_real_
 x$Holm_12[ok]<-p.adjust(x$p[ok],'holm',n=12);x$Bonferroni_12[ok]<-p.adjust(x$p[ok],'bonferroni',n=12)
 out<-file.path(ROOT,'results/TWELVE_H42_RESOURCES.csv');stopifnot(!file.exists(out))
 write.csv(x,out,row.names=FALSE)
 write_json(list(status='TWELVE_REGISTERED_SCOPES_COMBINED',registered=12,estimated=length(ok),original_four_complete=FALSE,full_H4_complete=FALSE,new_Mplus_calls=0),file.path(ROOT,'audit/TWELVE_RESOURCES.json'),auto_unbox=TRUE,pretty=TRUE)
 cat('TWELVE_H42_RESOURCES_COMBINED',length(ok),'estimated families\n')
})
