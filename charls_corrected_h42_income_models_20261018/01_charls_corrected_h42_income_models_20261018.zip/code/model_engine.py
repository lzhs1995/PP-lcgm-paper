"""单槽Windows监督器：清醒墙钟预算、原始墙钟另存；不接管外部作业。"""
from pathlib import Path
import ctypes, datetime, hashlib, json, os, sqlite3, subprocess, sys, time, traceback
import psutil
from active_clock import BudgetClock

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,obj,critical=True):
    p=Path(p);t=p.with_name(p.name+f'.{os.getpid()}.tmp')
    t.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    for attempt in range(16):
        try: os.replace(t,p);return True
        except PermissionError:
            if attempt<15: time.sleep(min(.05*2**attempt,.4));continue
            if critical: raise PermissionError('Atomic publication remained locked: '+str(p))
            # Heartbeat visibility failure must not terminate a healthy owned model.
            with p.with_name('heartbeat_publish_errors.jsonl').open('a',encoding='utf-8') as log:
                log.write(json.dumps({'utc':utc(),'target':str(p),'temporary':str(t),'status':'DEFERRED_HEARTBEAT'})+'\n')
            return False
class Memory(ctypes.Structure):
    _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(k,ctypes.c_ulonglong) for k in ['total','avail','commit_limit','commit_avail','virtual','virtual_avail','extended']]
def profile():
    m=Memory();m.length=ctypes.sizeof(m)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)): raise OSError('Windows memory unavailable')
    others=[]
    for p in psutil.process_iter(['pid','name']):
        if (p.info['name'] or '').lower()=='mplus.exe': others.append(p.info['pid'])
    return {'utc':utc(),'available_gib':m.avail/2**30,'commit_available_gib':m.commit_avail/2**30,'cpu_percent':psutil.cpu_percent(interval=.5),'other_mplus_pids':others}

def budget_adjustment(root,rows):
    # 只接受已冻结、可回读的单次待机中断；原始预算台账和失败输出不改写。
    amendment=root/'contracts/HOST_PAUSE_RECOVERY.json'
    if not amendment.exists():return 0.,0
    a=json.loads(amendment.read_text(encoding='utf-8'))
    assert sha(root/'contracts/RUN_CONTRACT.json')==a['original_contract_sha256']
    old=root/'models'/a['credit_call']/'engine_receipt.json'
    assert sha(old)==a['original_receipt_sha256']
    er=json.loads(old.read_text());assert er['status']=='TIMEOUT' and not (old.parent/'model.out').exists()
    matching=[r for r in rows if r[0]==a['credit_call']]
    assert len(matching)==1 and abs(matching[0][3]-a['old_wall_seconds'])<1e-6
    credit=a['budget_credit_seconds'];assert 0<=credit<=sum(x['overlap_seconds'] for x in a['power_events'])
    assert abs(a['old_wall_seconds']-credit-120)<1e-6 and a['additional_engine_calls']==1
    return credit,1

def main():
    job=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'));root=Path(job['root']);dest=Path(job['dest'])
    contract=json.loads((root/'contracts/RUN_CONTRACT.json').read_text(encoding='utf-8'))
    for f,h in job['hashes'].items():
        if sha(dest/f)!=h: raise ValueError('Changed input '+f)
    if (dest/'engine_receipt.json').exists(): print('EXISTING_RECEIPT');return
    if (dest/'model.out').exists(): raise RuntimeError('Unreconciled output; refusing rerun')
    lock=root/'runtime/engine.lock'
    try: fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError: raise RuntimeError('Existing ownership lock; inspect before recovery')
    os.write(fd,json.dumps({'pid':os.getpid(),'created':psutil.Process().create_time(),'job':job['id']}).encode());os.close(fd)
    db=None
    try:
        db=sqlite3.connect(root/'runtime/budget.sqlite',timeout=20)
        db.execute('CREATE TABLE IF NOT EXISTS calls(id TEXT PRIMARY KEY,category TEXT,state TEXT,seconds REAL,dest TEXT)');db.commit()
        rows=db.execute('SELECT id,category,state,seconds FROM calls').fetchall()
        if any(r[3] is None for r in rows): raise RuntimeError('Unreconciled reservation; no resubmission')
        credit,extra_calls=budget_adjustment(root,rows)
        if len(rows)>=contract['max_mplus_calls']+extra_calls:
            write(dest/'not_run.json',{'status':'CALL_LIMIT_EXHAUSTED','utc':utc()});return
        used=sum(r[3] for r in rows)-credit;cu=sum(r[3] for r in rows if r[1]==job['category'])-credit
        limit=min(job['cap_seconds'],contract['total_engine_seconds']-used,contract['total_engine_seconds']-cu)
        if limit<5: write(dest/'not_run.json',{'status':'BUDGET_EXHAUSTED','utc':utc()});return
        wait_clock=BudgetClock()
        while True:
            pf=profile();write(dest/'resource_before.json',pf)
            policy=contract['resource_admission']
            # 外部Mplus数量仅作记录；合同按真实余量准入，本批仍由独占锁限制为单槽。
            if pf['available_gib']>=policy['minimum_available_gib'] and pf['commit_available_gib']>=policy['minimum_commit_available_gib'] and pf['cpu_percent']<policy['max_cpu_percent']: break
            write(root/'runtime/progress.json',{'stage':'RESOURCE_WAIT','model':job['id'],'message':pf,'updated_at':utc()})
            if wait_clock.expired(120):
                write(dest/'not_run.json',{'status':'RESOURCE_HOLD','resource':pf,'utc':utc()});return
            time.sleep(10)
        db.execute('INSERT INTO calls VALUES(?,?,?,?,?)',(job['id'],job['category'],'CLAIMED',None,str(dest)));db.commit()
        clock=BudgetClock();started=utc();status='START_FAILED';code=None;peak=0;cpu=0;process=None;born=None
        awake=bool(ctypes.windll.kernel32.SetThreadExecutionState(0x80000001))
        try:
            with (dest/'mplus_execution.log').open('wb') as log:
                process=subprocess.Popen([job['rscript'],'--vanilla',str(root/'code/run_one.R'),str(dest/'model.inp'),job['mplus']],cwd=dest,stdout=log,stderr=subprocess.STDOUT)
                parent=psutil.Process(process.pid);born=parent.create_time()
                write(dest/'process.json',{'pid':process.pid,'created':born,'input_sha256':job['hashes']['model.inp'],'started_at':started})
                with (dest/'resources.jsonl').open('a',encoding='utf-8') as samples:
                    while process.poll() is None:
                        timing=clock.sample();elapsed=timing['active_seconds']
                        children=[]
                        try:
                            tree=[parent]+parent.children(recursive=True)
                            for p in tree:
                                try:
                                    mi=p.memory_info();ct=p.cpu_times();children.append({'pid':p.pid,'created':p.create_time(),'name':p.name(),'rss':mi.rss,'private':getattr(mi,'private',None),'cpu':ct.user+ct.system,'threads':p.num_threads(),'affinity':p.cpu_affinity()})
                                except psutil.Error: pass
                            peak=max(peak,sum(p['rss'] for p in children));cpu=max(cpu,sum(p['cpu'] for p in children))
                        except psutil.Error: pass
                        hb={'stage':'ESTIMATING','model':job['id'],'elapsed_seconds':elapsed,'clocks':timing,'limit_seconds':limit,'updated_at':utc(),'processes':children}
                        samples.write(json.dumps(hb)+'\n');samples.flush();write(root/'runtime/progress.json',hb,critical=False)
                        if elapsed>=limit:
                            if parent.is_running() and abs(parent.create_time()-born)<.001:
                                for child in parent.children(recursive=True):
                                    try: child.kill()
                                    except psutil.NoSuchProcess: pass
                                parent.kill()
                            process.wait(timeout=20);status='TIMEOUT';code=124;break
                        time.sleep(2)
                    if status!='TIMEOUT': code=process.returncode;status='EXITED' if code==0 else 'RUNNER_FAILED'
        except Exception as exc:
            status='SUPERVISOR_ERROR';write(dest/'supervisor_error.json',{'error':repr(exc),'traceback':traceback.format_exc(),'utc':utc()})
            if process is not None and process.poll() is None:
                parent=psutil.Process(process.pid)
                if abs(parent.create_time()-born)<.001:
                    for child in parent.children(recursive=True):
                        try: child.kill()
                        except psutil.NoSuchProcess: pass
                    parent.kill();process.wait(timeout=20)
        finally:
            if awake: ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
            timing=clock.sample();seconds=timing['active_seconds']
            er={'id':job['id'],'status':status,'exitcode':code,'seconds':seconds,'wall_seconds':timing['wall_seconds'],'clocks':timing,'started_at':started,'finished_at':utc(),'peak_tree_rss':peak,'sampled_tree_cpu_seconds':cpu,'accounting':'Rscript plus Mplus awake wall including launch and IO; raw wall retained; verified host sleep excluded','runner':'MplusAutomation::runModels','hashes':job['hashes']}
            if (dest/'model.out').exists(): er['output_sha256']=sha(dest/'model.out')
            write(dest/'engine_receipt.json',er)
            db.execute('UPDATE calls SET state=?,seconds=? WHERE id=?',(status,seconds,job['id']));db.commit()
            rr=db.execute('SELECT id,category,state,seconds FROM calls').fetchall()
            gross_wall=sum(json.loads((Path(x[0])/'engine_receipt.json').read_text()).get('wall_seconds',json.loads((Path(x[0])/'engine_receipt.json').read_text())['seconds']) for x in db.execute('SELECT dest FROM calls').fetchall())
            write(root/'runtime/budget_status.json',{'engine_seconds':sum(x[3] for x in rr)-credit,'gross_wall_seconds':gross_wall,'ledger_seconds_before_historical_credit':sum(x[3] for x in rr),'historical_sleep_credit_seconds':credit,'maximum_calls_including_one_host_recovery':contract['max_mplus_calls']+extra_calls,'rows':[dict(zip(['id','category','state','seconds'],x)) for x in rr],'updated_at':utc()})
            print(json.dumps(er))
    finally:
        if db is not None: db.close()
        lock.unlink()

if __name__=='__main__': main()
