# 核对当前原40链来源；旧H4.1只给起点，不将其旧插补冒充本次来源。
admit_income_scope<-function(z){
 src<-file.path(contract$source_MI,'mi',z);ap<-file.path(src,'audit/MI_ADMISSION.json')
 if(!file.exists(ap)){
  failed<-FALSE
  last<-file.path(src,'audit/COMBINED_ITER20.json')
  if(file.exists(last))failed<-identical(rj(last)$status,'MIXING_NOT_ACCEPTED_NO_EXTENSION')
  for(lane in c('a','b')){
   p<-file.path(contract$source_MI,'runtime',paste0('FORMAL_',lane,'_SCOPES.json'))
   if(file.exists(p)){v<-rj(p)[[z]];if(is.list(v)&&identical(v$passed,FALSE)&&!identical(v$error,'SCHEDULER_HANDOFF_AT_COMPLETED_BLOCK'))failed<-TRUE}
   # 计划交接是在新块入口前让出资源；真实接续失败另记，不能混成成功。
   for(it in c(10L,20L)){
    cp<-file.path(contract$source_MI,'continuation',paste(z,lane,it,sep='_'),'TERMINAL.json')
    if(file.exists(cp)&&identical(rj(cp)$passed,FALSE))failed<-TRUE
   }
  }
  return(list(status=if(failed)'SOURCE_MI_FAILED'else'WAITING_MI',passed=FALSE))
 }
 a<-rj(ap);stopifnot(a$status=='ADMITTED_WORKING_MI',a$m==40,isTRUE(a$mixing_pass),isTRUE(a$member_checks),isTRUE(a$original_block_members_identical))
 stopifnot(hashf(file.path(contract$source_MI,'contracts/RUN_CONTRACT.json'))==contract$source_imputation_contract_sha256)
 source_path<-file.path(contract$source_MI,'private',paste0(z,'_INPUTS.rds'))
 input<-readRDS(source_path);columns<-unique(c(names(input$analysis),'g'));parent<-parents[[paste0(z,'_INC')]]
 stopifnot(identical(columns,unlist(parent$columns)),nrow(input$analysis)==a$N,a$N==parent$N,a$communities==parent$communities)
 members<-read.csv(file.path(src,'audit/MI_MEMBERS.csv'))
 checks<-read.csv(file.path(src,'audit',paste0('MI_CHECKS_ITER',a$iterations,'.csv')))
 stopifnot(nrow(members)==40,identical(as.integer(members$member),1:40),all(members$N==a$N),all(members$columns==length(columns)))
 stopifnot(nrow(checks)==40,identical(as.integer(checks$member),1:40),all(as.matrix(checks[,c('observed_preserved','passive','XY_controls_preserved','support','complete')])))
 for(k in 1:40){p<-file.path(src,'private',sprintf('MI%02d.dat',k));stopifnot(hashf(p)==members$sha256[k])}
 for(b in c('a','b')){
  cp<-file.path(src,b,'checkpoints',sprintf('ITER%02d.rds',a$iterations));meta<-rj(paste0(cp,'.json'))
  stopifnot(meta$m==20,meta$iteration==a$iterations,meta$source_sha256==hashf(source_path),meta$sha256==hashf(cp))
 }
 result<-list(status='ADMITTED_WORKING_MI',passed=TRUE,m=40,N=a$N,communities=a$communities,
  columns=columns,data_root=file.path(src,'private'),admission_sha256=hashf(ap),source_input_sha256=hashf(source_path),
  mids_sha256=a$mids_sha256,source_members_sha256=hashf(file.path(src,'audit/MI_MEMBERS.csv')),
  compatibility=contract$compatibility,original_four_complete=FALSE,full_H4_complete=FALSE)
 all<-rj(file.path(ROOT,'audit/MI_ADMISSIONS.json'));all[[z]]<-result;wj(all,file.path(ROOT,'audit/MI_ADMISSIONS.json'))
 result
}
