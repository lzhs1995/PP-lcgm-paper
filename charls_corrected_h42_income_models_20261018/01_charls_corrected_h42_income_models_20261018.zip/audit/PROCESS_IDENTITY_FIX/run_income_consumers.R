# 只执行已准入范围；等待其余原插补时释放协调R，预算跨段保留。
local({
 ROOT<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_h42_income_models_20261018'
 stopifnot(exists('SEGMENT_ID'),length(SEGMENT_ID)==1L,is.finite(SEGMENT_ID),SEGMENT_ID>=1L,SEGMENT_ID==as.integer(SEGMENT_ID))
 Sys.setenv(OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1,MKL_NUM_THREADS=1)
 library(jsonlite);library(ps);library(processx)
 source(file.path(ROOT,'code/models.R'),local=TRUE);source(file.path(ROOT,'code/source_admission.R'),local=TRUE)
 stopifnot(file.exists(file.path(contract$dependency_models,'runtime/MODELS_TERMINAL')),!file.exists(file.path(contract$dependency_models,'runtime/engine.lock')))
 other<-rj(file.path(contract$dependency_models,'runtime/OWNER.json'))$owner
 alive<-function(x)tryCatch(ps_is_running(ps_handle(x$pid,x$created)),error=function(e)FALSE)
 stopifnot(!alive(other),!file.exists(file.path(ROOT,'runtime/engine.lock')))
 states<-rj(file.path(ROOT,'results/FAMILY_STATUS.json'));pending<-names(states)[vapply(states,function(s)s$status%in%c('WAITING_MI','REGISTERED_NOT_STARTED','RESOURCE_DEFERRED'),TRUE)]
 stopifnot(length(pending)>0,any(vapply(pending,function(f)file.exists(file.path(contract$source_MI,'mi',states[[f]]$z,'audit/MI_ADMISSION.json')),TRUE)))
 host<-rj(file.path(ROOT,'audit/HOST_ADMISSION.json'));stamp<-as.POSIXct(substr(host$utc,1,19),format='%Y-%m-%dT%H:%M:%S',tz='UTC')
 age<-as.numeric(difftime(Sys.time(),stamp,units='secs'));stopifnot(host$admitted,host$available_GiB>=1.4,is.finite(age),age>=0,age<120)
 ps_set_cpu_affinity(ps_handle(),unlist(host$selected_cores))
 seg<-file.path(ROOT,'runtime/segments',sprintf('%03d',SEGMENT_ID));stopifnot(!dir.exists(seg));dir.create(seg,recursive=TRUE)
 op<-file.path(ROOT,'runtime/OWNER.json')
 if(file.exists(op)){old<-rj(op);stopifnot(!alive(old$owner));stopifnot(file.rename(op,file.path(seg,'PREVIOUS_OWNER.json')))}
 wj(list(owner=list(pid=Sys.getpid(),created=as.numeric(ps_create_time(ps_handle()))),segment=SEGMENT_ID),op)
 startfile<-file.path(ROOT,'runtime/FIRST_SEGMENT_START.json')
 if(!file.exists(startfile))wj(list(utc=format(Sys.time(),tz='UTC',format='%Y-%m-%dT%H:%M:%S')),startfile)
 begun<-as.POSIXct(rj(startfile)$utc,format='%Y-%m-%dT%H:%M:%S',tz='UTC')
 aw<-file.path(seg,'awake');a<-process$new(PY,c('-X','utf8',file.path(ROOT,'code/windows_awake_guard.py'),'--owner-file',op,'--output',aw,'--interval','5'),stdout=file.path(seg,'awake.log'),stderr='2>&1',cleanup=FALSE)
 on.exit({if(dir.exists(aw))writeLines('release',file.path(aw,'stop.request'));a$wait(8000L)},add=TRUE)
 calls<-rj(file.path(ROOT,'results/CALL_RESULTS.json'));if(is.null(calls))calls<-list()
 for(f in pending){
  st<-states[[f]]
  if(as.numeric(difftime(Sys.time(),begun,units='secs'))>contract$wall_seconds-contract$per_call_seconds){st$status<-'BATCH_WALL_LIMIT';states[[f]]<-st;wj(states,file.path(ROOT,'results/FAMILY_STATUS.json'));next}
  ad<-admit_income_scope(st$z)
  if(!isTRUE(ad$passed)){st$status<-ad$status;states[[f]]<-st;wj(states,file.path(ROOT,'results/FAMILY_STATUS.json'));next}
  seqs<-c(list(list(type='E0',k=1L,start='A'),list(type='E1',k=1L,start='A'),list(type='E1',k=1L,start='B')),lapply(2:st$m,function(k)list(type='E1',k=k,start='A')))
  for(q in seqs){
   if(as.numeric(difftime(Sys.time(),begun,units='secs'))>contract$wall_seconds-contract$per_call_seconds){st$status<-'BATCH_WALL_LIMIT';break}
   j<-prepare(f,q$type,q$k,q$start);r<-run(j);calls[[j$id]]<-r;wj(calls,file.path(ROOT,'results/CALL_RESULTS.json'))
   if(r$status=='NOT_RUN_RESOURCE_OR_BUDGET'){st$status<-if(identical(r$detail$status,'RESOURCE_HOLD'))'RESOURCE_DEFERRED'else'BUDGET_NOT_RUN';break}
   if(r$status!='USABLE_SINGLE_DATASET'){st$status<-paste('MEMBER_FAILED',j$id,r$status,sep=':');break}
   if(q$type=='E1'&&q$start=='A')st$members<-q$k
   if(q$type=='E1'&&q$start=='B'&&!isTRUE(compare_starts(f)$passed)){st$status<-'STARTS_DISAGREE';break}
   st$status<-if(st$members==st$m)'FULL_FAMILY_PENDING_POOLING'else'RUNNING'
   states[[f]]<-st;wj(states,file.path(ROOT,'results/FAMILY_STATUS.json'))
  }
  states[[f]]<-st;wj(states,file.path(ROOT,'results/FAMILY_STATUS.json'))
  clauder_progress('income_H42_family_terminal',paste(f,st$status,st$members))
 }
 waiting<-names(states)[vapply(states,function(s)s$status%in%c('WAITING_MI','REGISTERED_NOT_STARTED','RESOURCE_DEFERRED'),TRUE)]
 if(!length(waiting)){
  source(file.path(ROOT,'code/pool_h42.R'),local=TRUE);pool_h42('INC')
  writeLines('All income source/model families adjudicated',file.path(ROOT,'runtime/MODELS_TERMINAL'))
 }
 status<-if(length(waiting))'SEGMENT_COMPLETE_WAITING_ORIGINAL_MI'else'ALL_INCOME_FAMILIES_ADJUDICATED'
 wj(list(status=status,segment=SEGMENT_ID,waiting=waiting,calls=length(calls),full_H4_complete=FALSE),file.path(seg,'TERMINAL.json'))
 clauder_progress('income_H42_segment_terminal',paste(status,paste(waiting,collapse=', ')))
 cat('CORRECTED_INCOME_H42_SEGMENT_NATIVE_TERMINAL\n')
})
