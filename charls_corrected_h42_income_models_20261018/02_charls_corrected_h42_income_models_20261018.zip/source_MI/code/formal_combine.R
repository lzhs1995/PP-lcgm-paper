# 只有两个独立链块及逐人不变性验证均通过，才生成正式40份分析入口。
local({
BATCH<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_h42_income_20261018';R<-file.path(BATCH,'mi',MI_SCOPE);for(d in c('audit','results','private'))dir.create(file.path(R,d),recursive=TRUE,showWarnings=FALSE);stopifnot(exists('MI_STOP_ITER'),MI_STOP_ITER%in%c(10L,20L))
.libPaths(c('<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_income_mi_pilot_20261016/library','<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))
library(mice);library(jsonlite);library(digest)
# 两块的真实终态、源哈希、完整成员逐项核验；顺序执行不伪造fanout证据。
a<-readRDS(file.path(BATCH,'private',paste0(MI_SCOPE,'_INPUTS.rds')));h0<-digest(file=file.path(BATCH,'private',paste0(MI_SCOPE,'_INPUTS.rds')),algo='sha256')
source(file.path(BATCH,'code/scale_design.R'),local=TRUE);a$passive<-passive_map(a);roots<-setNames(file.path(R,c('a','b')),c('a','b'))
blocks<-lapply(c('a','b'),function(z){p<-file.path(roots[[z]],'checkpoints',sprintf('ITER%02d.rds',MI_STOP_ITER));meta<-fromJSON(paste0(p,'.json'));rec<-fromJSON(file.path(roots[[z]],'audit',paste0('ITER',MI_STOP_ITER,'_TERMINAL.json')));stopifnot(rec$passed,meta$source_sha256==h0,digest(file=p,algo='sha256')==meta$sha256);readRDS(p)})
stopifnot(identical(blocks[[1]]$data,blocks[[2]]$data),identical(blocks[[1]]$predictorMatrix,blocks[[2]]$predictorMatrix),blocks[[1]]$iteration==MI_STOP_ITER,blocks[[2]]$iteration==MI_STOP_ITER)
imp<-ibind(blocks[[1]],blocks[[2]]);stopifnot(imp$m==40,identical(imp$data,a$data))
# mice3.19.10的ibind以[[name]]<-NULL删除完全观测列，占位丢失后complete按位置索引越界。
# 仅恢复完整命名容器：所有随机插补值和chainMean/chainVar不变；逐成员再与原块比对。
old_length<-length(imp$imp);aligned<-setNames(vector('list',ncol(imp$data)),names(imp$data))
for(n in names(aligned))aligned[n]<-list(cbind(blocks[[1]]$imp[[n]],blocks[[2]]$imp[[n]]))
for(n in names(imp$imp))stopifnot(identical(aligned[[n]],imp$imp[[n]]))
imp$imp<-aligned;stopifnot(identical(names(imp$imp),names(imp$data)),length(imp$imp)==ncol(imp$data))
write_json(list(status='CONTAINER_ALIGNED_DRAW_VALUES_UNCHANGED',mice_version=as.character(packageVersion('mice')),old_list_length=old_length,new_list_length=length(imp$imp),observed_columns_NULL_slots_preserved=TRUE,changed_imputation_values=FALSE,new_fits=0),file.path(R,'audit/MIDS_CONTAINER_REPAIR.json'),auto_unbox=TRUE,pretty=TRUE)
cv<-convergence(imp);write.csv(cv,file.path(R,'audit',paste0('CONVERGENCE_ITER',MI_STOP_ITER,'.csv')),row.names=FALSE)
tailcv<-cv[cv$vrb%in%c('g','adl')&cv$.it>MI_STOP_ITER-5L,,drop=FALSE];mix<-nrow(tailcv)==10L&&all(is.finite(tailcv$psrf))&&all(tailcv$psrf<1.1)
mids_path<-file.path(R,'private',paste0('MIDS40_ITER',MI_STOP_ITER,'_RECONCILED.rds'))
if(file.exists(mids_path)){
 saved<-readRDS(mids_path);fields<-setdiff(names(imp),c('call','formulas'))
 stopifnot(all(vapply(fields,function(n)identical(saved[[n]],imp[[n]]),TRUE)),identical(lapply(saved$formulas,deparse),lapply(imp$formulas,deparse)))
 # 公式环境经RDS重读不是同一内存引用；保存的数据、随机值和模型语法必须完全相同。
 imp<-saved
}else saveRDS(imp,mids_path)
pdf(file.path(R,'results',paste0('MI_CHAINS_ITER',MI_STOP_ITER,'.pdf')),width=10,height=7);print(plot(imp,c('g','adl')));dev.off()
check<-list();values<-list();summ<-list();raw<-as.matrix(a$data);obs<-!is.na(raw)
for(k in 1:40){
 v<-complete(imp,k);vv<-as.matrix(v);b<-a$analysis;b$c7<-v$adl;b$g<-v$g
 original_block<-if(k<=20)1L else 2L;original_k<-if(k<=20)k else k-20L
 stopifnot(identical(v,complete(blocks[[original_block]],original_k)))
 unchanged<-identical(unname(raw[obs]),unname(vv[obs]));passive<-all(vapply(names(a$passive),function(n)max(abs(v[[n]]-Reduce(`*`,v[a$passive[[n]]])))<1e-12,TRUE))
 keep<-setdiff(names(a$analysis),c('c7','g'));xy<-identical(b[keep],a$analysis[keep]);support<-all(v$g%in%0:1)&&all(v$adl%in%0:6)&&all(v$adl[is.na(a$data$adl)]%in%a$data$adl[!is.na(a$data$adl)])
 check[[k]]<-data.frame(member=k,observed_preserved=unchanged,passive=passive,XY_controls_preserved=xy,support=support,complete=!anyNA(v),N=nrow(b),communities=length(unique(b$cluster)))
 values[[k]]<-b;summ[[k]]<-data.frame(member=k,imputed_G_mean=mean(v$g[is.na(a$data$g)]),imputed_ADL_mean=mean(v$adl[is.na(a$data$adl)]),high_income_n=sum(v$g==1))
}
check<-do.call(rbind,check);summ<-do.call(rbind,summ);write.csv(check,file.path(R,'audit',paste0('MI_CHECKS_ITER',MI_STOP_ITER,'.csv')),row.names=FALSE);write.csv(summ,file.path(R,'results',paste0('MI_SUMMARIES_ITER',MI_STOP_ITER,'.csv')),row.names=FALSE)
passed<-all(as.matrix(check[,2:6]));stopifnot(passed)
fitcounts<-vapply(c('a','b'),function(z){ff<-lapply(readLines(file.path(roots[[z]],'audit/FIT_LOG.jsonl')),fromJSON);stopifnot(length(ff)==40*MI_STOP_ITER,all(vapply(ff,function(x)isTRUE(x$valid),TRUE)));length(ff)},0)
status<-if(mix)'ADMITTED_WORKING_MI' else if(MI_STOP_ITER==10)'CONTINUE_SAME_CHAINS_TO20' else 'MIXING_NOT_ACCEPTED_NO_EXTENSION'
rec<-list(status=status,m=40,iterations=MI_STOP_ITER,mids_path=mids_path,mids_sha256=digest(file=mids_path,algo='sha256'),original_block_members_identical=TRUE,mixing_pass=mix,max_tail_PSRF=if(all(is.finite(tailcv$psrf)))max(tailcv$psrf) else NA,member_checks=passed,conditional_fits=sum(fitcounts),N=nrow(a$data),communities=length(unique(a$data$cluster)),missing_income_group=sum(is.na(a$data$g)),missing_ADL=sum(is.na(a$data$adl)),raw_monetary_income_not_imputed=TRUE,exact_latent_SMC=FALSE,original_four_complete=FALSE,full_H4_complete=FALSE)
if(mix){
 stopifnot(!file.exists(file.path(R,'audit/MI_MEMBERS.csv')));datchecks<-list()
 for(k in 1:40){p<-file.path(R,'private',sprintf('MI%02d.dat',k));if(!file.exists(p))write.table(values[[k]],p,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999');back<-as.matrix(read.table(p));back[back==-9999]<-NA_real_;ref<-as.matrix(values[[k]]);stopifnot(identical(dim(back),dim(ref)),identical(unname(is.na(back)),unname(is.na(ref))));delta<-max(abs(back-ref),na.rm=TRUE);stopifnot(delta<1e-10);datchecks[[k]]<-data.frame(member=k,path=p,sha256=digest(file=p,algo='sha256'),N=nrow(ref),columns=ncol(ref),max_difference=delta)}
 b<-a$analysis;b$g<-a$data$g;cc<-b[!is.na(a$data$g)&!is.na(a$data$adl),];stopifnot(!anyNA(cc[c(paste0('c',1:11),'g')]))
 ccpath<-file.path(R,'private/CC.dat');stopifnot(!file.exists(ccpath));write.table(cc,ccpath,row.names=FALSE,col.names=FALSE,quote=FALSE,na='-9999');ccmeta<-list(N=nrow(cc),sha256=digest(file=ccpath,algo='sha256'));write_json(ccmeta,file.path(R,'audit/CC_INPUT.json'),auto_unbox=TRUE,pretty=TRUE);rec$N_CC<-nrow(cc);rec$CC_sha256<-ccmeta$sha256
 saveRDS(values,file.path(R,'private/COMPLETED.rds'));write.csv(do.call(rbind,datchecks),file.path(R,'audit/MI_MEMBERS.csv'),row.names=FALSE)
 write_json(rec,file.path(R,'audit/MI_ADMISSION.json'),auto_unbox=TRUE,pretty=TRUE,digits=16,na='null')
}
write_json(rec,file.path(R,'audit',paste0('COMBINED_ITER',MI_STOP_ITER,'.json')),auto_unbox=TRUE,pretty=TRUE,digits=16,na='null');print(rec);cat('CHARLS_INCOME_COMBINED_CHECK_DONE\n')
})
