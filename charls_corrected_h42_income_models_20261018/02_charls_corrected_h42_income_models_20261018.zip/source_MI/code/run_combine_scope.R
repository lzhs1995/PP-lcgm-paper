# 两个原始20链块合并检查；不拟合、不替换成员、不修改仍运行的FCS。
local({
main<-function(){
 BATCH<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_h42_income_20261018'
 stopifnot(exists('MI_SCOPE'),MI_SCOPE%in%c('sd','gender','oldest','son'),exists('MI_STOP_ITER'),MI_STOP_ITER%in%c(10L,20L))
 library(jsonlite);library(ps);library(processx);library(digest)
 d<-file.path(BATCH,'postprocess',paste0(MI_SCOPE,'_iter',MI_STOP_ITER));host<-fromJSON(file.path(d,'ADMISSION.json'))
 stamp<-as.POSIXct(substr(host$utc,1,19),format='%Y-%m-%dT%H:%M:%S',tz='UTC')
 age<-as.numeric(difftime(Sys.time(),stamp,units='secs'));stopifnot(host$admitted,is.finite(age),age>=0,age<120)
 for(n in names(host$code_sha256))stopifnot(digest(file=file.path(BATCH,'code',n),algo='sha256')==host$code_sha256[[n]])
 stopifnot(!file.exists(file.path(d,'OWNER.json')),!file.exists(file.path(d,'TERMINAL.json')))
 Sys.setenv(OMP_NUM_THREADS=1,OPENBLAS_NUM_THREADS=1,MKL_NUM_THREADS=1)
 me<-ps_handle();ps_set_cpu_affinity(me,unlist(host$selected_cores))
 write_json(list(owner=list(pid=Sys.getpid(),created=as.numeric(ps_create_time(me)))),file.path(d,'OWNER.json'),auto_unbox=TRUE,digits=16)
 stopfile<-file.path(d,'STOP');on.exit(writeLines('postprocess exited',stopfile),add=TRUE)
 PY<-'<WINDOWS_USERPROFILE>/AppData/Local/Programs/Python/Python314/python.exe'
 # 空拟合目录让既有看门狗只约束本合并worker的清醒总时间。
 empty<-file.path(d,'no_fits');dir.create(empty,showWarnings=FALSE)
 watch<-process$new(PY,c(file.path(BATCH,'code/bounded_worker_watch.py'),'--pid',as.character(Sys.getpid()),'--created',sprintf('%.6f',as.numeric(ps_create_time(me))),'--seconds','600','--receipt',file.path(d,'WATCH.json'),'--stop',stopfile,'--fit-dir',empty),stdout=file.path(d,'WATCH.log'),stderr='2>&1',cleanup=FALSE)
 clauder_progress('COMBINE_ORIGINAL_CHAINS',paste(MI_SCOPE,'two original20-chain blocks; iteration',MI_STOP_ITER))
 result<-tryCatch({
  began<-Sys.time();last_message<--Inf
  repeat{
   elapsed<-as.numeric(difftime(Sys.time(),began,units='secs'))
   stopifnot(watch$is_alive())
   wp<-file.path(d,'WATCH.json');wr<-if(file.exists(wp))tryCatch(fromJSON(wp),error=function(e)NULL)else NULL
   if(!is.null(wr)&&as.integer(wr$owner_pid)==Sys.getpid()&&abs(wr$owner_created-as.numeric(ps_create_time(me)))<.01&&wr$state=='WATCHING')break
   if(elapsed>=60)stop('Owned combination watcher not ready; no combination executed')
   if(elapsed-last_message>=5){clauder_progress('COMBINE_WATCH_STARTUP',paste(MI_SCOPE,round(elapsed),'seconds'));last_message<-elapsed}
   Sys.sleep(.2)
  }
  clauder_progress('COMBINE_VALIDATE_ORIGINAL_MEMBERS',paste(MI_SCOPE,'40 original members, mixing and passive products'))
  # 原合并脚本使用临时变量d；隔离其绑定，保留执行器的终态目录和进度函数。
  e<-new.env(parent=environment());e$MI_SCOPE<-MI_SCOPE;e$MI_STOP_ITER<-MI_STOP_ITER
  source(file.path(BATCH,'code/formal_combine.R'),local=e)
  rec<-fromJSON(file.path(BATCH,'mi',MI_SCOPE,'audit',paste0('COMBINED_ITER',MI_STOP_ITER,'.json')))
  list(status='COMBINATION_CHECK_COMPLETED',scientific_status=rec$status,record=rec)
 },error=function(e)list(status='COMBINATION_CHECK_FAILED',error=conditionMessage(e)))
 result$utc<-format(Sys.time(),tz='UTC',usetz=TRUE);result$memory_at_end<-as.list(ps_memory_info(me))
 write_json(result,file.path(d,'TERMINAL.json'),auto_unbox=TRUE,pretty=TRUE,digits=16,na='null')
 clauder_progress('COMBINE_TERMINAL',paste(MI_SCOPE,result$status,result$scientific_status))
 print(result);cat('ORIGINAL_CHAIN_COMBINATION_TERMINAL\n')
}
main()
})
