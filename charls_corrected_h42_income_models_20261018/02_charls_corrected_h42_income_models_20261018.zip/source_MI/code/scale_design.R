install_scaling<-function(){
 scale_x<-function(x,type){for(k in which(type==1))if(length(unique(x[,k]))>2){v<-sd(x[,k]);if(is.finite(v)&&v>0)x[,k]<-(x[,k]-mean(x[,k]))/v};x}
 binary<-get('mice.impute.2l.bin.logged',.GlobalEnv);pmm<-get('mice.impute.2l.pmm.logged',.GlobalEnv)
 assign('mice.impute.2l.bin.logged',function(y,ry,x,type,wy=NULL,...)binary(y,ry,scale_x(x,type),type,wy=wy,...),.GlobalEnv)
 assign('mice.impute.2l.pmm.logged',function(y,ry,x,type,wy=NULL,...)pmm(y,ry,scale_x(x,type),type,wy=wy,...),.GlobalEnv)
}

# 检查所有被动量，含三列乘积，不能只检查zg和z_adl。
passive_map<-function(a){ans<-list(zg=c('z0','g'),z_adl=c('z0','adl'));for(n in a$aux){ans[[paste0('g_',n)]]<-c('g',n);ans[[paste0('gz_',n)]]<-c('g','z0',n)};ans}
passive_ok<-function(v,a)all(vapply(names(a$passive),function(n)max(abs(v[[n]]-Reduce(`*`,v[a$passive[[n]]])))<1e-12,TRUE))
