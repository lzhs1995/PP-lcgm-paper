# 独立20链块；保留完整轮次及随机状态，只有合并40链后才判断混合。

BATCH<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_h42_income_20261018';stopifnot(exists('MI_SCOPE'),MI_SCOPE%in%c('sd','gender','oldest','son'))

# 只影响下一次块入口：已运行的块继续到完整检查点，不终止其进程。
if(file.exists(file.path(BATCH,'contracts/SCHEDULER_HANDOFF_REQUEST.json'))&&!identical(Sys.getenv('PP_LGCM_INCOME_DISPATCH'),'v2'))stop('SCHEDULER_HANDOFF_AT_COMPLETED_BLOCK')
stopifnot(exists('MI_BLOCK'),MI_BLOCK%in%c('a','b'),exists('MI_STOP_ITER'),MI_STOP_ITER%in%c(10L,20L))

Sys.setenv(OMP_NUM_THREADS=1,OPENBLAS_NUM_THREADS=1,MKL_NUM_THREADS=1)

ROOT<-file.path(BATCH,'mi',MI_SCOPE,MI_BLOCK);OUT<-file.path(BATCH,'runtime/fanout',MI_SCOPE,paste0('iter',MI_STOP_ITER))

for(s in c('audit','runtime','results','private','checkpoints'))dir.create(file.path(ROOT,s),recursive=TRUE,showWarnings=FALSE)

dir.create(OUT,recursive=TRUE,showWarnings=FALSE)

.libPaths(c('<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_income_mi_pilot_20261016/library','<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_adjusted_h41_20261015/library',.libPaths()))

library(mice);library(miceadds);library(lme4);library(glmmTMB);library(jsonlite);library(digest);library(processx);library(ps);library(fs)

contract<-fromJSON(file.path(BATCH,'contracts/RUN_CONTRACT.json'),simplifyVector=FALSE);block<-contract$chain_blocks[[MI_SCOPE]][[MI_BLOCK]];contract$max_conditional_calls<-2L*block$m*contract$maxit

stopifnot(packageVersion('mice')=='3.19.10',fromJSON(file.path(BATCH,'mi_income',MI_SCOPE,'pilot/audit/RECEIPT.json'))$passed)

source(file.path(BATCH,'code/atomic_status.R'),local=TRUE)

wj<-publish_status

wc<-function(x,p){tmp<-paste0(p,'.tmp');write.csv(x,tmp,row.names=FALSE);fs::file_move(tmp,p)}

progress<-function(stage,message){

 rec<-list(stage=stage,message=paste(MI_BLOCK,message),updated_at=format(Sys.time(),tz='UTC',usetz=TRUE),pid=Sys.getpid(),fit_n=if(exists('fit_env'))fit_env$fit_n else 0,target=if(exists('fit_env'))fit_env$target else '')

 append_status_event(rec,file.path(ROOT,'runtime/progress_events.jsonl'))

 tryCatch(wj(rec,file.path(ROOT,'runtime/progress.json'),critical=FALSE),error=function(e)FALSE)

 wj(rec,file.path(OUT,paste0('state_',MI_BLOCK,'.json')),critical=identical(stage,'complete'))

 cat(stage,MI_BLOCK,message,'\n');flush.console()

 if(exists('clauder_progress',mode='function'))tryCatch(clauder_progress(stage,rec$message),error=function(e)cat('NATIVE_PROGRESS_DEFERRED',conditionMessage(e),'\n'))

}

source(file.path(BATCH,'code/formal_imputers.R'),local=TRUE);source(file.path(BATCH,'code/scale_design.R'),local=TRUE);install_scaling();fit_env$scope<-paste0('H42_',MI_SCOPE,'_',MI_BLOCK)

src<-file.path(BATCH,'private',paste0(MI_SCOPE,'_INPUTS.rds'));h0<-digest(file=src,algo='sha256');a<-readRDS(src);a$passive<-passive_map(a);a$essential_G<-c('z0','z2','z_adl');a$essential_ADL<-c('g','z0','zg');warnings<-list()

capture<-function(expr)withCallingHandlers(expr,warning=function(w){warnings[[length(warnings)+1L]]<<-list(iteration=fit_env$iteration,fit_n=fit_env$fit_n,message=conditionMessage(w));invokeRestart('muffleWarning')})

checkpoint<-function(imp){

 p<-file.path(ROOT,'checkpoints',sprintf('ITER%02d.rds',imp$iteration));stopifnot(!file.exists(p));tmp<-paste0(p,'.tmp');saveRDS(imp,tmp);fs::file_move(tmp,p);saveRDS(list(global=.Random.seed,mids=imp$lastSeedValue),paste0(p,'.rng.rds'))

 if(exists(fit_env$scope,envir=fit_env$warm,inherits=FALSE))saveRDS(get(fit_env$scope,envir=fit_env$warm),paste0(p,'.warm.rds'))

 wj(list(iteration=imp$iteration,m=imp$m,sha256=digest(file=p,algo='sha256'),source_sha256=h0,fit_n=fit_env$fit_n),paste0(p,'.json'));p

}

main<-function(){

 terminal<-file.path(ROOT,'audit',paste0('ITER',MI_STOP_ITER,'_TERMINAL.json'));stopifnot(!file.exists(terminal))

 # 上次watch已终态才允许同一块恢复；禁止第二协调器竞争同一MIDS。

 lease<-file.path(ROOT,'runtime/lease.json')

 if(file.exists(lease)){
  old<-fromJSON(lease);alive<-tryCatch(abs(as.numeric(ps::ps_create_time(ps::ps_handle(old$pid)))-old$created)<.01,error=function(e)FALSE)
  # 同一串行原生worker只可在10轮已完成且watch已释放后继续原链到20轮。
  continuing<-alive&&old$pid==Sys.getpid()&&MI_STOP_ITER==20L&&file.exists(file.path(ROOT,'audit/ITER10_TERMINAL.json'))&&isTRUE(fromJSON(file.path(ROOT,'audit/ITER10_TERMINAL.json'))$passed)&&file.exists(file.path(ROOT,'runtime/WATCH_TERMINAL.json'))&&fromJSON(file.path(ROOT,'runtime/WATCH_TERMINAL.json'))$status=='STOP_REQUESTED'
  stopifnot(!alive||continuing)
 }
 created<-as.numeric(ps::ps_create_time(ps::ps_handle()));wj(list(pid=Sys.getpid(),created=created,block=MI_BLOCK),lease)

 if(file.exists(file.path(ROOT,'runtime/stop.request')))fs::file_move(file.path(ROOT,'runtime/stop.request'),file.path(ROOT,'runtime',paste0('stop_before_',MI_STOP_ITER,'.request')))

 PY<-'<WINDOWS_USERPROFILE>/AppData/Local/Programs/Python/Python314/python.exe'

 recovery<-file.path(ROOT,'audit/RECOVERY_SOURCE.json');prior_charge<-if(file.exists(recovery))fromJSON(recovery)$previous_active_charge_seconds else 0
 if(MI_STOP_ITER==20L&&file.exists(file.path(ROOT,'runtime/WATCH_TERMINAL.json'))){
  previous<-fromJSON(file.path(ROOT,'runtime/WATCH_TERMINAL.json'));prior_charge<-max(prior_charge,previous$elapsed_seconds)
  wj(previous,file.path(ROOT,'audit/WATCH_ITER10_TERMINAL.json'))
 }
 stopifnot(prior_charge<contract$per_worker_wall_seconds)
 watch<-process$new(PY,c('-X','utf8',file.path(BATCH,'code/mi_watch.py'),'--pid',Sys.getpid(),'--created',sprintf('%.6f',created),'--root',ROOT,'--seconds',contract$per_worker_wall_seconds-prior_charge,'--fit-seconds',contract$per_fit_seconds),stdout=file.path(ROOT,'runtime',paste0('watch_',MI_STOP_ITER,'.log')),stderr='2>&1',cleanup=FALSE)

 on.exit({writeLines('release',file.path(ROOT,'runtime/stop.request'));watch$wait(8000L)},add=TRUE)

 source(file.path(BATCH,'code/watch_ready.R'),local=TRUE)
 wait_for_owned_watch(watch,ROOT,created)
 cps<-sort(list.files(file.path(ROOT,'checkpoints'),pattern='^ITER[0-9]{2}\\.rds$',full.names=TRUE));imp<-NULL

 if(length(cps)){

  cp<-tail(cps,1);meta<-fromJSON(paste0(cp,'.json'));stopifnot(digest(file=cp,algo='sha256')==meta$sha256,meta$source_sha256==h0)

  imp<-readRDS(cp);stopifnot(identical(imp$data,a$data),imp$m==block$m,imp$iteration<=MI_STOP_ITER);fit_env$fit_n<-meta$fit_n

  log<-file.path(ROOT,'audit/FIT_LOG.jsonl');if(file.exists(log))stopifnot(length(readLines(log))==fit_env$fit_n)

  wp<-paste0(cp,'.warm.rds');if(file.exists(wp))assign(fit_env$scope,readRDS(wp),envir=fit_env$warm)

  progress('MI_RESUME',paste('verified checkpoint',imp$iteration,'original RNG retained'))

 }else{

  stopifnot(!file.exists(file.path(ROOT,'audit/FIT_LOG.jsonl')))

  fit_env$iteration<-1L;progress('MI_INITIALIZE','20 independent chains, frozen seed')

  imp<-capture(mice(a$data,m=block$m,maxit=1,method=a$method,predictorMatrix=a$predictors,visitSequence=a$visit,seed=block$seed,data.init=a$initial,blots=a$blots,remove.collinear=FALSE,remove.constant=FALSE,printFlag=FALSE));cp<-checkpoint(imp)

 }

 while(imp$iteration<MI_STOP_ITER){fit_env$iteration<-imp$iteration+1L;progress('MI_ITERATION',paste('iteration',fit_env$iteration,'target',MI_STOP_ITER));imp<-capture(mice.mids(imp,maxit=1,printFlag=FALSE));cp<-checkpoint(imp)}

 wc(data.frame(variable=rownames(imp$predictorMatrix),imp$predictorMatrix,check.names=FALSE),file.path(ROOT,'audit/PREDICTORS_ACTUAL.csv'))

 if(!is.null(imp$loggedEvents))wc(imp$loggedEvents,file.path(ROOT,'audit/LOGGED_EVENTS.csv'))

 checks<-lapply(seq_len(block$m),function(k){v<-complete(imp,k);raw<-as.matrix(a$data);vv<-as.matrix(v);obs<-!is.na(raw);data.frame(member=k,observed_preserved=identical(unname(raw[obs]),unname(vv[obs])),passive_products=all(vapply(names(a$passive),function(n)max(abs(v[[n]]-Reduce(`*`,v[a$passive[[n]]])))<1e-12,TRUE)),support=all(v$g%in%0:1)&&all(v$adl%in%0:6)&&all(v$adl[is.na(a$data$adl)]%in%a$data$adl[!is.na(a$data$adl)]),no_missing=!anyNA(v))})

 checks<-do.call(rbind,checks);wc(checks,file.path(ROOT,'results',paste0('MEMBERS_ITER',MI_STOP_ITER,'.csv')))

 stopifnot(identical(unname(imp$predictorMatrix),unname(a$predictors)))
 essential<-all(imp$predictorMatrix['g',a$essential_G]==1)&&all(imp$predictorMatrix['adl',a$essential_ADL]==1)&&all(imp$predictorMatrix[c('g','adl'),'cluster']==-2)

 no_self<-all(imp$predictorMatrix['g',a$gproducts]==0)&&imp$predictorMatrix['adl','z_adl']==0

 fits<-lapply(readLines(file.path(ROOT,'audit/FIT_LOG.jsonl')),fromJSON);fit_valid<-length(fits)==2L*block$m*imp$iteration&&all(vapply(fits,function(x)isTRUE(x$valid),TRUE))

 passed<-all(as.matrix(checks[,-1]))&&essential&&no_self&&fit_valid&&digest(file=src,algo='sha256')==h0

 rec<-list(status=if(passed)'CHAIN_BLOCK_COMPLETE_PENDING_COMBINED_DIAGNOSTICS' else 'CHAIN_BLOCK_FAILED',passed=passed,block=MI_BLOCK,m=block$m,iterations=imp$iteration,conditional_fits=length(fits),essential_predictors=essential,no_self_products=no_self,checkpoint=cp,sha256=digest(file=cp,algo='sha256'),source_sha256=h0)

 wj(rec,terminal);wc(data.frame(path=cp,sha256=rec$sha256,block=MI_BLOCK,iteration=imp$iteration),file.path(OUT,paste0('manifest_',MI_BLOCK,'.csv')));wc(data.frame(check=c('all_members','essential','no_self','all_fits'),passed=c(all(as.matrix(checks[,-1])),essential,no_self,fit_valid)),file.path(OUT,paste0('validation_',MI_BLOCK,'.csv')))

 progress(if(passed)'complete' else 'failed',rec$status);stopifnot(passed);cat('CHARLS_INCOME_MI_BLOCK_DONE\n')

}

tryCatch(main(),error=function(e){wj(list(status='MI_BLOCK_ERROR',passed=FALSE,block=MI_BLOCK,error=conditionMessage(e)),file.path(ROOT,'audit',paste0('ERROR_TO_ITER',MI_STOP_ITER,'.json')));progress('failed',conditionMessage(e));stop(e)},finally={wj(warnings,file.path(ROOT,'audit',paste0('WARNINGS_TO_ITER',MI_STOP_ITER,'.json')));writeLines(capture.output(sessionInfo()),file.path(ROOT,'audit/R_SESSION_INFO.txt'))})

