# 完整块交接后，启动尚未运行的原块或继续同一原链到20轮。
# 不改formal_worker.R、原种子、MIDS/RNG或累计计算时限。
local({
 BATCH<-'<WINDOWS_USERPROFILE>/pp_lgcm_review/charls_corrected_h42_income_20261018'
 stopifnot(exists('MI_SCOPE'),exists('MI_BLOCK'),exists('MI_STOP_ITER'))
 library(jsonlite);library(ps);library(digest)
 d<-file.path(BATCH,'continuation',paste(MI_SCOPE,MI_BLOCK,MI_STOP_ITER,sep='_'))
 host<-fromJSON(file.path(d,'ADMISSION.json'))
 stamp<-as.POSIXct(substr(host$utc,1,19),format='%Y-%m-%dT%H:%M:%S',tz='UTC')
 age<-as.numeric(difftime(Sys.time(),stamp,units='secs'))
 stopifnot(host$admitted,is.finite(age),age>=0,age<120)
 for(n in names(host$code_sha256))stopifnot(digest(file=file.path(BATCH,'code',n),algo='sha256')==host$code_sha256[[n]])
 stopifnot(!file.exists(file.path(d,'OWNER.json')),!file.exists(file.path(d,'TERMINAL.json')))
 Sys.setenv(OMP_NUM_THREADS=1,OPENBLAS_NUM_THREADS=1,MKL_NUM_THREADS=1,PP_LGCM_INCOME_DISPATCH='v2')
 me<-ps_handle();ps_set_cpu_affinity(me,unlist(host$selected_cores))
 write_json(list(owner=list(pid=Sys.getpid(),created=as.numeric(ps_create_time(me)))),file.path(d,'OWNER.json'),auto_unbox=TRUE,digits=16)
 clauder_progress('CONTINUE_ORIGINAL_BLOCK',paste(MI_SCOPE,MI_BLOCK,'target',MI_STOP_ITER))
 outcome<-tryCatch({
  e<-new.env(parent=environment());e$MI_SCOPE<-MI_SCOPE;e$MI_BLOCK<-MI_BLOCK;e$MI_STOP_ITER<-MI_STOP_ITER
  source(file.path(BATCH,'code/formal_worker.R'),local=e)
  r<-fromJSON(file.path(BATCH,'mi',MI_SCOPE,MI_BLOCK,'audit',paste0('ITER',MI_STOP_ITER,'_TERMINAL.json')))
  stopifnot(isTRUE(r$passed));list(status='ORIGINAL_BLOCK_COMPLETE_PENDING_COMBINATION',passed=TRUE,record=r)
 },error=function(e)list(status='ORIGINAL_BLOCK_FAILED_NO_REPLACEMENT',passed=FALSE,error=conditionMessage(e)))
 outcome$scope<-MI_SCOPE;outcome$block<-MI_BLOCK;outcome$iteration<-MI_STOP_ITER
 outcome$utc<-format(Sys.time(),tz='UTC',usetz=TRUE)
 write_json(outcome,file.path(d,'TERMINAL.json'),auto_unbox=TRUE,pretty=TRUE,digits=16)
 clauder_progress('CONTINUATION_TERMINAL',paste(MI_SCOPE,MI_BLOCK,outcome$status))
 cat('ORIGINAL_BLOCK_CONTINUATION_TERMINAL\n')
})
