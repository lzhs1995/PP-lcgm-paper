# 独立base-R读原始保存参数与TECH1/TECH3；不调用生产合并器，不启动Mplus。
verify_pooled_base<-function(root,phase='INC',public=FALSE){
 library(jsonlite);library(digest)
 jread<-function(p)fromJSON(p,simplifyVector=FALSE)
 hash<-function(p)digest(file=p,algo='sha256')
 csv<-function(p)read.csv(p,check.names=FALSE,stringsAsFactors=FALSE)
 progress<-function(stage,message){cat(stage,message,'\n');flush.console();if(exists('clauder_progress',mode='function',inherits=TRUE))get('clauder_progress',mode='function',inherits=TRUE)(stage,message)}
 close<-function(a,b,rtol=1e-8,atol=1e-10){a<-as.numeric(a);b<-as.numeric(b);stopifnot(length(a)==length(b));ok<-(is.infinite(a)&is.infinite(b)&sign(a)==sign(b))|abs(a-b)<=atol+rtol*abs(b);stopifnot(all(ok))}
 labels<-c('bii','bis','bss','bsyiy','gi0','gs0','gizg','gszg','dc','bxg','dcg')
 fields<-c('estimate','se','df','lower','upper','p','lambda','MCSE_over_SE')
 manifest<-NULL
 if(public){
  mm<-jread(file.path(root,'PAYLOAD_MANIFEST.json'));manifest<-setNames(mm,vapply(mm,`[[`,'','path'));stopifnot(!anyDuplicated(names(manifest)))
  for(rel in names(manifest)){stopifnot(!grepl('(^/|^[A-Za-z]:|(^|/)\\.\\.(/|$))',rel));stopifnot(hash(file.path(root,rel))==manifest[[rel]]$sha256)}
 }else{
  contract<-jread(file.path(root,'contracts/RUN_CONTRACT.json'));mi<-contract$source_MI
  stopifnot(hash(file.path(mi,'contracts/RUN_CONTRACT.json'))==contract$source_imputation_contract_sha256)
  admissions<-jread(file.path(root,'audit/MI_ADMISSIONS.json'))
  for(z in names(admissions)){
   a<-admissions[[z]];src<-file.path(mi,'mi',z);gate<-jread(file.path(src,'audit/MI_ADMISSION.json'))
   stopifnot(a$passed,a$m==40L,gate$m==40L,gate$status=='ADMITTED_WORKING_MI',gate$mixing_pass,gate$member_checks,gate$original_block_members_identical)
   stopifnot(hash(file.path(src,'audit/MI_ADMISSION.json'))==a$admission_sha256,
    hash(file.path(mi,'private',paste0(z,'_INPUTS.rds')))==a$source_input_sha256,
    hash(file.path(src,'audit/MI_MEMBERS.csv'))==a$source_members_sha256)
  }
  calls<-jread(file.path(root,'results/CALL_RESULTS.json'));families<-names(jread(file.path(root,'contracts/CC_PARENTS.json')))
  for(k in seq_along(calls)){
   name<-names(calls)[k];call<-calls[[k]];d<-file.path(root,'models',name);j<-jread(file.path(d,'job.json'))
   stopifnot(j$id==name,j$family%in%families,hash(file.path(d,'model.inp'))==j$hashes[['model.inp']])
   h<-hash(file.path(d,'data.dat'));stopifnot(h==j$hashes[['data.dat']],h==hash(file.path(mi,'mi',j$z,'private',sprintf('MI%02d.dat',j$member))))
   if(!is.null(call$output_sha256))stopifnot(hash(file.path(d,'model.out'))==call$output_sha256)else stopifnot(call$status!='USABLE_SINGLE_DATASET')
   if(k==1L||k%%20L==0L)progress('INDEPENDENT_INPUTS',paste(k,'of',length(calls)))
  }
 }
 verify_source<-function(path,expected){
  if(!public){stopifnot(hash(file.path(root,path))==expected);return(invisible(NULL))}
  e<-manifest[[path]];stopifnot(!is.null(e),hash(file.path(root,path))==e$sha256,expected==e$local_source_sha256)
 }
 tech1<-function(lines){
  begin<-which(grepl('PARAMETER SPECIFICATION',lines,fixed=TRUE))[1];end<-which(seq_along(lines)>begin&grepl('STARTING VALUES',lines,fixed=TRUE))[1]
  stopifnot(is.finite(begin),is.finite(end));ls<-trimws(lines[begin:end]);mats<-c('NU','LAMBDA','THETA','ALPHA','BETA','PSI','GAMMA','TAU','KAPPA');out<-list();i<-1L
  while(i<=length(ls)-2L){
   mat<-ls[i]
   if(!mat%in%mats||!grepl('^[_ ]+$',ls[i+2L])||!nzchar(ls[i+2L])){i<-i+1L;next}
   cols<-strsplit(ls[i+1L],'[[:space:]]+')[[1]];i<-i+3L
   while(i<=length(ls)&&nzchar(ls[i])&&!ls[i]%in%mats){
    tk<-strsplit(ls[i],'[[:space:]]+')[[1]]
    if(mat%in%c('NU','ALPHA','TAU','KAPPA')&&grepl('^[-+0-9]',tk[1])){row<-'1';values<-tk}else{row<-tk[1];values<-tk[-1]}
    n<-min(length(cols),length(values));if(n)out[[length(out)+1L]]<-data.frame(matrix=mat,row=row,column=cols[seq_len(n)],parameter=as.integer(values[seq_len(n)]))
    i<-i+1L
   }
  };do.call(rbind,out)
 }
 raw_model<-function(d){
  lines<-readLines(file.path(d,'model.out'),warn=FALSE,encoding='latin1');mapping<-tech1(lines)
  n<-max(mapping$parameter);stopifnot(setequal(mapping$parameter[mapping$parameter>0],seq_len(n)))
  q<-scan(file.path(d,'estimates.dat'),quiet=TRUE);sv<-scan(file.path(d,'tech3.dat'),quiet=TRUE)
  stopifnot(length(q)>=2L*n+2L,length(sv)==n*(n+1)/2)
  v<-matrix(0,n,n);at<-1L
  for(i in seq_len(n)){v[i,seq_len(i)]<-sv[at:(at+i-1L)];at<-at+i}
  v<-v+t(v)-diag(diag(v));close(sqrt(diag(v)),q[n+seq_len(n)],1e-6,1e-8)
  pp<-csv(file.path(d,'parameters_high_precision.csv'));pp<-pp[order(pp$parameter),];stopifnot(nrow(pp)==n)
  close(pp$estimate,q[seq_len(n)],1e-5,1e-12);close(pp$se,q[n+seq_len(n)],1e-5,1e-12)
  close(as.matrix(read.csv(file.path(d,'parameter_covariance.csv'),header=FALSE)),v,1e-12,1e-12)
  keys<-csv(file.path(d,'key_paths.csv'))
  for(i in seq_len(nrow(keys))){
   x<-keys[i,];allow<-if('matrix'%in%names(keys))x$matrix else c('BETA','GAMMA')
   found<-unique(mapping$parameter[mapping$matrix%in%allow&mapping$row==as.character(x$row)&mapping$column==as.character(x$column)&mapping$parameter>0])
   stopifnot(length(found)==1L,found==x$parameter);close(c(x$estimate,x$se),q[c(found,n+found)],1e-5,1e-12)
  }
  list(lines=lines,mapping=mapping,q=q[seq_len(n)],se=q[n+seq_len(n)],v=v,keys=setNames(keys$parameter,keys$label),ll=q[2L*n+2L])
 }
 pooldir<-file.path(root,'results',paste0('pool_',phase));summary<-csv(file.path(pooldir,'H42_REGISTERED.csv'));checked<-list()
 for(r in seq_len(nrow(summary))){
  row<-summary[r,];if(!row$status%in%c('FULL_CONDITIONAL_MI_POOLED','FULL_POOLED_MCSE_LIMIT_RETAINED'))next
  family<-row$family;dest<-file.path(pooldir,family);src<-csv(file.path(dest,'MEMBER_SOURCES.csv'));m<-row$m
  stopifnot(nrow(src)==m,identical(as.integer(src$member),seq_len(m)))
  progress('INDEPENDENT_FAMILY',family);Q<-matrix(NA_real_,m,length(labels));U<-vector('list',m)
  for(k in seq_len(m)){
   s<-src[k,];rel<-paste0('models/',s$model);d<-file.path(root,rel);j<-jread(file.path(d,'job.json'));stopifnot(j$member==s$member,j$start=='A',j$family==family)
   for(pair in list(c('model.out','output_sha256'),c('model.inp','input_sha256'),c('estimates.dat','results_sha256'),c('tech3.dat','tech3_sha256')))verify_source(paste0(rel,'/',pair[1]),s[[pair[2]]])
   x<-raw_model(d);stopifnot(any(grepl('THE MODEL ESTIMATION TERMINATED NORMALLY',x$lines,fixed=TRUE)),!any(grepl('FIXED TO AVOID SINGULARITY',x$lines,fixed=TRUE)))
   ln<-x$lines[grepl('Number of observations[[:space:]]+[0-9]+',x$lines)][1];stopifnot(as.integer(sub('.*Number of observations[[:space:]]+([0-9]+).*','\\1',ln))==row$N)
   diagp<-x$mapping$parameter[x$mapping$matrix%in%c('PSI','THETA')&x$mapping$row==x$mapping$column&x$mapping$parameter>0]
   stopifnot(all(x$q[diagp]>=0),min(eigen(cov2cor(x$v),symmetric=TRUE,only.values=TRUE)$values)>0)
   ix<-unname(x$keys[labels]);stopifnot(!anyNA(ix));Q[k,]<-x$q[ix];U[[k]]<-x$v[ix,ix]
   if(k==1L){
    b<-raw_model(file.path(root,'models',sub('A$','B',s$model)));ib<-unname(b$keys[labels]);mx<-pmax(x$se[ix],b$se[ib])
    stopifnot(abs(x$ll-b$ll)<=.01,all(abs(x$q[ix]-b$q[ib])<=pmax(.001,.05*mx)),all(abs(x$se[ix]-b$se[ib])/mx<=.05))
   }
   if(k%%5L==0L)progress('INDEPENDENT_MEMBERS',paste(family,k,'of',m))
  }
  W<-Reduce(`+`,U)/m;B<-cov(Q);T<-W+(1+1/m)*B;est<-colMeans(Q)
  scalar<-function(a,dfcom=Inf){
   project<-function(M)as.numeric(crossprod(a,M%*%a));e<-sum(a*est);se<-sqrt(project(T));rv<-(1+1/m)*project(B)/project(W);lambda<-(1+1/m)*project(B)/project(T)
   df<-if(rv>0)(m-1)*(1+1/rv)^2 else Inf
   if(is.finite(dfcom))df<-1/(1/df+1/((dfcom+1)/(dfcom+3)*dfcom*(1-lambda)))
   c(estimate=e,se=se,df=df,lower=e-qt(.975,df)*se,upper=e+qt(.975,df)*se,p=2*pt(-abs(e/se),df),lambda=lambda,MCSE_over_SE=sqrt(project(B)/m)/se)
  }
  contrast<-function(...){v<-c(...);a<-setNames(numeric(length(labels)),labels);a[names(v)]<-v;unname(a)}
  pp<-csv(file.path(dest,'POOLED_PATHS.csv'));pp<-pp[match(labels,pp$label),];close(t(vapply(seq_along(labels),function(i)scalar(diag(length(labels))[,i]),numeric(8))),as.matrix(pp[,fields]))
  for(name in c('WITHIN','BETWEEN','TOTAL')){rr<-csv(file.path(dest,paste0(name,'_COVARIANCE.csv')));close(as.matrix(rr[match(labels,rr$label),labels]),switch(name,WITHIN=W,BETWEEN=B,TOTAL=T),1e-8,1e-12)}
  cc<-list(delta_G0=contrast(dc=1),delta_G1=contrast(dc=1,dcg=1),direct_difference=contrast(dcg=1))
  for(file in c('GROUP_MODERATION_CONTRASTS.csv','CLUSTER_DF_SENSITIVITY.csv')){
   rr<-csv(file.path(dest,file));for(i in seq_len(nrow(rr)))close(scalar(cc[[rr$contrast[i]]],if('df_complete'%in%names(rr))rr$df_complete[i] else Inf),unlist(rr[i,fields]))
  }
  curves<-csv(file.path(dest,'CONDITIONAL_SLOPES.csv'))
  for(i in seq_len(nrow(curves))){v<-curves[i,];stopifnot(v$z>=v$support_min,v$z<=v$support_max);close(scalar(contrast(bss=1,dc=v$z,bxg=v$G,dcg=v$z*v$G)),unlist(v[fields]))}
  primary<-scalar(contrast(dcg=1));close(primary[c('estimate','se','lower','upper','p')],unlist(row[,c('estimate','se','lower','upper','p')]))
  checked[[family]]<-list(m=as.integer(m),N=as.integer(row$N),conditional_points=nrow(curves),p=unname(primary['p']));progress('INDEPENDENT_FAMILY_PASS',family)
 }
 valid<-is.finite(summary$p);p<-summary$p[valid];orderp<-order(p);holm<-numeric(length(p));holm[orderp]<-pmin(1,cummax((12-seq_along(p)+1)*p[orderp]))
 close(holm,summary$Holm_12[valid]);close(pmin(1,12*p),summary$Bonferroni_12[valid])
 receipt<-list(status='PASS',phase=phase,complete_families=checked,new_Mplus_calls=0,full_H4_complete=FALSE,original_CFPS_four_complete=FALSE,verification_engine='independent_base_R_raw_parameter_readback')
 write_json(receipt,file.path(root,'audit',paste0('POOL_INDEPENDENT_',phase,'.json')),auto_unbox=TRUE,pretty=TRUE,digits=16)
 progress('INDEPENDENT_BASE_R_COMPLETE',paste(length(checked),'complete families'));cat('INDEPENDENT_BASE_R_NATIVE_TERMINAL\n');invisible(receipt)
}
