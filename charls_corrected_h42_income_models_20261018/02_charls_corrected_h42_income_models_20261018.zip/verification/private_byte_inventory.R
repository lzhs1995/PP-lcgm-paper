# 在完整原队列终态之后，列出独立核验可能读取的文件；只记录路径和字节数。
private_byte_inventory<-function(root){
 contract<-jsonlite::fromJSON(file.path(root,'contracts/RUN_CONTRACT.json'))
 mi<-contract$source_MI;calls<-jsonlite::fromJSON(file.path(root,'results/CALL_RESULTS.json'),simplifyVector=FALSE)
 fixed<-c(file.path(root,'contracts',c('RUN_CONTRACT.json','CC_PARENTS.json')),
  file.path(root,'audit/MI_ADMISSIONS.json'),file.path(root,'results/CALL_RESULTS.json'),file.path(mi,'contracts/RUN_CONTRACT.json'))
 model_names<-c('model.inp','data.dat','model.out','job.json','estimates.dat','tech3.dat','parameters_high_precision.csv','parameter_covariance.csv','key_paths.csv')
 models<-unlist(lapply(names(calls),function(n)file.path(root,'models',n,model_names)),use.names=FALSE)
 source<-unlist(lapply(c('sd','gender','oldest','son'),function(z)c(
  file.path(mi,'private',paste0(z,'_INPUTS.rds')),
  file.path(mi,'mi',z,'audit',c('MI_ADMISSION.json','MI_MEMBERS.csv')),
  file.path(mi,'mi',z,'private',sprintf('MI%02d.dat',1:40)))),use.names=FALSE)
 pooled<-list.files(file.path(root,'results/pool_INC'),pattern='\\.csv$',recursive=TRUE,full.names=TRUE)
 paths<-unique(c(fixed,models,source,pooled));info<-file.info(paths)
 # 未执行/失败调用没有保存参数时不建虚拟文件；原核验器仍决定每种状态应有什么。
 keep<-!is.na(info$size)&!info$isdir
 ans<-data.frame(path=paths[keep],bytes=info$size[keep],stringsAsFactors=FALSE)
 jsonlite::write_json(ans,file.path(root,'audit/base_R_verification/PRIVATE_BYTE_INVENTORY.json'),dataframe='rows',pretty=TRUE)
 ans
}
