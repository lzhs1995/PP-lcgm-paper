"""独立复核12个登记检验：保留缺失处置及原系数，只重算固定范围校正。"""
from pathlib import Path
import json,hashlib,sys
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1];H=R/'source_EDU_URBAN' if '--public' in sys.argv else R.parent/'charls_corrected_h42_models_20261018'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert read(H/'audit/POOL_INDEPENDENT_EDU_URBAN.json')['status']=='PASS'
assert read(R/'audit/POOL_INDEPENDENT_INC.json')['status']=='PASS'
paths=[H/'results/pool_EDU_URBAN/H42_REGISTERED.csv',R/'results/pool_INC/H42_REGISTERED.csv']
original=pd.concat([pd.read_csv(p) for p in paths],ignore_index=True).set_index('family')
dest=R/'results/TWELVE_H42_RESOURCES.csv';result=pd.read_csv(dest).set_index('family')
expected={f'{z}_{g}' for z in ('sd','gender','oldest','son') for g in ('EDU','URBAN','INC')}
assert len(original)==len(result)==12 and original.index.is_unique and result.index.is_unique
assert set(original.index)==set(result.index)==expected
original=original.loc[result.index]
for c in original.columns:
 if c in ('Holm_12','Bonferroni_12'):continue
 pd.testing.assert_series_equal(original[c],result[c],check_dtype=False,rtol=1e-10,atol=1e-12)
ok=result.p.notna();p=result.loc[ok,'p'].to_numpy();order=np.argsort(p)
holm=np.empty(len(p));holm[order]=np.minimum(1,np.maximum.accumulate((12-np.arange(len(p)))*p[order]))
assert np.allclose(result.loc[ok,'Holm_12'],holm,rtol=1e-10,atol=1e-12)
assert np.allclose(result.loc[ok,'Bonferroni_12'],np.minimum(1,12*p),rtol=1e-10,atol=1e-12)
assert result.loc[~ok,['Holm_12','Bonferroni_12']].isna().all().all()
record=dict(status='PASS',registered=12,estimated=int(ok.sum()),source_sha256={str(p):sha(p) for p in paths},
 result_sha256=sha(dest),new_Mplus_calls=0,original_four_complete=False,full_H4_complete=False)
(R/'audit'/('PUBLIC_TWELVE_RESOURCES_INDEPENDENT.json' if '--public' in sys.argv else 'TWELVE_RESOURCES_INDEPENDENT.json')).write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record))
