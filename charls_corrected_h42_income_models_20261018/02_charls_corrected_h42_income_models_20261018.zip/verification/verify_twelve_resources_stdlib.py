"""无科学Python依赖地独立核对12项登记与Holm；不修改估计。"""
from pathlib import Path
import csv,hashlib,json,math,sys
R=Path(__file__).resolve().parents[1];public='--public' in sys.argv
H=R/'source_EDU_URBAN' if public else R.parent/'charls_corrected_h42_models_20261018'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert read(H/'audit/POOL_INDEPENDENT_EDU_URBAN.json')['status']=='PASS'
assert read(R/'audit/POOL_INDEPENDENT_INC.json')['status']=='PASS'
def rows(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
paths=[H/'results/pool_EDU_URBAN/H42_REGISTERED.csv',R/'results/pool_INC/H42_REGISTERED.csv']
source=rows(paths[0])+rows(paths[1]);dest=R/'results/TWELVE_H42_RESOURCES.csv';out=rows(dest)
expected={f'{z}_{g}' for z in ('sd','gender','oldest','son') for g in ('EDU','URBAN','INC')}
assert len(source)==len(out)==12
a={x['family']:x for x in source};b={x['family']:x for x in out}
assert set(a)==set(b)==expected
def number(x):
 try:return float(x)
 except (ValueError,TypeError):return math.nan
def same(x,y):
 if x==y:return True
 v,w=number(x),number(y)
 return (math.isnan(v) and math.isnan(w) and x in ('','NA','NaN') and y in ('','NA','NaN')) or math.isclose(v,w,rel_tol=1e-10,abs_tol=1e-12)
for family,row in a.items():
 assert set(row)==set(b[family])
 for col,x in row.items():
  if col not in ('Holm_12','Bonferroni_12'):assert same(x,b[family][col]),(family,col)
valid=sorted((number(row['p']),f) for f,row in b.items() if math.isfinite(number(row['p'])))
maximum=0.0
for i,(p,f) in enumerate(valid):
 maximum=max(maximum,(12-i)*p)
 assert same(str(min(1.0,maximum)),b[f]['Holm_12'])
 assert same(str(min(1.0,12*p)),b[f]['Bonferroni_12'])
for f,row in b.items():
 if not math.isfinite(number(row['p'])):assert all(row[c] in ('','NA','NaN') for c in ('Holm_12','Bonferroni_12'))
record=dict(status='PASS',registered=12,estimated=len(valid),source_sha256={str(p):sha(p) for p in paths},result_sha256=sha(dest),
 new_Mplus_calls=0,original_four_complete=False,full_H4_complete=False,verification_engine='independent_stdlib_csv_and_fixed12_Holm')
target=R/'audit'/('PUBLIC_TWELVE_RESOURCES_INDEPENDENT.json' if public else 'TWELVE_RESOURCES_INDEPENDENT.json')
assert not target.exists();target.write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record))
