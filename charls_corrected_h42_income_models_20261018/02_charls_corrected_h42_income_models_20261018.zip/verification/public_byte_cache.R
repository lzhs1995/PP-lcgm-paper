# 已封包文件的只读字节缓存：保留逐文件SHA核对与原核验器，减少重复Windows文件打开。
make_public_byte_cache<-function(root,parent=parent.frame(),limit_bytes=256*1024^2,inventory=NULL,stage='PUBLIC_PAYLOAD_READ'){
 manifest<-if(is.null(inventory))jsonlite::fromJSON(file.path(root,'PAYLOAD_MANIFEST.json'))else inventory
 stopifnot(!anyDuplicated(manifest$path),all(is.finite(manifest$bytes)),all(manifest$bytes>=0))
 paths<-setNames(as.numeric(manifest$bytes),if(is.null(inventory))file.path(root,manifest$path)else manifest$path)
 bytes<-new.env(hash=TRUE,parent=emptyenv());used<-0;reads<-0L;hits<-0L
 env<-new.env(parent=parent)
 cached<-function(path)is.character(path)&&length(path)==1L&&path%in%names(paths)
 getbytes<-function(path){
  if(exists(path,bytes,inherits=FALSE)){hits<<-hits+1L;return(get(path,bytes,inherits=FALSE))}
  n<-unname(paths[path]);stopifnot(length(n)==1L,is.finite(n),n<limit_bytes)
  con<-file(path,'rb');on.exit(close(con));raw<-readBin(con,'raw',n=n+1)
  stopifnot(length(raw)==n)
  reads<<-reads+1L
  if(used+n<=limit_bytes){assign(path,raw,bytes);used<<-used+n}
  if(reads%%100L==0L&&exists('clauder_progress',mode='function',inherits=TRUE))
   get('clauder_progress',mode='function',inherits=TRUE)(stage,paste(reads,'files; retained',round(used/1024^2,1),'MiB'))
  raw
 }
 env$digest<-function(object=NULL,algo='md5',serialize=TRUE,file=FALSE,...){
  if(is.character(file)&&cached(file))return(digest::digest(getbytes(file),algo=algo,serialize=FALSE,...))
  digest::digest(object=object,algo=algo,serialize=serialize,file=file,...)
 }
 env$fromJSON<-function(txt,...){if(cached(txt))txt<-rawToChar(getbytes(txt));jsonlite::fromJSON(txt,...)}
 env$readLines<-function(con=stdin(),...){
  if(!cached(con))return(base::readLines(con,...))
  connection<-textConnection(rawToChar(getbytes(con)));on.exit(close(connection));base::readLines(connection,...)
 }
 env$read.csv<-function(file='',...){
  if(!cached(file))return(utils::read.csv(file=file,...))
  utils::read.csv(text=rawToChar(getbytes(file)),...)
 }
 env$scan<-function(file='',...){
  if(!cached(file))return(base::scan(file=file,...))
  base::scan(text=rawToChar(getbytes(file)),...)
 }
 env$cache_stats<-function()list(disk_reads=reads,cache_hits=hits,retained_bytes=used,limit_bytes=limit_bytes,
  note='File hashes and original numerical verifier remain mandatory; a cache hit is not an acceptance result')
 env
}
