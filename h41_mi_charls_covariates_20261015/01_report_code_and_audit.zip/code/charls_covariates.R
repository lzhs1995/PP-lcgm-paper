# 基期控制变量：只在独立沙盒构造；不重新筛选原队列，不运行CHARLS模型。
library(haven);library(dplyr);library(jsonlite);library(digest)
ROOT <- '<LOCAL_USER_HOME>/pp_lgcm_review/h41_mi_charls_covariates_20261015'
OLD <- '<LOCAL_USER_HOME>/pp_lgcm_review/reopen_observed_charls_20261015'
RAW <- '<LOCAL_USER_HOME>/Desktop/20230505 毕业论文/开题报告/开题报告/CHARLS'
sources <- c(cohort=file.path(OLD,'private/charls_cohort.rds'),frame=file.path(OLD,'private/charls_mplus_frame.rds'),
 harmonized=file.path(RAW,'charls11_20_harmonized/data_Harmonized/H_CHARLS_D_Data.dta'),demographic=file.path(RAW,'CHARLS2011/Data/demographic_background.dta'))
hashes<-vapply(sources,function(f)digest(file=f,algo='sha256'),'')
wj<-function(x,p)write_json(x,file.path(ROOT,p),pretty=TRUE,auto_unbox=TRUE,na='null',digits=16)
csv<-function(x,p)write.csv(x,file.path(ROOT,p),row.names=FALSE,na='')
update<-function(s,m){cat(s,m,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(s,m)}
update('charls_baseline','Reading exact baseline sources and retaining cohort identity')
d<-readRDS(sources['cohort']); f<-readRDS(sources['frame'])
vars<-c('ID','householdID','communityID','ragender','raeduc_c','r1agey','r1mstat','h1rural','r1rural2','r1shlta','r1adlab_c','r1itearn','hh1itot','hh1ctot','h1child','h1coresd')
h<-read_dta(sources['harmonized'],col_select=all_of(vars));r<-read_dta(sources['demographic'],col_select=all_of(c('ID','householdID','ba002_1','ba004','bd001','be001','be002','rgender')))
stopifnot(!anyDuplicated(h$ID),!anyDuplicated(r$ID),nrow(d)==3006,nrow(f)==nrow(d))
j<-match(d$pid,h$ID);rpid<-paste0(r$householdID,'0',substr(r$ID,nchar(r$ID)-1,nchar(r$ID)));jr<-match(d$pid,rpid)
stopifnot(!anyNA(j),!anyNA(jr),identical(as.character(h$householdID[j]),as.character(d$fid1)))
h<-h[j,];r<-r[jr,]
num<-function(x)as.numeric(x)
valid<-function(x,allowed){a<-num(x);a[!a%in%allowed]<-NA_real_;a}
age<-2011-num(r$ba002_1);age_fallback<-is.na(age);age[age_fallback]<-num(r$ba004)[age_fallback]
# 历史contact1.do第120—122行：无出生年时用同次问卷自报年龄；本队列2例。
stopifnot(identical(age,num(d$age1)),all(age>=60&age<=110))
sex<-valid(r$rgender,1:2)-1
educ<-valid(r$bd001,1:11);edu<-ifelse(is.na(educ),NA_real_,as.numeric(educ>=5))
mar<-valid(r$be001,1:6);partner<-valid(r$be002,1:2)
married<-ifelse(mar%in%1:2,1,ifelse(!is.na(mar)&partner==1,1,ifelse(!is.na(mar)&partner==2,0,NA_real_)))
# be002 为非在婚者追问：不将未知回答当“无伴侣”。
urban<-1-valid(h$h1rural,0:1);health<-valid(h$r1shlta,1:5);adl<-valid(h$r1adlab_c,0:6)
inc<-num(h$hh1itot);cons<-num(h$hh1ctot);cons[cons<0]<-NA_real_
earn<-num(h$r1itearn)
cv<-data.frame(pid=d$pid,fid=d$fid1,community=as.character(h$communityID),age=age,female=sex,edu_junior=edu,urban=urban,
 partnered=married,health_poorer=health,adl_difficulties=adl,n_reported_valid=d$n1,
 hh_income=inc,hh_income_asinh=asinh(inc/1000),hh_consumption=cons,hh_consumption_log=log1p(cons),
 work_earnings=earn,rural_hukou=valid(h$r1rural2,0:1),coresident_child=valid(h$h1coresd,0:1),living_children=num(h$h1child))
stopifnot(all(is.na(cv$female)|cv$female%in%0:1),all(is.na(cv$edu_junior)|cv$edu_junior%in%0:1),all(is.na(cv$urban)|cv$urban%in%0:1))
main<-c('age','female','edu_junior','urban','partnered','n_reported_valid','health_poorer','adl_difficulties')
extended<-c(main,'hh_income_asinh')
out<-cbind(cv,f[setdiff(names(f),'fid')]);saveRDS(out,file.path(ROOT,'private/charls_covariate_cohort.rds'))
saveRDS(list(raw_harmonized=h,raw_demographic=r,cohort=d),file.path(ROOT,'private/charls_covariate_raw_audit.rds'))
missing<-do.call(rbind,lapply(setdiff(names(cv),c('pid','fid','community')),function(v){x<-cv[[v]];data.frame(variable=v,n=length(x),observed=sum(!is.na(x)),missing=sum(is.na(x)),missing_pct=100*mean(is.na(x)),min=min(x,na.rm=TRUE),max=max(x,na.rm=TRUE),zero=sum(x==0,na.rm=TRUE),negative=sum(x<0,na.rm=TRUE))}))
csv(missing,'results/CHARLS_BASELINE_MISSINGNESS.csv')
freq<-do.call(rbind,lapply(c('female','edu_junior','urban','partnered','health_poorer','adl_difficulties','n_reported_valid'),function(v){t<-table(cv[[v]],useNA='ifany');data.frame(variable=v,value=names(t),n=as.integer(t))}))
csv(freq,'results/CHARLS_BASELINE_FREQUENCIES.csv')
tags<-do.call(rbind,lapply(setdiff(vars,c('ID','householdID','communityID')),function(v){x<-h[[v]];tag<-ifelse(!is.na(x),'observed',ifelse(is_tagged_na(x),paste0('.',na_tag(x)),'.'));t<-table(tag);data.frame(variable=v,missing_code=names(t),n=as.integer(t))}))
csv(tags,'audit/CHARLS_HARMONIZED_MISSING_CODES.csv')
comparison<-data.frame(check=c('raw_age_matches_prepared_cohort','harmonized_age_disagrees','harmonized_age_under60','harmonized_age_missing','raw_gender_vs_harmonized','raw_education_ge_junior_vs_harmonized','raw_partnered_vs_harmonized','living_children_less_than_valid_reported','main_complete_cases','expanded_income_complete_cases','consumption_sensitivity_complete_cases'),
 n=c(sum(age==d$age1),sum(num(h$r1agey)!=age,na.rm=TRUE),sum(h$r1agey<60,na.rm=TRUE),sum(is.na(h$r1agey)),sum(num(h$ragender)!=num(r$rgender),na.rm=TRUE),sum(edu!=(num(h$raeduc_c)>=5),na.rm=TRUE),sum(married!=(num(h$r1mstat)%in%c(1,3)),na.rm=TRUE),sum(cv$living_children<cv$n_reported_valid,na.rm=TRUE),sum(complete.cases(cv[main])),sum(complete.cases(cv[extended])),sum(complete.cases(cv[c(main,'hh_consumption_log')]))))
csv(comparison,'audit/CHARLS_BASELINE_SOURCE_COMPARISON.csv')
bywave<-do.call(rbind,lapply(1:5,function(k){miss<-is.na(d[[paste0('y',k)]]);data.frame(year=c(2011,2013,2015,2018,2020)[k],N=nrow(d),Y_missing=sum(miss),Y_missing_with_cov_missing=sum(miss&!complete.cases(cv[main])),Y_observed_with_cov_missing=sum(!miss&!complete.cases(cv[main])),X_missing=sum(is.na(d[[paste0('x',k)]])))}))
csv(bywave,'results/CHARLS_COVARIATE_WAVE_MISSINGNESS.csv')
shared<-c('urban','hh_income','hh_consumption','living_children','coresident_child')
viol<-sapply(shared,function(v)sum(tapply(cv[[v]],cv$fid,function(x)length(unique(x[!is.na(x)]))>1)))
stopifnot(!any(viol));csv(data.frame(variable=shared,inconsistent_households=viol),'audit/CHARLS_HOUSEHOLD_SHARED_CHECK.csv')
dictionary<-data.frame(variable=c(main,'hh_income_asinh','hh_consumption_log','work_earnings','living_children','rural_hukou','coresident_child'),
 source=c('2011 demographic ba002_1, ba004 fallback','2011 demographic rgender','2011 demographic bd001','Harmonized h1rural','2011 demographic be001/be002','frozen cohort n1','Harmonized r1shlta','Harmonized r1adlab_c','Harmonized hh1itot','Harmonized hh1ctot','Harmonized r1itearn','Harmonized h1child','Harmonized r1rural2','Harmonized h1coresd'),
 transformation=c('2011 - birth year; missing birth year uses same-wave reported age ba004 (2 cases); centered/scaled only within model copy','female=1 male=0','>=5 junior high or above','1-h1rural','married codes1/2 or nonmarried with be002=1; unknown retained missing','number of children with valid 2011 meeting-frequency report; not total living children','1 very good to5 very poor; categorical dummies in model','integer0-6; retain original missing','asinh(household net income/1000); negatives retained','log1p(nonnegative household consumption)','earnings after tax, NOT total personal income','retain audit only: conflicts with valid reported count','0 urban 1 rural','0 no 1 yes'),
 role=c(rep('primary_adjustment',length(main)),'expanded_adjustment','alternative_resource_sensitivity','auxiliary_only','audit_only','sensitivity_only','excluded_from_primary_contact_definition_overlap'))
csv(dictionary,'contracts/CHARLS_BASELINE_DICTIONARY.csv')
plan<-list(status='PREPARED_NOT_IMPUTED_NOT_ESTIMATED',N=nrow(cv),households=length(unique(cv$fid)),communities=length(unique(cv$community)),
 main_adjustment=main,expanded_adjustment=extended,resource_sensitivity=c(main,'hh_consumption_log'),
 primary_missing_targets=main[colSums(is.na(cv[main]))>0],main_complete_cases=sum(complete.cases(cv[main])),
 imputation=list(main_m=20,extended_m=40,seed=26101541,maxit_initial=20,
  targets='Only missing baseline covariates; PMM5 for bounded ADL and monetary amounts. Impute raw money then passive transformations. Binary variables logistic only if newly missing.',
  auxiliaries='Baseline covariates and all five X/Y observations, wave-response masks. If chained equations fill auxiliary X/Y, restore exact original X/Y missing mask before Mplus FIML.',
  household='Financial variables once per household; map back. Here N equals household count, so no duplicate-person household draws.',
  admission='Preserve observed cells and source hashes; range and household checks; trace/chain checks; compare imputations and MCSE/SE<=0.1 for reported paths. Do not select on p-values.',
  future_interactions='This plan is for adjusted PP main associations. Do not automatically reuse it for H4 or SX*Z0: specify a compatible branch-specific imputation model, including relevant joint structure; passive multiplication alone is not a guarantee.',
  stopping='At most one diagnosed iteration increase to40; if convergence/compatibility fails report incomplete, do not pool subset.'),
 missing_scope=list(trajectories='Observed X/Y only; original masks retained and likelihood handles missing under stated MAR assumptions',
  structural_Z='Sex-composition/rank undefined Z not filled as ordinary missing; branch-specific eligible cohorts and reasons',
  complete_case='Sensitivity only, not default sample reduction',
  nonresponse='No claim that MAR is verified; attrition/death/existing child-list selection remain limitations'),
 estimation=list(next_model='Same continuous PP work model, actual time0,2,4,7,9, baseline fixed scaling; adjust growth factors for frozen core controls',clustering='Use baseline community ID; current cohort one respondent per household. No claim of survey-weighted population inference.',calls_this_batch=0),
 holds=c('Province not inferred from first ID digits; old crosswave province file is not certified baseline geography','Living child count has contradictions: retain reported valid count as measurement adjustment and disclose limitation','No source-data overwrites, no raw data publication'))
wj(plan,'contracts/CHARLS_MISSING_DATA_PLAN.json')
csv(data.frame(source=names(sources),file=unname(sources),sha256=hashes),'audit/CHARLS_COVARIATE_SOURCE_HASHES.csv')
after<-vapply(sources,function(f)digest(file=f,algo='sha256'),'');stopifnot(identical(hashes,after))
wj(list(status='PASS',N=nrow(d),source_unchanged=identical(hashes,after),ids_matched=TRUE,age_raw_verified=TRUE,age_same_wave_fallback=sum(age_fallback),shared_consistent=TRUE,main_missing=as.list(colSums(is.na(cv[main]))),imputations_generated=0,model_calls=0,private_data_sha256=digest(file=file.path(ROOT,'private/charls_covariate_cohort.rds'),algo='sha256')),'results/CHARLS_COVARIATE_RECEIPT.json')
update('charls_covariates_ready','Baseline frame, aggregate audit and missing-data contract saved; no new model')
