# 仅绘制保存的合并结果，不再估计。
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/h41_mi_charls_covariates_20261015'
x<-read.csv(file.path(ROOT,'results/H41_GROUP_CONTRASTS.csv'))
draw<-function(){
 par(mar=c(6,10,3,2));y<-6:1
 plot(x$estimate,y,xlim=range(c(x$lower,x$upper)),ylim=c(.5,6.5),yaxt='n',ylab='',xlab='Conditional coefficient and 95% MI interval',pch=19,col='#245B83',main='CFPS H4.1: SD by baseline education')
 axis(2,at=y,labels=c('IY: primary or below','IY: junior high or above','IY: education difference','SY: primary or below','SY: junior high or above','SY: education difference'),las=1,cex.axis=.85)
 abline(v=0,lty=2,col='grey55');segments(x$lower,y,x$upper,y,col='#245B83',lwd=2)
 mtext('10 imputations; joint D1 p = 0.304. Not the full H4 or dynamic moderation test.',side=1,line=4.6,cex=.7)
}
pdf(file.path(ROOT,'results/H41_GROUP_CONTRASTS.pdf'),width=9,height=5);draw();dev.off()
png(file.path(ROOT,'results/H41_GROUP_CONTRASTS.png'),width=1500,height=850,res=160);draw();dev.off()
