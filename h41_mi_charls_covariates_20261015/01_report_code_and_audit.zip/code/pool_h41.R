# 十份合法估计后合并；不平均p值，不把起点重复当插补成员。
library(jsonlite);library(mitml)
ROOT<-'<LOCAL_USER_HOME>/pp_lgcm_review/h41_mi_charls_covariates_20261015'
Sys.setenv(R2E_ROOT=ROOT);source(file.path(ROOT,'code/r2e_local.R'),local=TRUE)
stopifnot(rj(file.path(ROOT,'results/FAMILY_STATUS.json'))$status=='TEN_USABLE_PENDING_POOLING')
members<-rj(file.path(ROOT,'results/MI_MEMBERS.json'));stopifnot(length(members)==10L)
labs<-c('bii','bis','bss','bsyiy','gi0','gs0','gizg','gszg');Q<-matrix(NA,10,8,dimnames=list(sprintf('MI%02d',1:10),labs));U<-list();rows<-list();ds<-list()
for(k in 1:10){
 d<-members[[sprintf('MI%02d',k)]]$source_dir;r<-rj(file.path(d,'receipt.json'));stopifnot(r$status=='USABLE',identical(hashf(file.path(d,'model.out')),r$output_sha256))
 key<-read.csv(file.path(d,'key_paths.csv'));key<-key[match(labs,key$label),];stopifnot(!anyNA(key$parameter))
 V<-as.matrix(read.csv(file.path(d,'parameter_covariance.csv'),header=FALSE));Q[k,]<-key$estimate;U[[k]]<-V[key$parameter,key$parameter];dimnames(U[[k]])<-list(labs,labs)
 stopifnot(max(abs(diag(U[[k]])-key$se^2))<1e-6)
 rows[[k]]<-data.frame(member=k,source_dir=d,output_sha256=hashf(file.path(d,'model.out')),data_sha256=hashf(file.path(d,'data.dat')),SY_residual=r$sy,status=r$status)
 ds[[k]]<-read_dat(file.path(d,'data.dat'),R2D_NAMES)
}
stopifnot(all(vapply(ds,function(x)nrow(x)==nrow(ds[[1]]),logical(1))))
fixed<-c('fid',paste0('x',1:5),paste0('y',1:5),'z0')
stopifnot(all(vapply(ds,function(x)identical(x[fixed],ds[[1]][fixed]),logical(1))))
vary<-sapply(setdiff(names(ds[[1]]),fixed),function(v)sum(Reduce('|',lapply(ds,function(x)ifelse(is.na(x[[v]])&is.na(ds[[1]][[v]]),FALSE,is.na(x[[v]])!=is.na(ds[[1]][[v]])|abs(x[[v]]-ds[[1]][[v]])>1e-12))),na.rm=TRUE))
csv(data.frame(variable=names(vary),rows_varying_across_members=vary),file.path(ROOT,'audit/CFPS_IMPUTATION_VARIATION.csv'))
po<-rubin_pool(Q,U);tab<-data.frame(label=labs,po$table,row.names=NULL);csv(tab,file.path(ROOT,'results/H41_POOLED_PATHS.csv'))
qq<-lapply(1:10,function(k)setNames(Q[k,],labs))
joint<-mitml::testConstraints(qhat=qq,uhat=U,constraints=c('gizg','gszg'),method='D1')
jj<-data.frame(family='H4.1',Z='SD',G='EDU',F=joint$test[1,1],df1=joint$test[1,2],df2=joint$test[1,3],p=joint$test[1,4],RIV=joint$test[1,5],bonferroni_p_12=min(1,12*joint$test[1,4]),remaining_family_tests=11)
csv(jj,file.path(ROOT,'results/H41_JOINT_D1.csv'));writeLines(capture.output(print(joint)),file.path(ROOT,'results/H41_JOINT_D1.txt'))
cs<-list(IY_Z0_lowedu=c(gi0=1),IY_Z0_highedu=c(gi0=1,gizg=1),IY_difference=c(gizg=1),SY_Z0_lowedu=c(gs0=1),SY_Z0_highedu=c(gs0=1,gszg=1),SY_difference=c(gszg=1))
cc<-do.call(rbind,lapply(names(cs),function(n){a<-setNames(rep(0,8),labs);a[names(cs[[n]])]<-cs[[n]];data.frame(contrast=n,pool_contrast(Q,U,a),row.names=NULL)}));csv(cc,file.path(ROOT,'results/H41_GROUP_CONTRASTS.csv'))
csv(data.frame(member=1:10,Q),file.path(ROOT,'results/H41_MEMBER_ESTIMATES.csv'))
uu<-do.call(rbind,lapply(1:10,function(k){a<-expand.grid(row=labs,column=labs,stringsAsFactors=FALSE);data.frame(member=k,a,covariance=as.vector(U[[k]]))}));csv(uu,file.path(ROOT,'results/H41_MEMBER_COVARIANCES.csv'))
csv(do.call(rbind,rows),file.path(ROOT,'audit/H41_MEMBER_SOURCES.csv'))
wj(list(status='H41_SD_EDU_10_MI_COMPLETE',members=10,N=nrow(ds[[1]]),households=length(unique(ds[[1]]$fid)),primary_test=as.list(jj[1,]),
 inference='Conditional on frozen corrected control imputations, observed baseline Z0 definition and working model; one of 12 registered H4.1 specifications, not four dynamic moderation families or full H4',
 MI_compatibility='Upstream FCS working model was not established as congenial to all interactions; education differs for2 participants across imputations. Complete estimation and correct pooling do not close that substantive-model compatibility limitation.',
 education_varies_across_MI=unname(vary['c2']),method='mitml::testConstraints D1, MLR TECH3 within-imputation covariance; Rubin path pooling with large-sample complete-data df and finite-MI df',
 multiplicity='Interim conservative Bonferroni over fixed12; final Holm pending remaining tests',mitml_version=as.character(packageVersion('mitml')),source='https://search.r-project.org/CRAN/refmans/mitml/html/testConstraints.html'),file.path(ROOT,'results/H41_POOLING_RECEIPT.json'))
cat('H41_POOLING_COMPLETE\n');print(jj);print(cc)
