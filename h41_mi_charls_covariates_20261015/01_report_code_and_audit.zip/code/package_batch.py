"""仅发布显式列明的汇总证据；真实数据不进入公开包。"""
from pathlib import Path
import json,csv,hashlib,zipfile,io,re
root=Path('<LOCAL_USER_HOME>/pp_lgcm_review/h41_mi_charls_covariates_20261015')
old=Path('<LOCAL_USER_HOME>/pp_lgcm_review/reopen_observed_charls_20261015')
stage=root/'public_stage';stage.mkdir(exist_ok=True)
names='''reports/REPORT.md
reports/FOR_WEB_REVIEWERS.md
reports/BATCH_RECEIPT.json
contracts/RUN_CONTRACT.json
contracts/CHARLS_BASELINE_DICTIONARY.csv
contracts/CHARLS_MISSING_DATA_PLAN.json
results/CALLS.csv
results/H4_REGISTER_UPDATED.csv
results/MI01_START_COMPARISON.json
results/FAMILY_STATUS.json
results/H41_POOLED_PATHS.csv
results/H41_JOINT_D1.csv
results/H41_JOINT_D1.txt
results/H41_GROUP_CONTRASTS.csv
results/H41_GROUP_CONTRASTS.png
results/H41_GROUP_CONTRASTS.pdf
results/H41_MEMBER_ESTIMATES.csv
results/H41_MEMBER_COVARIANCES.csv
results/H41_POOLING_RECEIPT.json
results/CHARLS_BASELINE_MISSINGNESS.csv
results/CHARLS_BASELINE_FREQUENCIES.csv
results/CHARLS_COVARIATE_WAVE_MISSINGNESS.csv
results/CHARLS_COVARIATE_RECEIPT.json
audit/H41_MEMBER_SOURCES.csv
audit/H41_INDEPENDENT_POOLING.json
audit/CFPS_IMPUTATION_VARIATION.csv
audit/CHARLS_BASELINE_SOURCE_COMPARISON.csv
audit/CHARLS_HARMONIZED_MISSING_CODES.csv
audit/CHARLS_HOUSEHOLD_SHARED_CHECK.csv
audit/CHARLS_COVARIATE_SOURCE_HASHES.csv
audit/EXECUTION_REPAIRS.json
audit/CLAUDER_COMPLETION.json
audit/R_SESSION_INFO.txt
code/h41_family.R
code/charls_covariates.R
code/pool_h41.R
code/plot_h41.R
code/verify_pooling.py
code/package_batch.py
code/pilot.R
code/r2e_local.R
code/r2e_tools.R
code/r2e_upstream_math.R
code/engine.py
code/run_one.R
code/reused_hierarchical_mi_reference.R'''.splitlines()
selected={n:root/n for n in names}
model_names=[r['model'] for r in csv.DictReader((root/'results/CALLS.csv').open(encoding='utf-8-sig'))]
modeldirs=[(f'models/{n}',root/'models'/n) for n in model_names]+[('reused_models/CFPS_SD_H41_EDU_MI01',old/'models/CFPS_SD_H41_EDU_MI01')]
model_files=['model.inp','model.out','engine_receipt.json','receipt.json','validation.json','parameters_high_precision.csv','key_paths.csv','matrix_values.csv','tech1_parameter_map.csv','parameter_covariance.csv','estimates.dat','tech3.dat']
for prefix,d in modeldirs:
 for f in model_files:
  assert (d/f).is_file(),(d,f)
  selected[prefix+'/'+f]=d/f
sha=lambda b:hashlib.sha256(b).hexdigest()
payload={};manifest=[]
for n,p in selected.items():
 assert p.is_file() and 'private/' not in n and p.name not in ['data.dat','job.json'] and p.suffix!='.rds'
 b=p.read_bytes();orig=sha(b);changed=False
 if p.suffix.lower() not in ['.pdf','.png']:
  s=b.decode('utf-8-sig')
  for prefix in ['<LOCAL_USER_HOME>','<LOCAL_USER_HOME>','C:\\\\Users\\\\LZHS','<LOCAL_USER_HOME>','<LOCAL_USER_HOME>']:
   if prefix in s:s=s.replace(prefix,'<LOCAL_USER_HOME>');changed=True
  assert not re.search(r'(?i)(?:api[_-]?key|access_token)\s*[:=]\s*["\']?[A-Za-z0-9_-]{20,}',s)
  if p.suffix=='.csv' and p.name!='parameter_covariance.csv':
   hdr=next(csv.reader(io.StringIO(s)),[])
   assert not set(x.lower() for x in hdr)&{'pid','fid','householdid','communityid','id'},(n,hdr)
  b=s.encode('utf-8')
 payload[n]=b;manifest.append({'path':n,'bytes':len(b),'sha256':sha(b),'local_source_sha256':orig,'paths_redacted':changed})
payload['PAYLOAD_MANIFEST.json']=json.dumps(manifest,indent=2,ensure_ascii=False).encode()
packages=[]
for models,fn in [(False,'01_report_code_and_audit.zip'),(True,'02_model_evidence.zip')]:
 chosen=[n for n in payload if n.startswith(('models/','reused_models/'))==models]
 zpath=stage/fn
 with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n in chosen:z.writestr(n,payload[n])
 assert zpath.stat().st_size<25_000_000
 with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
 packages.append({'file':fn,'bytes':zpath.stat().st_size,'sha256':sha(zpath.read_bytes()),'files':len(chosen)})
for n in ['REPORT.md','FOR_WEB_REVIEWERS.md','BATCH_RECEIPT.json']:(stage/n).write_bytes(payload['reports/'+n])
(stage/'PACKAGE_MANIFEST.json').write_text(json.dumps({'packages':packages,'payload_files':len(payload),'privacy':'Explicit file allowlist; no microdata/IDs/MI objects. Saved estimates.dat and tech3.dat are aggregate parameters and covariance.','reused_MI01':'Included as reused_models; the extra startB is not an imputation member'},ensure_ascii=False,indent=2),encoding='utf-8')
(root/'audit/PUBLIC_FILE_SELECTION.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
(stage/'README.md').write_text('''# H4.1 插补家族完成与 CHARLS 基期准备

**四项调节完整推断、完整 H4 仍未完成。**

[报告](REPORT.md) · [网页评议说明](FOR_WEB_REVIEWERS.md) · [批次回执](BATCH_RECEIPT.json) · [包清单](PACKAGE_MANIFEST.json)

本批完成 H4.1 相对SD×教育十份合法估计与合并，联合D1 P=0.30408；CHARLS 3,006人基期控制数据与缺失处理合同已保存，尚未执行新的插补或调整模型。

两包均小于25MB，不含微观数据。包02含10个不同插补成员和1个起点检查，后者不参与MI合并。没有原样重跑失败CFPS规格，也没有替换已收尾稿件。

方法经验见 [mplusautomation-guide 增量](https://github.com/lzhs1995/clauder-rstudio-workbench/pull/25)。
''',encoding='utf-8')
print(json.dumps({'packages':packages,'payload_files':len(payload),'privacy':'PASS'},ensure_ascii=False))
