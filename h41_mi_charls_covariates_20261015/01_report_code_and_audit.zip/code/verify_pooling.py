"""直接读取各模型高精度参数和协方差，独立复算R合并值与D1。无Mplus调用。"""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
from scipy.stats import t as student_t,f as f_dist
root=Path('<LOCAL_USER_HOME>/pp_lgcm_review/h41_mi_charls_covariates_20261015')
rows=pd.read_csv(root/'audit/H41_MEMBER_SOURCES.csv')
labs=['bii','bis','bss','bsyiy','gi0','gs0','gizg','gszg']
Q=[];U=[]
for row in rows.itertuples():
    p=Path(row.source_dir)
    assert hashlib.sha256((p/'model.out').read_bytes()).hexdigest()==row.output_sha256
    key=pd.read_csv(p/'key_paths.csv').set_index('label').loc[labs]
    full=pd.read_csv(p/'parameters_high_precision.csv').set_index('parameter')
    q=full.loc[key.parameter,'estimate'].to_numpy()
    v=pd.read_csv(p/'parameter_covariance.csv',header=None).to_numpy()
    ix=key.parameter.to_numpy(dtype=int)-1
    Q.append(q);U.append(v[np.ix_(ix,ix)])
Q=np.array(Q);U=np.array(U);m=len(Q);assert m==10
W=U.mean(axis=0);B=np.cov(Q,rowvar=False,ddof=1);T=W+(1+1/m)*B
est=Q.mean(axis=0);se=np.sqrt(T.diagonal());rr=(1+1/m)*B.diagonal()/W.diagonal()
df=(m-1)*(1+1/rr)**2
lo=est-student_t.ppf(.975,df)*se;hi=est+student_t.ppf(.975,df)*se
ref=pd.read_csv(root/'results/H41_POOLED_PATHS.csv').set_index('label').loc[labs]
errors={}
for n,a in [('estimate',est),('se',se),('lower',lo),('upper',hi)]:
    errors[n]=float(np.max(np.abs(ref[n].to_numpy()-a)))
    assert np.allclose(ref[n],a,atol=1e-10,rtol=1e-8),(n,errors[n])
z=[6,7];w=W[np.ix_(z,z)];b=B[np.ix_(z,z)];q=est[z];k=2
r=(1+1/m)*np.trace(b@np.linalg.inv(w))/k
stat=q@np.linalg.solve((1+r)*w,q)/k
v=4+(k*(m-1)-4)*(1+(1-2/(k*(m-1)))/r)**2
p=f_dist.sf(stat,k,v);jr=pd.read_csv(root/'results/H41_JOINT_D1.csv').iloc[0]
assert np.allclose([stat,v,p,r],[jr.F,jr.df2,jr.p,jr.RIV],atol=1e-8,rtol=2e-6)
constraints={'IY_Z0_lowedu':{4:1},'IY_Z0_highedu':{4:1,6:1},'IY_difference':{6:1},'SY_Z0_lowedu':{5:1},'SY_Z0_highedu':{5:1,7:1},'SY_difference':{7:1}}
cr=pd.read_csv(root/'results/H41_GROUP_CONTRASTS.csv').set_index('contrast')
for name,co in constraints.items():
    a=np.zeros(8)
    for i,n in co.items():a[i]=n
    e=float(a@est);s=float(np.sqrt(a@T@a));rel=(1+1/m)*(a@B@a)/(a@W@a);nu=(m-1)*(1+1/rel)**2
    assert np.allclose([e,s,e-student_t.ppf(.975,nu)*s,e+student_t.ppf(.975,nu)*s],cr.loc[name,['estimate','se','lower','upper']].to_numpy(dtype=float),atol=1e-10,rtol=1e-8)
result={'status':'PASS','source':'Saved full parameter tables and covariance, independently indexed by path labels','members':m,'path_checks':8,'contrast_checks':6,'D1':{'F':stat,'df1':k,'df2':v,'p':p,'RIV':r},'max_abs_errors':errors,'new_estimates':0}
(root/'audit/H41_INDEPENDENT_POOLING.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
