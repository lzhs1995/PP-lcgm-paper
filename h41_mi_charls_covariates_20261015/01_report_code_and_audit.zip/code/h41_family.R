# H4.1 新批：复用已通过MI01；仅补起点核验与MI02—10。
OLD <- '<LOCAL_USER_HOME>/pp_lgcm_review/reopen_observed_charls_20261015'
NEW <- '<LOCAL_USER_HOME>/pp_lgcm_review/h41_mi_charls_covariates_20261015'
Sys.setenv(PP_PREPARE_ONLY='1')
source(file.path(NEW,'code/pilot.R'),local=TRUE)
Sys.unsetenv('PP_PREPARE_ONLY')
ROOT <- NEW; Sys.setenv(R2E_ROOT=NEW)
prepare_member <- function(k,second=FALSE) {
 id <- sprintf('CFPS_SD_H41_EDU_MI%02d%s',k,if(second)'_startB' else '')
 d <- file.path(ROOT,'models',id); dir.create(d,showWarnings=FALSE)
 if(file.exists(file.path(d,'job.json')))return(rj(file.path(d,'job.json')))
 si <- custom_spec('H41_EDU')
 src <- file.path(E,'models',sprintf('CFPS_SD_E0_%02d_base',k))
 mm <- make_model(si,src,perturb=second)
 sc <- splice_check(mm$lines,si);stopifnot(isTRUE(sc$ok))
 wj(sc,file.path(d,'splice_check.json'));csv(mm$mapping,file.path(d,'start_mapping.csv'))
 lines <- inp_text(paste('H41 complete MI',id),si$use,wrap90(analysis_r2e('linear')),mm$lines,define=si$define,kind='linear')
 stopifnot(file.copy(datpath('SD',k),file.path(d,'data.dat'),overwrite=FALSE))
 writeLines(lines,file.path(d,'model.inp'))
 job <- list(id=id,root=ROOT,dest=d,spec='H41_EDU',member=k,second_start=second,category='H41',cap_seconds=180,
 rscript=file.path(R.home('bin'),'Rscript.exe'),mplus=MPLUS,source_data=datpath('SD',k),source_start=src,
 hashes=list(model.inp=hashf(file.path(d,'model.inp')),data.dat=hashf(file.path(d,'data.dat'))))
 wj(job,file.path(d,'job.json'));job
}
main <- function() {
 olddir <- file.path(OLD,'models/CFPS_SD_H41_EDU_MI01')
 old <- rj(file.path(olddir,'receipt.json'));stopifnot(old$status=='USABLE',identical(old$output_sha256,hashf(file.path(olddir,'model.out'))))
 stopifnot(identical(hashf(file.path(olddir,'data.dat')),hashf(datpath('SD',1))))
 jobs <- c(list(prepare_member(1,TRUE)),lapply(2:10,prepare_member))
 wj(jobs,file.path(ROOT,'contracts/MI_JOBS.json'))
 b <- run(jobs[[1]])
 comp <- if(b$status=='USABLE') compare_numeric(
 list(key=read.csv(file.path(olddir,'key_paths.csv')),receipt=old),
 list(key=read.csv(file.path(jobs[[1]]$dest,'key_paths.csv')),receipt=b)) else list(passed=FALSE,reason=b$status)
 wj(comp,file.path(ROOT,'results/MI01_START_COMPARISON.json'))
 results <- list(MI01=c(old,list(source_dir=olddir)))
 if(!isTRUE(comp$passed)){
  wj(list(status='STOP_SECOND_START',comparison=comp),file.path(ROOT,'results/FAMILY_STATUS.json'));return(invisible(NULL))
 }
 for(j in jobs[-1]) {
  ans<-run(j);results[[sprintf('MI%02d',j$member)]]<-c(ans,list(source_dir=j$dest))
  wj(results,file.path(ROOT,'results/MI_MEMBERS.json'))
  if(ans$status!='USABLE'){
   wj(list(status='INCOMPLETE_STOPPED',failed=j$id,available=length(results)),file.path(ROOT,'results/FAMILY_STATUS.json'));return(invisible(NULL))
  }
 }
 wj(list(status='TEN_USABLE_PENDING_POOLING',members=10,reused=1,new_members=9,start_check_calls=1,all_sources=lapply(results,function(x)x$source_dir)),file.path(ROOT,'results/FAMILY_STATUS.json'))
 writeLines(capture.output(sessionInfo()),file.path(ROOT,'audit/R_SESSION_INFO.txt'))
 progress('H41_TEN_USABLE','Ten usable members; ready for covariance-aware pooled inference')
}
main()
