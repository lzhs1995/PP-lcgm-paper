"""独立 pandas 原始名单读取与指标复算；不调用 R 构建函数。"""
from pathlib import Path
import json,hashlib
import pandas as pd
import numpy as np
R=Path(__file__).resolve().parents[1]
RAW=Path('<LOCAL_USER>/Desktop/20230505 毕业论文/开题报告/开题报告/CHARLS')
types={n:str for n in ['pid']+[f'fid{k}' for k in range(1,6)]}
old=pd.read_csv(R/'private/charls_cohort_reference.csv',dtype=types)
new=pd.read_csv(R/'private/charls_cohort_roster_candidate_reference.csv',dtype=types)
def stata(p):return pd.read_stata(p,convert_categoricals=False)
def valid(x,lo,hi):return float(x) if pd.notna(x) and lo<=x<=hi else np.nan
def val(row,n):return row[n] if n in row else np.nan
def equal(a,b):return np.allclose(np.asarray(a,dtype=float),np.asarray(b,dtype=float),rtol=0,atol=1e-10,equal_nan=True)
all_checks=[];contrast_checks=[]
for year,k in [(2013,2),(2015,3),(2018,4),(2020,5)]:
 f=stata(RAW/f'CHARLS{year}/Data/Family_Information.dta').set_index('householdID' if year==2020 else 'ID')
 assert f.index.is_unique
 people=dict(zip(old.pid,old.fid5 if year==2020 else old.pid))
 expected=[];mapped={}
 def add(pid,identity,slot,kind,sex,birth,code=np.nan,months=np.nan,cores=False,from_age=False):
  contact=10-float(code) if pd.notna(code) and 1<=code<=9 else np.nan
  restore=pd.isna(contact) and cores
  if restore:contact=9.
  expected.append(dict(pid=pid,identity=identity,slot=slot,kind=kind,sex=sex,birth=birth,code=code,months=months,meet=contact,birth_from_age=from_age,contact_source='coresidence_proxy' if restore else 'reported_frequency' if pd.notna(contact) else 'missing'))
 if year<2018:
  c=stata(RAW/f'CHARLS{year}/Data/Child.dta')
  keep=c.ID.isin(old.pid)&c.alive.eq(1)
  if year==2013:keep &= c.cat.isin([1,2,3,4])
  for _,z in c[keep].iterrows():
   pid=z.ID;s=int(z.childID);row=f.loc[pid];b=valid(z.cb051_1 if year==2013 else z.byear,1800,year);age=valid(z.age,0,130);from_age=pd.isna(b) and pd.notna(age)
   if from_age:b=year-age
   add(pid,f'child:{s}',s,'official_living_child',valid(z.gender,1,2),b,val(row,f'cd003_{s}_'),cores=z.cb053 in (1,2) or pd.notna(z.HHmemberID),from_age=from_age)
   if year==2013 and pd.notna(z.HHmemberID):mapped.setdefault(pid,set()).add(int(z.HHmemberID))
 else:
  t=stata(RAW/'CHARLS2018/Data/Family_Transfer.dta').set_index('ID') if year==2018 else f
  prefix='xchildalive_' if year==2018 else 'xchildpanalive_'
  slots=sorted(int(n[len(prefix):-1]) for n in f.columns if n.startswith(prefix) and n[len(prefix):-1].isdigit())
  for pid,link in people.items():
   if pd.isna(link) or link not in f.index:continue
   row=f.loc[link]
   for s in slots:
    if val(row,f'{prefix}{s}_')!=1:continue
    tr=t.loc[pid] if year==2018 and pid in t.index else row if year==2020 else pd.Series(dtype=float)
    code=val(tr,f'cd003_{s}_' if year==2018 else f'ca015_{s}_');months=val(tr,f'cd003_w4_{s}_' if year==2018 else f'ca014_{s}_')
    cores=months==12 or (year==2018 and val(row,f'cb053_{s}_') in (1,2))
    add(pid,f'child:{s}',s,'living_child' if year==2018 else 'pandemic_alive_child',valid(val(row,f'xchildgender_{s}_'),1,2),valid(val(row,f'xchildbirth_{s}_'),1800,year),code,months,cores)
 prefix='cb005_' if year==2020 else 'a006_'
 slots=sorted(int(n[len(prefix):-1]) for n in f.columns if n.startswith(prefix) and n[len(prefix):-1].isdigit())
 for pid,link in people.items():
  if pd.isna(link) or link not in f.index:continue
  row=f.loc[link]
  for s in slots:
   if val(row,f'{prefix}{s}_')!=(7 if year<2018 else 8):continue
   if year==2013 and s in mapped.get(pid,set()):continue
   if year==2013:
    sex=valid(val(row,f'a002_{s}_'),1,2);birth=valid(val(row,f'a003_1_{s}_'),1800,year)
    if pd.isna(sex):sex=valid(val(row,f'za002_{s}_'),1,2)
    if pd.isna(birth):birth=valid(val(row,f'za003_1_{s}_'),1800,year)
   elif year==2015:sex=valid(val(row,f'a005_w3_{s}_'),1,2);birth=valid(val(row,f'a006_w3_1_{s}_'),1800,year)
   else:
    sex=valid(val(row,('a005_w3_' if year==2018 else 'cb003_')+str(s)+'_'),1,2)
    birth=year-valid(val(row,('a005_w4_' if year==2018 else 'cb004_')+str(s)+'_'),0,130)
   add(pid,f'new_household:{s}',int('11'+str(s)),'additional_household_child',sex,birth,cores=True,from_age=year>=2018)
 e=pd.DataFrame(expected).set_index(['pid','identity']).sort_index()
 actual=pd.read_csv(R/f'private/REBUILT_ROSTER_{year}.csv',dtype={'pid':str}).set_index(['pid','identity']).sort_index()
 assert e.index.equals(actual.index),(year,'roster keys')
 for field in ['slot','sex','birth','code','months','meet']:
  assert equal(e[field],actual[field]),(year,field)
 for field in ['kind','birth_from_age','contact_source']:assert (e[field]==actual[field]).all(),(year,field)
 all_checks.append(dict(year=year,children=len(e),parents=e.index.get_level_values('pid').nunique(),raw_fields_checked=9,status='PASS'))
 out=[]
 for pid,z in e.reset_index().groupby('pid',sort=False):
  z=z[z.meet.notna()];n=len(z)
  values=dict(pid=pid,n=n,x=z.meet.mean() if n>=2 else np.nan,sd=z.meet.std(ddof=1) if n>=2 else np.nan)
  for name in ['gender','oldest','son']:
   values[name]=np.nan
   if name in ('gender','son') and z.sex.isna().any():continue
   if name=='gender':g=z.sex.eq(1)
   else:
    if z.birth.isna().any():continue
    eligible=z.sex.eq(1) if name=='son' else pd.Series(True,index=z.index)
    if not eligible.any():continue
    g=eligible & z.birth.eq(z.loc[eligible,'birth'].min())
    if g.sum()!=1:continue
   if not g.any() or g.all():continue
   values[name]=z.loc[g,'meet'].mean()-z.loc[~g,'meet'].mean()
  out.append(values)
 out=pd.DataFrame(out).set_index('pid').reindex(old.pid)
 for field in ['n','x','sd','gender','oldest','son']:
  assert equal(out[field],new[field+str(k)]),(year,field,'aggregate')
  contrast_checks.append(dict(year=year,field=field,people=len(old),status='PASS'))
changed=[f'{n}{k}' for k in range(2,6) for n in ['n','x','sd','gender','oldest','son']]
for col in set(old)-set(changed):assert old[col].equals(new[col]),col
src=pd.read_csv(R/'audit/REBUILD_SOURCE_HASHES.csv')
for z in src.itertuples():assert hashlib.sha256(Path(z.file).read_bytes()).hexdigest()==z.sha256
pd.DataFrame(all_checks).to_csv(R/'results/INDEPENDENT_REBUILD_FIELDS.csv',index=False)
pd.DataFrame(contrast_checks).to_csv(R/'results/INDEPENDENT_REBUILD_AGGREGATES.csv',index=False)
receipt=dict(status='PASS',method='Separate pandas source loading, eligible-roster reconstruction, field comparison, and direct contrasts',waves=4,roster_rows=sum(x['children'] for x in all_checks),source_fields_checked=9,person_indicator_cells=len(contrast_checks)*len(old),baseline_Y_controls_and_order_unchanged=True,source_hashes_unchanged=True,scope='Numerical reconstruction verified under declared same-wave roster and coresidence-proxy rules. Does not resolve survey reporting contradictions or validate a new longitudinal measurement model.',new_mplus=0,new_MI=0)
(R/'audit/INDEPENDENT_REBUILD_VERIFICATION.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))
