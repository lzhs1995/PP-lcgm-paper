"""只读核对子女/家户编号规则；逐人记录留本地，报告只含聚合值。"""
from pathlib import Path
import json,hashlib
import pandas as pd
import numpy as np
import fitz
R=Path(__file__).resolve().parents[1]
raw=Path('<LOCAL_USER>/Desktop/20230505 毕业论文/开题报告/开题报告/CHARLS')
base=Path('<LOCAL_USER>/Desktop/开题报告/0_data_clo')
co=pd.read_csv(R.parent/'charls_roster_moderation_20261015/private/COHORT_REFERENCE.csv',dtype={'pid':str})
def stata(p,cols=None):return pd.read_stata(p,convert_categoricals=False,columns=cols)
def cell(d,ids,cols):
 out=np.full(len(ids),np.nan)
 for c in set(cols):
  if c in d.columns:
   j=np.where(cols==c)[0];out[j]=pd.to_numeric(d[c].reindex(ids[j]),errors='coerce').to_numpy()
 return out
rows=[]
for y in [2013,2015]:
 f=stata(raw/f'CHARLS{y}/Data/Family_Information.dta').set_index('ID')
 c=stata(raw/f'charls11_20_harmonized/data_{y}/child.dta');c=c[c.ID.isin(co.pid)].copy()
 l=stata(base/f'contact_{y}_long.dta',['pid','ID_c2gc','cb049_','cb051_1_','cd003_']);l=l[l.pid.isin(co.pid)].copy()
 l['slot']=l.ID_c2gc.astype(int);c['slot']=c.childID.astype(int)
 c['canonical_hh_slot']=c.HHmemberID.map(lambda h: int('11'+str(int(h))) if pd.notna(h) else np.nan)
 z=l.merge(c,on=['slot'],how='left',suffixes=('_legacy','_child')) if False else l.merge(c,left_on=['pid','slot'],right_on=['ID','slot'],how='left',validate='one_to_one')
 if y==2013:
  c['raw_hh_slot']=cell(f,c.ID.to_numpy(),np.array([f'xchildmembercv_{i}_' for i in c.slot]))
  both=c.HHmemberID.notna()&c.raw_hh_slot.notna()
  rows.append(dict(year=y,check='official_HHmemberID_vs_raw_xchildmembercv',n=int(both.sum()),different=int((c.loc[both,'HHmemberID']!=c.loc[both,'raw_hh_slot']).sum())))
 missing=z[z.ID.isna()].copy()
 for name,template in [('raw_gender','xchildgender_{}_'),('raw_birth','xchildbyear_{}_' if y==2015 else 'cb051_1_{}_'),('raw_meet_code','cd003_{}_')]:
  missing[name]=cell(f,missing.pid.to_numpy(),np.array([template.format(i) for i in missing.slot]))
 rows.append(dict(year=y,check='legacy_same_childID_unmatched',n=len(missing),legacy_hh=int((missing.slot>=111).sum()),raw_valid_contact=int(missing.raw_meet_code.between(1,9).sum()),raw_valid_sex=int(missing.raw_gender.isin([1,2]).sum()),raw_valid_birth=int(missing.raw_birth.between(1800,y).sum())))
 # 同一 childID 与 HHmemberID 的候选重复；只能在原问卷映射证实后裁定。
 h=z[z.canonical_hh_slot.notna()].copy();h=h.merge(l,left_on=['pid','canonical_hh_slot'],right_on=['pid','slot'],suffixes=('','_hh'),how='inner',validate='one_to_one')
 for v in ['cb049_','cb051_1_','cd003_']:
  both=h[v].notna()&h[v+'_hh'].notna();rows.append(dict(year=y,check='child_vs_hh_candidate_'+v,n=len(h),both=int(both.sum()),different=int((h.loc[both,v]!=h.loc[both,v+'_hh']).sum())))
 h.to_csv(R/f'private/ALIAS_CANDIDATES_{y}.csv',index=False)
 missing.to_csv(R/f'private/UNMATCHED_SAME_CHILD_ID_{y}.csv',index=False)
pd.DataFrame(rows).to_csv(R/'results/DIRECT_ROSTER_KEY_DIAGNOSIS.csv',index=False)
docs={2013:'CHARLS_Wave2_Main_Questionnaire.pdf',2015:'CHARLS_2015_Questionnaire.pdf',2018:'CHARLS_2018_Household_Questionnaire.pdf',2020:'CHARLS_2020_Questionnaire_Chinese.pdf'}
loc=[]
for y,n in docs.items():
 p=raw/f'CHARLS{y}/Document'/n
 with fitz.open(p) as pdf:
  texts=[]
  for i,page in enumerate(pdf):
   text=page.get_text();texts.append(f'\n--- PDF_PAGE_{i+1} ---\n'+text)
   for term in (['XChildMemberCV','XChildMember','CD003','A006'] if y==2013 else ['XChildAlive','XHHChild','A006','XChildMember'] if y==2015 else ['XChildAlive','CB001','A006','XChildMember'] if y==2018 else ['XChildPanAliveName','XHHMember','CB001','CB002']):
    if term.lower() in text.lower():loc.append(dict(year=y,pdf_page=i+1,term=term))
  (R/f'private/QUESTIONNAIRE_KEY_{y}.txt').write_text(''.join(texts),encoding='utf-8')
pd.DataFrame(loc).to_csv(R/'audit/ROSTER_QUESTIONNAIRE_PAGES.csv',index=False)
print(pd.DataFrame(rows).to_string(index=False))
