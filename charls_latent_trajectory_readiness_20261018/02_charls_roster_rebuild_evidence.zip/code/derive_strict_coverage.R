# 全名单差异与可用作答子集分开，不把结构性未定义值送入普通插补。
library(jsonlite)
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_latent_trajectory_readiness_20261018'
b<-readRDS('<LOCAL_USER>/pp_lgcm_review/charls_roster_moderation_20261015/private/CONSTRUCTED_BASELINE_CONTRASTS.rds')
c<-readRDS(file.path(ROOT,'private/charls_cohort_roster_candidate.rds'))
z<-readRDS(file.path(ROOT,'private/REBUILT_ROSTERS.rds'))
state<-function(d,type){
 if(is.null(d)||!nrow(d))return('NO_LINKED_ROSTER')
 if(nrow(d)<2)return('STRUCTURAL_FEWER_THAN_TWO')
 if(type%in%c('gender','son')){if(anyNA(d$sex))return('MISSING_CHILD_SEX');if(type=='gender'&&length(unique(d$sex))<2)return('STRUCTURAL_ONE_SEX_ONLY');if(type=='son'&&!any(d$sex==1))return('STRUCTURAL_NO_SON')}
 if(type%in%c('oldest','son')){if(anyNA(d$birth))return('MISSING_BIRTH_YEAR');g<-if(type=='son')d$sex==1 else rep(TRUE,nrow(d));if(sum(g&d$birth==min(d$birth[g]))!=1)return('AMBIGUOUS_EARLIEST_BIRTH_YEAR')}
 if(anyNA(d$meet))return('MISSING_CHILD_CONTACT')
 'DEFINED'
}
value<-function(d,type){v<-d$meet;if(type=='sd')return(sd(v));if(type=='gender')g<-d$sex==1 else {a<-if(type=='son')d$sex==1 else rep(TRUE,nrow(d));g<-a&d$birth==min(d$birth[a])};mean(v[g])-mean(v[!g])}
rows<-list();base<-b$all_listed[match(c$pid,b$all_listed$pid),];stopifnot(identical(as.character(base$pid),as.character(c$pid)))
for(v in c('sd','gender','oldest','son'))rows[[length(rows)+1L]]<-data.frame(pid=c$pid,year=2011,indicator=v,status=base[[paste0(v,'_status')]],absolute=base[[paste0(v,'_absolute')]],relative=base[[paste0(v,'_relative')]],baseline_source_compatible=b$legacy_keys_compatible)
for(y in names(z)){sp<-split(z[[y]],z[[y]]$pid);for(v in c('sd','gender','oldest','son')){
 st<-vapply(c$pid,function(p)state(sp[[p]],v),'');av<-vapply(seq_along(st),function(i)if(st[i]=='DEFINED')value(sp[[c$pid[i]]],v)else NA_real_,0.0);mu<-vapply(c$pid,function(p){d<-sp[[p]];if(is.null(d))NA_real_ else mean(d$meet)},0.0)
 rows[[length(rows)+1L]]<-data.frame(pid=c$pid,year=as.integer(y),indicator=v,status=st,absolute=av,relative=av/mu,baseline_source_compatible=b$legacy_keys_compatible)
}}
d<-do.call(rbind,rows);stopifnot(nrow(d)==nrow(c)*5*4,all(is.na(d$absolute[d$status!='DEFINED'])))
saveRDS(d,file.path(ROOT,'private/STRICT_FIVEWAVE_CONTRASTS.rds'));write.csv(d,file.path(ROOT,'private/STRICT_FIVEWAVE_CONTRASTS.csv'),row.names=FALSE,na='')
t<-aggregate(rep(1L,nrow(d)),by=d[c('year','indicator','status','baseline_source_compatible')],FUN=sum);names(t)[5]<-'N';write.csv(t,file.path(ROOT,'results/STRICT_FIVEWAVE_MISSINGNESS.csv'),row.names=FALSE)
coverage<-do.call(rbind,lapply(split(d,d$indicator),function(a){n<-tapply(a$status=='DEFINED',a$pid,sum);eligible<-a$pid[a$year==2011&a$baseline_source_compatible&a$status=='DEFINED'];data.frame(indicator=a$indicator[1],cohort=length(n),at_least_two=sum(n>=2),at_least_three=sum(n>=3),all_five=sum(n==5),baseline_defined_and_source_compatible=length(eligible),baseline_eligible_at_least_two=sum(n[eligible]>=2),baseline_eligible_at_least_three=sum(n[eligible]>=3))}))
write.csv(coverage,file.path(ROOT,'results/STRICT_TRAJECTORY_COVERAGE.csv'),row.names=FALSE)
write_json(list(status='STRICT_COVERAGE_READY_NOT_MODEL_READY',definition='Full linked same-wave roster, all required contact/sex/birth observed; unique oldest birth year; absolute primary, relative sensitivity',missing_policy='Structural absence, incomplete child information, and ambiguous ranks stay distinct; no direct MI of derived Z. FIML by itself does not establish validity for structurally undefined outcomes.',baseline_unmatched=22,working_candidate='Follow-up mean/SD and contrasts from available contacts are separate from strict all-listed contrasts.',new_model_calls=0,new_MI=0),file.path(ROOT,'audit/STRICT_COVERAGE_RECEIPT.json'),auto_unbox=TRUE,pretty=TRUE)
print(coverage)
