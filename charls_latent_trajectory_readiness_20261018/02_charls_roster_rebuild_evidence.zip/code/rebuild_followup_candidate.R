# 按同波名单重建候选；不更换3006人队列，不修改源文件，不送入估计。
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_latent_trajectory_readiness_20261018'
RAW<-'<LOCAL_USER>/Desktop/20230505 毕业论文/开题报告/开题报告/CHARLS'
library(haven);library(jsonlite);library(digest)
target<-file.path(ROOT,'private/charls_cohort_roster_candidate.rds')
stopifnot(!file.exists(target))
origin<-'<LOCAL_USER>/pp_lgcm_review/reopen_observed_charls_20261015/private/charls_cohort.rds'
original_hash<-digest(file=origin,algo='sha256');old<-readRDS(origin);new<-old
manifest<-list();summ<-list();impacts<-list();rosters<-list();excluded<-list()
readsrc<-function(p){manifest[[length(manifest)+1L]]<<-data.frame(file=p,sha256=digest(file=p,algo='sha256'));read_dta(p)}
clean<-function(x,valid=NULL,lo=NULL,hi=NULL){x<-as.numeric(x);if(!is.null(valid))x[!x%in%valid]<-NA_real_;if(!is.null(lo))x[is.na(x)|x<lo|x>hi]<-NA_real_;x}
cell<-function(d,idx,cols){v<-rep(NA_real_,length(idx));for(n in unique(cols)){j<-which(cols==n);if(n%in%names(d))v[j]<-as.numeric(d[[n]])[idx[j]]};v}
fallback<-function(a,b){a[is.na(a)]<-b[is.na(a)];a}
measure<-function(a){z<-a[!is.na(a$meet),];v<-z$meet;gap<-function(g){if(anyNA(g)||!any(g)||all(g))return(NA_real_);mean(v[g])-mean(v[!g])};rankgap<-function(son=FALSE){if(anyNA(z$birth)||(son&&anyNA(z$sex)))return(NA_real_);g<-if(son)z$sex==1 else rep(TRUE,length(v));if(!any(g))return(NA_real_);top<-g&z$birth==min(z$birth[g]);if(sum(top)!=1)return(NA_real_);gap(top)}
 data.frame(n=length(v),n_roster=nrow(a),x=if(length(v)>=2)mean(v)else NA_real_,sd=if(length(v)>=2)sd(v)else NA_real_,gender=gap(z$sex==1),oldest=rankgap(),son=rankgap(TRUE))}
for(y in c(2013,2015,2018,2020)){
 cat('重建同波名单 ',y,'\n');flush.console();k<-match(y,c(2011,2013,2015,2018,2020))
 f<-readsrc(file.path(RAW,paste0('CHARLS',y),'Data/Family_Information.dta'))
 r<-list();dup<-0L
 if(y%in%c(2013,2015)){
  c<-readsrc(file.path(RAW,paste0('CHARLS',y),'Data/Child.dta'));c<-c[as.character(c$ID)%in%old$pid,]
  known<-!is.na(c$alive)&c$alive==1
  if(y==2013)known<-known&!is.na(c$cat)&c$cat%in%1:4
  c<-c[known,];ix<-match(c$ID,f$ID);slot<-as.integer(c$childID)
  birth<-if(y==2013)clean(c$cb051_1,lo=1800,hi=y)else clean(c$byear,lo=1800,hi=y)
  age<-clean(c$age,lo=0,hi=130);from_age<-is.na(birth)&!is.na(age);birth<-fallback(birth,y-age)
  code<-cell(f,ix,paste0('cd003_',slot,'_'));meet<-ifelse(code%in%1:9,10-code,NA_real_)
  cores<-c$cb053%in%1:2|!is.na(c$HHmemberID);restore<-is.na(meet)&cores;meet[restore]<-9
  r[[1]]<-data.frame(pid=as.character(c$ID),identity=paste0('child:',slot),slot=slot,kind='official_living_child',sex=clean(c$gender,1:2),birth=birth,birth_from_age=from_age,code=code,months=NA_real_,meet=meet,contact_source=ifelse(restore,'coresidence_proxy',ifelse(!is.na(meet),'reported_frequency','missing')))
 }else{
  idx<-match(if(y==2020)old$fid5 else old$pid,if(y==2020)as.character(f$householdID)else as.character(f$ID))
  # 2020问卷保持原i编号，并允许疫情初期健在、调查时已去世的子女回答过去一年题。
  stems<-grep(if(y==2020)'^xchildpanalive_[0-9]+_$'else'^xchildalive_[0-9]+_$',names(f),value=TRUE)
  if(y==2018){t<-readsrc(file.path(RAW,'CHARLS2018/Data/Family_Transfer.dta'));ti<-match(old$pid,as.character(t$ID))}
  for(n in stems){s<-as.integer(sub('^.*_([0-9]+)_$','\\1',n));live<-cell(f,idx,rep(n,length(idx)))%in%1;keep<-which(live);if(!length(keep))next
   birth<-clean(cell(f,idx[keep],rep(paste0('xchildbirth_',s,'_'),length(keep))),lo=1800,hi=y)
   sex<-clean(cell(f,idx[keep],rep(paste0('xchildgender_',s,'_'),length(keep))),1:2)
   if(y==2018){code<-cell(t,ti[keep],rep(paste0('cd003_',s,'_'),length(keep)));months<-cell(t,ti[keep],rep(paste0('cd003_w4_',s,'_'),length(keep)));res<-cell(f,idx[keep],rep(paste0('cb053_',s,'_'),length(keep)))}else{code<-cell(f,idx[keep],rep(paste0('ca015_',s,'_'),length(keep)));months<-cell(f,idx[keep],rep(paste0('ca014_',s,'_'),length(keep)));res<-rep(NA_real_,length(keep))}
   meet<-ifelse(code%in%1:9,10-code,NA_real_);restore<-is.na(meet)&(months%in%12|res%in%1:2);meet[restore]<-9
   r[[length(r)+1L]]<-data.frame(pid=old$pid[keep],identity=paste0('child:',s),slot=s,kind=if(y==2020)'pandemic_alive_child'else'living_child',sex=sex,birth=birth,birth_from_age=FALSE,code=code,months=months,meet=meet,contact_source=ifelse(restore,'coresidence_proxy',ifelse(!is.na(meet),'reported_frequency','missing')))
  }
 }
 # 问卷中的其他家户成员：2013用显式映射消除主子女名单重复；后期仅新增成员分支。
 if(y%in%c(2013,2015,2018))stems<-grep('^a006_[0-9]+_$',names(f),value=TRUE)else stems<-grep('^cb005_[0-9]+_$',names(f),value=TRUE)
 idx<-match(if(y==2020)old$fid5 else old$pid,if(y==2020)as.character(f$householdID)else as.character(f$ID))
 mapped<-if(y==2013)paste(as.character(c$ID),as.integer(c$HHmemberID))else character()
 for(n in stems){s<-as.integer(sub('^.*_([0-9]+)_$','\\1',n));role<-cell(f,idx,rep(n,length(idx)));keep<-which(role%in%if(y%in%c(2013,2015))7 else 8)
  if(!length(keep))next
  if(y==2013){isdup<-paste(old$pid[keep],s)%in%mapped;dup<-dup+sum(isdup);keep<-keep[!isdup]}
  if(!length(keep))next
  if(y==2013){sex<-fallback(clean(cell(f,idx[keep],rep(paste0('a002_',s,'_'),length(keep))),1:2),clean(cell(f,idx[keep],rep(paste0('za002_',s,'_'),length(keep))),1:2));birth<-fallback(clean(cell(f,idx[keep],rep(paste0('a003_1_',s,'_'),length(keep))),lo=1800,hi=y),clean(cell(f,idx[keep],rep(paste0('za003_1_',s,'_'),length(keep))),lo=1800,hi=y));fa<-FALSE
  }else if(y==2015){sex<-clean(cell(f,idx[keep],rep(paste0('a005_w3_',s,'_'),length(keep))),1:2);birth<-clean(cell(f,idx[keep],rep(paste0('a006_w3_1_',s,'_'),length(keep))),lo=1800,hi=y);fa<-FALSE
  }else{sex<-clean(cell(f,idx[keep],rep(paste0(if(y==2018)'a005_w3_'else'cb003_',s,'_'),length(keep))),1:2);age<-clean(cell(f,idx[keep],rep(paste0(if(y==2018)'a005_w4_'else'cb004_',s,'_'),length(keep))),lo=0,hi=130);birth<-y-age;fa<-TRUE}
  r[[length(r)+1L]]<-data.frame(pid=old$pid[keep],identity=paste0('new_household:',s),slot=as.integer(paste0('11',s)),kind='additional_household_child',sex=sex,birth=birth,birth_from_age=fa,code=NA_real_,months=NA_real_,meet=9,contact_source='coresidence_proxy')
 }
 r<-do.call(rbind,r);stopifnot(!anyDuplicated(paste(r$pid,r$identity)),all(r$pid%in%old$pid));r$year<-y
 r<-r[order(r$pid,r$identity),];rosters[[as.character(y)]]<-r
 values<-lapply(split(r,r$pid),function(z)cbind(pid=z$pid[1],measure(z)));values<-do.call(rbind,values);j<-match(old$pid,values$pid)
 for(v in c('n','x','sd','gender','oldest','son')){before<-old[[paste0(v,k)]];after<-values[[v]][j];new[[paste0(v,k)]]<-after;impacts[[length(impacts)+1L]]<-data.frame(year=y,variable=v,old_nonmissing=sum(!is.na(before)),new_nonmissing=sum(!is.na(after)),both_changed=sum(!is.na(before)&!is.na(after)&abs(before-after)>1e-10),missing_mask_changed=sum(is.na(before)!=is.na(after)))}
 summ[[length(summ)+1L]]<-data.frame(year=y,parents=length(unique(r$pid)),children=nrow(r),contact_valid=sum(!is.na(r$meet)),coresidence_proxy=sum(r$contact_source=='coresidence_proxy'),additional_household=sum(r$kind=='additional_household_child'),mapped_household_duplicates_removed=dup,missing_sex=sum(is.na(r$sex)),missing_birth=sum(is.na(r$birth)))
 write.csv(r,file.path(ROOT,'private',paste0('REBUILT_ROSTER_',y,'.csv')),row.names=FALSE,na='')
}
changed<-unlist(lapply(2:5,function(k)paste0(c('n','x','sd','gender','oldest','son'),k)))
stopifnot(identical(old[setdiff(names(old),changed)],new[setdiff(names(old),changed)]),nrow(new)==3006,digest(file=origin,algo='sha256')==original_hash)
saveRDS(new,target);saveRDS(rosters,file.path(ROOT,'private/REBUILT_ROSTERS.rds'))
src<-unique(do.call(rbind,manifest));src$unchanged<-vapply(src$file,function(p)digest(file=p,algo='sha256'),'')==src$sha256;stopifnot(all(src$unchanged))
write.csv(src,file.path(ROOT,'audit/REBUILD_SOURCE_HASHES.csv'),row.names=FALSE)
write.csv(do.call(rbind,summ),file.path(ROOT,'results/REBUILT_ROSTER_COUNTS.csv'),row.names=FALSE)
write.csv(do.call(rbind,impacts),file.path(ROOT,'results/REBUILT_COHORT_IMPACT.csv'),row.names=FALSE)
write_json(list(status='ROSTER_CANDIDATE_REBUILT_PENDING_INDEPENDENT_REVIEW',people=nrow(new),baseline_and_Y_unchanged=TRUE,source_unchanged=TRUE,new_mplus_calls=0,new_MI=0,original_hash=original_hash,candidate_hash=digest(file=target,algo='sha256'),exclusion_policy='Primary child list uses explicitly living/eligible official same-wave roster; beyond-roster frequency cells remain in original files and diagnostic quarantine, not silently promoted to children.',scope='Fixed original cohort; same-wave current attributes and declared coresidence proxy; candidate only, no model input produced.'),file.path(ROOT,'audit/ROSTER_REBUILD_RECEIPT.json'),auto_unbox=TRUE,pretty=TRUE)
print(do.call(rbind,summ));print(do.call(rbind,impacts));cat('已生成隔离名单候选，等待独立核验。\n')
