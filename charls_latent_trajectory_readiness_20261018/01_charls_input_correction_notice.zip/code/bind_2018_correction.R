# 把已独立确认的2018修正绑定全部40份收入DAT；不更改DAT，不重新拟合。
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_latent_trajectory_readiness_20261018'
library(jsonlite);library(digest)
q<-read.csv('<LOCAL_USER>/pp_lgcm_review/charls_mean_income_20261017/audit/MI_MEMBERS.csv')
v<-readRDS(file.path(ROOT,'private/2018_X4_CORRECTION.rds'));checks<-list()
for(i in seq_len(nrow(q))){
 x<-read.table(q$path[i]);stopifnot(nrow(x)==3006,ncol(x)==23,digest(file=q$path[i],algo='sha256')==q$sha256[i])
 actual<-sprintf('<LOCAL_USER>/pp_lgcm_review/charls_mean_income_20261017/models/CHARLS_INCOME_INCOME_MI%02d_A/data.dat',q$member[i])
 stopifnot(file.exists(actual),digest(file=actual,algo='sha256')==q$sha256[i])
 z<-x$V5;z[z==-9999]<-NA_real_
 stopifnot(identical(is.na(z),is.na(v$old_x4)),max(abs(z-v$old_x4),na.rm=TRUE)<1e-10)
 checks[[i]]<-data.frame(member=q$member[i],input_sha256=q$sha256[i],actual_model_data_sha256=digest(file=actual,algo='sha256'),old_x4_verified=TRUE,changed_nonmissing=sum(abs(v$old_x4-v$corrected_x4)>1e-10,na.rm=TRUE),restored_X4=sum(is.na(v$old_x4)&!is.na(v$corrected_x4)))
}
write.csv(do.call(rbind,checks),file.path(ROOT,'audit/2018_ALL40_MODEL_BINDINGS.csv'),row.names=FALSE)
write_json(list(status='ALL40_ORIGINAL_INPUTS_CONFIRMED_AFFECTED',members=40,source_untouched=TRUE,reestimation=0,disposition='Historical inference remains traceable to old inputs; corrected-input scientific adoption pending roster/MI repair'),file.path(ROOT,'audit/2018_MODEL_DEPENDENCY_RECEIPT.json'),pretty=TRUE,auto_unbox=TRUE)
cat('ALL40_INPUT_BINDINGS_PASS_NO_DATA_MODIFIED\n')
