# 仅保存已独立核实的2018修正候选；其他来源问题未关闭，禁止自动接Mplus。
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_latent_trajectory_readiness_20261018'
library(jsonlite);library(digest)
src<-'<LOCAL_USER>/pp_lgcm_review/reopen_observed_charls_20261015/private/charls_cohort.rds'
stopifnot(!file.exists(file.path(ROOT,'private/charls_cohort_2018fix_candidate.rds')))
before<-digest(file=src,algo='sha256');old<-readRDS(src);d<-old
q<-readRDS(file.path(ROOT,'private/FOLLOWUP_2018.rds'));v<-q$candidates
# 与独立pandas生成的逐人均值相互核对。
p<-read.csv(file.path(ROOT,'private/2018_X4_CORRECTION_REFERENCE.csv'),colClasses=c(pid='character'))
stopifnot(identical(as.character(old$pid),p$pid),nrow(v)==nrow(old),identical(is.na(v$x),is.na(p$new_x4)),max(abs(v$x-p$new_x4),na.rm=TRUE)<1e-12)
changes<-list()
for(n in c('x','sd','gender','oldest','son')){
 col<-paste0(n,4);d[[col]]<-v[[n]]
 changes[[n]]<-data.frame(field=col,changed_nonmissing=sum(abs(old[[col]]-d[[col]])>1e-10,na.rm=TRUE),missing_mask_changes=sum(is.na(old[[col]])!=is.na(d[[col]])))
}
cols<-paste0(c('x','sd','gender','oldest','son'),4)
stopifnot(identical(d[setdiff(names(d),cols)],old[setdiff(names(old),cols)]))
# n4仍为历史计数，避免把局部候选称为完整新队列；正式重建须一并更新全名册。
saveRDS(d,file.path(ROOT,'private/charls_cohort_2018fix_candidate.rds'))
stopifnot(digest(file=src,algo='sha256')==before)
write.csv(do.call(rbind,changes),file.path(ROOT,'results/CANDIDATE_CHANGE_MANIFEST.csv'),row.names=FALSE)
write_json(list(status='ISOLATED_PARTIAL_CANDIDATE_NOT_FOR_ESTIMATION',source_sha256=before,candidate_sha256=digest(file=file.path(ROOT,'private/charls_cohort_2018fix_candidate.rds'),algo='sha256'),changed_columns=cols,other_fields_unchanged=TRUE,original_files_unchanged=TRUE,blocked_consumers=c('new MI','new Mplus','manuscript adoption'),remaining='Resolve 2013 and 2015 crosswalks and late-wave roster support; then rebuild consistent counts, auxiliaries and MI inputs once'),file.path(ROOT,'audit/CANDIDATE_RECEIPT.json'),auto_unbox=TRUE,pretty=TRUE)
cat('ISOLATED_2018_CORRECTION_SAVED_NOT_MODEL_READY\n')
