# 逐期回查原始子女来源，保存聚合差异与本地逐条参照，不修改现有分析数据。
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_latent_trajectory_readiness_20261018'
RAW<-'<LOCAL_USER>/Desktop/20230505 毕业论文/开题报告/开题报告/CHARLS'
BASE<-'<LOCAL_USER>/Desktop/开题报告/0_data_clo'
library(haven);library(jsonlite);library(digest)
stopifnot(!file.exists(file.path(ROOT,'audit/FOLLOWUP_ROSTER_TERMINAL.json')))
co<-readRDS('<LOCAL_USER>/pp_lgcm_review/reopen_observed_charls_20261015/private/charls_cohort.rds')
src<-list();summ<-list();detail<-list();wave_input<-list()
csv<-function(x,p)write.csv(x,file.path(ROOT,p),row.names=FALSE,na='')
wj<-function(x,p)write_json(x,file.path(ROOT,p),auto_unbox=TRUE,pretty=TRUE,na='null',null='null',digits=16)
progress<-function(s,m){cat(s,m,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(s,m)}
readsrc<-function(p,cols=NULL){h<-digest(file=p,algo='sha256');src[[length(src)+1L]]<<-data.frame(file=p,sha256=h);if(is.null(cols))read_dta(p)else read_dta(p,col_select=any_of(cols))}
numeric_clean<-function(x,valid=NULL,lo=NULL,hi=NULL){x<-as.numeric(x);if(!is.null(valid))x[!x%in%valid]<-NA_real_;if(!is.null(lo))x[x<lo|x>hi]<-NA_real_;x}
cell<-function(d,idx,cols){v<-rep(NA_real_,length(idx));for(n in unique(cols)){j<-which(cols==n);if(n%in%names(d))v[j]<-as.numeric(d[[n]])[idx[j]]};v}
diffcount<-function(a,b)sum(is.na(a)!=is.na(b)|(!is.na(a)&!is.na(b)&abs(a-b)>1e-10))
measure<-function(z){v<-z$meet;gap<-function(g){if(anyNA(g)||!any(g)||all(g))return(NA_real_);mean(v[g])-mean(v[!g])};rg<-function(son=FALSE){b<-z$birth;if(anyNA(b)||(son&&anyNA(z$sex)))return(NA_real_);g<-if(son)z$sex==1 else rep(TRUE,length(b));if(!any(g))return(NA_real_);q<-g&b==min(b[g]);if(sum(q)!=1)return(NA_real_);gap(q)}
 data.frame(x=if(length(v)>=2)mean(v)else NA_real_,sd=if(length(v)>=2)sd(v)else NA_real_,gender=gap(z$sex==1),oldest=rg(),son=rg(TRUE))}
for(y in c(2013,2015,2018,2020)){
 progress('raw_followup_crosswalk',as.character(y));k<-match(y,c(2011,2013,2015,2018,2020))
 lp<-file.path(BASE,paste0('contact_',y,'_long.dta'))
 l<-readsrc(lp,c('pid','fid','ID_c2gc','cb049_','cb051_1_','cb053_','cd003_','cd003_w4_'));l<-l[as.character(l$pid)%in%co$pid,]
 stopifnot(!anyDuplicated(paste(l$pid,l$ID_c2gc)))
 legacy<-data.frame(pid=as.character(l$pid),fid=as.character(l$fid),slot=as.integer(l$ID_c2gc),sex=numeric_clean(l$cb049_,1:2),birth=numeric_clean(l$cb051_1_,lo=1800,hi=y),code=as.numeric(l$cd003_))
 legacy$meet<-ifelse(legacy$code%in%1:9,10-legacy$code,NA_real_)
 cores<-if(y<2020)l$cb053_%in%1:2 else l$cd003_w4_%in%12
 legacy$meet[is.na(legacy$meet)&cores]<-9
 base<-file.path(RAW,paste0('CHARLS',y),'Data');fp<-list.files(base,pattern='^Family_Information.dta$',ignore.case=TRUE,full.names=TRUE)
 f<-readsrc(fp);official<-NULL;unmatched<-0L;alive_removed<-0L
 if(y%in%c(2013,2015)){
  c<-readsrc(file.path(RAW,'charls11_20_harmonized',paste0('data_',y),'child.dta'));c<-c[as.character(c$ID)%in%co$pid,]
  hh<-!is.na(c$HHmemberID);cs<-as.integer(c$childID);hs<-as.integer(c$HHmemberID);ii<-match(c$ID,f$ID)
  official<-data.frame(pid=as.character(c$ID),fid=as.character(c$householdID),slot=ifelse(hh,as.integer(paste0('11',hs)),cs),child_slot=cs,household_slot=hs,alive=as.numeric(c$alive),sex=numeric_clean(c$gender,1:2),birth=if(y==2013)numeric_clean(c$cb051_1,lo=1800,hi=y)else numeric_clean(c$byear,lo=1800,hi=y),residence=as.numeric(c$cb053),code=cell(f,ii,paste0('cd003_',cs,'_')))
  # 同期年龄派生出生年须单独标记，不能静默冒充直接回答。
  official$birth_from_age<-is.na(official$birth)&!is.na(c$age)&c$age>=0&c$age<=130
  official$birth_age_candidate<-ifelse(official$birth_from_age,y-as.numeric(c$age),official$birth)
  official$meet<-ifelse(official$code%in%1:9,10-official$code,NA_real_)
  official$meet[hh|is.na(official$meet)&official$residence%in%1:2]<-9
  stopifnot(!anyDuplicated(paste(official$pid,official$slot)))
  j<-match(paste(legacy$pid,legacy$slot),paste(official$pid,official$slot));unmatched<-sum(is.na(j))
  current<-official[j,];current$pid<-legacy$pid;current$slot<-legacy$slot
  alive_removed<-sum(!is.na(j)&!is.na(current$alive)&current$alive!=1)
 }else{
  ii<-match(if(y==2020)legacy$fid else legacy$pid,if(y==2020)as.character(f$householdID) else as.character(f$ID))
  stopifnot(!anyDuplicated(if(y==2020)f$householdID else f$ID));unmatched<-sum(is.na(ii));slot<-legacy$slot;hh<-slot>=111
  hs<-as.integer(sub('^11','',as.character(slot)))
  current<-data.frame(pid=legacy$pid,slot=slot)
  current$sex<-cell(f,ii,ifelse(hh,paste0(if(y==2020)'cb003_'else'a005_w3_',hs,'_'),paste0('xchildgender_',slot,'_')))
  current$birth<-cell(f,ii,ifelse(hh,paste0(if(y==2020)'cb004_'else'a005_w4_',hs,'_'),paste0('xchildbirth_',slot,'_')))
  current$birth[hh]<-y-current$birth[hh]
  current$sex<-numeric_clean(current$sex,1:2);current$birth<-numeric_clean(current$birth,lo=1800,hi=y)
  if(y==2018){
   tp<-list.files(base,pattern='^Family_Transfer.dta$',ignore.case=TRUE,full.names=TRUE);t<-readsrc(tp);ti<-match(legacy$pid,as.character(t$ID));stopifnot(!anyDuplicated(t$ID))
   current$code<-cell(t,ti,paste0('cd003_',slot,'_'));current$months<-cell(t,ti,paste0('cd003_w4_',slot,'_'));current$residence<-cell(f,ii,paste0('cb053_',slot,'_'))
  }else{
   current$code<-cell(f,ii,paste0('ca015_',slot,'_'));current$months<-cell(f,ii,paste0('ca014_',slot,'_'));current$residence<-NA_real_
  }
  current$meet<-ifelse(current$code%in%1:9,10-current$code,NA_real_)
  current$meet[hh|is.na(current$meet)&(current$months%in%12|current$residence%in%1:2)]<-9
  current$index_semantics<-if(y==2020)'same suffix match only; all-child vs pandemic-alive index requires questionnaire verification'else 'same-wave suffix; household-child duplicate crosswalk not yet verified'
 }
 for(v in c('sex','birth','meet'))summ[[length(summ)+1L]]<-data.frame(year=y,field=v,legacy_rows=nrow(legacy),unmatched_keys=unmatched,nonmissing_pair=sum(complete.cases(legacy[[v]],current[[v]])),value_disagreement=sum(!is.na(legacy[[v]])&!is.na(current[[v]])&abs(legacy[[v]]-current[[v]])>1e-10),old_observed_raw_missing=sum(!is.na(legacy[[v]])&is.na(current[[v]])),raw_observed_old_missing=sum(is.na(legacy[[v]])&!is.na(current[[v]])),all_disagreement=diffcount(legacy[[v]],current[[v]]))
 # 只比较同一旧子女集合的原始字段替换，不能声称已建立全部名册的新队列。
 cands<-lapply(split(current,current$pid),function(a)cbind(pid=a$pid[1],measure(a[!is.na(a$meet),])))
 cands<-do.call(rbind,cands);cands<-cands[match(co$pid,cands$pid),]
 for(v in c('x','sd','gender','oldest','son')){
  old<-co[[paste0(v,k)]];new<-cands[[v]]
  detail[[length(detail)+1L]]<-data.frame(year=y,indicator=v,old_observed=sum(!is.na(old)),raw_candidate_observed=sum(!is.na(new)),both=sum(complete.cases(old,new)),numeric_difference=sum(!is.na(old)&!is.na(new)&abs(old-new)>1e-10),missing_mask_difference=sum(is.na(old)!=is.na(new)),maximum_abs_difference=if(any(complete.cases(old,new)))max(abs(old-new),na.rm=TRUE)else NA_real_)
 }
 saveRDS(list(legacy=legacy,current=current,official=official,candidates=cands),file.path(ROOT,'private',paste0('FOLLOWUP_',y,'.rds')))
 wave_input[[as.character(y)]]<-data.frame(year=y,N_legacy_parents=length(unique(legacy$pid)),N_legacy_children=nrow(legacy),unmatched=unmatched,legacy_nonliving_official=alive_removed)
}
manifest<-unique(do.call(rbind,src));manifest$unchanged<-vapply(manifest$file,function(p)digest(file=p,algo='sha256'),'')==manifest$sha256;stopifnot(all(manifest$unchanged))
csv(manifest,'audit/FOLLOWUP_SOURCE_HASHES.csv');csv(do.call(rbind,summ),'results/RAW_LEGACY_FIELD_COMPARISON.csv');csv(do.call(rbind,detail),'results/RAW_CANDIDATE_AGGREGATE_DIFFERENCES.csv');csv(do.call(rbind,wave_input),'results/FOLLOWUP_KEY_COUNTS.csv')
wj(list(status='FOLLOWUP_SOURCE_DIAGNOSTIC_COMPLETE_NOT_MODEL_READY',original_files_unchanged=TRUE,models_called=0,limitations=c('2018 household-child crosswalk needs explicit identity','2020 all-child vs pandemic-alive contact indexing needs questionnaire evidence','2015 inherited sex/birth in legacy differs from same-wave source; provenance not presumed erroneous')), 'audit/FOLLOWUP_ROSTER_TERMINAL.json')
print(do.call(rbind,summ));progress('FOLLOWUP_SOURCE_DIAGNOSTIC_DONE','raw source comparisons saved; no model call or analysis data overwritten')
