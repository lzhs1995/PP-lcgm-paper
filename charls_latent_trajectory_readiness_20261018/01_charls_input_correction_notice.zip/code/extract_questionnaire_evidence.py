"""本地问卷定位证据；仅保存有关程序的短片段，不发送个人资料。"""
from pathlib import Path
import hashlib,json
import fitz
R=Path(__file__).resolve().parents[1];raw=Path('<LOCAL_USER>/Desktop/20230505 毕业论文/开题报告/开题报告/CHARLS')
files={2018:raw/'CHARLS2018/Document/CHARLS_2018_Household_Questionnaire.pdf',2020:raw/'CHARLS2020/Document/CHARLS_2020_Questionnaire_Chinese.pdf'}
records=[]
for year,path in files.items():
 with fitz.open(path) as doc:
  for i,page in enumerate(doc):
   txt=page.get_text()
   terms=['CD003_W4','CD003', 'XChildPanAliveName','CA014'] if year==2018 else ['XChildPanAliveName','CA014','XChildBirth']
   for term in terms:
    start=txt.find(term)
    if start>=0:
     records.append(dict(year=year,pdf=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),page_index=i,term=term,context=txt[max(0,start-350):min(len(txt),start+1800)]))
 (R/'private'/f'QUESTIONNAIRE_{year}_TEXT.txt').write_text('\n'.join(p.get_text() for p in fitz.open(path)),encoding='utf-8')
(R/'audit/QUESTIONNAIRE_LOCATIONS.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps([{'year':r['year'],'page_index':r['page_index'],'term':r['term']} for r in records],ensure_ascii=False))
