# 原潜在家内差异轨迹路线的输入准备；复用3006人队列，不估计模型、不改源数据。
ROOT<-'<LOCAL_USER>/pp_lgcm_review/charls_latent_trajectory_readiness_20261018'
RAW<-'<LOCAL_USER>/Desktop/20230505 毕业论文/开题报告/开题报告/CHARLS'
OLD<-'<LOCAL_USER>/pp_lgcm_review/reopen_observed_charls_20261015'
library(haven);library(jsonlite);library(digest)
for(n in c('audit','contracts','results','private','reports'))dir.create(file.path(ROOT,n),showWarnings=FALSE)
stopifnot(!file.exists(file.path(ROOT,'audit/SOURCE_INVENTORY_TERMINAL.json')))
csv<-function(x,p)write.csv(x,file.path(ROOT,p),row.names=FALSE,na='')
wj<-function(x,p)write_json(x,file.path(ROOT,p),pretty=TRUE,auto_unbox=TRUE,digits=16,na='null',null='null')
progress<-function(s,m){cat(s,m,'\n');flush.console();if(exists('clauder_progress',mode='function'))clauder_progress(s,m)}
wj(list(task='Original latent family-difference trajectory readiness',new_mplus_limit=0,new_MI_limit=0,original_cohort_preserved=TRUE,not_replication_claim='Legacy five-wave contrasts are candidate inputs only until raw crosswalk and structural missingness are verified',scope=c('SD','son-minus-daughter','oldest-minus-others','oldest-son-minus-others'),existing_families='No completed observed-Z or H4 model will be rerun'), 'contracts/READINESS_SCOPE.json')
cp<-file.path(OLD,'private/charls_cohort.rds');ch<-digest(file=cp,algo='sha256');d<-readRDS(cp);stopifnot(nrow(d)==3006,!anyDuplicated(d$pid))
sources<-list(data.frame(file=cp,sha256=ch,bytes=file.info(cp)$size));dictionary<-list();coverage<-list();pairing<-list();hist<-list()
years<-c(2011,2013,2015,2018,2020)
for(k in seq_along(years)){
 y<-years[k];progress('wave_source_inventory',as.character(y))
 paths<-c(file.path(RAW,'charls11_20_harmonized',paste0('data_',y),'child.dta'),list.files(file.path(RAW,paste0('CHARLS',y),'Data'),pattern='^(family_information|household_roster)\\.dta$',ignore.case=TRUE,full.names=TRUE))
 for(p in paths){
  if(!file.exists(p)){sources[[length(sources)+1L]]<-data.frame(file=p,sha256=NA_character_,bytes=NA_real_);next}
  sources[[length(sources)+1L]]<-data.frame(file=p,sha256=digest(file=p,algo='sha256'),bytes=file.info(p)$size)
  h<-read_dta(p,n_max=0)
  for(n in names(h))dictionary[[length(dictionary)+1L]]<-data.frame(year=y,file=p,variable=n,label=if(is.null(attr(h[[n]],'label')))'' else attr(h[[n]],'label'),codes=toJSON(as.list(attr(h[[n]],'labels')),auto_unbox=TRUE))
 }
 for(v in c('sd','gender','oldest','son')){
  z<-d[[paste0(v,k)]];x<-d[[paste0('x',k)]];yy<-d[[paste0('y',k)]]
  coverage[[length(coverage)+1L]]<-data.frame(indicator=v,year=y,cohort=nrow(d),observed=sum(!is.na(z)),zero=sum(z==0,na.rm=TRUE),mean=mean(z,na.rm=TRUE),sd=sd(z,na.rm=TRUE),minimum=min(z,na.rm=TRUE),maximum=max(z,na.rm=TRUE),both_XZ=sum(complete.cases(x,z)),both_YZ=sum(complete.cases(yy,z)),cor_XZ=cor(x,z,use='complete.obs'))
 }
}
for(v in c('sd','gender','oldest','son')){
 z<-as.matrix(d[paste0(v,1:5)]);nn<-rowSums(!is.na(z));tt<-table(factor(nn,levels=0:5))
 hist[[v]]<-data.frame(indicator=v,observed_waves=0:5,N=as.integer(tt))
 for(a in 1:4)for(b in (a+1):5){ok<-complete.cases(z[,a],z[,b]);dif<-z[ok,b]-z[ok,a]
  pairing[[length(pairing)+1L]]<-data.frame(indicator=v,year_a=years[a],year_b=years[b],N=sum(ok),unchanged=sum(abs(dif)<1e-10),change_mean=mean(dif),change_sd=sd(dif),correlation=cor(z[ok,a],z[ok,b]))
 }
}
csv(do.call(rbind,sources),'audit/SOURCE_FILES.csv');csv(do.call(rbind,dictionary),'audit/WAVE_DICTIONARY.csv')
csv(do.call(rbind,coverage),'results/CANDIDATE_COVERAGE.csv');csv(do.call(rbind,hist),'results/CANDIDATE_OBSERVATION_COUNTS.csv');csv(do.call(rbind,pairing),'results/CANDIDATE_PAIRWISE_CHANGE.csv')
stopifnot(identical(ch,digest(file=cp,algo='sha256')))
wj(list(status='SOURCE_INVENTORY_COMPLETE_NOT_MODEL_READY',cohort=3006,source_count=length(sources),dictionary_rows=length(dictionary),new_Mplus=0,new_MI=0,next_action='Verify nonbaseline child identity, raw fields, all-listed contrast definitions and structural missingness before any latent trajectory estimate'), 'audit/SOURCE_INVENTORY_TERMINAL.json')
cat('SOURCE_INVENTORY_COMPLETE_NOT_MODEL_READY\n');print(do.call(rbind,hist));progress('SOURCE_INVENTORY_DONE','source metadata and legacy candidate coverage saved; no model launched')
