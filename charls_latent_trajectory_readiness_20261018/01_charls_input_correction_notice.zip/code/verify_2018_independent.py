"""独立读取原始Stata，核验2018全年同住漏分及既有模型实际输入；不估计。"""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1]
RAW=Path('<LOCAL_USER>/Desktop/20230505 毕业论文/开题报告/开题报告/CHARLS')
BASE=Path('<LOCAL_USER>/Desktop/开题报告/0_data_clo')
ROSTER=R.parent/'charls_roster_moderation_20261015'
OLD=R.parent/'reopen_observed_charls_20261015'
INCOME=R.parent/'charls_mean_income_20261017'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=[RAW/'CHARLS2018/Data/Family_Transfer.dta',RAW/'CHARLS2018/Data/Family_Information.dta',BASE/'contact_2018_long.dta',ROSTER/'private/COHORT_REFERENCE.csv',OLD/'results/CHARLS_BASELINE_SCALING.csv',INCOME/'private/mi/MI01.dat']
# DAT的真实地址由已验收成员表读取，不假定命名。
members=pd.read_csv(INCOME/'audit/MI_MEMBERS.csv')
print('MEMBER_COLUMNS',list(members),flush=True)
refs=pd.read_csv(ROSTER/'private/COHORT_REFERENCE.csv',dtype={'pid':str})
t=pd.read_stata(paths[0],convert_categoricals=False).set_index('ID');f=pd.read_stata(paths[1],convert_categoricals=False).set_index('ID')
l=pd.read_stata(paths[2],convert_categoricals=False,columns=['pid','fid','ID_c2gc','cd003_','cd003_w4_','cb053_','cb049_','cb051_1_'])
l=l[l.pid.astype(str).isin(refs.pid)].copy();l['pid']=l.pid.astype(str)
assert not l.duplicated(['pid','ID_c2gc']).any() and t.index.is_unique and f.index.is_unique
for c in ['cd003_','cd003_w4_','cb053_','cb049_','cb051_1_']:l[c]=l[c].astype('float64')
old=np.where(l.cd003_.isin(range(1,10)),10-l.cd003_,np.nan)
old=np.where(np.isnan(old)&l.cb053_.isin([1,2]),9,old)
new=old.copy();months=[];raw_code=[]
for row in l.itertuples():
 i=int(row.ID_c2gc);pid=row.pid
 months.append(t.loc[pid].get(f'cd003_w4_{i}_',np.nan) if pid in t.index else np.nan)
 raw_code.append(t.loc[pid].get(f'cd003_{i}_',np.nan) if pid in t.index else np.nan)
months=np.asarray(months,dtype='float64');raw_code=np.asarray(raw_code,dtype='float64')
restore=np.isnan(old)&(months==12)
assert np.all(np.isnan(raw_code[restore])) and np.all(l.cd003_w4_.to_numpy()[restore]==12)
new[restore]=9
l['old_meet']=old;l['new_meet']=new
def contrasts(z,col):
 z=z[z[col].notna()];v=z[col].to_numpy(dtype='float64');sex=z.cb049_.to_numpy();birth=z.cb051_1_.to_numpy()
 sex=np.where(np.isin(sex,[1,2]),sex,np.nan);birth=np.where((birth>=1800)&(birth<=2018),birth,np.nan)
 def gap(g):
  return float(v[g].mean()-v[~g].mean()) if g.any() and not g.all() else np.nan
 def rank(son=False):
  if np.isnan(birth).any() or (son and np.isnan(sex).any()) or not len(v):return np.nan
  e=sex==1 if son else np.ones(len(v),dtype=bool)
  if not e.any():return np.nan
  g=e&(birth==birth[e].min())
  return gap(g) if g.sum()==1 else np.nan
 return dict(x=float(v.mean()) if len(v)>=2 else np.nan,sd=float(v.std(ddof=1)) if len(v)>=2 else np.nan,gender=gap(sex==1) if not np.isnan(sex).any() else np.nan,oldest=rank(),son=rank(True))
a=pd.DataFrame({pid:contrasts(z,'old_meet') for pid,z in l.groupby('pid')}).T.reindex(refs.pid)
b=pd.DataFrame({pid:contrasts(z,'new_meet') for pid,z in l.groupby('pid')}).T.reindex(refs.pid)
check=pd.read_csv(R/'results/RAW_CANDIDATE_AGGREGATE_DIFFERENCES.csv');check=check[check.year.eq(2018)].set_index('indicator')
rows=[]
for c in a:
 both=a[c].notna()&b[c].notna();nd=int(((a[c]-b[c]).abs()>1e-10).sum());nm=int((a[c].isna()!=b[c].isna()).sum())
 assert nd==int(check.loc[c,'numeric_difference']) and nm==int(check.loc[c,'missing_mask_difference'])
 rows.append(dict(indicator=c,numeric_difference=nd,missing_mask_difference=nm,old_observed=int(a[c].notna().sum()),new_observed=int(b[c].notna().sum()),max_abs_difference=float((a[c]-b[c]).abs().max())))
assert int(restore.sum())==235 and l.loc[restore,'pid'].nunique()==206
# 只在隔离private保存逐人变化；公开报告只读取上面的聚合计数。
pd.DataFrame({'pid':refs.pid.to_numpy(),'old_x4':a.x.to_numpy(),'new_x4':b.x.to_numpy()}).to_csv(R/'private/2018_X4_CORRECTION_REFERENCE.csv',index=False)
pd.DataFrame(rows).to_csv(R/'results/2018_INDEPENDENT_AGGREGATE_IMPACT.csv',index=False)
sources={str(p):sha(p) for p in paths[:5]}
receipt=dict(status='PASS',independent_reader='pandas raw Stata',restore_child_rows=int(restore.sum()),affected_parents=int(l.loc[restore,'pid'].nunique()),questionnaire_basis='2018 CD003_W4=12 skips CD003; raw transfer answers verified',person_identifiers_public=False,source_hashes=sources,new_mplus_calls=0,old_and_new_personal_values='private/2018_X4_CORRECTION_REFERENCE.csv',aggregate_impacts=rows)
(R/'audit/2018_INDEPENDENT_VERIFICATION.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in receipt.items() if k not in ('source_hashes','aggregate_impacts')},ensure_ascii=False),flush=True)
